//
// Licensed Materials - Property of IBM
// 5725-C15
// � Copyright IBM Corp. 1994, 2012 All Rights Reserved
// 
// US Government Users Restricted Rights - Use, duplication or
// disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Xml;
using System.Windows.Forms;
using dcDTlib;

namespace MedicalClaimsPanels
{
    public partial class PClaim : dotPanelBase
    {
        public PClaim()
        {
            InitializeComponent();
        }

        private void btnSwapNamesFld2_Click(object sender, EventArgs e)
        {    //Swap First and Last names - box 2
            string sTemp = dced2PaLName.CtlText;
            dced2PaLName.CtlText = dced2PaFName.CtlText;
            dced2PaFName.CtlText = sTemp;
            return;
        }

        private void btnSwapNames4_Click(object sender, EventArgs e)
        {   //Swap First and Last names - box 4
            string sTemp = dced4InsLNam.CtlText;
            dced4InsLNam.CtlText = dced4InsFNam.CtlText;
            dced4InsFNam.CtlText = sTemp;
            return;
        }

        private void btnCopyNm2to4_Click(object sender, EventArgs e)
        {   //Copy Name from box 2 to box 4
            dced4InsFNam.CtlText = dced2PaFName.CtlText;
            dced4InsLNam.CtlText = dced2PaLName.CtlText;
            dced4InsMIni.CtlText = dced2PaMInit.CtlText;
            return;
        }

        private void btnCopyNm4to2_Click(object sender, EventArgs e)
        {  //Copy Name from box 4 to box 2
           dced2PaFName.CtlText=dced4InsFNam.CtlText;
           dced2PaLName.CtlText=dced4InsLNam.CtlText;
           dced2PaMInit.CtlText=dced4InsMIni.CtlText;
           return;
        }
        
 

        private void btnCopyAdd2to4_Click(object sender, EventArgs e)
        {
             //Copy Field 5 Address to Field 7 Address
            dced7IAddStr.CtlText = dced5PAddStr.CtlText;
	        dced7IAddCty.CtlText = dced5PAddCty.CtlText;
	        dced7IAddSta.CtlText = dced5PAddSta.CtlText;
	        dced7IAddZip.CtlText = dced5PAddZip.CtlText;
            dced7IAddTel.CtlText = dced5PAddTel.CtlText;
            return;
        }

        private void btnCopyAdd4to2_Click(object sender, EventArgs e)
        {
            //Copy Field 7 Address to Field 5 Address
            dced5PAddStr.CtlText = dced7IAddStr.CtlText;
            dced5PAddCty.CtlText = dced7IAddCty.CtlText;
            dced5PAddSta.CtlText = dced7IAddSta.CtlText;
            dced5PAddZip.CtlText = dced7IAddZip.CtlText;
            dced5PAddTel.CtlText = dced7IAddTel.CtlText;
            return;
        }

        private void btnSwapNm31_Click(object sender, EventArgs e)
        {   //Swap First and Last names - box 31
            string sTemp = dced31aPhLNm.CtlText;
	        dced31aPhLNm.CtlText = dced31aPhFNm.CtlText;
            dced31aPhFNm.CtlText = sTemp;
            return;
        }

        private void button6_Click(object sender, EventArgs e)
        {   
            //Copy box 32 Name & Address to box 33 Name & Address
            dced33PhBNam.CtlText = dced32FacNam.CtlText;
	        dced33Ph1Add.CtlText = dced32F1Addr.CtlText;
	        dced33Ph2Add.CtlText = dced32F2Addr.CtlText;
	        dced33PhCity.CtlText = dced32FacCit.CtlText;
	        dced33PhStat.CtlText = dced32FacSta.CtlText;
            dced33PhyZip.CtlText = dced32FacZip.CtlText;
            return;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            //Copy box 33 Name & Address to box 32 Name & Address
	        dced32FacNam.CtlText = dced33PhBNam.CtlText;
	        dced32F1Addr.CtlText = dced33Ph1Add.CtlText;
	        dced32F2Addr.CtlText = dced33Ph2Add.CtlText;
	        dced32FacCit.CtlText = dced33PhCity.CtlText;
	        dced32FacSta.CtlText = dced33PhStat.CtlText;
            dced32FacZip.CtlText = dced33PhyZip.CtlText;
            return;
        }

      
   

                
    }
}
