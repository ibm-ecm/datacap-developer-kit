
namespace MedicalClaimsPanels
{
    partial class PClaim_8
    {
        /// 
        /// Required designer variable.
        /// 
        private System.ComponentModel.IContainer components = null;

        /// 
        /// Clean up any resources being used.
        /// 
        /// true if managed resources should be disposed; otherwise, false.
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// 
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PClaim_8));
            this.dced5PAddStr = new AxDCEDITLib.AxDcedit();
            this.dced5PAddCty = new AxDCEDITLib.AxDcedit();
            this.dcim5PAddSta = new AxDCIMAGELib.AxDcimage();
            this.dced5PAddSta = new AxDCEDITLib.AxDcedit();
            this.dcim5PAddZip = new AxDCIMAGELib.AxDcimage();
            this.dced5PAddZip = new AxDCEDITLib.AxDcedit();
            this.lbl3Pat_DOB = new System.Windows.Forms.Label();
            this.dcim3Pat_DOB = new AxDCIMAGELib.AxDcimage();
            this.dced3Pat_DOB = new AxDCEDITLib.AxDcedit();
            this.lbl3aPatSex = new System.Windows.Forms.Label();
            this.dcim3aPatSex = new AxDCIMAGELib.AxDcimage();
            this.cmb3aPatSex = new System.Windows.Forms.ComboBox();
            this.lbl1aInsrID = new System.Windows.Forms.Label();
            this.dcim1aInsrID = new AxDCIMAGELib.AxDcimage();
            this.dced1aInsrID = new AxDCEDITLib.AxDcedit();
            this.lbl7IAddStr = new System.Windows.Forms.Label();
            this.dced7IAddStr = new AxDCEDITLib.AxDcedit();
            this.lbl7IAddCty = new System.Windows.Forms.Label();
            this.dced7IAddCty = new AxDCEDITLib.AxDcedit();
            this.dced7IAddSta = new AxDCEDITLib.AxDcedit();
            this.dcim7IAddZip = new AxDCIMAGELib.AxDcimage();
            this.dced7IAddZip = new AxDCEDITLib.AxDcedit();
            this.lbl7IAddTel = new System.Windows.Forms.Label();
            this.dcim33DocAdd = new AxDCIMAGELib.AxDcimage();
            this.dced7IAddTel = new AxDCEDITLib.AxDcedit();
            this.lbl11IPolNo = new System.Windows.Forms.Label();
            this.dcim11IPolNo = new AxDCIMAGELib.AxDcimage();
            this.dced11IPolNo = new AxDCEDITLib.AxDcedit();
            this.lbl11aInSex = new System.Windows.Forms.Label();
            this.dcim11aInSex = new AxDCIMAGELib.AxDcimage();
            this.cmb11aInSex = new System.Windows.Forms.ComboBox();
            this.lbl11aInDOB = new System.Windows.Forms.Label();
            this.dcim11aInDOB = new AxDCIMAGELib.AxDcimage();
            this.dced11aInDOB = new AxDCEDITLib.AxDcedit();
            this.lbl11cIPlan = new System.Windows.Forms.Label();
            this.dcim11cIPlan = new AxDCIMAGELib.AxDcimage();
            this.dced11cIPlan = new AxDCEDITLib.AxDcedit();
            this.lbl11dPlOth = new System.Windows.Forms.Label();
            this.dcim11dPlOth = new AxDCIMAGELib.AxDcimage();
            this.cmb11dPlOth = new System.Windows.Forms.ComboBox();
            this.lbl17aRfDID = new System.Windows.Forms.Label();
            this.dcim17aRfDID = new AxDCIMAGELib.AxDcimage();
            this.dced17aRfDID = new AxDCEDITLib.AxDcedit();
            this.lbl17aRfCd = new System.Windows.Forms.Label();
            this.dced17aRfCd = new AxDCEDITLib.AxDcedit();
            this.dcim17bRfNPI = new AxDCIMAGELib.AxDcimage();
            this.dced17bRfNPI = new AxDCEDITLib.AxDcedit();
            this.lbl25aFedTx = new System.Windows.Forms.Label();
            this.dcim25aFedTx = new AxDCIMAGELib.AxDcimage();
            this.dced25aFedTx = new AxDCEDITLib.AxDcedit();
            this.lbl26PActNo = new System.Windows.Forms.Label();
            this.dcim26PActNo = new AxDCIMAGELib.AxDcimage();
            this.dced26PActNo = new AxDCEDITLib.AxDcedit();
            this.lbl27AccAss = new System.Windows.Forms.Label();
            this.dcim27AccAss = new AxDCIMAGELib.AxDcimage();
            this.cmb27AccAss = new System.Windows.Forms.ComboBox();
            this.lbl28TotChg = new System.Windows.Forms.Label();
            this.dcim28TotChg = new AxDCIMAGELib.AxDcimage();
            this.dced28TotChg = new AxDCEDITLib.AxDcedit();
            this.lbl29Amt_Pd = new System.Windows.Forms.Label();
            this.dcim29Amt_Pd = new AxDCIMAGELib.AxDcimage();
            this.dced29Amt_Pd = new AxDCEDITLib.AxDcedit();
            this.lbl30BalDue = new System.Windows.Forms.Label();
            this.dcim30BalDue = new AxDCIMAGELib.AxDcimage();
            this.dced30BalDue = new AxDCEDITLib.AxDcedit();
            this.dcim32FacAdd = new AxDCIMAGELib.AxDcimage();
            this.dced32FacNPI = new AxDCEDITLib.AxDcedit();
            this.dced32FacID = new AxDCEDITLib.AxDcedit();
            this.lbl24aDtFr1 = new System.Windows.Forms.Label();
            this.dced2PaLName = new AxDCEDITLib.AxDcedit();
            this.dced2PaFName = new AxDCEDITLib.AxDcedit();
            this.dced2PaMInit = new AxDCEDITLib.AxDcedit();
            this.dced4InsLNam = new AxDCEDITLib.AxDcedit();
            this.dced4InsFNam = new AxDCEDITLib.AxDcedit();
            this.dced4InsMIni = new AxDCEDITLib.AxDcedit();
            this.dcim17ReCred = new AxDCIMAGELib.AxDcimage();
            this.dced17ReCred = new AxDCEDITLib.AxDcedit();
            this.dcim17ReSufx = new AxDCIMAGELib.AxDcimage();
            this.dced17ReSufx = new AxDCEDITLib.AxDcedit();
            this.dced31aPhLNm = new AxDCEDITLib.AxDcedit();
            this.dced31aPhFNm = new AxDCEDITLib.AxDcedit();
            this.dced31aPhIni = new AxDCEDITLib.AxDcedit();
            this.dced32FacNam = new AxDCEDITLib.AxDcedit();
            this.dced32F1Addr = new AxDCEDITLib.AxDcedit();
            this.dced32F2Addr = new AxDCEDITLib.AxDcedit();
            this.dced32FacCit = new AxDCEDITLib.AxDcedit();
            this.dced32FacSta = new AxDCEDITLib.AxDcedit();
            this.dced32FacZip = new AxDCEDITLib.AxDcedit();
            this.dced33PhBNam = new AxDCEDITLib.AxDcedit();
            this.dced33Ph1Add = new AxDCEDITLib.AxDcedit();
            this.dced33Ph2Add = new AxDCEDITLib.AxDcedit();
            this.dced33PhCity = new AxDCEDITLib.AxDcedit();
            this.dced33PhStat = new AxDCEDITLib.AxDcedit();
            this.dced33PhyZip = new AxDCEDITLib.AxDcedit();
            this.dced33PhyNPI = new AxDCEDITLib.AxDcedit();
            this.dced33PhyID = new AxDCEDITLib.AxDcedit();
            this.lbReferenceId = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.lbDateFrom = new System.Windows.Forms.Label();
            this.lbPlaceofService = new System.Windows.Forms.Label();
            this.lbTypeofService = new System.Windows.Forms.Label();
            this.lbCPT_Code = new System.Windows.Forms.Label();
            this.lbDiagPointer = new System.Windows.Forms.Label();
            this.lbCharges = new System.Windows.Forms.Label();
            this.lbDays_Units = new System.Windows.Forms.Label();
            this.lbNPI = new System.Windows.Forms.Label();
            this.panLINEITEM = new System.Windows.Forms.Panel();
            this.dcimNDCQty = new AxDCIMAGELib.AxDcimage();
            this.dcedNDCQty = new AxDCEDITLib.AxDcedit();
            this.dcimEPSDTcode = new AxDCIMAGELib.AxDcimage();
            this.dcedEPSDTcode = new AxDCEDITLib.AxDcedit();
            this.dcimEPSD = new AxDCIMAGELib.AxDcimage();
            this.dcedEPSD = new AxDCEDITLib.AxDcedit();
            this.dcimCharges = new AxDCIMAGELib.AxDcimage();
            this.dcimNDCType = new AxDCIMAGELib.AxDcimage();
            this.dcedNDCType = new AxDCEDITLib.AxDcedit();
            this.dcimNDC = new AxDCIMAGELib.AxDcimage();
            this.dcedNDC = new AxDCEDITLib.AxDcedit();
            this.dcimEMG_C = new AxDCIMAGELib.AxDcimage();
            this.dcedEMG_C = new AxDCEDITLib.AxDcedit();
            this.dcimReferenceId = new AxDCIMAGELib.AxDcimage();
            this.dcedReferenceId = new AxDCEDITLib.AxDcedit();
            this.dcimDateFrom = new AxDCIMAGELib.AxDcimage();
            this.dcedDateFrom = new AxDCEDITLib.AxDcedit();
            this.dcimDateThru = new AxDCIMAGELib.AxDcimage();
            this.dcedDateThru = new AxDCEDITLib.AxDcedit();
            this.dcimPlaceofService = new AxDCIMAGELib.AxDcimage();
            this.dcedPlaceofService = new AxDCEDITLib.AxDcedit();
            this.dcimCPT_Code = new AxDCIMAGELib.AxDcimage();
            this.dcedCPT_Code = new AxDCEDITLib.AxDcedit();
            this.dcimModifiers = new AxDCIMAGELib.AxDcimage();
            this.dcedModifiers = new AxDCEDITLib.AxDcedit();
            this.dcimDiagPointer = new AxDCIMAGELib.AxDcimage();
            this.dcedDiagPointer = new AxDCEDITLib.AxDcedit();
            this.dcedCharges = new AxDCEDITLib.AxDcedit();
            this.dcimDays_Units = new AxDCIMAGELib.AxDcimage();
            this.dcedDays_Units = new AxDCEDITLib.AxDcedit();
            this.dcimQualifier = new AxDCIMAGELib.AxDcimage();
            this.dcedQualifier = new AxDCEDITLib.AxDcedit();
            this.dcimNPI = new AxDCIMAGELib.AxDcimage();
            this.dcedNPI = new AxDCEDITLib.AxDcedit();
            this.dcedInfo = new AxDCEDITLib.AxDcedit();
            this.dcimInfo = new AxDCIMAGELib.AxDcimage();
            this.btnDelpbLINEITEM = new System.Windows.Forms.Button();
            this.btnInsAfterpbLINEITEM = new System.Windows.Forms.Button();
            this.btnInsBeforepbLINEITEM = new System.Windows.Forms.Button();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label21_Diag1 = new System.Windows.Forms.Label();
            this.dcim7IAddStr = new AxDCIMAGELib.AxDcimage();
            this.lbl7IAddSta = new System.Windows.Forms.Label();
            this.dced21_Diag1 = new AxDCEDITLib.AxDcedit();
            this.dced21_Diag2 = new AxDCEDITLib.AxDcedit();
            this.dced21_Diag3 = new AxDCEDITLib.AxDcedit();
            this.dced21_Diag4 = new AxDCEDITLib.AxDcedit();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btnSwapNm31 = new System.Windows.Forms.Button();
            this.lblcopynm = new System.Windows.Forms.Label();
            this.lblCopyAddress = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.dced5PAddTel = new AxDCEDITLib.AxDcedit();
            this.lblCopyAll = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.btnCopyAdd2to4 = new System.Windows.Forms.Button();
            this.btnCopyAdd4to2 = new System.Windows.Forms.Button();
            this.btnCopyNm4to2 = new System.Windows.Forms.Button();
            this.btnCopyNm2to4 = new System.Windows.Forms.Button();
            this.btnSwapNames4 = new System.Windows.Forms.Button();
            this.btnSwapNamesFld2 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label12 = new System.Windows.Forms.Label();
            this.dcim1InsType = new AxDCIMAGELib.AxDcimage();
            this.cmb1InsType = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.dcim6PatRela = new AxDCIMAGELib.AxDcimage();
            this.cmb6PatRela = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.dcim11bIEmNm = new AxDCIMAGELib.AxDcimage();
            this.dced11bIEmNm = new AxDCEDITLib.AxDcedit();
            this.label15 = new System.Windows.Forms.Label();
            this.dcim25bSSEIN = new AxDCIMAGELib.AxDcimage();
            this.cmb25bSSEIN = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.dcim14SymDat = new AxDCIMAGELib.AxDcimage();
            this.dced14SymDat = new AxDCEDITLib.AxDcedit();
            this.label51 = new System.Windows.Forms.Label();
            this.dcim15HisDat = new AxDCIMAGELib.AxDcimage();
            this.dced15HisDat = new AxDCEDITLib.AxDcedit();
            this.label52 = new System.Windows.Forms.Label();
            this.dcim17RefDoc = new AxDCIMAGELib.AxDcimage();
            this.dced17ReLNam = new AxDCEDITLib.AxDcedit();
            this.dced17ReFNam = new AxDCEDITLib.AxDcedit();
            this.dcedReMIni = new AxDCEDITLib.AxDcedit();
            this.label53 = new System.Windows.Forms.Label();
            this.dcim18aHpDtF = new AxDCIMAGELib.AxDcimage();
            this.dced18aHpDtF = new AxDCEDITLib.AxDcedit();
            this.dcim18bHpDtT = new AxDCIMAGELib.AxDcimage();
            this.dced18bHpDtT = new AxDCEDITLib.AxDcedit();
            this.label54 = new System.Windows.Forms.Label();
            this.dcim22aResub = new AxDCIMAGELib.AxDcimage();
            this.dced22aResub = new AxDCEDITLib.AxDcedit();
            this.label55 = new System.Windows.Forms.Label();
            this.dcim22bOrigR = new AxDCIMAGELib.AxDcimage();
            this.dced22bOrigR = new AxDCEDITLib.AxDcedit();
            this.label56 = new System.Windows.Forms.Label();
            this.dcim23PriAth = new AxDCIMAGELib.AxDcimage();
            this.dced23PriAth = new AxDCEDITLib.AxDcedit();
            this.dcim10dLocUs = new AxDCIMAGELib.AxDcimage();
            this.dced10dLocUs = new AxDCEDITLib.AxDcedit();
            this.label10dLocUs = new System.Windows.Forms.Label();
            this.label8aPStatM = new System.Windows.Forms.Label();
            this.dcim8aPStatM = new AxDCIMAGELib.AxDcimage();
            this.cmb8aPStatM = new System.Windows.Forms.ComboBox();
            this.label8bPStatE = new System.Windows.Forms.Label();
            this.dcim8bPStatE = new AxDCIMAGELib.AxDcimage();
            this.cmb8bPStatE = new System.Windows.Forms.ComboBox();
            this.label10aPCREm = new System.Windows.Forms.Label();
            this.dcim10aPCREm = new AxDCIMAGELib.AxDcimage();
            this.cmb10aPCREm = new System.Windows.Forms.ComboBox();
            this.label10cPCROA = new System.Windows.Forms.Label();
            this.dcim10cPCROA = new AxDCIMAGELib.AxDcimage();
            this.cmb10cPCROA = new System.Windows.Forms.ComboBox();
            this.label10bPCRAA = new System.Windows.Forms.Label();
            this.dcim10bPCRAA = new AxDCIMAGELib.AxDcimage();
            this.cmb10bPCRAA = new System.Windows.Forms.ComboBox();
            this.label10bautop = new System.Windows.Forms.Label();
            this.dcim10bautop = new AxDCIMAGELib.AxDcimage();
            this.dced10bautop = new AxDCEDITLib.AxDcedit();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.label11bqual = new System.Windows.Forms.Label();
            this.dcim11bqual = new AxDCIMAGELib.AxDcimage();
            this.dced11bqual = new AxDCEDITLib.AxDcedit();
            this.label9OtInsLNam = new System.Windows.Forms.Label();
            this.dcim9OtInsLNam = new AxDCIMAGELib.AxDcimage();
            this.dced9OtInsLNam = new AxDCEDITLib.AxDcedit();
            this.label9OtInsFNam = new System.Windows.Forms.Label();
            this.dcim9OtInsFNam = new AxDCIMAGELib.AxDcimage();
            this.dced9OtInsFNam = new AxDCEDITLib.AxDcedit();
            this.label9OtInsMInit = new System.Windows.Forms.Label();
            this.dcim9OtInsMInit = new AxDCIMAGELib.AxDcimage();
            this.dced9OtInsMInit = new AxDCEDITLib.AxDcedit();
            this.label59 = new System.Windows.Forms.Label();
            this.dcim9aOtInNo = new AxDCIMAGELib.AxDcimage();
            this.dced9aOtInNo = new AxDCEDITLib.AxDcedit();
            this.label9bOInDOB = new System.Windows.Forms.Label();
            this.dcim9bOInDOB = new AxDCIMAGELib.AxDcimage();
            this.dced9bOInDOB = new AxDCEDITLib.AxDcedit();
            this.label9cOIEmNm = new System.Windows.Forms.Label();
            this.dcim9cOIEmNm = new AxDCIMAGELib.AxDcimage();
            this.dced9cOIEmNm = new AxDCEDITLib.AxDcedit();
            this.label9dOIPlNm = new System.Windows.Forms.Label();
            this.dcim9dOIPlNm = new AxDCIMAGELib.AxDcimage();
            this.dced9dOIPlNm = new AxDCEDITLib.AxDcedit();
            this.label9bOInSex = new System.Windows.Forms.Label();
            this.dcim9bOInSex = new AxDCIMAGELib.AxDcimage();
            this.cmb9bOInSex = new System.Windows.Forms.ComboBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.label12aPSign = new System.Windows.Forms.Label();
            this.dcim12aPSign = new AxDCIMAGELib.AxDcimage();
            this.cmb12aPSign = new System.Windows.Forms.ComboBox();
            this.dcim12bDtSgn = new AxDCIMAGELib.AxDcimage();
            this.dced12bDtSgn = new AxDCEDITLib.AxDcedit();
            this.label13InsSig = new System.Windows.Forms.Label();
            this.dcim13InsSig = new AxDCIMAGELib.AxDcimage();
            this.cmb13InsSig = new System.Windows.Forms.ComboBox();
            this.dcim14aSym = new AxDCIMAGELib.AxDcimage();
            this.dced14aSym = new AxDCEDITLib.AxDcedit();
            this.label14aSym = new System.Windows.Forms.Label();
            this.label15qual = new System.Windows.Forms.Label();
            this.dcim15qual = new AxDCIMAGELib.AxDcimage();
            this.dced15qual = new AxDCEDITLib.AxDcedit();
            this.dcim16bDsDtT = new AxDCIMAGELib.AxDcimage();
            this.dced16bDsDtT = new AxDCEDITLib.AxDcedit();
            this.label57 = new System.Windows.Forms.Label();
            this.dcim16aDsDtF = new AxDCIMAGELib.AxDcimage();
            this.dced16aDsDtF = new AxDCEDITLib.AxDcedit();
            this.label20aOutLb = new System.Windows.Forms.Label();
            this.dcim20aOutLb = new AxDCIMAGELib.AxDcimage();
            this.cmb20aOutLb = new System.Windows.Forms.ComboBox();
            this.dcim20bLChgs = new AxDCIMAGELib.AxDcimage();
            this.dced20bLChgs = new AxDCEDITLib.AxDcedit();
            this.label17qual = new System.Windows.Forms.Label();
            this.dcim17qual = new AxDCIMAGELib.AxDcimage();
            this.dced17qual = new AxDCEDITLib.AxDcedit();
            this.label19LocUse = new System.Windows.Forms.Label();
            this.dcim19LocUse = new AxDCIMAGELib.AxDcimage();
            this.dced19LocUse = new AxDCEDITLib.AxDcedit();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.dced21_Diag8 = new AxDCEDITLib.AxDcedit();
            this.dced21_Diag7 = new AxDCEDITLib.AxDcedit();
            this.dced21_Diag6 = new AxDCEDITLib.AxDcedit();
            this.dced21_Diag5 = new AxDCEDITLib.AxDcedit();
            this.label58 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.dced21_Diag12 = new AxDCEDITLib.AxDcedit();
            this.dced21_Diag11 = new AxDCEDITLib.AxDcedit();
            this.dced21_Diag10 = new AxDCEDITLib.AxDcedit();
            this.dced21_Diag9 = new AxDCEDITLib.AxDcedit();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.dced21_ICDInd = new AxDCEDITLib.AxDcedit();
            this.labelCD = new System.Windows.Forms.Label();
            this.labelEPSD = new System.Windows.Forms.Label();
            this.dcim31bPSDat = new AxDCIMAGELib.AxDcimage();
            this.dced31bPSDat = new AxDCEDITLib.AxDcedit();
            this.label31bPSDat = new System.Windows.Forms.Label();
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dced5PAddStr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced5PAddCty)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim5PAddSta)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced5PAddSta)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim5PAddZip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced5PAddZip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim3Pat_DOB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced3Pat_DOB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim3aPatSex)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim1aInsrID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced1aInsrID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced7IAddStr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced7IAddCty)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced7IAddSta)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim7IAddZip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced7IAddZip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim33DocAdd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced7IAddTel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim11IPolNo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced11IPolNo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim11aInSex)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim11aInDOB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced11aInDOB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim11cIPlan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced11cIPlan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim11dPlOth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim17aRfDID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced17aRfDID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced17aRfCd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim17bRfNPI)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced17bRfNPI)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim25aFedTx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced25aFedTx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim26PActNo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced26PActNo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim27AccAss)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim28TotChg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced28TotChg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim29Amt_Pd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced29Amt_Pd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim30BalDue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced30BalDue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim32FacAdd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced32FacNPI)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced32FacID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced2PaLName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced2PaFName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced2PaMInit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced4InsLNam)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced4InsFNam)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced4InsMIni)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim17ReCred)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced17ReCred)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim17ReSufx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced17ReSufx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced31aPhLNm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced31aPhFNm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced31aPhIni)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced32FacNam)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced32F1Addr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced32F2Addr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced32FacCit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced32FacSta)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced32FacZip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced33PhBNam)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced33Ph1Add)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced33Ph2Add)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced33PhCity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced33PhStat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced33PhyZip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced33PhyNPI)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced33PhyID)).BeginInit();
            this.panLINEITEM.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dcimNDCQty)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedNDCQty)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimEPSDTcode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedEPSDTcode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimEPSD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedEPSD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimCharges)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimNDCType)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedNDCType)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimNDC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedNDC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimEMG_C)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedEMG_C)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimReferenceId)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedReferenceId)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimDateFrom)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedDateFrom)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimDateThru)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedDateThru)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimPlaceofService)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedPlaceofService)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimCPT_Code)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedCPT_Code)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimModifiers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedModifiers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimDiagPointer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedDiagPointer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedCharges)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimDays_Units)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedDays_Units)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimQualifier)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedQualifier)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimNPI)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedNPI)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedInfo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimInfo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim7IAddStr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced21_Diag1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced21_Diag2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced21_Diag3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced21_Diag4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced5PAddTel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim1InsType)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim6PatRela)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim11bIEmNm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced11bIEmNm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim25bSSEIN)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim14SymDat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced14SymDat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim15HisDat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced15HisDat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim17RefDoc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced17ReLNam)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced17ReFNam)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedReMIni)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim18aHpDtF)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced18aHpDtF)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim18bHpDtT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced18bHpDtT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim22aResub)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced22aResub)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim22bOrigR)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced22bOrigR)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim23PriAth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced23PriAth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim10dLocUs)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced10dLocUs)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim8aPStatM)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim8bPStatE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim10aPCREm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim10cPCROA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim10bPCRAA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim10bautop)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced10bautop)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim11bqual)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced11bqual)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim9OtInsLNam)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced9OtInsLNam)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim9OtInsFNam)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced9OtInsFNam)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim9OtInsMInit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced9OtInsMInit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim9aOtInNo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced9aOtInNo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim9bOInDOB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced9bOInDOB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim9cOIEmNm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced9cOIEmNm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim9dOIPlNm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced9dOIPlNm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim9bOInSex)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim12aPSign)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim12bDtSgn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced12bDtSgn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim13InsSig)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim14aSym)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced14aSym)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim15qual)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced15qual)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim16bDsDtT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced16bDsDtT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim16aDsDtF)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced16aDsDtF)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim20aOutLb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim20bLChgs)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced20bLChgs)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim17qual)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced17qual)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim19LocUse)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced19LocUse)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced21_Diag8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced21_Diag7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced21_Diag6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced21_Diag5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced21_Diag12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced21_Diag11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced21_Diag10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced21_Diag9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced21_ICDInd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim31bPSDat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced31bPSDat)).BeginInit();
            this.SuspendLayout();
            // 
            // dced5PAddStr
            // 
            this.dced5PAddStr.Location = new System.Drawing.Point(75, 306);
            this.dced5PAddStr.Name = "dced5PAddStr";
            this.dced5PAddStr.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced5PAddStr.OcxState")));
            this.dced5PAddStr.Size = new System.Drawing.Size(236, 18);
            this.dced5PAddStr.TabIndex = 19;
            this.dced5PAddStr.Tag = "5PAddStr";
            // 
            // dced5PAddCty
            // 
            this.dced5PAddCty.Location = new System.Drawing.Point(75, 339);
            this.dced5PAddCty.Name = "dced5PAddCty";
            this.dced5PAddCty.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced5PAddCty.OcxState")));
            this.dced5PAddCty.Size = new System.Drawing.Size(191, 18);
            this.dced5PAddCty.TabIndex = 21;
            this.dced5PAddCty.Tag = "5PAddCty";
            // 
            // dcim5PAddSta
            // 
            this.dcim5PAddSta.Location = new System.Drawing.Point(75, 110);
            this.dcim5PAddSta.Name = "dcim5PAddSta";
            this.dcim5PAddSta.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim5PAddSta.OcxState")));
            this.dcim5PAddSta.Size = new System.Drawing.Size(236, 116);
            this.dcim5PAddSta.TabIndex = 11;
            this.dcim5PAddSta.TabStop = false;
            this.dcim5PAddSta.Tag = "2PatSFLD";
            // 
            // dced5PAddSta
            // 
            this.dced5PAddSta.Location = new System.Drawing.Point(272, 339);
            this.dced5PAddSta.Name = "dced5PAddSta";
            this.dced5PAddSta.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced5PAddSta.OcxState")));
            this.dced5PAddSta.Size = new System.Drawing.Size(39, 18);
            this.dced5PAddSta.TabIndex = 23;
            this.dced5PAddSta.Tag = "5PAddSta";
            // 
            // dcim5PAddZip
            // 
            this.dcim5PAddZip.Location = new System.Drawing.Point(364, 110);
            this.dcim5PAddZip.Name = "dcim5PAddZip";
            this.dcim5PAddZip.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim5PAddZip.OcxState")));
            this.dcim5PAddZip.Size = new System.Drawing.Size(236, 116);
            this.dcim5PAddZip.TabIndex = 35;
            this.dcim5PAddZip.TabStop = false;
            this.dcim5PAddZip.Tag = "4InsSFLD";
            // 
            // dced5PAddZip
            // 
            this.dced5PAddZip.Location = new System.Drawing.Point(74, 372);
            this.dced5PAddZip.Name = "dced5PAddZip";
            this.dced5PAddZip.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced5PAddZip.OcxState")));
            this.dced5PAddZip.Size = new System.Drawing.Size(100, 18);
            this.dced5PAddZip.TabIndex = 25;
            this.dced5PAddZip.Tag = "5PAddZip";
            // 
            // lbl3Pat_DOB
            // 
            this.lbl3Pat_DOB.AutoSize = true;
            this.lbl3Pat_DOB.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl3Pat_DOB.Location = new System.Drawing.Point(901, 14);
            this.lbl3Pat_DOB.Name = "lbl3Pat_DOB";
            this.lbl3Pat_DOB.Size = new System.Drawing.Size(91, 13);
            this.lbl3Pat_DOB.TabIndex = 6;
            this.lbl3Pat_DOB.Tag = "3Pat_DOB";
            this.lbl3Pat_DOB.Text = "3. Patient DOB";
            // 
            // dcim3Pat_DOB
            // 
            this.dcim3Pat_DOB.Location = new System.Drawing.Point(898, 27);
            this.dcim3Pat_DOB.Name = "dcim3Pat_DOB";
            this.dcim3Pat_DOB.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim3Pat_DOB.OcxState")));
            this.dcim3Pat_DOB.Size = new System.Drawing.Size(94, 18);
            this.dcim3Pat_DOB.TabIndex = 7;
            this.dcim3Pat_DOB.TabStop = false;
            this.dcim3Pat_DOB.Tag = "3Pat_DOB";
            // 
            // dced3Pat_DOB
            // 
            this.dced3Pat_DOB.Location = new System.Drawing.Point(898, 45);
            this.dced3Pat_DOB.Name = "dced3Pat_DOB";
            this.dced3Pat_DOB.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced3Pat_DOB.OcxState")));
            this.dced3Pat_DOB.Size = new System.Drawing.Size(94, 18);
            this.dced3Pat_DOB.TabIndex = 8;
            this.dced3Pat_DOB.Tag = "3Pat_DOB";
            // 
            // lbl3aPatSex
            // 
            this.lbl3aPatSex.AutoSize = true;
            this.lbl3aPatSex.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl3aPatSex.Location = new System.Drawing.Point(671, 68);
            this.lbl3aPatSex.Name = "lbl3aPatSex";
            this.lbl3aPatSex.Size = new System.Drawing.Size(94, 13);
            this.lbl3aPatSex.TabIndex = 53;
            this.lbl3aPatSex.Tag = "3aPatSex";
            this.lbl3aPatSex.Text = "3a. Patient Sex";
            // 
            // dcim3aPatSex
            // 
            this.dcim3aPatSex.Location = new System.Drawing.Point(671, 81);
            this.dcim3aPatSex.Name = "dcim3aPatSex";
            this.dcim3aPatSex.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim3aPatSex.OcxState")));
            this.dcim3aPatSex.Size = new System.Drawing.Size(104, 34);
            this.dcim3aPatSex.TabIndex = 53;
            this.dcim3aPatSex.TabStop = false;
            this.dcim3aPatSex.Tag = "3aPatSex";
            // 
            // cmb3aPatSex
            // 
            this.cmb3aPatSex.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb3aPatSex.FormattingEnabled = true;
            this.cmb3aPatSex.Location = new System.Drawing.Point(671, 115);
            this.cmb3aPatSex.Name = "cmb3aPatSex";
            this.cmb3aPatSex.Size = new System.Drawing.Size(104, 21);
            this.cmb3aPatSex.TabIndex = 54;
            this.cmb3aPatSex.Tag = "3aPatSex";
            // 
            // lbl1aInsrID
            // 
            this.lbl1aInsrID.AutoSize = true;
            this.lbl1aInsrID.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1aInsrID.Location = new System.Drawing.Point(673, 14);
            this.lbl1aInsrID.Name = "lbl1aInsrID";
            this.lbl1aInsrID.Size = new System.Drawing.Size(100, 13);
            this.lbl1aInsrID.TabIndex = 3;
            this.lbl1aInsrID.Tag = "1aInsrID";
            this.lbl1aInsrID.Text = "1a. Insured\'s ID";
            // 
            // dcim1aInsrID
            // 
            this.dcim1aInsrID.Location = new System.Drawing.Point(670, 27);
            this.dcim1aInsrID.Name = "dcim1aInsrID";
            this.dcim1aInsrID.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim1aInsrID.OcxState")));
            this.dcim1aInsrID.Size = new System.Drawing.Size(222, 18);
            this.dcim1aInsrID.TabIndex = 4;
            this.dcim1aInsrID.TabStop = false;
            this.dcim1aInsrID.Tag = "1aInsrID";
            // 
            // dced1aInsrID
            // 
            this.dced1aInsrID.Location = new System.Drawing.Point(670, 45);
            this.dced1aInsrID.Name = "dced1aInsrID";
            this.dced1aInsrID.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced1aInsrID.OcxState")));
            this.dced1aInsrID.Size = new System.Drawing.Size(222, 18);
            this.dced1aInsrID.TabIndex = 5;
            this.dced1aInsrID.Tag = "1aInsrID";
            this.dced1aInsrID.Change += new System.EventHandler(this.dced1aInsrID_Change);
            // 
            // lbl7IAddStr
            // 
            this.lbl7IAddStr.AutoSize = true;
            this.lbl7IAddStr.BackColor = System.Drawing.Color.Lavender;
            this.lbl7IAddStr.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl7IAddStr.Location = new System.Drawing.Point(78, 97);
            this.lbl7IAddStr.Name = "lbl7IAddStr";
            this.lbl7IAddStr.Size = new System.Drawing.Size(206, 13);
            this.lbl7IAddStr.TabIndex = 10;
            this.lbl7IAddStr.Tag = "";
            this.lbl7IAddStr.Text = "2. Patient Name/Address/Zip Code";
            // 
            // dced7IAddStr
            // 
            this.dced7IAddStr.Location = new System.Drawing.Point(364, 306);
            this.dced7IAddStr.Name = "dced7IAddStr";
            this.dced7IAddStr.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced7IAddStr.OcxState")));
            this.dced7IAddStr.Size = new System.Drawing.Size(236, 18);
            this.dced7IAddStr.TabIndex = 43;
            this.dced7IAddStr.Tag = "7IAddStr";
            // 
            // lbl7IAddCty
            // 
            this.lbl7IAddCty.AutoSize = true;
            this.lbl7IAddCty.BackColor = System.Drawing.Color.Lavender;
            this.lbl7IAddCty.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl7IAddCty.Location = new System.Drawing.Point(367, 97);
            this.lbl7IAddCty.Name = "lbl7IAddCty";
            this.lbl7IAddCty.Size = new System.Drawing.Size(211, 13);
            this.lbl7IAddCty.TabIndex = 34;
            this.lbl7IAddCty.Tag = "";
            this.lbl7IAddCty.Text = "4. Insured Name/Address/Zip Code";
            // 
            // dced7IAddCty
            // 
            this.dced7IAddCty.Location = new System.Drawing.Point(364, 339);
            this.dced7IAddCty.Name = "dced7IAddCty";
            this.dced7IAddCty.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced7IAddCty.OcxState")));
            this.dced7IAddCty.Size = new System.Drawing.Size(191, 18);
            this.dced7IAddCty.TabIndex = 45;
            this.dced7IAddCty.Tag = "7IAddCty";
            // 
            // dced7IAddSta
            // 
            this.dced7IAddSta.Location = new System.Drawing.Point(561, 339);
            this.dced7IAddSta.Name = "dced7IAddSta";
            this.dced7IAddSta.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced7IAddSta.OcxState")));
            this.dced7IAddSta.Size = new System.Drawing.Size(39, 18);
            this.dced7IAddSta.TabIndex = 47;
            this.dced7IAddSta.Tag = "7IAddSta";
            // 
            // dcim7IAddZip
            // 
            this.dcim7IAddZip.Location = new System.Drawing.Point(23, 1286);
            this.dcim7IAddZip.Name = "dcim7IAddZip";
            this.dcim7IAddZip.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim7IAddZip.OcxState")));
            this.dcim7IAddZip.Size = new System.Drawing.Size(250, 81);
            this.dcim7IAddZip.TabIndex = 253;
            this.dcim7IAddZip.TabStop = false;
            this.dcim7IAddZip.Tag = "31aPhSig";
            // 
            // dced7IAddZip
            // 
            this.dced7IAddZip.Location = new System.Drawing.Point(363, 372);
            this.dced7IAddZip.Name = "dced7IAddZip";
            this.dced7IAddZip.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced7IAddZip.OcxState")));
            this.dced7IAddZip.Size = new System.Drawing.Size(100, 18);
            this.dced7IAddZip.TabIndex = 49;
            this.dced7IAddZip.Tag = "7IAddZip";
            // 
            // lbl7IAddTel
            // 
            this.lbl7IAddTel.AutoSize = true;
            this.lbl7IAddTel.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl7IAddTel.Location = new System.Drawing.Point(21, 1273);
            this.lbl7IAddTel.Name = "lbl7IAddTel";
            this.lbl7IAddTel.Size = new System.Drawing.Size(141, 13);
            this.lbl7IAddTel.TabIndex = 252;
            this.lbl7IAddTel.Tag = "";
            this.lbl7IAddTel.Text = "31. Physician Signature";
            // 
            // dcim33DocAdd
            // 
            this.dcim33DocAdd.Location = new System.Drawing.Point(717, 1286);
            this.dcim33DocAdd.Name = "dcim33DocAdd";
            this.dcim33DocAdd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim33DocAdd.OcxState")));
            this.dcim33DocAdd.Size = new System.Drawing.Size(247, 94);
            this.dcim33DocAdd.TabIndex = 286;
            this.dcim33DocAdd.TabStop = false;
            this.dcim33DocAdd.Tag = "33DocAdd";
            // 
            // dced7IAddTel
            // 
            this.dced7IAddTel.Location = new System.Drawing.Point(470, 372);
            this.dced7IAddTel.Name = "dced7IAddTel";
            this.dced7IAddTel.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced7IAddTel.OcxState")));
            this.dced7IAddTel.Size = new System.Drawing.Size(130, 18);
            this.dced7IAddTel.TabIndex = 51;
            this.dced7IAddTel.Tag = "7IAddTel";
            // 
            // lbl11IPolNo
            // 
            this.lbl11IPolNo.AutoSize = true;
            this.lbl11IPolNo.BackColor = System.Drawing.Color.Lavender;
            this.lbl11IPolNo.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl11IPolNo.Location = new System.Drawing.Point(283, 413);
            this.lbl11IPolNo.Name = "lbl11IPolNo";
            this.lbl11IPolNo.Size = new System.Drawing.Size(111, 13);
            this.lbl11IPolNo.TabIndex = 100;
            this.lbl11IPolNo.Tag = "11IPolNo";
            this.lbl11IPolNo.Text = "11. Policy Number";
            // 
            // dcim11IPolNo
            // 
            this.dcim11IPolNo.Location = new System.Drawing.Point(286, 426);
            this.dcim11IPolNo.Name = "dcim11IPolNo";
            this.dcim11IPolNo.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim11IPolNo.OcxState")));
            this.dcim11IPolNo.Size = new System.Drawing.Size(221, 18);
            this.dcim11IPolNo.TabIndex = 101;
            this.dcim11IPolNo.TabStop = false;
            this.dcim11IPolNo.Tag = "11IPolNo";
            // 
            // dced11IPolNo
            // 
            this.dced11IPolNo.Location = new System.Drawing.Point(286, 444);
            this.dced11IPolNo.Name = "dced11IPolNo";
            this.dced11IPolNo.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced11IPolNo.OcxState")));
            this.dced11IPolNo.Size = new System.Drawing.Size(221, 18);
            this.dced11IPolNo.TabIndex = 102;
            this.dced11IPolNo.Tag = "11IPolNo";
            // 
            // lbl11aInSex
            // 
            this.lbl11aInSex.AutoSize = true;
            this.lbl11aInSex.BackColor = System.Drawing.Color.Lavender;
            this.lbl11aInSex.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl11aInSex.Location = new System.Drawing.Point(404, 466);
            this.lbl11aInSex.Name = "lbl11aInSex";
            this.lbl11aInSex.Size = new System.Drawing.Size(106, 13);
            this.lbl11aInSex.TabIndex = 106;
            this.lbl11aInSex.Tag = "11aInSex";
            this.lbl11aInSex.Text = "11a. Insured Sex";
            // 
            // dcim11aInSex
            // 
            this.dcim11aInSex.Location = new System.Drawing.Point(404, 479);
            this.dcim11aInSex.Name = "dcim11aInSex";
            this.dcim11aInSex.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim11aInSex.OcxState")));
            this.dcim11aInSex.Size = new System.Drawing.Size(104, 34);
            this.dcim11aInSex.TabIndex = 107;
            this.dcim11aInSex.TabStop = false;
            this.dcim11aInSex.Tag = "11aInSex";
            // 
            // cmb11aInSex
            // 
            this.cmb11aInSex.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb11aInSex.FormattingEnabled = true;
            this.cmb11aInSex.Location = new System.Drawing.Point(404, 513);
            this.cmb11aInSex.Name = "cmb11aInSex";
            this.cmb11aInSex.Size = new System.Drawing.Size(105, 21);
            this.cmb11aInSex.TabIndex = 108;
            this.cmb11aInSex.Tag = "11aInSex";
            // 
            // lbl11aInDOB
            // 
            this.lbl11aInDOB.AutoSize = true;
            this.lbl11aInDOB.BackColor = System.Drawing.Color.Lavender;
            this.lbl11aInDOB.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl11aInDOB.Location = new System.Drawing.Point(280, 466);
            this.lbl11aInDOB.Name = "lbl11aInDOB";
            this.lbl11aInDOB.Size = new System.Drawing.Size(110, 13);
            this.lbl11aInDOB.TabIndex = 103;
            this.lbl11aInDOB.Tag = "11aInDOB";
            this.lbl11aInDOB.Text = "11a. Insured DOB";
            // 
            // dcim11aInDOB
            // 
            this.dcim11aInDOB.Location = new System.Drawing.Point(286, 479);
            this.dcim11aInDOB.Name = "dcim11aInDOB";
            this.dcim11aInDOB.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim11aInDOB.OcxState")));
            this.dcim11aInDOB.Size = new System.Drawing.Size(75, 18);
            this.dcim11aInDOB.TabIndex = 104;
            this.dcim11aInDOB.TabStop = false;
            this.dcim11aInDOB.Tag = "11aInDOB";
            // 
            // dced11aInDOB
            // 
            this.dced11aInDOB.Location = new System.Drawing.Point(286, 497);
            this.dced11aInDOB.Name = "dced11aInDOB";
            this.dced11aInDOB.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced11aInDOB.OcxState")));
            this.dced11aInDOB.Size = new System.Drawing.Size(75, 18);
            this.dced11aInDOB.TabIndex = 105;
            this.dced11aInDOB.Tag = "11aInDOB";
            // 
            // lbl11cIPlan
            // 
            this.lbl11cIPlan.AutoSize = true;
            this.lbl11cIPlan.BackColor = System.Drawing.Color.Lavender;
            this.lbl11cIPlan.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl11cIPlan.Location = new System.Drawing.Point(281, 587);
            this.lbl11cIPlan.Name = "lbl11cIPlan";
            this.lbl11cIPlan.Size = new System.Drawing.Size(157, 13);
            this.lbl11cIPlan.TabIndex = 115;
            this.lbl11cIPlan.Tag = "11cIPlan";
            this.lbl11cIPlan.Text = "11c. Insurance Plan Name";
            // 
            // dcim11cIPlan
            // 
            this.dcim11cIPlan.Location = new System.Drawing.Point(286, 603);
            this.dcim11cIPlan.Name = "dcim11cIPlan";
            this.dcim11cIPlan.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim11cIPlan.OcxState")));
            this.dcim11cIPlan.Size = new System.Drawing.Size(221, 18);
            this.dcim11cIPlan.TabIndex = 116;
            this.dcim11cIPlan.TabStop = false;
            this.dcim11cIPlan.Tag = "11cIPlan";
            // 
            // dced11cIPlan
            // 
            this.dced11cIPlan.Location = new System.Drawing.Point(286, 621);
            this.dced11cIPlan.Name = "dced11cIPlan";
            this.dced11cIPlan.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced11cIPlan.OcxState")));
            this.dced11cIPlan.Size = new System.Drawing.Size(221, 18);
            this.dced11cIPlan.TabIndex = 117;
            this.dced11cIPlan.Tag = "11cIPlan";
            // 
            // lbl11dPlOth
            // 
            this.lbl11dPlOth.AutoSize = true;
            this.lbl11dPlOth.BackColor = System.Drawing.Color.Lavender;
            this.lbl11dPlOth.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl11dPlOth.Location = new System.Drawing.Point(283, 642);
            this.lbl11dPlOth.Name = "lbl11dPlOth";
            this.lbl11dPlOth.Size = new System.Drawing.Size(109, 13);
            this.lbl11dPlOth.TabIndex = 118;
            this.lbl11dPlOth.Tag = "11dPlOth";
            this.lbl11dPlOth.Text = "11d. Another Plan";
            // 
            // dcim11dPlOth
            // 
            this.dcim11dPlOth.Location = new System.Drawing.Point(286, 659);
            this.dcim11dPlOth.Name = "dcim11dPlOth";
            this.dcim11dPlOth.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim11dPlOth.OcxState")));
            this.dcim11dPlOth.Size = new System.Drawing.Size(104, 34);
            this.dcim11dPlOth.TabIndex = 119;
            this.dcim11dPlOth.TabStop = false;
            this.dcim11dPlOth.Tag = "11dPlOth";
            // 
            // cmb11dPlOth
            // 
            this.cmb11dPlOth.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb11dPlOth.FormattingEnabled = true;
            this.cmb11dPlOth.Location = new System.Drawing.Point(286, 693);
            this.cmb11dPlOth.Name = "cmb11dPlOth";
            this.cmb11dPlOth.Size = new System.Drawing.Size(104, 21);
            this.cmb11dPlOth.TabIndex = 120;
            this.cmb11dPlOth.Tag = "11dPlOth";
            // 
            // lbl17aRfDID
            // 
            this.lbl17aRfDID.AutoSize = true;
            this.lbl17aRfDID.BackColor = System.Drawing.Color.Lavender;
            this.lbl17aRfDID.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl17aRfDID.Location = new System.Drawing.Point(717, 605);
            this.lbl17aRfDID.Name = "lbl17aRfDID";
            this.lbl17aRfDID.Size = new System.Drawing.Size(154, 13);
            this.lbl17aRfDID.TabIndex = 157;
            this.lbl17aRfDID.Tag = "";
            this.lbl17aRfDID.Text = "17a. Qualifier and Ref. ID";
            // 
            // dcim17aRfDID
            // 
            this.dcim17aRfDID.Location = new System.Drawing.Point(720, 618);
            this.dcim17aRfDID.Name = "dcim17aRfDID";
            this.dcim17aRfDID.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim17aRfDID.OcxState")));
            this.dcim17aRfDID.Size = new System.Drawing.Size(151, 18);
            this.dcim17aRfDID.TabIndex = 158;
            this.dcim17aRfDID.TabStop = false;
            this.dcim17aRfDID.Tag = "17aRfDID";
            // 
            // dced17aRfDID
            // 
            this.dced17aRfDID.Location = new System.Drawing.Point(758, 636);
            this.dced17aRfDID.Name = "dced17aRfDID";
            this.dced17aRfDID.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced17aRfDID.OcxState")));
            this.dced17aRfDID.Size = new System.Drawing.Size(113, 18);
            this.dced17aRfDID.TabIndex = 160;
            this.dced17aRfDID.Tag = "17aRfDID";
            // 
            // lbl17aRfCd
            // 
            this.lbl17aRfCd.AutoSize = true;
            this.lbl17aRfCd.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl17aRfCd.Location = new System.Drawing.Point(372, 1273);
            this.lbl17aRfCd.Name = "lbl17aRfCd";
            this.lbl17aRfCd.Size = new System.Drawing.Size(173, 13);
            this.lbl17aRfCd.TabIndex = 264;
            this.lbl17aRfCd.Tag = "";
            this.lbl17aRfCd.Text = "32. Facility\'s Name / Address";
            // 
            // dced17aRfCd
            // 
            this.dced17aRfCd.Location = new System.Drawing.Point(720, 636);
            this.dced17aRfCd.Name = "dced17aRfCd";
            this.dced17aRfCd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced17aRfCd.OcxState")));
            this.dced17aRfCd.Size = new System.Drawing.Size(37, 18);
            this.dced17aRfCd.TabIndex = 159;
            this.dced17aRfCd.Tag = "17aRfCd";
            // 
            // dcim17bRfNPI
            // 
            this.dcim17bRfNPI.Location = new System.Drawing.Point(890, 618);
            this.dcim17bRfNPI.Name = "dcim17bRfNPI";
            this.dcim17bRfNPI.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim17bRfNPI.OcxState")));
            this.dcim17bRfNPI.Size = new System.Drawing.Size(117, 18);
            this.dcim17bRfNPI.TabIndex = 162;
            this.dcim17bRfNPI.TabStop = false;
            this.dcim17bRfNPI.Tag = "17bRfNPI";
            // 
            // dced17bRfNPI
            // 
            this.dced17bRfNPI.Location = new System.Drawing.Point(890, 636);
            this.dced17bRfNPI.Name = "dced17bRfNPI";
            this.dced17bRfNPI.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced17bRfNPI.OcxState")));
            this.dced17bRfNPI.Size = new System.Drawing.Size(117, 18);
            this.dced17bRfNPI.TabIndex = 163;
            this.dced17bRfNPI.Tag = "17bRfNPI";
            // 
            // lbl25aFedTx
            // 
            this.lbl25aFedTx.AutoSize = true;
            this.lbl25aFedTx.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl25aFedTx.Location = new System.Drawing.Point(22, 1211);
            this.lbl25aFedTx.Name = "lbl25aFedTx";
            this.lbl25aFedTx.Size = new System.Drawing.Size(130, 13);
            this.lbl25aFedTx.TabIndex = 231;
            this.lbl25aFedTx.Tag = "25aFedTx";
            this.lbl25aFedTx.Text = "25a. Federal Tax ID#";
            // 
            // dcim25aFedTx
            // 
            this.dcim25aFedTx.Location = new System.Drawing.Point(23, 1224);
            this.dcim25aFedTx.Name = "dcim25aFedTx";
            this.dcim25aFedTx.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim25aFedTx.OcxState")));
            this.dcim25aFedTx.Size = new System.Drawing.Size(130, 18);
            this.dcim25aFedTx.TabIndex = 232;
            this.dcim25aFedTx.TabStop = false;
            this.dcim25aFedTx.Tag = "25aFedTx";
            // 
            // dced25aFedTx
            // 
            this.dced25aFedTx.Location = new System.Drawing.Point(23, 1243);
            this.dced25aFedTx.Name = "dced25aFedTx";
            this.dced25aFedTx.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced25aFedTx.OcxState")));
            this.dced25aFedTx.Size = new System.Drawing.Size(130, 18);
            this.dced25aFedTx.TabIndex = 233;
            this.dced25aFedTx.Tag = "25aFedTx";
            // 
            // lbl26PActNo
            // 
            this.lbl26PActNo.AutoSize = true;
            this.lbl26PActNo.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl26PActNo.Location = new System.Drawing.Point(371, 1211);
            this.lbl26PActNo.Name = "lbl26PActNo";
            this.lbl26PActNo.Size = new System.Drawing.Size(130, 13);
            this.lbl26PActNo.TabIndex = 237;
            this.lbl26PActNo.Tag = "26PActNo";
            this.lbl26PActNo.Text = "26. Patient Account #";
            // 
            // dcim26PActNo
            // 
            this.dcim26PActNo.Location = new System.Drawing.Point(371, 1224);
            this.dcim26PActNo.Name = "dcim26PActNo";
            this.dcim26PActNo.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim26PActNo.OcxState")));
            this.dcim26PActNo.Size = new System.Drawing.Size(130, 18);
            this.dcim26PActNo.TabIndex = 238;
            this.dcim26PActNo.TabStop = false;
            this.dcim26PActNo.Tag = "26PActNo";
            // 
            // dced26PActNo
            // 
            this.dced26PActNo.Location = new System.Drawing.Point(371, 1243);
            this.dced26PActNo.Name = "dced26PActNo";
            this.dced26PActNo.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced26PActNo.OcxState")));
            this.dced26PActNo.Size = new System.Drawing.Size(130, 18);
            this.dced26PActNo.TabIndex = 239;
            this.dced26PActNo.Tag = "26PActNo";
            // 
            // lbl27AccAss
            // 
            this.lbl27AccAss.AutoSize = true;
            this.lbl27AccAss.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl27AccAss.Location = new System.Drawing.Point(516, 1211);
            this.lbl27AccAss.Name = "lbl27AccAss";
            this.lbl27AccAss.Size = new System.Drawing.Size(95, 13);
            this.lbl27AccAss.TabIndex = 240;
            this.lbl27AccAss.Tag = "27AccAss";
            this.lbl27AccAss.Text = "27. Assignment";
            // 
            // dcim27AccAss
            // 
            this.dcim27AccAss.Location = new System.Drawing.Point(519, 1224);
            this.dcim27AccAss.Name = "dcim27AccAss";
            this.dcim27AccAss.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim27AccAss.OcxState")));
            this.dcim27AccAss.Size = new System.Drawing.Size(88, 39);
            this.dcim27AccAss.TabIndex = 241;
            this.dcim27AccAss.TabStop = false;
            this.dcim27AccAss.Tag = "27AccAss";
            // 
            // cmb27AccAss
            // 
            this.cmb27AccAss.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb27AccAss.FormattingEnabled = true;
            this.cmb27AccAss.Location = new System.Drawing.Point(610, 1224);
            this.cmb27AccAss.Name = "cmb27AccAss";
            this.cmb27AccAss.Size = new System.Drawing.Size(91, 26);
            this.cmb27AccAss.TabIndex = 242;
            this.cmb27AccAss.Tag = "27AccAss";
            // 
            // lbl28TotChg
            // 
            this.lbl28TotChg.AutoSize = true;
            this.lbl28TotChg.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl28TotChg.Location = new System.Drawing.Point(714, 1211);
            this.lbl28TotChg.Name = "lbl28TotChg";
            this.lbl28TotChg.Size = new System.Drawing.Size(61, 13);
            this.lbl28TotChg.TabIndex = 243;
            this.lbl28TotChg.Tag = "28TotChg";
            this.lbl28TotChg.Text = "28. Total ";
            // 
            // dcim28TotChg
            // 
            this.dcim28TotChg.Location = new System.Drawing.Point(717, 1224);
            this.dcim28TotChg.Name = "dcim28TotChg";
            this.dcim28TotChg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim28TotChg.OcxState")));
            this.dcim28TotChg.Size = new System.Drawing.Size(84, 18);
            this.dcim28TotChg.TabIndex = 244;
            this.dcim28TotChg.TabStop = false;
            this.dcim28TotChg.Tag = "28TotChg";
            // 
            // dced28TotChg
            // 
            this.dced28TotChg.Location = new System.Drawing.Point(717, 1243);
            this.dced28TotChg.Name = "dced28TotChg";
            this.dced28TotChg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced28TotChg.OcxState")));
            this.dced28TotChg.Size = new System.Drawing.Size(84, 18);
            this.dced28TotChg.TabIndex = 245;
            this.dced28TotChg.Tag = "28TotChg";
            // 
            // lbl29Amt_Pd
            // 
            this.lbl29Amt_Pd.AutoSize = true;
            this.lbl29Amt_Pd.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl29Amt_Pd.Location = new System.Drawing.Point(813, 1211);
            this.lbl29Amt_Pd.Name = "lbl29Amt_Pd";
            this.lbl29Amt_Pd.Size = new System.Drawing.Size(53, 13);
            this.lbl29Amt_Pd.TabIndex = 246;
            this.lbl29Amt_Pd.Tag = "29Amt_Pd";
            this.lbl29Amt_Pd.Text = "29. Paid";
            // 
            // dcim29Amt_Pd
            // 
            this.dcim29Amt_Pd.Location = new System.Drawing.Point(816, 1224);
            this.dcim29Amt_Pd.Name = "dcim29Amt_Pd";
            this.dcim29Amt_Pd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim29Amt_Pd.OcxState")));
            this.dcim29Amt_Pd.Size = new System.Drawing.Size(84, 18);
            this.dcim29Amt_Pd.TabIndex = 247;
            this.dcim29Amt_Pd.TabStop = false;
            this.dcim29Amt_Pd.Tag = "29Amt_Pd";
            // 
            // dced29Amt_Pd
            // 
            this.dced29Amt_Pd.Location = new System.Drawing.Point(816, 1243);
            this.dced29Amt_Pd.Name = "dced29Amt_Pd";
            this.dced29Amt_Pd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced29Amt_Pd.OcxState")));
            this.dced29Amt_Pd.Size = new System.Drawing.Size(84, 18);
            this.dced29Amt_Pd.TabIndex = 248;
            this.dced29Amt_Pd.Tag = "29Amt_Pd";
            // 
            // lbl30BalDue
            // 
            this.lbl30BalDue.AutoSize = true;
            this.lbl30BalDue.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl30BalDue.Location = new System.Drawing.Point(913, 1211);
            this.lbl30BalDue.Name = "lbl30BalDue";
            this.lbl30BalDue.Size = new System.Drawing.Size(52, 13);
            this.lbl30BalDue.TabIndex = 249;
            this.lbl30BalDue.Tag = "30BalDue";
            this.lbl30BalDue.Text = "30. Due";
            // 
            // dcim30BalDue
            // 
            this.dcim30BalDue.Location = new System.Drawing.Point(915, 1224);
            this.dcim30BalDue.Name = "dcim30BalDue";
            this.dcim30BalDue.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim30BalDue.OcxState")));
            this.dcim30BalDue.Size = new System.Drawing.Size(84, 18);
            this.dcim30BalDue.TabIndex = 250;
            this.dcim30BalDue.TabStop = false;
            this.dcim30BalDue.Tag = "30BalDue";
            // 
            // dced30BalDue
            // 
            this.dced30BalDue.Location = new System.Drawing.Point(915, 1243);
            this.dced30BalDue.Name = "dced30BalDue";
            this.dced30BalDue.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced30BalDue.OcxState")));
            this.dced30BalDue.Size = new System.Drawing.Size(84, 18);
            this.dced30BalDue.TabIndex = 251;
            this.dced30BalDue.Tag = "30BalDue";
            // 
            // dcim32FacAdd
            // 
            this.dcim32FacAdd.Location = new System.Drawing.Point(373, 1286);
            this.dcim32FacAdd.Name = "dcim32FacAdd";
            this.dcim32FacAdd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim32FacAdd.OcxState")));
            this.dcim32FacAdd.Size = new System.Drawing.Size(250, 94);
            this.dcim32FacAdd.TabIndex = 265;
            this.dcim32FacAdd.TabStop = false;
            this.dcim32FacAdd.Tag = "32FacAdd";
            // 
            // dced32FacNPI
            // 
            this.dced32FacNPI.Location = new System.Drawing.Point(373, 1570);
            this.dced32FacNPI.Name = "dced32FacNPI";
            this.dced32FacNPI.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced32FacNPI.OcxState")));
            this.dced32FacNPI.Size = new System.Drawing.Size(125, 18);
            this.dced32FacNPI.TabIndex = 277;
            this.dced32FacNPI.Tag = "32FacNPI";
            // 
            // dced32FacID
            // 
            this.dced32FacID.Location = new System.Drawing.Point(505, 1569);
            this.dced32FacID.Name = "dced32FacID";
            this.dced32FacID.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced32FacID.OcxState")));
            this.dced32FacID.Size = new System.Drawing.Size(117, 18);
            this.dced32FacID.TabIndex = 281;
            this.dced32FacID.Tag = "32FacID";
            // 
            // lbl24aDtFr1
            // 
            this.lbl24aDtFr1.AutoSize = true;
            this.lbl24aDtFr1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl24aDtFr1.Location = new System.Drawing.Point(715, 1273);
            this.lbl24aDtFr1.Name = "lbl24aDtFr1";
            this.lbl24aDtFr1.Size = new System.Drawing.Size(179, 13);
            this.lbl24aDtFr1.TabIndex = 285;
            this.lbl24aDtFr1.Tag = "";
            this.lbl24aDtFr1.Text = "33. Physician\'s Name/Address";
            // 
            // dced2PaLName
            // 
            this.dced2PaLName.Location = new System.Drawing.Point(75, 240);
            this.dced2PaLName.Name = "dced2PaLName";
            this.dced2PaLName.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced2PaLName.OcxState")));
            this.dced2PaLName.Size = new System.Drawing.Size(236, 18);
            this.dced2PaLName.TabIndex = 13;
            this.dced2PaLName.Tag = "2PaLName";
            // 
            // dced2PaFName
            // 
            this.dced2PaFName.Location = new System.Drawing.Point(75, 273);
            this.dced2PaFName.Name = "dced2PaFName";
            this.dced2PaFName.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced2PaFName.OcxState")));
            this.dced2PaFName.Size = new System.Drawing.Size(191, 18);
            this.dced2PaFName.TabIndex = 15;
            this.dced2PaFName.Tag = "2PaFName";
            // 
            // dced2PaMInit
            // 
            this.dced2PaMInit.Location = new System.Drawing.Point(272, 273);
            this.dced2PaMInit.Name = "dced2PaMInit";
            this.dced2PaMInit.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced2PaMInit.OcxState")));
            this.dced2PaMInit.Size = new System.Drawing.Size(39, 18);
            this.dced2PaMInit.TabIndex = 17;
            this.dced2PaMInit.Tag = "2PaMInit";
            // 
            // dced4InsLNam
            // 
            this.dced4InsLNam.Location = new System.Drawing.Point(364, 240);
            this.dced4InsLNam.Name = "dced4InsLNam";
            this.dced4InsLNam.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced4InsLNam.OcxState")));
            this.dced4InsLNam.Size = new System.Drawing.Size(236, 18);
            this.dced4InsLNam.TabIndex = 37;
            this.dced4InsLNam.Tag = "4InsLNam";
            // 
            // dced4InsFNam
            // 
            this.dced4InsFNam.Location = new System.Drawing.Point(364, 273);
            this.dced4InsFNam.Name = "dced4InsFNam";
            this.dced4InsFNam.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced4InsFNam.OcxState")));
            this.dced4InsFNam.Size = new System.Drawing.Size(191, 18);
            this.dced4InsFNam.TabIndex = 39;
            this.dced4InsFNam.Tag = "4InsFNam";
            // 
            // dced4InsMIni
            // 
            this.dced4InsMIni.Location = new System.Drawing.Point(561, 273);
            this.dced4InsMIni.Name = "dced4InsMIni";
            this.dced4InsMIni.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced4InsMIni.OcxState")));
            this.dced4InsMIni.Size = new System.Drawing.Size(39, 18);
            this.dced4InsMIni.TabIndex = 41;
            this.dced4InsMIni.Tag = "4InsMIni";
            // 
            // dcim17ReCred
            // 
            this.dcim17ReCred.Location = new System.Drawing.Point(894, 3311);
            this.dcim17ReCred.Name = "dcim17ReCred";
            this.dcim17ReCred.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim17ReCred.OcxState")));
            this.dcim17ReCred.Size = new System.Drawing.Size(130, 23);
            this.dcim17ReCred.TabIndex = 568;
            this.dcim17ReCred.TabStop = false;
            this.dcim17ReCred.Tag = "17ReCred";
            // 
            // dced17ReCred
            // 
            this.dced17ReCred.Location = new System.Drawing.Point(896, 3335);
            this.dced17ReCred.Name = "dced17ReCred";
            this.dced17ReCred.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced17ReCred.OcxState")));
            this.dced17ReCred.Size = new System.Drawing.Size(125, 23);
            this.dced17ReCred.TabIndex = 569;
            this.dced17ReCred.Tag = "17ReCred";
            // 
            // dcim17ReSufx
            // 
            this.dcim17ReSufx.Location = new System.Drawing.Point(1053, 3311);
            this.dcim17ReSufx.Name = "dcim17ReSufx";
            this.dcim17ReSufx.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim17ReSufx.OcxState")));
            this.dcim17ReSufx.Size = new System.Drawing.Size(130, 23);
            this.dcim17ReSufx.TabIndex = 571;
            this.dcim17ReSufx.TabStop = false;
            this.dcim17ReSufx.Tag = "17ReSufx";
            // 
            // dced17ReSufx
            // 
            this.dced17ReSufx.Location = new System.Drawing.Point(1054, 3335);
            this.dced17ReSufx.Name = "dced17ReSufx";
            this.dced17ReSufx.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced17ReSufx.OcxState")));
            this.dced17ReSufx.Size = new System.Drawing.Size(125, 23);
            this.dced17ReSufx.TabIndex = 572;
            this.dced17ReSufx.Tag = "17ReSufx";
            // 
            // dced31aPhLNm
            // 
            this.dced31aPhLNm.Location = new System.Drawing.Point(23, 1382);
            this.dced31aPhLNm.Name = "dced31aPhLNm";
            this.dced31aPhLNm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced31aPhLNm.OcxState")));
            this.dced31aPhLNm.Size = new System.Drawing.Size(250, 18);
            this.dced31aPhLNm.TabIndex = 255;
            this.dced31aPhLNm.Tag = "31aPhLNm";
            // 
            // dced31aPhFNm
            // 
            this.dced31aPhFNm.Location = new System.Drawing.Point(23, 1416);
            this.dced31aPhFNm.Name = "dced31aPhFNm";
            this.dced31aPhFNm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced31aPhFNm.OcxState")));
            this.dced31aPhFNm.Size = new System.Drawing.Size(203, 18);
            this.dced31aPhFNm.TabIndex = 257;
            this.dced31aPhFNm.Tag = "31aPhFNm";
            // 
            // dced31aPhIni
            // 
            this.dced31aPhIni.Location = new System.Drawing.Point(234, 1416);
            this.dced31aPhIni.Name = "dced31aPhIni";
            this.dced31aPhIni.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced31aPhIni.OcxState")));
            this.dced31aPhIni.Size = new System.Drawing.Size(39, 18);
            this.dced31aPhIni.TabIndex = 259;
            this.dced31aPhIni.Tag = "31aPhIni";
            // 
            // dced32FacNam
            // 
            this.dced32FacNam.Location = new System.Drawing.Point(373, 1395);
            this.dced32FacNam.Name = "dced32FacNam";
            this.dced32FacNam.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced32FacNam.OcxState")));
            this.dced32FacNam.Size = new System.Drawing.Size(250, 18);
            this.dced32FacNam.TabIndex = 267;
            this.dced32FacNam.Tag = "32FacNam";
            // 
            // dced32F1Addr
            // 
            this.dced32F1Addr.Location = new System.Drawing.Point(373, 1430);
            this.dced32F1Addr.Name = "dced32F1Addr";
            this.dced32F1Addr.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced32F1Addr.OcxState")));
            this.dced32F1Addr.Size = new System.Drawing.Size(250, 18);
            this.dced32F1Addr.TabIndex = 269;
            this.dced32F1Addr.Tag = "32F1Addr";
            // 
            // dced32F2Addr
            // 
            this.dced32F2Addr.Location = new System.Drawing.Point(373, 1465);
            this.dced32F2Addr.Name = "dced32F2Addr";
            this.dced32F2Addr.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced32F2Addr.OcxState")));
            this.dced32F2Addr.Size = new System.Drawing.Size(250, 18);
            this.dced32F2Addr.TabIndex = 271;
            this.dced32F2Addr.Tag = "32F2Addr";
            // 
            // dced32FacCit
            // 
            this.dced32FacCit.Location = new System.Drawing.Point(373, 1500);
            this.dced32FacCit.Name = "dced32FacCit";
            this.dced32FacCit.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced32FacCit.OcxState")));
            this.dced32FacCit.Size = new System.Drawing.Size(179, 18);
            this.dced32FacCit.TabIndex = 273;
            this.dced32FacCit.Tag = "32FacCit";
            // 
            // dced32FacSta
            // 
            this.dced32FacSta.Location = new System.Drawing.Point(560, 1500);
            this.dced32FacSta.Name = "dced32FacSta";
            this.dced32FacSta.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced32FacSta.OcxState")));
            this.dced32FacSta.Size = new System.Drawing.Size(62, 18);
            this.dced32FacSta.TabIndex = 279;
            this.dced32FacSta.Tag = "32FacSta";
            // 
            // dced32FacZip
            // 
            this.dced32FacZip.Location = new System.Drawing.Point(373, 1535);
            this.dced32FacZip.Name = "dced32FacZip";
            this.dced32FacZip.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced32FacZip.OcxState")));
            this.dced32FacZip.Size = new System.Drawing.Size(250, 18);
            this.dced32FacZip.TabIndex = 275;
            this.dced32FacZip.Tag = "32FacZip";
            // 
            // dced33PhBNam
            // 
            this.dced33PhBNam.Location = new System.Drawing.Point(716, 1395);
            this.dced33PhBNam.Name = "dced33PhBNam";
            this.dced33PhBNam.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced33PhBNam.OcxState")));
            this.dced33PhBNam.Size = new System.Drawing.Size(250, 18);
            this.dced33PhBNam.TabIndex = 288;
            this.dced33PhBNam.Tag = "33PhBNam";
            // 
            // dced33Ph1Add
            // 
            this.dced33Ph1Add.Location = new System.Drawing.Point(716, 1430);
            this.dced33Ph1Add.Name = "dced33Ph1Add";
            this.dced33Ph1Add.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced33Ph1Add.OcxState")));
            this.dced33Ph1Add.Size = new System.Drawing.Size(250, 18);
            this.dced33Ph1Add.TabIndex = 290;
            this.dced33Ph1Add.Tag = "33Ph1Add";
            // 
            // dced33Ph2Add
            // 
            this.dced33Ph2Add.Location = new System.Drawing.Point(716, 1465);
            this.dced33Ph2Add.Name = "dced33Ph2Add";
            this.dced33Ph2Add.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced33Ph2Add.OcxState")));
            this.dced33Ph2Add.Size = new System.Drawing.Size(250, 18);
            this.dced33Ph2Add.TabIndex = 292;
            this.dced33Ph2Add.Tag = "33Ph2Add";
            // 
            // dced33PhCity
            // 
            this.dced33PhCity.Location = new System.Drawing.Point(716, 1500);
            this.dced33PhCity.Name = "dced33PhCity";
            this.dced33PhCity.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced33PhCity.OcxState")));
            this.dced33PhCity.Size = new System.Drawing.Size(179, 18);
            this.dced33PhCity.TabIndex = 294;
            this.dced33PhCity.Tag = "33PhCity";
            // 
            // dced33PhStat
            // 
            this.dced33PhStat.Location = new System.Drawing.Point(902, 1500);
            this.dced33PhStat.Name = "dced33PhStat";
            this.dced33PhStat.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced33PhStat.OcxState")));
            this.dced33PhStat.Size = new System.Drawing.Size(62, 18);
            this.dced33PhStat.TabIndex = 296;
            this.dced33PhStat.Tag = "33PhStat";
            // 
            // dced33PhyZip
            // 
            this.dced33PhyZip.Location = new System.Drawing.Point(716, 1535);
            this.dced33PhyZip.Name = "dced33PhyZip";
            this.dced33PhyZip.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced33PhyZip.OcxState")));
            this.dced33PhyZip.Size = new System.Drawing.Size(250, 18);
            this.dced33PhyZip.TabIndex = 298;
            this.dced33PhyZip.Tag = "33PhyZip";
            // 
            // dced33PhyNPI
            // 
            this.dced33PhyNPI.Location = new System.Drawing.Point(716, 1570);
            this.dced33PhyNPI.Name = "dced33PhyNPI";
            this.dced33PhyNPI.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced33PhyNPI.OcxState")));
            this.dced33PhyNPI.Size = new System.Drawing.Size(125, 18);
            this.dced33PhyNPI.TabIndex = 300;
            this.dced33PhyNPI.Tag = "33PhyNPI";
            // 
            // dced33PhyID
            // 
            this.dced33PhyID.Location = new System.Drawing.Point(848, 1570);
            this.dced33PhyID.Name = "dced33PhyID";
            this.dced33PhyID.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced33PhyID.OcxState")));
            this.dced33PhyID.Size = new System.Drawing.Size(117, 18);
            this.dced33PhyID.TabIndex = 302;
            this.dced33PhyID.Tag = "33PhyID";
            // 
            // lbReferenceId
            // 
            this.lbReferenceId.BackColor = System.Drawing.Color.Beige;
            this.lbReferenceId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbReferenceId.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbReferenceId.Location = new System.Drawing.Point(624, 849);
            this.lbReferenceId.Name = "lbReferenceId";
            this.lbReferenceId.Size = new System.Drawing.Size(94, 16);
            this.lbReferenceId.TabIndex = 216;
            this.lbReferenceId.Tag = "ReferenceId";
            this.lbReferenceId.Text = "Reference ID";
            this.lbReferenceId.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Lavender;
            this.label3.Location = new System.Drawing.Point(72, 227);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "Last Name";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Lavender;
            this.label5.Location = new System.Drawing.Point(72, 260);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 13);
            this.label5.TabIndex = 14;
            this.label5.Text = "First Name";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Lavender;
            this.label6.Location = new System.Drawing.Point(269, 260);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(19, 13);
            this.label6.TabIndex = 16;
            this.label6.Text = "MI";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Lavender;
            this.label7.Location = new System.Drawing.Point(72, 293);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(88, 13);
            this.label7.TabIndex = 18;
            this.label7.Text = "Patient\'s Address";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Lavender;
            this.label8.Location = new System.Drawing.Point(72, 326);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(24, 13);
            this.label8.TabIndex = 20;
            this.label8.Text = "City";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Lavender;
            this.label9.Location = new System.Drawing.Point(269, 326);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(32, 13);
            this.label9.TabIndex = 22;
            this.label9.Text = "State";
            this.label9.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Lavender;
            this.label10.Location = new System.Drawing.Point(72, 359);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(50, 13);
            this.label10.TabIndex = 24;
            this.label10.Text = "Zip Code";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.Lavender;
            this.label18.Location = new System.Drawing.Point(361, 227);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(58, 13);
            this.label18.TabIndex = 36;
            this.label18.Text = "Last Name";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.Lavender;
            this.label19.Location = new System.Drawing.Point(361, 260);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(57, 13);
            this.label19.TabIndex = 38;
            this.label19.Text = "First Name";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.Lavender;
            this.label20.Location = new System.Drawing.Point(361, 293);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(88, 13);
            this.label20.TabIndex = 42;
            this.label20.Text = "Patient\'s Address";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.Lavender;
            this.label21.Location = new System.Drawing.Point(558, 260);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(19, 13);
            this.label21.TabIndex = 40;
            this.label21.Text = "MI";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.Lavender;
            this.label22.Location = new System.Drawing.Point(361, 326);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(24, 13);
            this.label22.TabIndex = 44;
            this.label22.Text = "City";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.Lavender;
            this.label23.Location = new System.Drawing.Point(558, 326);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(32, 13);
            this.label23.TabIndex = 46;
            this.label23.Text = "State";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.Lavender;
            this.label24.Location = new System.Drawing.Point(361, 359);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(50, 13);
            this.label24.TabIndex = 48;
            this.label24.Text = "Zip Code";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.Color.Lavender;
            this.label25.Location = new System.Drawing.Point(467, 359);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(58, 13);
            this.label25.TabIndex = 50;
            this.label25.Text = "Telephone";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(22, 1369);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(58, 13);
            this.label32.TabIndex = 254;
            this.label32.Text = "Last Name";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(22, 1403);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(57, 13);
            this.label33.TabIndex = 256;
            this.label33.Text = "First Name";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(231, 1402);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(19, 13);
            this.label34.TabIndex = 258;
            this.label34.Text = "MI";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(370, 1381);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(70, 13);
            this.label35.TabIndex = 266;
            this.label35.Text = "Facility Name";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(370, 1416);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(54, 13);
            this.label36.TabIndex = 268;
            this.label36.Text = "Address 1";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(370, 1451);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(54, 13);
            this.label37.TabIndex = 270;
            this.label37.Text = "Address 2";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(370, 1486);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(24, 13);
            this.label38.TabIndex = 272;
            this.label38.Text = "City";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(557, 1486);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(32, 13);
            this.label39.TabIndex = 278;
            this.label39.Text = "State";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(370, 1521);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(50, 13);
            this.label40.TabIndex = 274;
            this.label40.Text = "Zip Code";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(370, 1556);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(25, 13);
            this.label41.TabIndex = 276;
            this.label41.Text = "NPI";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(502, 1556);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(18, 13);
            this.label42.TabIndex = 280;
            this.label42.Text = "ID";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(714, 1381);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(83, 13);
            this.label43.TabIndex = 287;
            this.label43.Text = "Physician Name";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(714, 1416);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(54, 13);
            this.label44.TabIndex = 289;
            this.label44.Text = "Address 1";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(714, 1451);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(54, 13);
            this.label45.TabIndex = 291;
            this.label45.Text = "Address 2";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(714, 1486);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(24, 13);
            this.label46.TabIndex = 293;
            this.label46.Text = "City";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(899, 1486);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(32, 13);
            this.label47.TabIndex = 295;
            this.label47.Text = "State";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(714, 1521);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(50, 13);
            this.label48.TabIndex = 297;
            this.label48.Text = "Zip Code";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(714, 1556);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(25, 13);
            this.label49.TabIndex = 299;
            this.label49.Text = "NPI";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(845, 1556);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(30, 13);
            this.label50.TabIndex = 301;
            this.label50.Text = "GRP";
            // 
            // lbDateFrom
            // 
            this.lbDateFrom.BackColor = System.Drawing.Color.Beige;
            this.lbDateFrom.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDateFrom.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDateFrom.Location = new System.Drawing.Point(23, 866);
            this.lbDateFrom.Name = "lbDateFrom";
            this.lbDateFrom.Size = new System.Drawing.Size(137, 16);
            this.lbDateFrom.TabIndex = 220;
            this.lbDateFrom.Tag = "DateFrom";
            this.lbDateFrom.Text = "Dates of Service (from-to)";
            // 
            // lbPlaceofService
            // 
            this.lbPlaceofService.BackColor = System.Drawing.Color.Beige;
            this.lbPlaceofService.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbPlaceofService.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPlaceofService.Location = new System.Drawing.Point(160, 866);
            this.lbPlaceofService.Name = "lbPlaceofService";
            this.lbPlaceofService.Size = new System.Drawing.Size(37, 16);
            this.lbPlaceofService.TabIndex = 221;
            this.lbPlaceofService.Tag = "PlaceofService";
            this.lbPlaceofService.Text = "POS";
            this.lbPlaceofService.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lbTypeofService
            // 
            this.lbTypeofService.BackColor = System.Drawing.Color.Beige;
            this.lbTypeofService.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbTypeofService.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTypeofService.Location = new System.Drawing.Point(197, 866);
            this.lbTypeofService.Name = "lbTypeofService";
            this.lbTypeofService.Size = new System.Drawing.Size(40, 16);
            this.lbTypeofService.TabIndex = 222;
            this.lbTypeofService.Tag = "TypeofService";
            this.lbTypeofService.Text = "EMG";
            this.lbTypeofService.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lbCPT_Code
            // 
            this.lbCPT_Code.BackColor = System.Drawing.Color.Beige;
            this.lbCPT_Code.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbCPT_Code.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCPT_Code.Location = new System.Drawing.Point(237, 866);
            this.lbCPT_Code.Name = "lbCPT_Code";
            this.lbCPT_Code.Size = new System.Drawing.Size(140, 16);
            this.lbCPT_Code.TabIndex = 223;
            this.lbCPT_Code.Tag = "CPT_Code";
            this.lbCPT_Code.Text = "Procedures/Modifiers";
            this.lbCPT_Code.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lbDiagPointer
            // 
            this.lbDiagPointer.BackColor = System.Drawing.Color.Beige;
            this.lbDiagPointer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDiagPointer.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDiagPointer.Location = new System.Drawing.Point(377, 866);
            this.lbDiagPointer.Name = "lbDiagPointer";
            this.lbDiagPointer.Size = new System.Drawing.Size(41, 16);
            this.lbDiagPointer.TabIndex = 224;
            this.lbDiagPointer.Tag = "DiagPointer";
            this.lbDiagPointer.Text = "Diag";
            this.lbDiagPointer.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lbCharges
            // 
            this.lbCharges.BackColor = System.Drawing.Color.Beige;
            this.lbCharges.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbCharges.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCharges.Location = new System.Drawing.Point(418, 866);
            this.lbCharges.Name = "lbCharges";
            this.lbCharges.Size = new System.Drawing.Size(83, 16);
            this.lbCharges.TabIndex = 225;
            this.lbCharges.Tag = "Charges";
            this.lbCharges.Text = "Charges";
            this.lbCharges.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lbDays_Units
            // 
            this.lbDays_Units.BackColor = System.Drawing.Color.Beige;
            this.lbDays_Units.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDays_Units.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDays_Units.Location = new System.Drawing.Point(501, 866);
            this.lbDays_Units.Name = "lbDays_Units";
            this.lbDays_Units.Size = new System.Drawing.Size(41, 16);
            this.lbDays_Units.TabIndex = 226;
            this.lbDays_Units.Tag = "Days_Units";
            this.lbDays_Units.Text = "Days";
            this.lbDays_Units.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lbNPI
            // 
            this.lbNPI.BackColor = System.Drawing.Color.Beige;
            this.lbNPI.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbNPI.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNPI.Location = new System.Drawing.Point(624, 866);
            this.lbNPI.Name = "lbNPI";
            this.lbNPI.Size = new System.Drawing.Size(94, 16);
            this.lbNPI.TabIndex = 228;
            this.lbNPI.Tag = "NPI";
            this.lbNPI.Text = "NPI";
            this.lbNPI.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // panLINEITEM
            // 
            this.panLINEITEM.AutoScroll = true;
            this.panLINEITEM.BackColor = System.Drawing.Color.Beige;
            this.panLINEITEM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panLINEITEM.Controls.Add(this.dcimNDCQty);
            this.panLINEITEM.Controls.Add(this.dcedNDCQty);
            this.panLINEITEM.Controls.Add(this.dcimEPSDTcode);
            this.panLINEITEM.Controls.Add(this.dcedEPSDTcode);
            this.panLINEITEM.Controls.Add(this.dcimEPSD);
            this.panLINEITEM.Controls.Add(this.dcedEPSD);
            this.panLINEITEM.Controls.Add(this.dcimCharges);
            this.panLINEITEM.Controls.Add(this.dcimNDCType);
            this.panLINEITEM.Controls.Add(this.dcedNDCType);
            this.panLINEITEM.Controls.Add(this.dcimNDC);
            this.panLINEITEM.Controls.Add(this.dcedNDC);
            this.panLINEITEM.Controls.Add(this.dcimEMG_C);
            this.panLINEITEM.Controls.Add(this.dcedEMG_C);
            this.panLINEITEM.Controls.Add(this.dcimReferenceId);
            this.panLINEITEM.Controls.Add(this.dcedReferenceId);
            this.panLINEITEM.Controls.Add(this.dcimDateFrom);
            this.panLINEITEM.Controls.Add(this.dcedDateFrom);
            this.panLINEITEM.Controls.Add(this.dcimDateThru);
            this.panLINEITEM.Controls.Add(this.dcedDateThru);
            this.panLINEITEM.Controls.Add(this.dcimPlaceofService);
            this.panLINEITEM.Controls.Add(this.dcedPlaceofService);
            this.panLINEITEM.Controls.Add(this.dcimCPT_Code);
            this.panLINEITEM.Controls.Add(this.dcedCPT_Code);
            this.panLINEITEM.Controls.Add(this.dcimModifiers);
            this.panLINEITEM.Controls.Add(this.dcedModifiers);
            this.panLINEITEM.Controls.Add(this.dcimDiagPointer);
            this.panLINEITEM.Controls.Add(this.dcedDiagPointer);
            this.panLINEITEM.Controls.Add(this.dcedCharges);
            this.panLINEITEM.Controls.Add(this.dcimDays_Units);
            this.panLINEITEM.Controls.Add(this.dcedDays_Units);
            this.panLINEITEM.Controls.Add(this.dcimQualifier);
            this.panLINEITEM.Controls.Add(this.dcedQualifier);
            this.panLINEITEM.Controls.Add(this.dcimNPI);
            this.panLINEITEM.Controls.Add(this.dcedNPI);
            this.panLINEITEM.Controls.Add(this.dcedInfo);
            this.panLINEITEM.Controls.Add(this.dcimInfo);
            this.panLINEITEM.Location = new System.Drawing.Point(20, 883);
            this.panLINEITEM.Name = "panLINEITEM";
            this.panLINEITEM.Size = new System.Drawing.Size(991, 293);
            this.panLINEITEM.TabIndex = 227;
            this.panLINEITEM.Tag = "LINEITEM";
            // 
            // dcimNDCQty
            // 
            this.dcimNDCQty.Location = new System.Drawing.Point(873, 3);
            this.dcimNDCQty.Name = "dcimNDCQty";
            this.dcimNDCQty.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimNDCQty.OcxState")));
            this.dcimNDCQty.Size = new System.Drawing.Size(105, 18);
            this.dcimNDCQty.TabIndex = 34;
            this.dcimNDCQty.TabStop = false;
            this.dcimNDCQty.Tag = "NDCQty";
            // 
            // dcedNDCQty
            // 
            this.dcedNDCQty.Location = new System.Drawing.Point(873, 20);
            this.dcedNDCQty.Name = "dcedNDCQty";
            this.dcedNDCQty.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedNDCQty.OcxState")));
            this.dcedNDCQty.Size = new System.Drawing.Size(105, 18);
            this.dcedNDCQty.TabIndex = 35;
            this.dcedNDCQty.Tag = "NDCQty";
            // 
            // dcimEPSDTcode
            // 
            this.dcimEPSDTcode.Location = new System.Drawing.Point(549, 3);
            this.dcimEPSDTcode.Name = "dcimEPSDTcode";
            this.dcimEPSDTcode.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimEPSDTcode.OcxState")));
            this.dcimEPSDTcode.Size = new System.Drawing.Size(15, 18);
            this.dcimEPSDTcode.TabIndex = 24;
            this.dcimEPSDTcode.TabStop = false;
            this.dcimEPSDTcode.Tag = "EPSDTcode";
            // 
            // dcedEPSDTcode
            // 
            this.dcedEPSDTcode.Location = new System.Drawing.Point(549, 20);
            this.dcedEPSDTcode.Name = "dcedEPSDTcode";
            this.dcedEPSDTcode.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedEPSDTcode.OcxState")));
            this.dcedEPSDTcode.Size = new System.Drawing.Size(15, 18);
            this.dcedEPSDTcode.TabIndex = 25;
            this.dcedEPSDTcode.Tag = "EPSDTcode";
            // 
            // dcimEPSD
            // 
            this.dcimEPSD.Location = new System.Drawing.Point(523, 38);
            this.dcimEPSD.Name = "dcimEPSD";
            this.dcimEPSD.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimEPSD.OcxState")));
            this.dcimEPSD.Size = new System.Drawing.Size(41, 18);
            this.dcimEPSD.TabIndex = 18;
            this.dcimEPSD.TabStop = false;
            this.dcimEPSD.Tag = "EPSD";
            // 
            // dcedEPSD
            // 
            this.dcedEPSD.Location = new System.Drawing.Point(523, 55);
            this.dcedEPSD.Name = "dcedEPSD";
            this.dcedEPSD.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedEPSD.OcxState")));
            this.dcedEPSD.Size = new System.Drawing.Size(41, 18);
            this.dcedEPSD.TabIndex = 19;
            this.dcedEPSD.Tag = "EPSD";
            // 
            // dcimCharges
            // 
            this.dcimCharges.Location = new System.Drawing.Point(399, 38);
            this.dcimCharges.Name = "dcimCharges";
            this.dcimCharges.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimCharges.OcxState")));
            this.dcimCharges.Size = new System.Drawing.Size(83, 18);
            this.dcimCharges.TabIndex = 14;
            this.dcimCharges.TabStop = false;
            this.dcimCharges.Tag = "Charges";
            // 
            // dcimNDCType
            // 
            this.dcimNDCType.Location = new System.Drawing.Point(805, 3);
            this.dcimNDCType.Name = "dcimNDCType";
            this.dcimNDCType.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimNDCType.OcxState")));
            this.dcimNDCType.Size = new System.Drawing.Size(68, 18);
            this.dcimNDCType.TabIndex = 32;
            this.dcimNDCType.TabStop = false;
            this.dcimNDCType.Tag = "NDCType";
            // 
            // dcedNDCType
            // 
            this.dcedNDCType.Location = new System.Drawing.Point(805, 20);
            this.dcedNDCType.Name = "dcedNDCType";
            this.dcedNDCType.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedNDCType.OcxState")));
            this.dcedNDCType.Size = new System.Drawing.Size(68, 18);
            this.dcedNDCType.TabIndex = 33;
            this.dcedNDCType.Tag = "NDCType";
            // 
            // dcimNDC
            // 
            this.dcimNDC.Location = new System.Drawing.Point(702, 3);
            this.dcimNDC.Name = "dcimNDC";
            this.dcimNDC.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimNDC.OcxState")));
            this.dcimNDC.Size = new System.Drawing.Size(103, 18);
            this.dcimNDC.TabIndex = 30;
            this.dcimNDC.TabStop = false;
            this.dcimNDC.Tag = "NDC";
            // 
            // dcedNDC
            // 
            this.dcedNDC.Location = new System.Drawing.Point(702, 20);
            this.dcedNDC.Name = "dcedNDC";
            this.dcedNDC.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedNDC.OcxState")));
            this.dcedNDC.Size = new System.Drawing.Size(103, 18);
            this.dcedNDC.TabIndex = 31;
            this.dcedNDC.Tag = "NDC";
            // 
            // dcimEMG_C
            // 
            this.dcimEMG_C.Location = new System.Drawing.Point(176, 38);
            this.dcimEMG_C.Name = "dcimEMG_C";
            this.dcimEMG_C.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimEMG_C.OcxState")));
            this.dcimEMG_C.Size = new System.Drawing.Size(26, 18);
            this.dcimEMG_C.TabIndex = 6;
            this.dcimEMG_C.TabStop = false;
            this.dcimEMG_C.Tag = "EMG_C";
            // 
            // dcedEMG_C
            // 
            this.dcedEMG_C.Location = new System.Drawing.Point(176, 55);
            this.dcedEMG_C.Name = "dcedEMG_C";
            this.dcedEMG_C.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedEMG_C.OcxState")));
            this.dcedEMG_C.Size = new System.Drawing.Size(26, 18);
            this.dcedEMG_C.TabIndex = 7;
            this.dcedEMG_C.Tag = "EMG_C";
            this.dcedEMG_C.Change += new System.EventHandler(this.dcedEMG_C_Change);
            // 
            // dcimReferenceId
            // 
            this.dcimReferenceId.Location = new System.Drawing.Point(600, 3);
            this.dcimReferenceId.Name = "dcimReferenceId";
            this.dcimReferenceId.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimReferenceId.OcxState")));
            this.dcimReferenceId.Size = new System.Drawing.Size(96, 18);
            this.dcimReferenceId.TabIndex = 28;
            this.dcimReferenceId.TabStop = false;
            this.dcimReferenceId.Tag = "ReferenceId";
            this.dcimReferenceId.Visible = false;
            // 
            // dcedReferenceId
            // 
            this.dcedReferenceId.Location = new System.Drawing.Point(600, 20);
            this.dcedReferenceId.Name = "dcedReferenceId";
            this.dcedReferenceId.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedReferenceId.OcxState")));
            this.dcedReferenceId.Size = new System.Drawing.Size(96, 18);
            this.dcedReferenceId.TabIndex = 29;
            this.dcedReferenceId.Tag = "ReferenceId";
            this.dcedReferenceId.Visible = false;
            // 
            // dcimDateFrom
            // 
            this.dcimDateFrom.Location = new System.Drawing.Point(0, 38);
            this.dcimDateFrom.Name = "dcimDateFrom";
            this.dcimDateFrom.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimDateFrom.OcxState")));
            this.dcimDateFrom.Size = new System.Drawing.Size(75, 18);
            this.dcimDateFrom.TabIndex = 0;
            this.dcimDateFrom.TabStop = false;
            this.dcimDateFrom.Tag = "DateFrom";
            // 
            // dcedDateFrom
            // 
            this.dcedDateFrom.Location = new System.Drawing.Point(0, 55);
            this.dcedDateFrom.Name = "dcedDateFrom";
            this.dcedDateFrom.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedDateFrom.OcxState")));
            this.dcedDateFrom.Size = new System.Drawing.Size(75, 18);
            this.dcedDateFrom.TabIndex = 1;
            this.dcedDateFrom.Tag = "DateFrom";
            // 
            // dcimDateThru
            // 
            this.dcimDateThru.Location = new System.Drawing.Point(75, 38);
            this.dcimDateThru.Name = "dcimDateThru";
            this.dcimDateThru.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimDateThru.OcxState")));
            this.dcimDateThru.Size = new System.Drawing.Size(75, 18);
            this.dcimDateThru.TabIndex = 2;
            this.dcimDateThru.TabStop = false;
            this.dcimDateThru.Tag = "DateThru";
            // 
            // dcedDateThru
            // 
            this.dcedDateThru.Location = new System.Drawing.Point(75, 55);
            this.dcedDateThru.Name = "dcedDateThru";
            this.dcedDateThru.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedDateThru.OcxState")));
            this.dcedDateThru.Size = new System.Drawing.Size(75, 18);
            this.dcedDateThru.TabIndex = 3;
            this.dcedDateThru.Tag = "DateThru";
            // 
            // dcimPlaceofService
            // 
            this.dcimPlaceofService.Location = new System.Drawing.Point(150, 38);
            this.dcimPlaceofService.Name = "dcimPlaceofService";
            this.dcimPlaceofService.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimPlaceofService.OcxState")));
            this.dcimPlaceofService.Size = new System.Drawing.Size(26, 18);
            this.dcimPlaceofService.TabIndex = 4;
            this.dcimPlaceofService.TabStop = false;
            this.dcimPlaceofService.Tag = "PlaceofService";
            // 
            // dcedPlaceofService
            // 
            this.dcedPlaceofService.Location = new System.Drawing.Point(150, 55);
            this.dcedPlaceofService.Name = "dcedPlaceofService";
            this.dcedPlaceofService.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedPlaceofService.OcxState")));
            this.dcedPlaceofService.Size = new System.Drawing.Size(26, 18);
            this.dcedPlaceofService.TabIndex = 5;
            this.dcedPlaceofService.Tag = "PlaceofService";
            // 
            // dcimCPT_Code
            // 
            this.dcimCPT_Code.Location = new System.Drawing.Point(202, 38);
            this.dcimCPT_Code.Name = "dcimCPT_Code";
            this.dcimCPT_Code.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimCPT_Code.OcxState")));
            this.dcimCPT_Code.Size = new System.Drawing.Size(66, 18);
            this.dcimCPT_Code.TabIndex = 8;
            this.dcimCPT_Code.TabStop = false;
            this.dcimCPT_Code.Tag = "CPT_Code";
            // 
            // dcedCPT_Code
            // 
            this.dcedCPT_Code.Location = new System.Drawing.Point(202, 55);
            this.dcedCPT_Code.Name = "dcedCPT_Code";
            this.dcedCPT_Code.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedCPT_Code.OcxState")));
            this.dcedCPT_Code.Size = new System.Drawing.Size(66, 18);
            this.dcedCPT_Code.TabIndex = 9;
            this.dcedCPT_Code.Tag = "CPT_Code";
            // 
            // dcimModifiers
            // 
            this.dcimModifiers.Location = new System.Drawing.Point(268, 38);
            this.dcimModifiers.Name = "dcimModifiers";
            this.dcimModifiers.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimModifiers.OcxState")));
            this.dcimModifiers.Size = new System.Drawing.Size(88, 18);
            this.dcimModifiers.TabIndex = 10;
            this.dcimModifiers.TabStop = false;
            this.dcimModifiers.Tag = "Modifiers";
            // 
            // dcedModifiers
            // 
            this.dcedModifiers.Location = new System.Drawing.Point(268, 55);
            this.dcedModifiers.Name = "dcedModifiers";
            this.dcedModifiers.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedModifiers.OcxState")));
            this.dcedModifiers.Size = new System.Drawing.Size(88, 18);
            this.dcedModifiers.TabIndex = 11;
            this.dcedModifiers.Tag = "Modifiers";
            // 
            // dcimDiagPointer
            // 
            this.dcimDiagPointer.Location = new System.Drawing.Point(356, 38);
            this.dcimDiagPointer.Name = "dcimDiagPointer";
            this.dcimDiagPointer.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimDiagPointer.OcxState")));
            this.dcimDiagPointer.Size = new System.Drawing.Size(43, 18);
            this.dcimDiagPointer.TabIndex = 12;
            this.dcimDiagPointer.TabStop = false;
            this.dcimDiagPointer.Tag = "DiagPointer";
            // 
            // dcedDiagPointer
            // 
            this.dcedDiagPointer.Location = new System.Drawing.Point(356, 55);
            this.dcedDiagPointer.Name = "dcedDiagPointer";
            this.dcedDiagPointer.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedDiagPointer.OcxState")));
            this.dcedDiagPointer.Size = new System.Drawing.Size(43, 18);
            this.dcedDiagPointer.TabIndex = 13;
            this.dcedDiagPointer.Tag = "DiagPointer";
            // 
            // dcedCharges
            // 
            this.dcedCharges.Location = new System.Drawing.Point(399, 55);
            this.dcedCharges.Name = "dcedCharges";
            this.dcedCharges.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedCharges.OcxState")));
            this.dcedCharges.Size = new System.Drawing.Size(83, 18);
            this.dcedCharges.TabIndex = 15;
            this.dcedCharges.Tag = "Charges";
            // 
            // dcimDays_Units
            // 
            this.dcimDays_Units.Location = new System.Drawing.Point(482, 38);
            this.dcimDays_Units.Name = "dcimDays_Units";
            this.dcimDays_Units.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimDays_Units.OcxState")));
            this.dcimDays_Units.Size = new System.Drawing.Size(41, 18);
            this.dcimDays_Units.TabIndex = 16;
            this.dcimDays_Units.TabStop = false;
            this.dcimDays_Units.Tag = "Days_Units";
            // 
            // dcedDays_Units
            // 
            this.dcedDays_Units.Location = new System.Drawing.Point(482, 55);
            this.dcedDays_Units.Name = "dcedDays_Units";
            this.dcedDays_Units.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedDays_Units.OcxState")));
            this.dcedDays_Units.Size = new System.Drawing.Size(41, 18);
            this.dcedDays_Units.TabIndex = 17;
            this.dcedDays_Units.Tag = "Days_Units";
            // 
            // dcimQualifier
            // 
            this.dcimQualifier.Location = new System.Drawing.Point(569, 3);
            this.dcimQualifier.Name = "dcimQualifier";
            this.dcimQualifier.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimQualifier.OcxState")));
            this.dcimQualifier.Size = new System.Drawing.Size(31, 18);
            this.dcimQualifier.TabIndex = 26;
            this.dcimQualifier.TabStop = false;
            this.dcimQualifier.Tag = "Qualifier";
            // 
            // dcedQualifier
            // 
            this.dcedQualifier.Location = new System.Drawing.Point(569, 20);
            this.dcedQualifier.Name = "dcedQualifier";
            this.dcedQualifier.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedQualifier.OcxState")));
            this.dcedQualifier.Size = new System.Drawing.Size(31, 18);
            this.dcedQualifier.TabIndex = 27;
            this.dcedQualifier.Tag = "Qualifier";
            // 
            // dcimNPI
            // 
            this.dcimNPI.Location = new System.Drawing.Point(600, 38);
            this.dcimNPI.Name = "dcimNPI";
            this.dcimNPI.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimNPI.OcxState")));
            this.dcimNPI.Size = new System.Drawing.Size(96, 18);
            this.dcimNPI.TabIndex = 20;
            this.dcimNPI.TabStop = false;
            this.dcimNPI.Tag = "NPI";
            // 
            // dcedNPI
            // 
            this.dcedNPI.Location = new System.Drawing.Point(600, 55);
            this.dcedNPI.Name = "dcedNPI";
            this.dcedNPI.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedNPI.OcxState")));
            this.dcedNPI.Size = new System.Drawing.Size(96, 18);
            this.dcedNPI.TabIndex = 21;
            this.dcedNPI.Tag = "NPI";
            // 
            // dcedInfo
            // 
            this.dcedInfo.Location = new System.Drawing.Point(0, 20);
            this.dcedInfo.Name = "dcedInfo";
            this.dcedInfo.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedInfo.OcxState")));
            this.dcedInfo.Size = new System.Drawing.Size(543, 18);
            this.dcedInfo.TabIndex = 23;
            this.dcedInfo.Tag = "Info";
            // 
            // dcimInfo
            // 
            this.dcimInfo.Location = new System.Drawing.Point(0, 3);
            this.dcimInfo.Name = "dcimInfo";
            this.dcimInfo.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimInfo.OcxState")));
            this.dcimInfo.Size = new System.Drawing.Size(543, 18);
            this.dcimInfo.TabIndex = 22;
            this.dcimInfo.TabStop = false;
            this.dcimInfo.Tag = "Info";
            // 
            // btnDelpbLINEITEM
            // 
            this.btnDelpbLINEITEM.Location = new System.Drawing.Point(147, 1180);
            this.btnDelpbLINEITEM.Name = "btnDelpbLINEITEM";
            this.btnDelpbLINEITEM.Size = new System.Drawing.Size(55, 23);
            this.btnDelpbLINEITEM.TabIndex = 230;
            this.btnDelpbLINEITEM.Tag = "LINEITEM";
            this.btnDelpbLINEITEM.Text = "Delete";
            this.btnDelpbLINEITEM.UseVisualStyleBackColor = true;
            // 
            // btnInsAfterpbLINEITEM
            // 
            this.btnInsAfterpbLINEITEM.Location = new System.Drawing.Point(86, 1180);
            this.btnInsAfterpbLINEITEM.Name = "btnInsAfterpbLINEITEM";
            this.btnInsAfterpbLINEITEM.Size = new System.Drawing.Size(55, 23);
            this.btnInsAfterpbLINEITEM.TabIndex = 229;
            this.btnInsAfterpbLINEITEM.Tag = "LINEITEM";
            this.btnInsAfterpbLINEITEM.Text = "Append";
            this.btnInsAfterpbLINEITEM.UseVisualStyleBackColor = true;
            // 
            // btnInsBeforepbLINEITEM
            // 
            this.btnInsBeforepbLINEITEM.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnInsBeforepbLINEITEM.Location = new System.Drawing.Point(25, 1180);
            this.btnInsBeforepbLINEITEM.Name = "btnInsBeforepbLINEITEM";
            this.btnInsBeforepbLINEITEM.Size = new System.Drawing.Size(55, 23);
            this.btnInsBeforepbLINEITEM.TabIndex = 228;
            this.btnInsBeforepbLINEITEM.Tag = "LINEITEM";
            this.btnInsBeforepbLINEITEM.Text = "Insert";
            this.btnInsBeforepbLINEITEM.UseVisualStyleBackColor = true;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.BackColor = System.Drawing.Color.Lavender;
            this.label31.Location = new System.Drawing.Point(650, 761);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(18, 13);
            this.label31.TabIndex = 185;
            this.label31.Text = "D.";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.BackColor = System.Drawing.Color.Lavender;
            this.label30.Location = new System.Drawing.Point(560, 761);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(17, 13);
            this.label30.TabIndex = 183;
            this.label30.Text = "C.";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.BackColor = System.Drawing.Color.Lavender;
            this.label29.Location = new System.Drawing.Point(468, 761);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(17, 13);
            this.label29.TabIndex = 181;
            this.label29.Text = "B.";
            // 
            // label21_Diag1
            // 
            this.label21_Diag1.AutoSize = true;
            this.label21_Diag1.BackColor = System.Drawing.Color.Lavender;
            this.label21_Diag1.Location = new System.Drawing.Point(376, 761);
            this.label21_Diag1.Name = "label21_Diag1";
            this.label21_Diag1.Size = new System.Drawing.Size(17, 13);
            this.label21_Diag1.TabIndex = 179;
            this.label21_Diag1.Text = "A.";
            // 
            // dcim7IAddStr
            // 
            this.dcim7IAddStr.Location = new System.Drawing.Point(36, 759);
            this.dcim7IAddStr.Name = "dcim7IAddStr";
            this.dcim7IAddStr.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim7IAddStr.OcxState")));
            this.dcim7IAddStr.Size = new System.Drawing.Size(332, 72);
            this.dcim7IAddStr.TabIndex = 178;
            this.dcim7IAddStr.TabStop = false;
            this.dcim7IAddStr.Tag = "21DiSFLD";
            // 
            // lbl7IAddSta
            // 
            this.lbl7IAddSta.AutoSize = true;
            this.lbl7IAddSta.BackColor = System.Drawing.Color.Lavender;
            this.lbl7IAddSta.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl7IAddSta.Location = new System.Drawing.Point(33, 743);
            this.lbl7IAddSta.Name = "lbl7IAddSta";
            this.lbl7IAddSta.Size = new System.Drawing.Size(118, 13);
            this.lbl7IAddSta.TabIndex = 177;
            this.lbl7IAddSta.Tag = "";
            this.lbl7IAddSta.Text = "21. Diagnosis Code";
            // 
            // dced21_Diag1
            // 
            this.dced21_Diag1.Location = new System.Drawing.Point(393, 758);
            this.dced21_Diag1.Name = "dced21_Diag1";
            this.dced21_Diag1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced21_Diag1.OcxState")));
            this.dced21_Diag1.Size = new System.Drawing.Size(70, 18);
            this.dced21_Diag1.TabIndex = 180;
            this.dced21_Diag1.Tag = "21_Diag1";
            // 
            // dced21_Diag2
            // 
            this.dced21_Diag2.Location = new System.Drawing.Point(484, 758);
            this.dced21_Diag2.Name = "dced21_Diag2";
            this.dced21_Diag2.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced21_Diag2.OcxState")));
            this.dced21_Diag2.Size = new System.Drawing.Size(70, 18);
            this.dced21_Diag2.TabIndex = 182;
            this.dced21_Diag2.Tag = "21_Diag2";
            // 
            // dced21_Diag3
            // 
            this.dced21_Diag3.Location = new System.Drawing.Point(575, 758);
            this.dced21_Diag3.Name = "dced21_Diag3";
            this.dced21_Diag3.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced21_Diag3.OcxState")));
            this.dced21_Diag3.Size = new System.Drawing.Size(70, 18);
            this.dced21_Diag3.TabIndex = 184;
            this.dced21_Diag3.Tag = "21_Diag3";
            // 
            // dced21_Diag4
            // 
            this.dced21_Diag4.Location = new System.Drawing.Point(666, 758);
            this.dced21_Diag4.Name = "dced21_Diag4";
            this.dced21_Diag4.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced21_Diag4.OcxState")));
            this.dced21_Diag4.Size = new System.Drawing.Size(70, 18);
            this.dced21_Diag4.TabIndex = 186;
            this.dced21_Diag4.Tag = "21_Diag4";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Lavender;
            this.label1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(888, 605);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 13);
            this.label1.TabIndex = 161;
            this.label1.Tag = "";
            this.label1.Text = "17b. NPI ID";
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Beige;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label2.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(589, 849);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 16);
            this.label2.TabIndex = 215;
            this.label2.Tag = "ReferenceId";
            this.label2.Text = "Qual ID";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.Beige;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label4.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(23, 849);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(541, 16);
            this.label4.TabIndex = 214;
            this.label4.Tag = "Info";
            this.label4.Text = "Service Information";
            this.label4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label4.UseMnemonic = false;
            // 
            // btnSwapNm31
            // 
            this.btnSwapNm31.Image = global::MedicalClaimsPanels.Properties.Resources.sw90neg;
            this.btnSwapNm31.Location = new System.Drawing.Point(279, 1387);
            this.btnSwapNm31.Name = "btnSwapNm31";
            this.btnSwapNm31.Size = new System.Drawing.Size(35, 45);
            this.btnSwapNm31.TabIndex = 260;
            this.btnSwapNm31.UseVisualStyleBackColor = true;
            this.btnSwapNm31.Click += new System.EventHandler(this.btnSwapNm31_Click);
            // 
            // lblcopynm
            // 
            this.lblcopynm.BackColor = System.Drawing.Color.Lavender;
            this.lblcopynm.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcopynm.Location = new System.Drawing.Point(315, 180);
            this.lblcopynm.Name = "lblcopynm";
            this.lblcopynm.Size = new System.Drawing.Size(47, 49);
            this.lblcopynm.TabIndex = 28;
            this.lblcopynm.Text = "Copy Name";
            this.lblcopynm.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCopyAddress
            // 
            this.lblCopyAddress.BackColor = System.Drawing.Color.Lavender;
            this.lblCopyAddress.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCopyAddress.Location = new System.Drawing.Point(309, 276);
            this.lblCopyAddress.Name = "lblCopyAddress";
            this.lblCopyAddress.Size = new System.Drawing.Size(59, 49);
            this.lblCopyAddress.TabIndex = 31;
            this.lblCopyAddress.Text = "Copy Address";
            this.lblCopyAddress.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Lavender;
            this.label11.Location = new System.Drawing.Point(184, 359);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(58, 13);
            this.label11.TabIndex = 26;
            this.label11.Text = "Telephone";
            // 
            // dced5PAddTel
            // 
            this.dced5PAddTel.Location = new System.Drawing.Point(181, 372);
            this.dced5PAddTel.Name = "dced5PAddTel";
            this.dced5PAddTel.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced5PAddTel.OcxState")));
            this.dced5PAddTel.Size = new System.Drawing.Size(130, 18);
            this.dced5PAddTel.TabIndex = 27;
            this.dced5PAddTel.Tag = "5PAddTel";
            // 
            // lblCopyAll
            // 
            this.lblCopyAll.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCopyAll.Location = new System.Drawing.Point(652, 1386);
            this.lblCopyAll.Name = "lblCopyAll";
            this.lblCopyAll.Size = new System.Drawing.Size(47, 49);
            this.lblCopyAll.TabIndex = 282;
            this.lblCopyAll.Text = "Copy All";
            this.lblCopyAll.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button7
            // 
            this.button7.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.Image = global::MedicalClaimsPanels.Properties.Resources.golt;
            this.button7.Location = new System.Drawing.Point(657, 1458);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(35, 32);
            this.button7.TabIndex = 284;
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button6
            // 
            this.button6.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Image = global::MedicalClaimsPanels.Properties.Resources.gort;
            this.button6.Location = new System.Drawing.Point(657, 1427);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(35, 32);
            this.button6.TabIndex = 283;
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // btnCopyAdd2to4
            // 
            this.btnCopyAdd2to4.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCopyAdd2to4.Image = global::MedicalClaimsPanels.Properties.Resources.gort;
            this.btnCopyAdd2to4.Location = new System.Drawing.Point(321, 312);
            this.btnCopyAdd2to4.Name = "btnCopyAdd2to4";
            this.btnCopyAdd2to4.Size = new System.Drawing.Size(35, 32);
            this.btnCopyAdd2to4.TabIndex = 32;
            this.btnCopyAdd2to4.UseVisualStyleBackColor = true;
            this.btnCopyAdd2to4.Click += new System.EventHandler(this.btnCopyAdd2to4_Click);
            // 
            // btnCopyAdd4to2
            // 
            this.btnCopyAdd4to2.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCopyAdd4to2.Image = global::MedicalClaimsPanels.Properties.Resources.golt;
            this.btnCopyAdd4to2.Location = new System.Drawing.Point(321, 343);
            this.btnCopyAdd4to2.Name = "btnCopyAdd4to2";
            this.btnCopyAdd4to2.Size = new System.Drawing.Size(35, 32);
            this.btnCopyAdd4to2.TabIndex = 33;
            this.btnCopyAdd4to2.UseVisualStyleBackColor = true;
            this.btnCopyAdd4to2.Click += new System.EventHandler(this.btnCopyAdd4to2_Click);
            // 
            // btnCopyNm4to2
            // 
            this.btnCopyNm4to2.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCopyNm4to2.Image = global::MedicalClaimsPanels.Properties.Resources.golt;
            this.btnCopyNm4to2.Location = new System.Drawing.Point(321, 247);
            this.btnCopyNm4to2.Name = "btnCopyNm4to2";
            this.btnCopyNm4to2.Size = new System.Drawing.Size(35, 32);
            this.btnCopyNm4to2.TabIndex = 30;
            this.btnCopyNm4to2.UseVisualStyleBackColor = true;
            this.btnCopyNm4to2.Click += new System.EventHandler(this.btnCopyNm4to2_Click);
            // 
            // btnCopyNm2to4
            // 
            this.btnCopyNm2to4.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCopyNm2to4.Image = global::MedicalClaimsPanels.Properties.Resources.gort;
            this.btnCopyNm2to4.Location = new System.Drawing.Point(321, 216);
            this.btnCopyNm2to4.Name = "btnCopyNm2to4";
            this.btnCopyNm2to4.Size = new System.Drawing.Size(35, 32);
            this.btnCopyNm2to4.TabIndex = 29;
            this.btnCopyNm2to4.UseVisualStyleBackColor = true;
            this.btnCopyNm2to4.Click += new System.EventHandler(this.btnCopyNm2to4_Click);
            // 
            // btnSwapNames4
            // 
            this.btnSwapNames4.Image = global::MedicalClaimsPanels.Properties.Resources.sw90neg;
            this.btnSwapNames4.Location = new System.Drawing.Point(606, 243);
            this.btnSwapNames4.Name = "btnSwapNames4";
            this.btnSwapNames4.Size = new System.Drawing.Size(35, 45);
            this.btnSwapNames4.TabIndex = 52;
            this.btnSwapNames4.UseVisualStyleBackColor = true;
            this.btnSwapNames4.Click += new System.EventHandler(this.btnSwapNames4_Click);
            // 
            // btnSwapNamesFld2
            // 
            this.btnSwapNamesFld2.Image = global::MedicalClaimsPanels.Properties.Resources.sw90pos;
            this.btnSwapNamesFld2.Location = new System.Drawing.Point(34, 240);
            this.btnSwapNamesFld2.Name = "btnSwapNamesFld2";
            this.btnSwapNamesFld2.Size = new System.Drawing.Size(35, 46);
            this.btnSwapNamesFld2.TabIndex = 9;
            this.btnSwapNamesFld2.UseVisualStyleBackColor = true;
            this.btnSwapNamesFld2.Click += new System.EventHandler(this.btnSwapNamesFld2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Lavender;
            this.pictureBox1.Location = new System.Drawing.Point(23, 737);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(786, 104);
            this.pictureBox1.TabIndex = 656;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Lavender;
            this.pictureBox2.Location = new System.Drawing.Point(23, 84);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(626, 322);
            this.pictureBox2.TabIndex = 669;
            this.pictureBox2.TabStop = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(25, 14);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(111, 13);
            this.label12.TabIndex = 0;
            this.label12.Tag = "3aPatSex";
            this.label12.Text = "1. Insurance Type";
            // 
            // dcim1InsType
            // 
            this.dcim1InsType.Location = new System.Drawing.Point(25, 27);
            this.dcim1InsType.Name = "dcim1InsType";
            this.dcim1InsType.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim1InsType.OcxState")));
            this.dcim1InsType.Size = new System.Drawing.Size(465, 37);
            this.dcim1InsType.TabIndex = 1;
            this.dcim1InsType.TabStop = false;
            this.dcim1InsType.Tag = "1InsType";
            // 
            // cmb1InsType
            // 
            this.cmb1InsType.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb1InsType.FormattingEnabled = true;
            this.cmb1InsType.Location = new System.Drawing.Point(492, 27);
            this.cmb1InsType.Name = "cmb1InsType";
            this.cmb1InsType.Size = new System.Drawing.Size(104, 21);
            this.cmb1InsType.TabIndex = 2;
            this.cmb1InsType.Tag = "1InsType";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(788, 68);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(91, 13);
            this.label13.TabIndex = 55;
            this.label13.Tag = "6. Patient Rel";
            this.label13.Text = "6. Relationship";
            // 
            // dcim6PatRela
            // 
            this.dcim6PatRela.Location = new System.Drawing.Point(788, 81);
            this.dcim6PatRela.Name = "dcim6PatRela";
            this.dcim6PatRela.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim6PatRela.OcxState")));
            this.dcim6PatRela.Size = new System.Drawing.Size(104, 34);
            this.dcim6PatRela.TabIndex = 56;
            this.dcim6PatRela.TabStop = false;
            this.dcim6PatRela.Tag = "6PatRela";
            // 
            // cmb6PatRela
            // 
            this.cmb6PatRela.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb6PatRela.FormattingEnabled = true;
            this.cmb6PatRela.Location = new System.Drawing.Point(788, 115);
            this.cmb6PatRela.Name = "cmb6PatRela";
            this.cmb6PatRela.Size = new System.Drawing.Size(104, 21);
            this.cmb6PatRela.TabIndex = 57;
            this.cmb6PatRela.Tag = "6PatRela";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Lavender;
            this.label14.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(338, 531);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(170, 13);
            this.label14.TabIndex = 112;
            this.label14.Tag = "11cIPlan";
            this.label14.Text = "11b. Employer/School Name";
            // 
            // dcim11bIEmNm
            // 
            this.dcim11bIEmNm.Location = new System.Drawing.Point(339, 547);
            this.dcim11bIEmNm.Name = "dcim11bIEmNm";
            this.dcim11bIEmNm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim11bIEmNm.OcxState")));
            this.dcim11bIEmNm.Size = new System.Drawing.Size(168, 18);
            this.dcim11bIEmNm.TabIndex = 113;
            this.dcim11bIEmNm.TabStop = false;
            this.dcim11bIEmNm.Tag = "11bIEmNm";
            // 
            // dced11bIEmNm
            // 
            this.dced11bIEmNm.Location = new System.Drawing.Point(339, 565);
            this.dced11bIEmNm.Name = "dced11bIEmNm";
            this.dced11bIEmNm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced11bIEmNm.OcxState")));
            this.dced11bIEmNm.Size = new System.Drawing.Size(168, 18);
            this.dced11bIEmNm.TabIndex = 114;
            this.dced11bIEmNm.Tag = "11bIEmNm";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(166, 1211);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(85, 13);
            this.label15.TabIndex = 234;
            this.label15.Tag = "27AccAss";
            this.label15.Text = "25b. SSN/EIN";
            // 
            // dcim25bSSEIN
            // 
            this.dcim25bSSEIN.Location = new System.Drawing.Point(167, 1224);
            this.dcim25bSSEIN.Name = "dcim25bSSEIN";
            this.dcim25bSSEIN.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim25bSSEIN.OcxState")));
            this.dcim25bSSEIN.Size = new System.Drawing.Size(88, 39);
            this.dcim25bSSEIN.TabIndex = 235;
            this.dcim25bSSEIN.TabStop = false;
            this.dcim25bSSEIN.Tag = "25bSSEIN";
            // 
            // cmb25bSSEIN
            // 
            this.cmb25bSSEIN.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb25bSSEIN.FormattingEnabled = true;
            this.cmb25bSSEIN.Location = new System.Drawing.Point(258, 1224);
            this.cmb25bSSEIN.Name = "cmb25bSSEIN";
            this.cmb25bSSEIN.Size = new System.Drawing.Size(84, 26);
            this.cmb25bSSEIN.TabIndex = 236;
            this.cmb25bSSEIN.Tag = "25bSSEIN";
            // 
            // label16
            // 
            this.label16.BackColor = System.Drawing.Color.Beige;
            this.label16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label16.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(895, 849);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(101, 16);
            this.label16.TabIndex = 219;
            this.label16.Tag = "Charges";
            this.label16.Text = "NDC Quantity";
            this.label16.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label17
            // 
            this.label17.BackColor = System.Drawing.Color.Beige;
            this.label17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label17.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(827, 849);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(68, 16);
            this.label17.TabIndex = 218;
            this.label17.Tag = "Charges";
            this.label17.Text = "NDC Type";
            this.label17.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label26
            // 
            this.label26.BackColor = System.Drawing.Color.Beige;
            this.label26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label26.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(723, 849);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(104, 16);
            this.label26.TabIndex = 217;
            this.label26.Tag = "Charges";
            this.label26.Text = "NDC";
            this.label26.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.BackColor = System.Drawing.Color.Lavender;
            this.label27.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(714, 479);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(95, 13);
            this.label27.TabIndex = 132;
            this.label27.Tag = "3Pat_DOB";
            this.label27.Text = "14. Illness date";
            // 
            // dcim14SymDat
            // 
            this.dcim14SymDat.Location = new System.Drawing.Point(717, 492);
            this.dcim14SymDat.Name = "dcim14SymDat";
            this.dcim14SymDat.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim14SymDat.OcxState")));
            this.dcim14SymDat.Size = new System.Drawing.Size(75, 18);
            this.dcim14SymDat.TabIndex = 133;
            this.dcim14SymDat.TabStop = false;
            this.dcim14SymDat.Tag = "14SymDat";
            // 
            // dced14SymDat
            // 
            this.dced14SymDat.Location = new System.Drawing.Point(717, 510);
            this.dced14SymDat.Name = "dced14SymDat";
            this.dced14SymDat.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced14SymDat.OcxState")));
            this.dced14SymDat.Size = new System.Drawing.Size(75, 18);
            this.dced14SymDat.TabIndex = 134;
            this.dced14SymDat.Tag = "14SymDat";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.BackColor = System.Drawing.Color.Lavender;
            this.label51.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(872, 479);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(98, 13);
            this.label51.TabIndex = 138;
            this.label51.Tag = "3Pat_DOB";
            this.label51.Text = "15. History date";
            // 
            // dcim15HisDat
            // 
            this.dcim15HisDat.Location = new System.Drawing.Point(875, 492);
            this.dcim15HisDat.Name = "dcim15HisDat";
            this.dcim15HisDat.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim15HisDat.OcxState")));
            this.dcim15HisDat.Size = new System.Drawing.Size(75, 18);
            this.dcim15HisDat.TabIndex = 139;
            this.dcim15HisDat.TabStop = false;
            this.dcim15HisDat.Tag = "15HisDat";
            // 
            // dced15HisDat
            // 
            this.dced15HisDat.Location = new System.Drawing.Point(875, 510);
            this.dced15HisDat.Name = "dced15HisDat";
            this.dced15HisDat.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced15HisDat.OcxState")));
            this.dced15HisDat.Size = new System.Drawing.Size(75, 18);
            this.dced15HisDat.TabIndex = 140;
            this.dced15HisDat.Tag = "15HisDat";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.BackColor = System.Drawing.Color.Lavender;
            this.label52.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(764, 551);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(154, 13);
            this.label52.TabIndex = 152;
            this.label52.Tag = "";
            this.label52.Text = "Referring Physician Name";
            // 
            // dcim17RefDoc
            // 
            this.dcim17RefDoc.Location = new System.Drawing.Point(765, 564);
            this.dcim17RefDoc.Name = "dcim17RefDoc";
            this.dcim17RefDoc.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim17RefDoc.OcxState")));
            this.dcim17RefDoc.Size = new System.Drawing.Size(242, 18);
            this.dcim17RefDoc.TabIndex = 153;
            this.dcim17RefDoc.TabStop = false;
            this.dcim17RefDoc.Tag = "17RefDoc";
            // 
            // dced17ReLNam
            // 
            this.dced17ReLNam.Location = new System.Drawing.Point(765, 582);
            this.dced17ReLNam.Name = "dced17ReLNam";
            this.dced17ReLNam.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced17ReLNam.OcxState")));
            this.dced17ReLNam.Size = new System.Drawing.Size(114, 18);
            this.dced17ReLNam.TabIndex = 154;
            this.dced17ReLNam.Tag = "17ReLNam";
            // 
            // dced17ReFNam
            // 
            this.dced17ReFNam.Location = new System.Drawing.Point(880, 582);
            this.dced17ReFNam.Name = "dced17ReFNam";
            this.dced17ReFNam.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced17ReFNam.OcxState")));
            this.dced17ReFNam.Size = new System.Drawing.Size(91, 18);
            this.dced17ReFNam.TabIndex = 155;
            this.dced17ReFNam.Tag = "17ReFNam";
            // 
            // dcedReMIni
            // 
            this.dcedReMIni.Location = new System.Drawing.Point(972, 582);
            this.dcedReMIni.Name = "dcedReMIni";
            this.dcedReMIni.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedReMIni.OcxState")));
            this.dcedReMIni.Size = new System.Drawing.Size(35, 18);
            this.dcedReMIni.TabIndex = 156;
            this.dcedReMIni.Tag = "17ReMIni";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.Location = new System.Drawing.Point(535, 623);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(144, 13);
            this.label53.TabIndex = 164;
            this.label53.Tag = "3Pat_DOB";
            this.label53.Text = "18. Hospialization Dates";
            // 
            // dcim18aHpDtF
            // 
            this.dcim18aHpDtF.Location = new System.Drawing.Point(538, 636);
            this.dcim18aHpDtF.Name = "dcim18aHpDtF";
            this.dcim18aHpDtF.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim18aHpDtF.OcxState")));
            this.dcim18aHpDtF.Size = new System.Drawing.Size(75, 18);
            this.dcim18aHpDtF.TabIndex = 165;
            this.dcim18aHpDtF.TabStop = false;
            this.dcim18aHpDtF.Tag = "18aHpDtF";
            // 
            // dced18aHpDtF
            // 
            this.dced18aHpDtF.Location = new System.Drawing.Point(538, 654);
            this.dced18aHpDtF.Name = "dced18aHpDtF";
            this.dced18aHpDtF.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced18aHpDtF.OcxState")));
            this.dced18aHpDtF.Size = new System.Drawing.Size(75, 18);
            this.dced18aHpDtF.TabIndex = 167;
            this.dced18aHpDtF.Tag = "18aHpDtF";
            // 
            // dcim18bHpDtT
            // 
            this.dcim18bHpDtT.Location = new System.Drawing.Point(613, 636);
            this.dcim18bHpDtT.Name = "dcim18bHpDtT";
            this.dcim18bHpDtT.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim18bHpDtT.OcxState")));
            this.dcim18bHpDtT.Size = new System.Drawing.Size(75, 18);
            this.dcim18bHpDtT.TabIndex = 166;
            this.dcim18bHpDtT.TabStop = false;
            this.dcim18bHpDtT.Tag = "18bHpDtT";
            // 
            // dced18bHpDtT
            // 
            this.dced18bHpDtT.Location = new System.Drawing.Point(613, 654);
            this.dced18bHpDtT.Name = "dced18bHpDtT";
            this.dced18bHpDtT.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced18bHpDtT.OcxState")));
            this.dced18bHpDtT.Size = new System.Drawing.Size(75, 18);
            this.dced18bHpDtT.TabIndex = 168;
            this.dced18bHpDtT.Tag = "18bHpDtT";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.Location = new System.Drawing.Point(818, 740);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(59, 13);
            this.label54.TabIndex = 205;
            this.label54.Tag = "";
            this.label54.Text = "22. Code";
            // 
            // dcim22aResub
            // 
            this.dcim22aResub.Location = new System.Drawing.Point(820, 753);
            this.dcim22aResub.Name = "dcim22aResub";
            this.dcim22aResub.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim22aResub.OcxState")));
            this.dcim22aResub.Size = new System.Drawing.Size(70, 18);
            this.dcim22aResub.TabIndex = 206;
            this.dcim22aResub.TabStop = false;
            this.dcim22aResub.Tag = "22aResub";
            // 
            // dced22aResub
            // 
            this.dced22aResub.Location = new System.Drawing.Point(820, 771);
            this.dced22aResub.Name = "dced22aResub";
            this.dced22aResub.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced22aResub.OcxState")));
            this.dced22aResub.Size = new System.Drawing.Size(70, 18);
            this.dced22aResub.TabIndex = 207;
            this.dced22aResub.Tag = "22aResub";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.Location = new System.Drawing.Point(894, 740);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(113, 13);
            this.label55.TabIndex = 208;
            this.label55.Tag = "";
            this.label55.Text = "Original Reference";
            // 
            // dcim22bOrigR
            // 
            this.dcim22bOrigR.Location = new System.Drawing.Point(896, 753);
            this.dcim22bOrigR.Name = "dcim22bOrigR";
            this.dcim22bOrigR.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim22bOrigR.OcxState")));
            this.dcim22bOrigR.Size = new System.Drawing.Size(111, 18);
            this.dcim22bOrigR.TabIndex = 209;
            this.dcim22bOrigR.TabStop = false;
            this.dcim22bOrigR.Tag = "22bOrigR";
            // 
            // dced22bOrigR
            // 
            this.dced22bOrigR.Location = new System.Drawing.Point(896, 771);
            this.dced22bOrigR.Name = "dced22bOrigR";
            this.dced22bOrigR.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced22bOrigR.OcxState")));
            this.dced22bOrigR.Size = new System.Drawing.Size(111, 18);
            this.dced22bOrigR.TabIndex = 210;
            this.dced22bOrigR.Tag = "22bOrigR";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label56.Location = new System.Drawing.Point(859, 792);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(135, 13);
            this.label56.TabIndex = 211;
            this.label56.Tag = "";
            this.label56.Text = "23. Prior Authorization";
            // 
            // dcim23PriAth
            // 
            this.dcim23PriAth.Location = new System.Drawing.Point(861, 805);
            this.dcim23PriAth.Name = "dcim23PriAth";
            this.dcim23PriAth.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim23PriAth.OcxState")));
            this.dcim23PriAth.Size = new System.Drawing.Size(146, 18);
            this.dcim23PriAth.TabIndex = 212;
            this.dcim23PriAth.TabStop = false;
            this.dcim23PriAth.Tag = "23PriAth";
            // 
            // dced23PriAth
            // 
            this.dced23PriAth.Location = new System.Drawing.Point(861, 823);
            this.dced23PriAth.Name = "dced23PriAth";
            this.dced23PriAth.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced23PriAth.OcxState")));
            this.dced23PriAth.Size = new System.Drawing.Size(146, 18);
            this.dced23PriAth.TabIndex = 213;
            this.dced23PriAth.Tag = "23PriAth";
            // 
            // dcim10dLocUs
            // 
            this.dcim10dLocUs.Location = new System.Drawing.Point(806, 430);
            this.dcim10dLocUs.Name = "dcim10dLocUs";
            this.dcim10dLocUs.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim10dLocUs.OcxState")));
            this.dcim10dLocUs.Size = new System.Drawing.Size(200, 18);
            this.dcim10dLocUs.TabIndex = 127;
            this.dcim10dLocUs.TabStop = false;
            this.dcim10dLocUs.Tag = "10dLocUs";
            // 
            // dced10dLocUs
            // 
            this.dced10dLocUs.Location = new System.Drawing.Point(806, 448);
            this.dced10dLocUs.Name = "dced10dLocUs";
            this.dced10dLocUs.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced10dLocUs.OcxState")));
            this.dced10dLocUs.Size = new System.Drawing.Size(200, 18);
            this.dced10dLocUs.TabIndex = 128;
            this.dced10dLocUs.Tag = "10dLocUs";
            // 
            // label10dLocUs
            // 
            this.label10dLocUs.AutoSize = true;
            this.label10dLocUs.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10dLocUs.Location = new System.Drawing.Point(803, 417);
            this.label10dLocUs.Name = "label10dLocUs";
            this.label10dLocUs.Size = new System.Drawing.Size(90, 13);
            this.label10dLocUs.TabIndex = 126;
            this.label10dLocUs.Tag = "10dLocUs";
            this.label10dLocUs.Text = "10d. Local Use";
            // 
            // label8aPStatM
            // 
            this.label8aPStatM.AutoSize = true;
            this.label8aPStatM.BackColor = System.Drawing.Color.Lavender;
            this.label8aPStatM.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8aPStatM.Location = new System.Drawing.Point(676, 155);
            this.label8aPStatM.Name = "label8aPStatM";
            this.label8aPStatM.Size = new System.Drawing.Size(107, 13);
            this.label8aPStatM.TabIndex = 58;
            this.label8aPStatM.Tag = "8aPStatM";
            this.label8aPStatM.Text = "8a. Marital Status";
            // 
            // dcim8aPStatM
            // 
            this.dcim8aPStatM.Location = new System.Drawing.Point(676, 168);
            this.dcim8aPStatM.Name = "dcim8aPStatM";
            this.dcim8aPStatM.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim8aPStatM.OcxState")));
            this.dcim8aPStatM.Size = new System.Drawing.Size(104, 34);
            this.dcim8aPStatM.TabIndex = 59;
            this.dcim8aPStatM.TabStop = false;
            this.dcim8aPStatM.Tag = "8aPStatM";
            // 
            // cmb8aPStatM
            // 
            this.cmb8aPStatM.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb8aPStatM.FormattingEnabled = true;
            this.cmb8aPStatM.Location = new System.Drawing.Point(676, 202);
            this.cmb8aPStatM.Name = "cmb8aPStatM";
            this.cmb8aPStatM.Size = new System.Drawing.Size(104, 21);
            this.cmb8aPStatM.TabIndex = 60;
            this.cmb8aPStatM.Tag = "8aPStatM";
            // 
            // label8bPStatE
            // 
            this.label8bPStatE.AutoSize = true;
            this.label8bPStatE.BackColor = System.Drawing.Color.Lavender;
            this.label8bPStatE.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8bPStatE.Location = new System.Drawing.Point(793, 155);
            this.label8bPStatE.Name = "label8bPStatE";
            this.label8bPStatE.Size = new System.Drawing.Size(100, 13);
            this.label8bPStatE.TabIndex = 61;
            this.label8bPStatE.Tag = "8bPStatE";
            this.label8bPStatE.Text = "8b. Employment";
            // 
            // dcim8bPStatE
            // 
            this.dcim8bPStatE.Location = new System.Drawing.Point(793, 168);
            this.dcim8bPStatE.Name = "dcim8bPStatE";
            this.dcim8bPStatE.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim8bPStatE.OcxState")));
            this.dcim8bPStatE.Size = new System.Drawing.Size(104, 34);
            this.dcim8bPStatE.TabIndex = 62;
            this.dcim8bPStatE.TabStop = false;
            this.dcim8bPStatE.Tag = "8bPStatE";
            // 
            // cmb8bPStatE
            // 
            this.cmb8bPStatE.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb8bPStatE.FormattingEnabled = true;
            this.cmb8bPStatE.Location = new System.Drawing.Point(793, 202);
            this.cmb8bPStatE.Name = "cmb8bPStatE";
            this.cmb8bPStatE.Size = new System.Drawing.Size(104, 21);
            this.cmb8bPStatE.TabIndex = 63;
            this.cmb8bPStatE.Tag = "8bPStatE";
            // 
            // label10aPCREm
            // 
            this.label10aPCREm.AutoSize = true;
            this.label10aPCREm.BackColor = System.Drawing.Color.Lavender;
            this.label10aPCREm.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10aPCREm.Location = new System.Drawing.Point(676, 246);
            this.label10aPCREm.Name = "label10aPCREm";
            this.label10aPCREm.Size = new System.Drawing.Size(107, 13);
            this.label10aPCREm.TabIndex = 64;
            this.label10aPCREm.Tag = "10aPCREm";
            this.label10aPCREm.Text = "10a. Employment";
            // 
            // dcim10aPCREm
            // 
            this.dcim10aPCREm.Location = new System.Drawing.Point(676, 259);
            this.dcim10aPCREm.Name = "dcim10aPCREm";
            this.dcim10aPCREm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim10aPCREm.OcxState")));
            this.dcim10aPCREm.Size = new System.Drawing.Size(104, 34);
            this.dcim10aPCREm.TabIndex = 65;
            this.dcim10aPCREm.TabStop = false;
            this.dcim10aPCREm.Tag = "10aPCREm";
            // 
            // cmb10aPCREm
            // 
            this.cmb10aPCREm.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb10aPCREm.FormattingEnabled = true;
            this.cmb10aPCREm.Location = new System.Drawing.Point(676, 293);
            this.cmb10aPCREm.Name = "cmb10aPCREm";
            this.cmb10aPCREm.Size = new System.Drawing.Size(104, 21);
            this.cmb10aPCREm.TabIndex = 66;
            this.cmb10aPCREm.Tag = "10aPCREm";
            // 
            // label10cPCROA
            // 
            this.label10cPCROA.AutoSize = true;
            this.label10cPCROA.BackColor = System.Drawing.Color.Lavender;
            this.label10cPCROA.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10cPCROA.Location = new System.Drawing.Point(793, 246);
            this.label10cPCROA.Name = "label10cPCROA";
            this.label10cPCROA.Size = new System.Drawing.Size(119, 13);
            this.label10cPCROA.TabIndex = 67;
            this.label10cPCROA.Tag = "10cPCROA";
            this.label10cPCROA.Text = "10c. Other Accident";
            // 
            // dcim10cPCROA
            // 
            this.dcim10cPCROA.Location = new System.Drawing.Point(793, 259);
            this.dcim10cPCROA.Name = "dcim10cPCROA";
            this.dcim10cPCROA.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim10cPCROA.OcxState")));
            this.dcim10cPCROA.Size = new System.Drawing.Size(104, 34);
            this.dcim10cPCROA.TabIndex = 68;
            this.dcim10cPCROA.TabStop = false;
            this.dcim10cPCROA.Tag = "10cPCROA";
            // 
            // cmb10cPCROA
            // 
            this.cmb10cPCROA.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb10cPCROA.FormattingEnabled = true;
            this.cmb10cPCROA.Location = new System.Drawing.Point(793, 293);
            this.cmb10cPCROA.Name = "cmb10cPCROA";
            this.cmb10cPCROA.Size = new System.Drawing.Size(104, 21);
            this.cmb10cPCROA.TabIndex = 69;
            this.cmb10cPCROA.Tag = "10cPCROA";
            // 
            // label10bPCRAA
            // 
            this.label10bPCRAA.AutoSize = true;
            this.label10bPCRAA.BackColor = System.Drawing.Color.Lavender;
            this.label10bPCRAA.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10bPCRAA.Location = new System.Drawing.Point(676, 323);
            this.label10bPCRAA.Name = "label10bPCRAA";
            this.label10bPCRAA.Size = new System.Drawing.Size(114, 13);
            this.label10bPCRAA.TabIndex = 70;
            this.label10bPCRAA.Tag = "10bPCRAA";
            this.label10bPCRAA.Text = "10b. Auto Accident";
            // 
            // dcim10bPCRAA
            // 
            this.dcim10bPCRAA.Location = new System.Drawing.Point(676, 336);
            this.dcim10bPCRAA.Name = "dcim10bPCRAA";
            this.dcim10bPCRAA.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim10bPCRAA.OcxState")));
            this.dcim10bPCRAA.Size = new System.Drawing.Size(104, 34);
            this.dcim10bPCRAA.TabIndex = 71;
            this.dcim10bPCRAA.TabStop = false;
            this.dcim10bPCRAA.Tag = "10bPCRAA";
            // 
            // cmb10bPCRAA
            // 
            this.cmb10bPCRAA.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb10bPCRAA.FormattingEnabled = true;
            this.cmb10bPCRAA.Location = new System.Drawing.Point(676, 370);
            this.cmb10bPCRAA.Name = "cmb10bPCRAA";
            this.cmb10bPCRAA.Size = new System.Drawing.Size(104, 21);
            this.cmb10bPCRAA.TabIndex = 72;
            this.cmb10bPCRAA.Tag = "10bPCRAA";
            // 
            // label10bautop
            // 
            this.label10bautop.AutoSize = true;
            this.label10bautop.BackColor = System.Drawing.Color.Lavender;
            this.label10bautop.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10bautop.Location = new System.Drawing.Point(806, 323);
            this.label10bautop.Name = "label10bautop";
            this.label10bautop.Size = new System.Drawing.Size(66, 13);
            this.label10bautop.TabIndex = 73;
            this.label10bautop.Tag = "10bautop";
            this.label10bautop.Text = "10b. Place";
            // 
            // dcim10bautop
            // 
            this.dcim10bautop.Location = new System.Drawing.Point(803, 336);
            this.dcim10bautop.Name = "dcim10bautop";
            this.dcim10bautop.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim10bautop.OcxState")));
            this.dcim10bautop.Size = new System.Drawing.Size(94, 18);
            this.dcim10bautop.TabIndex = 74;
            this.dcim10bautop.TabStop = false;
            this.dcim10bautop.Tag = "10bautop";
            // 
            // dced10bautop
            // 
            this.dced10bautop.Location = new System.Drawing.Point(803, 354);
            this.dced10bautop.Name = "dced10bautop";
            this.dced10bautop.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced10bautop.OcxState")));
            this.dced10bautop.Size = new System.Drawing.Size(94, 18);
            this.dced10bautop.TabIndex = 75;
            this.dced10bautop.Tag = "10bautop";
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Lavender;
            this.pictureBox3.Location = new System.Drawing.Point(666, 142);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(249, 91);
            this.pictureBox3.TabIndex = 1110;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Lavender;
            this.pictureBox4.Location = new System.Drawing.Point(666, 240);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(250, 166);
            this.pictureBox4.TabIndex = 1111;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.Lavender;
            this.pictureBox5.Location = new System.Drawing.Point(270, 412);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(250, 307);
            this.pictureBox5.TabIndex = 1112;
            this.pictureBox5.TabStop = false;
            // 
            // label11bqual
            // 
            this.label11bqual.AutoSize = true;
            this.label11bqual.BackColor = System.Drawing.Color.Lavender;
            this.label11bqual.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11bqual.Location = new System.Drawing.Point(281, 532);
            this.label11bqual.Name = "label11bqual";
            this.label11bqual.Size = new System.Drawing.Size(48, 13);
            this.label11bqual.TabIndex = 109;
            this.label11bqual.Tag = "11bqual";
            this.label11bqual.Text = "b. Qual";
            // 
            // dcim11bqual
            // 
            this.dcim11bqual.Location = new System.Drawing.Point(286, 547);
            this.dcim11bqual.Name = "dcim11bqual";
            this.dcim11bqual.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim11bqual.OcxState")));
            this.dcim11bqual.Size = new System.Drawing.Size(47, 18);
            this.dcim11bqual.TabIndex = 110;
            this.dcim11bqual.TabStop = false;
            this.dcim11bqual.Tag = "11bqual";
            // 
            // dced11bqual
            // 
            this.dced11bqual.Location = new System.Drawing.Point(286, 565);
            this.dced11bqual.Name = "dced11bqual";
            this.dced11bqual.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced11bqual.OcxState")));
            this.dced11bqual.Size = new System.Drawing.Size(47, 18);
            this.dced11bqual.TabIndex = 111;
            this.dced11bqual.Tag = "11bqual";
            // 
            // label9OtInsLNam
            // 
            this.label9OtInsLNam.AutoSize = true;
            this.label9OtInsLNam.BackColor = System.Drawing.Color.Lavender;
            this.label9OtInsLNam.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9OtInsLNam.Location = new System.Drawing.Point(34, 415);
            this.label9OtInsLNam.Name = "label9OtInsLNam";
            this.label9OtInsLNam.Size = new System.Drawing.Size(82, 13);
            this.label9OtInsLNam.TabIndex = 76;
            this.label9OtInsLNam.Tag = "9OtInsLNam";
            this.label9OtInsLNam.Text = "9. Last Name";
            // 
            // dcim9OtInsLNam
            // 
            this.dcim9OtInsLNam.Location = new System.Drawing.Point(37, 428);
            this.dcim9OtInsLNam.Name = "dcim9OtInsLNam";
            this.dcim9OtInsLNam.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim9OtInsLNam.OcxState")));
            this.dcim9OtInsLNam.Size = new System.Drawing.Size(200, 18);
            this.dcim9OtInsLNam.TabIndex = 77;
            this.dcim9OtInsLNam.TabStop = false;
            this.dcim9OtInsLNam.Tag = "9OtInsLNam";
            // 
            // dced9OtInsLNam
            // 
            this.dced9OtInsLNam.Location = new System.Drawing.Point(37, 446);
            this.dced9OtInsLNam.Name = "dced9OtInsLNam";
            this.dced9OtInsLNam.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced9OtInsLNam.OcxState")));
            this.dced9OtInsLNam.Size = new System.Drawing.Size(200, 18);
            this.dced9OtInsLNam.TabIndex = 78;
            this.dced9OtInsLNam.Tag = "9OtInsLNam";
            // 
            // label9OtInsFNam
            // 
            this.label9OtInsFNam.AutoSize = true;
            this.label9OtInsFNam.BackColor = System.Drawing.Color.Lavender;
            this.label9OtInsFNam.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9OtInsFNam.Location = new System.Drawing.Point(34, 464);
            this.label9OtInsFNam.Name = "label9OtInsFNam";
            this.label9OtInsFNam.Size = new System.Drawing.Size(68, 13);
            this.label9OtInsFNam.TabIndex = 79;
            this.label9OtInsFNam.Tag = "9OtInsFNam";
            this.label9OtInsFNam.Text = "First Name";
            // 
            // dcim9OtInsFNam
            // 
            this.dcim9OtInsFNam.Location = new System.Drawing.Point(37, 477);
            this.dcim9OtInsFNam.Name = "dcim9OtInsFNam";
            this.dcim9OtInsFNam.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim9OtInsFNam.OcxState")));
            this.dcim9OtInsFNam.Size = new System.Drawing.Size(161, 18);
            this.dcim9OtInsFNam.TabIndex = 80;
            this.dcim9OtInsFNam.TabStop = false;
            this.dcim9OtInsFNam.Tag = "9OtInsFNam";
            // 
            // dced9OtInsFNam
            // 
            this.dced9OtInsFNam.Location = new System.Drawing.Point(37, 495);
            this.dced9OtInsFNam.Name = "dced9OtInsFNam";
            this.dced9OtInsFNam.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced9OtInsFNam.OcxState")));
            this.dced9OtInsFNam.Size = new System.Drawing.Size(161, 18);
            this.dced9OtInsFNam.TabIndex = 81;
            this.dced9OtInsFNam.Tag = "9OtInsFNam";
            // 
            // label9OtInsMInit
            // 
            this.label9OtInsMInit.AutoSize = true;
            this.label9OtInsMInit.BackColor = System.Drawing.Color.Lavender;
            this.label9OtInsMInit.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9OtInsMInit.Location = new System.Drawing.Point(207, 464);
            this.label9OtInsMInit.Name = "label9OtInsMInit";
            this.label9OtInsMInit.Size = new System.Drawing.Size(21, 13);
            this.label9OtInsMInit.TabIndex = 82;
            this.label9OtInsMInit.Tag = "9OtInsMInit";
            this.label9OtInsMInit.Text = "MI";
            // 
            // dcim9OtInsMInit
            // 
            this.dcim9OtInsMInit.Location = new System.Drawing.Point(207, 477);
            this.dcim9OtInsMInit.Name = "dcim9OtInsMInit";
            this.dcim9OtInsMInit.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim9OtInsMInit.OcxState")));
            this.dcim9OtInsMInit.Size = new System.Drawing.Size(30, 18);
            this.dcim9OtInsMInit.TabIndex = 83;
            this.dcim9OtInsMInit.TabStop = false;
            this.dcim9OtInsMInit.Tag = "9OtInsMInit";
            // 
            // dced9OtInsMInit
            // 
            this.dced9OtInsMInit.Location = new System.Drawing.Point(207, 495);
            this.dced9OtInsMInit.Name = "dced9OtInsMInit";
            this.dced9OtInsMInit.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced9OtInsMInit.OcxState")));
            this.dced9OtInsMInit.Size = new System.Drawing.Size(30, 18);
            this.dced9OtInsMInit.TabIndex = 84;
            this.dced9OtInsMInit.Tag = "9OtInsMInit";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.BackColor = System.Drawing.Color.Lavender;
            this.label59.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label59.Location = new System.Drawing.Point(34, 513);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(166, 13);
            this.label59.TabIndex = 85;
            this.label59.Tag = "9aOtInNo";
            this.label59.Text = "9a. Policy or Group Number";
            // 
            // dcim9aOtInNo
            // 
            this.dcim9aOtInNo.Location = new System.Drawing.Point(37, 526);
            this.dcim9aOtInNo.Name = "dcim9aOtInNo";
            this.dcim9aOtInNo.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim9aOtInNo.OcxState")));
            this.dcim9aOtInNo.Size = new System.Drawing.Size(200, 18);
            this.dcim9aOtInNo.TabIndex = 86;
            this.dcim9aOtInNo.TabStop = false;
            this.dcim9aOtInNo.Tag = "9aOtInNo";
            // 
            // dced9aOtInNo
            // 
            this.dced9aOtInNo.Location = new System.Drawing.Point(37, 544);
            this.dced9aOtInNo.Name = "dced9aOtInNo";
            this.dced9aOtInNo.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced9aOtInNo.OcxState")));
            this.dced9aOtInNo.Size = new System.Drawing.Size(200, 18);
            this.dced9aOtInNo.TabIndex = 87;
            this.dced9aOtInNo.Tag = "9aOtInNo";
            // 
            // label9bOInDOB
            // 
            this.label9bOInDOB.AutoSize = true;
            this.label9bOInDOB.BackColor = System.Drawing.Color.Lavender;
            this.label9bOInDOB.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9bOInDOB.Location = new System.Drawing.Point(33, 562);
            this.label9bOInDOB.Name = "label9bOInDOB";
            this.label9bOInDOB.Size = new System.Drawing.Size(55, 13);
            this.label9bOInDOB.TabIndex = 88;
            this.label9bOInDOB.Tag = "9bOInDOB";
            this.label9bOInDOB.Text = "9b. DOB";
            // 
            // dcim9bOInDOB
            // 
            this.dcim9bOInDOB.Location = new System.Drawing.Point(36, 575);
            this.dcim9bOInDOB.Name = "dcim9bOInDOB";
            this.dcim9bOInDOB.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim9bOInDOB.OcxState")));
            this.dcim9bOInDOB.Size = new System.Drawing.Size(75, 18);
            this.dcim9bOInDOB.TabIndex = 89;
            this.dcim9bOInDOB.TabStop = false;
            this.dcim9bOInDOB.Tag = "9bOInDOB";
            // 
            // dced9bOInDOB
            // 
            this.dced9bOInDOB.Location = new System.Drawing.Point(36, 593);
            this.dced9bOInDOB.Name = "dced9bOInDOB";
            this.dced9bOInDOB.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced9bOInDOB.OcxState")));
            this.dced9bOInDOB.Size = new System.Drawing.Size(75, 18);
            this.dced9bOInDOB.TabIndex = 90;
            this.dced9bOInDOB.Tag = "9bOInDOB";
            // 
            // label9cOIEmNm
            // 
            this.label9cOIEmNm.AutoSize = true;
            this.label9cOIEmNm.BackColor = System.Drawing.Color.Lavender;
            this.label9cOIEmNm.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9cOIEmNm.Location = new System.Drawing.Point(34, 628);
            this.label9cOIEmNm.Name = "label9cOIEmNm";
            this.label9cOIEmNm.Size = new System.Drawing.Size(187, 13);
            this.label9cOIEmNm.TabIndex = 94;
            this.label9cOIEmNm.Tag = "9cOIEmNm";
            this.label9cOIEmNm.Text = "9c. Employer, School/Reserved";
            // 
            // dcim9cOIEmNm
            // 
            this.dcim9cOIEmNm.Location = new System.Drawing.Point(37, 641);
            this.dcim9cOIEmNm.Name = "dcim9cOIEmNm";
            this.dcim9cOIEmNm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim9cOIEmNm.OcxState")));
            this.dcim9cOIEmNm.Size = new System.Drawing.Size(200, 18);
            this.dcim9cOIEmNm.TabIndex = 95;
            this.dcim9cOIEmNm.TabStop = false;
            this.dcim9cOIEmNm.Tag = "9cOIEmNm";
            // 
            // dced9cOIEmNm
            // 
            this.dced9cOIEmNm.Location = new System.Drawing.Point(37, 659);
            this.dced9cOIEmNm.Name = "dced9cOIEmNm";
            this.dced9cOIEmNm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced9cOIEmNm.OcxState")));
            this.dced9cOIEmNm.Size = new System.Drawing.Size(200, 18);
            this.dced9cOIEmNm.TabIndex = 96;
            this.dced9cOIEmNm.Tag = "9cOIEmNm";
            // 
            // label9dOIPlNm
            // 
            this.label9dOIPlNm.AutoSize = true;
            this.label9dOIPlNm.BackColor = System.Drawing.Color.Lavender;
            this.label9dOIPlNm.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9dOIPlNm.Location = new System.Drawing.Point(34, 677);
            this.label9dOIPlNm.Name = "label9dOIPlNm";
            this.label9dOIPlNm.Size = new System.Drawing.Size(159, 13);
            this.label9dOIPlNm.TabIndex = 97;
            this.label9dOIPlNm.Tag = "9dOIPlNm";
            this.label9dOIPlNm.Text = "9d. Plan or Program Name";
            // 
            // dcim9dOIPlNm
            // 
            this.dcim9dOIPlNm.Location = new System.Drawing.Point(37, 690);
            this.dcim9dOIPlNm.Name = "dcim9dOIPlNm";
            this.dcim9dOIPlNm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim9dOIPlNm.OcxState")));
            this.dcim9dOIPlNm.Size = new System.Drawing.Size(200, 18);
            this.dcim9dOIPlNm.TabIndex = 98;
            this.dcim9dOIPlNm.TabStop = false;
            this.dcim9dOIPlNm.Tag = "9dOIPlNm";
            // 
            // dced9dOIPlNm
            // 
            this.dced9dOIPlNm.Location = new System.Drawing.Point(37, 708);
            this.dced9dOIPlNm.Name = "dced9dOIPlNm";
            this.dced9dOIPlNm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced9dOIPlNm.OcxState")));
            this.dced9dOIPlNm.Size = new System.Drawing.Size(200, 18);
            this.dced9dOIPlNm.TabIndex = 99;
            this.dced9dOIPlNm.Tag = "9dOIPlNm";
            // 
            // label9bOInSex
            // 
            this.label9bOInSex.AutoSize = true;
            this.label9bOInSex.BackColor = System.Drawing.Color.Lavender;
            this.label9bOInSex.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9bOInSex.Location = new System.Drawing.Point(131, 562);
            this.label9bOInSex.Name = "label9bOInSex";
            this.label9bOInSex.Size = new System.Drawing.Size(51, 13);
            this.label9bOInSex.TabIndex = 91;
            this.label9bOInSex.Tag = "9bOInSex";
            this.label9bOInSex.Text = "9b. Sex";
            // 
            // dcim9bOInSex
            // 
            this.dcim9bOInSex.Location = new System.Drawing.Point(133, 575);
            this.dcim9bOInSex.Name = "dcim9bOInSex";
            this.dcim9bOInSex.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim9bOInSex.OcxState")));
            this.dcim9bOInSex.Size = new System.Drawing.Size(104, 34);
            this.dcim9bOInSex.TabIndex = 92;
            this.dcim9bOInSex.TabStop = false;
            this.dcim9bOInSex.Tag = "9bOInSex";
            // 
            // cmb9bOInSex
            // 
            this.cmb9bOInSex.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb9bOInSex.FormattingEnabled = true;
            this.cmb9bOInSex.Location = new System.Drawing.Point(133, 609);
            this.cmb9bOInSex.Name = "cmb9bOInSex";
            this.cmb9bOInSex.Size = new System.Drawing.Size(104, 21);
            this.cmb9bOInSex.TabIndex = 93;
            this.cmb9bOInSex.Tag = "9bOInSex";
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.Color.Lavender;
            this.pictureBox6.Location = new System.Drawing.Point(23, 412);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(230, 319);
            this.pictureBox6.TabIndex = 1140;
            this.pictureBox6.TabStop = false;
            // 
            // label12aPSign
            // 
            this.label12aPSign.AutoSize = true;
            this.label12aPSign.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12aPSign.Location = new System.Drawing.Point(537, 417);
            this.label12aPSign.Name = "label12aPSign";
            this.label12aPSign.Size = new System.Drawing.Size(183, 13);
            this.label12aPSign.TabIndex = 121;
            this.label12aPSign.Tag = "12aPSign";
            this.label12aPSign.Text = "12. Patient Signature and Date";
            // 
            // dcim12aPSign
            // 
            this.dcim12aPSign.Location = new System.Drawing.Point(537, 430);
            this.dcim12aPSign.Name = "dcim12aPSign";
            this.dcim12aPSign.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim12aPSign.OcxState")));
            this.dcim12aPSign.Size = new System.Drawing.Size(150, 34);
            this.dcim12aPSign.TabIndex = 122;
            this.dcim12aPSign.TabStop = false;
            this.dcim12aPSign.Tag = "12aPSign";
            // 
            // cmb12aPSign
            // 
            this.cmb12aPSign.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb12aPSign.FormattingEnabled = true;
            this.cmb12aPSign.Location = new System.Drawing.Point(537, 464);
            this.cmb12aPSign.Name = "cmb12aPSign";
            this.cmb12aPSign.Size = new System.Drawing.Size(150, 21);
            this.cmb12aPSign.TabIndex = 123;
            this.cmb12aPSign.Tag = "12aPSign";
            // 
            // dcim12bDtSgn
            // 
            this.dcim12bDtSgn.Location = new System.Drawing.Point(689, 430);
            this.dcim12bDtSgn.Name = "dcim12bDtSgn";
            this.dcim12bDtSgn.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim12bDtSgn.OcxState")));
            this.dcim12bDtSgn.Size = new System.Drawing.Size(75, 18);
            this.dcim12bDtSgn.TabIndex = 124;
            this.dcim12bDtSgn.TabStop = false;
            this.dcim12bDtSgn.Tag = "12bDtSgn";
            // 
            // dced12bDtSgn
            // 
            this.dced12bDtSgn.Location = new System.Drawing.Point(689, 448);
            this.dced12bDtSgn.Name = "dced12bDtSgn";
            this.dced12bDtSgn.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced12bDtSgn.OcxState")));
            this.dced12bDtSgn.Size = new System.Drawing.Size(75, 18);
            this.dced12bDtSgn.TabIndex = 125;
            this.dced12bDtSgn.Tag = "12bDtSgn";
            // 
            // label13InsSig
            // 
            this.label13InsSig.AutoSize = true;
            this.label13InsSig.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13InsSig.Location = new System.Drawing.Point(537, 497);
            this.label13InsSig.Name = "label13InsSig";
            this.label13InsSig.Size = new System.Drawing.Size(132, 13);
            this.label13InsSig.TabIndex = 129;
            this.label13InsSig.Tag = "13InsSig";
            this.label13InsSig.Text = "13. Insured Signature";
            // 
            // dcim13InsSig
            // 
            this.dcim13InsSig.Location = new System.Drawing.Point(537, 510);
            this.dcim13InsSig.Name = "dcim13InsSig";
            this.dcim13InsSig.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim13InsSig.OcxState")));
            this.dcim13InsSig.Size = new System.Drawing.Size(150, 34);
            this.dcim13InsSig.TabIndex = 130;
            this.dcim13InsSig.TabStop = false;
            this.dcim13InsSig.Tag = "13InsSig";
            // 
            // cmb13InsSig
            // 
            this.cmb13InsSig.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb13InsSig.FormattingEnabled = true;
            this.cmb13InsSig.Location = new System.Drawing.Point(537, 544);
            this.cmb13InsSig.Name = "cmb13InsSig";
            this.cmb13InsSig.Size = new System.Drawing.Size(150, 21);
            this.cmb13InsSig.TabIndex = 131;
            this.cmb13InsSig.Tag = "13InsSig";
            // 
            // dcim14aSym
            // 
            this.dcim14aSym.Location = new System.Drawing.Point(809, 492);
            this.dcim14aSym.Name = "dcim14aSym";
            this.dcim14aSym.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim14aSym.OcxState")));
            this.dcim14aSym.Size = new System.Drawing.Size(40, 18);
            this.dcim14aSym.TabIndex = 136;
            this.dcim14aSym.TabStop = false;
            this.dcim14aSym.Tag = "14aSym";
            // 
            // dced14aSym
            // 
            this.dced14aSym.Location = new System.Drawing.Point(809, 510);
            this.dced14aSym.Name = "dced14aSym";
            this.dced14aSym.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced14aSym.OcxState")));
            this.dced14aSym.Size = new System.Drawing.Size(40, 18);
            this.dced14aSym.TabIndex = 137;
            this.dced14aSym.Tag = "14aSym";
            // 
            // label14aSym
            // 
            this.label14aSym.AutoSize = true;
            this.label14aSym.BackColor = System.Drawing.Color.Lavender;
            this.label14aSym.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14aSym.Location = new System.Drawing.Point(806, 479);
            this.label14aSym.Name = "label14aSym";
            this.label14aSym.Size = new System.Drawing.Size(33, 13);
            this.label14aSym.TabIndex = 135;
            this.label14aSym.Tag = "14aSym";
            this.label14aSym.Text = "Qual";
            // 
            // label15qual
            // 
            this.label15qual.AutoSize = true;
            this.label15qual.BackColor = System.Drawing.Color.Lavender;
            this.label15qual.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15qual.Location = new System.Drawing.Point(971, 479);
            this.label15qual.Name = "label15qual";
            this.label15qual.Size = new System.Drawing.Size(33, 13);
            this.label15qual.TabIndex = 141;
            this.label15qual.Tag = "15qual";
            this.label15qual.Text = "Qual";
            // 
            // dcim15qual
            // 
            this.dcim15qual.Location = new System.Drawing.Point(965, 492);
            this.dcim15qual.Name = "dcim15qual";
            this.dcim15qual.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim15qual.OcxState")));
            this.dcim15qual.Size = new System.Drawing.Size(40, 18);
            this.dcim15qual.TabIndex = 142;
            this.dcim15qual.TabStop = false;
            this.dcim15qual.Tag = "15qual";
            // 
            // dced15qual
            // 
            this.dced15qual.Location = new System.Drawing.Point(965, 510);
            this.dced15qual.Name = "dced15qual";
            this.dced15qual.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced15qual.OcxState")));
            this.dced15qual.Size = new System.Drawing.Size(40, 18);
            this.dced15qual.TabIndex = 143;
            this.dced15qual.Tag = "15qual";
            // 
            // dcim16bDsDtT
            // 
            this.dcim16bDsDtT.Location = new System.Drawing.Point(613, 582);
            this.dcim16bDsDtT.Name = "dcim16bDsDtT";
            this.dcim16bDsDtT.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim16bDsDtT.OcxState")));
            this.dcim16bDsDtT.Size = new System.Drawing.Size(75, 18);
            this.dcim16bDsDtT.TabIndex = 147;
            this.dcim16bDsDtT.TabStop = false;
            this.dcim16bDsDtT.Tag = "16bDsDtT";
            // 
            // dced16bDsDtT
            // 
            this.dced16bDsDtT.Location = new System.Drawing.Point(613, 600);
            this.dced16bDsDtT.Name = "dced16bDsDtT";
            this.dced16bDsDtT.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced16bDsDtT.OcxState")));
            this.dced16bDsDtT.Size = new System.Drawing.Size(75, 18);
            this.dced16bDsDtT.TabIndex = 148;
            this.dced16bDsDtT.Tag = "16bDsDtT";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label57.Location = new System.Drawing.Point(535, 569);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(154, 13);
            this.label57.TabIndex = 144;
            this.label57.Tag = "3Pat_DOB";
            this.label57.Text = "16. Unable to Work Dates";
            // 
            // dcim16aDsDtF
            // 
            this.dcim16aDsDtF.Location = new System.Drawing.Point(538, 582);
            this.dcim16aDsDtF.Name = "dcim16aDsDtF";
            this.dcim16aDsDtF.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim16aDsDtF.OcxState")));
            this.dcim16aDsDtF.Size = new System.Drawing.Size(75, 18);
            this.dcim16aDsDtF.TabIndex = 145;
            this.dcim16aDsDtF.TabStop = false;
            this.dcim16aDsDtF.Tag = "16aDsDtF";
            // 
            // dced16aDsDtF
            // 
            this.dced16aDsDtF.Location = new System.Drawing.Point(538, 600);
            this.dced16aDsDtF.Name = "dced16aDsDtF";
            this.dced16aDsDtF.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced16aDsDtF.OcxState")));
            this.dced16aDsDtF.Size = new System.Drawing.Size(75, 18);
            this.dced16aDsDtF.TabIndex = 146;
            this.dced16aDsDtF.Tag = "16aDsDtF";
            // 
            // label20aOutLb
            // 
            this.label20aOutLb.AutoSize = true;
            this.label20aOutLb.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20aOutLb.Location = new System.Drawing.Point(860, 667);
            this.label20aOutLb.Name = "label20aOutLb";
            this.label20aOutLb.Size = new System.Drawing.Size(148, 13);
            this.label20aOutLb.TabIndex = 172;
            this.label20aOutLb.Tag = "20aOutLb";
            this.label20aOutLb.Text = "20. Outside Lab Charges";
            // 
            // dcim20aOutLb
            // 
            this.dcim20aOutLb.Location = new System.Drawing.Point(862, 680);
            this.dcim20aOutLb.Name = "dcim20aOutLb";
            this.dcim20aOutLb.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim20aOutLb.OcxState")));
            this.dcim20aOutLb.Size = new System.Drawing.Size(64, 34);
            this.dcim20aOutLb.TabIndex = 173;
            this.dcim20aOutLb.TabStop = false;
            this.dcim20aOutLb.Tag = "20aOutLb";
            // 
            // cmb20aOutLb
            // 
            this.cmb20aOutLb.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb20aOutLb.FormattingEnabled = true;
            this.cmb20aOutLb.Location = new System.Drawing.Point(862, 714);
            this.cmb20aOutLb.Name = "cmb20aOutLb";
            this.cmb20aOutLb.Size = new System.Drawing.Size(64, 21);
            this.cmb20aOutLb.TabIndex = 174;
            this.cmb20aOutLb.Tag = "20aOutLb";
            // 
            // dcim20bLChgs
            // 
            this.dcim20bLChgs.Location = new System.Drawing.Point(931, 680);
            this.dcim20bLChgs.Name = "dcim20bLChgs";
            this.dcim20bLChgs.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim20bLChgs.OcxState")));
            this.dcim20bLChgs.Size = new System.Drawing.Size(75, 18);
            this.dcim20bLChgs.TabIndex = 175;
            this.dcim20bLChgs.TabStop = false;
            this.dcim20bLChgs.Tag = "20bLChgs";
            // 
            // dced20bLChgs
            // 
            this.dced20bLChgs.Location = new System.Drawing.Point(931, 698);
            this.dced20bLChgs.Name = "dced20bLChgs";
            this.dced20bLChgs.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced20bLChgs.OcxState")));
            this.dced20bLChgs.Size = new System.Drawing.Size(75, 18);
            this.dced20bLChgs.TabIndex = 176;
            this.dced20bLChgs.Tag = "20bLChgs";
            // 
            // label17qual
            // 
            this.label17qual.AutoSize = true;
            this.label17qual.BackColor = System.Drawing.Color.Lavender;
            this.label17qual.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17qual.Location = new System.Drawing.Point(721, 551);
            this.label17qual.Name = "label17qual";
            this.label17qual.Size = new System.Drawing.Size(33, 13);
            this.label17qual.TabIndex = 149;
            this.label17qual.Tag = "17qual";
            this.label17qual.Text = "Qual";
            // 
            // dcim17qual
            // 
            this.dcim17qual.Location = new System.Drawing.Point(720, 564);
            this.dcim17qual.Name = "dcim17qual";
            this.dcim17qual.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim17qual.OcxState")));
            this.dcim17qual.Size = new System.Drawing.Size(34, 18);
            this.dcim17qual.TabIndex = 150;
            this.dcim17qual.TabStop = false;
            this.dcim17qual.Tag = "17qual";
            // 
            // dced17qual
            // 
            this.dced17qual.Location = new System.Drawing.Point(720, 582);
            this.dced17qual.Name = "dced17qual";
            this.dced17qual.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced17qual.OcxState")));
            this.dced17qual.Size = new System.Drawing.Size(34, 18);
            this.dced17qual.TabIndex = 151;
            this.dced17qual.Tag = "17qual";
            // 
            // label19LocUse
            // 
            this.label19LocUse.AutoSize = true;
            this.label19LocUse.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19LocUse.Location = new System.Drawing.Point(534, 680);
            this.label19LocUse.Name = "label19LocUse";
            this.label19LocUse.Size = new System.Drawing.Size(260, 13);
            this.label19LocUse.TabIndex = 169;
            this.label19LocUse.Tag = "19LocUse";
            this.label19LocUse.Text = "19. Local Use / Additional Claim Information";
            // 
            // dcim19LocUse
            // 
            this.dcim19LocUse.Location = new System.Drawing.Point(537, 693);
            this.dcim19LocUse.Name = "dcim19LocUse";
            this.dcim19LocUse.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim19LocUse.OcxState")));
            this.dcim19LocUse.Size = new System.Drawing.Size(304, 18);
            this.dcim19LocUse.TabIndex = 170;
            this.dcim19LocUse.TabStop = false;
            this.dcim19LocUse.Tag = "19LocUse";
            // 
            // dced19LocUse
            // 
            this.dced19LocUse.Location = new System.Drawing.Point(537, 711);
            this.dced19LocUse.Name = "dced19LocUse";
            this.dced19LocUse.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced19LocUse.OcxState")));
            this.dced19LocUse.Size = new System.Drawing.Size(304, 18);
            this.dced19LocUse.TabIndex = 171;
            this.dced19LocUse.Tag = "19LocUse";
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackColor = System.Drawing.Color.Lavender;
            this.pictureBox7.Location = new System.Drawing.Point(710, 544);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(302, 115);
            this.pictureBox7.TabIndex = 1173;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackColor = System.Drawing.Color.Lavender;
            this.pictureBox8.Location = new System.Drawing.Point(708, 475);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(146, 61);
            this.pictureBox8.TabIndex = 1174;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.BackColor = System.Drawing.Color.Lavender;
            this.pictureBox9.Location = new System.Drawing.Point(866, 475);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(146, 61);
            this.pictureBox9.TabIndex = 1175;
            this.pictureBox9.TabStop = false;
            // 
            // dced21_Diag8
            // 
            this.dced21_Diag8.Location = new System.Drawing.Point(666, 787);
            this.dced21_Diag8.Name = "dced21_Diag8";
            this.dced21_Diag8.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced21_Diag8.OcxState")));
            this.dced21_Diag8.Size = new System.Drawing.Size(70, 18);
            this.dced21_Diag8.TabIndex = 194;
            this.dced21_Diag8.Tag = "21_Diag8";
            // 
            // dced21_Diag7
            // 
            this.dced21_Diag7.Location = new System.Drawing.Point(575, 787);
            this.dced21_Diag7.Name = "dced21_Diag7";
            this.dced21_Diag7.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced21_Diag7.OcxState")));
            this.dced21_Diag7.Size = new System.Drawing.Size(70, 18);
            this.dced21_Diag7.TabIndex = 192;
            this.dced21_Diag7.Tag = "21_Diag7";
            // 
            // dced21_Diag6
            // 
            this.dced21_Diag6.Location = new System.Drawing.Point(484, 787);
            this.dced21_Diag6.Name = "dced21_Diag6";
            this.dced21_Diag6.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced21_Diag6.OcxState")));
            this.dced21_Diag6.Size = new System.Drawing.Size(70, 18);
            this.dced21_Diag6.TabIndex = 190;
            this.dced21_Diag6.Tag = "21_Diag6";
            // 
            // dced21_Diag5
            // 
            this.dced21_Diag5.Location = new System.Drawing.Point(393, 787);
            this.dced21_Diag5.Name = "dced21_Diag5";
            this.dced21_Diag5.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced21_Diag5.OcxState")));
            this.dced21_Diag5.Size = new System.Drawing.Size(70, 18);
            this.dced21_Diag5.TabIndex = 188;
            this.dced21_Diag5.Tag = "21_Diag5";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.BackColor = System.Drawing.Color.Lavender;
            this.label58.Location = new System.Drawing.Point(376, 790);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(17, 13);
            this.label58.TabIndex = 187;
            this.label58.Text = "E.";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.BackColor = System.Drawing.Color.Lavender;
            this.label60.Location = new System.Drawing.Point(650, 790);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(18, 13);
            this.label60.TabIndex = 193;
            this.label60.Text = "H.";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.BackColor = System.Drawing.Color.Lavender;
            this.label61.Location = new System.Drawing.Point(560, 790);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(18, 13);
            this.label61.TabIndex = 191;
            this.label61.Text = "G.";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.BackColor = System.Drawing.Color.Lavender;
            this.label62.Location = new System.Drawing.Point(468, 790);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(16, 13);
            this.label62.TabIndex = 189;
            this.label62.Text = "F.";
            // 
            // dced21_Diag12
            // 
            this.dced21_Diag12.Location = new System.Drawing.Point(666, 816);
            this.dced21_Diag12.Name = "dced21_Diag12";
            this.dced21_Diag12.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced21_Diag12.OcxState")));
            this.dced21_Diag12.Size = new System.Drawing.Size(70, 18);
            this.dced21_Diag12.TabIndex = 202;
            this.dced21_Diag12.Tag = "21_Diag12";
            this.dced21_Diag12.Change += new System.EventHandler(this.axDcedit5_Change);
            // 
            // dced21_Diag11
            // 
            this.dced21_Diag11.Location = new System.Drawing.Point(575, 816);
            this.dced21_Diag11.Name = "dced21_Diag11";
            this.dced21_Diag11.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced21_Diag11.OcxState")));
            this.dced21_Diag11.Size = new System.Drawing.Size(70, 18);
            this.dced21_Diag11.TabIndex = 200;
            this.dced21_Diag11.Tag = "21_Diag11";
            // 
            // dced21_Diag10
            // 
            this.dced21_Diag10.Location = new System.Drawing.Point(484, 816);
            this.dced21_Diag10.Name = "dced21_Diag10";
            this.dced21_Diag10.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced21_Diag10.OcxState")));
            this.dced21_Diag10.Size = new System.Drawing.Size(70, 18);
            this.dced21_Diag10.TabIndex = 198;
            this.dced21_Diag10.Tag = "21_Diag10";
            // 
            // dced21_Diag9
            // 
            this.dced21_Diag9.Location = new System.Drawing.Point(393, 816);
            this.dced21_Diag9.Name = "dced21_Diag9";
            this.dced21_Diag9.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced21_Diag9.OcxState")));
            this.dced21_Diag9.Size = new System.Drawing.Size(70, 18);
            this.dced21_Diag9.TabIndex = 196;
            this.dced21_Diag9.Tag = "21_Diag9";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.BackColor = System.Drawing.Color.Lavender;
            this.label63.Location = new System.Drawing.Point(376, 819);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(13, 13);
            this.label63.TabIndex = 195;
            this.label63.Text = "I.";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.BackColor = System.Drawing.Color.Lavender;
            this.label64.Location = new System.Drawing.Point(650, 819);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(16, 13);
            this.label64.TabIndex = 201;
            this.label64.Text = "L.";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.BackColor = System.Drawing.Color.Lavender;
            this.label65.Location = new System.Drawing.Point(560, 819);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(17, 13);
            this.label65.TabIndex = 199;
            this.label65.Text = "K.";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.BackColor = System.Drawing.Color.Lavender;
            this.label66.Location = new System.Drawing.Point(468, 819);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(15, 13);
            this.label66.TabIndex = 197;
            this.label66.Text = "J.";
            // 
            // dced21_ICDInd
            // 
            this.dced21_ICDInd.Location = new System.Drawing.Point(761, 785);
            this.dced21_ICDInd.Name = "dced21_ICDInd";
            this.dced21_ICDInd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced21_ICDInd.OcxState")));
            this.dced21_ICDInd.Size = new System.Drawing.Size(31, 18);
            this.dced21_ICDInd.TabIndex = 204;
            this.dced21_ICDInd.Tag = "21_ICDInd";
            // 
            // labelCD
            // 
            this.labelCD.AutoSize = true;
            this.labelCD.BackColor = System.Drawing.Color.Lavender;
            this.labelCD.Location = new System.Drawing.Point(764, 771);
            this.labelCD.Name = "labelCD";
            this.labelCD.Size = new System.Drawing.Size(25, 13);
            this.labelCD.TabIndex = 203;
            this.labelCD.Text = "ICD";
            // 
            // labelEPSD
            // 
            this.labelEPSD.BackColor = System.Drawing.Color.Beige;
            this.labelEPSD.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelEPSD.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelEPSD.Location = new System.Drawing.Point(542, 866);
            this.labelEPSD.Name = "labelEPSD";
            this.labelEPSD.Size = new System.Drawing.Size(47, 16);
            this.labelEPSD.TabIndex = 227;
            this.labelEPSD.Tag = "EPSD";
            this.labelEPSD.Text = "EPSDT";
            this.labelEPSD.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // dcim31bPSDat
            // 
            this.dcim31bPSDat.Location = new System.Drawing.Point(23, 1468);
            this.dcim31bPSDat.Name = "dcim31bPSDat";
            this.dcim31bPSDat.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim31bPSDat.OcxState")));
            this.dcim31bPSDat.Size = new System.Drawing.Size(75, 18);
            this.dcim31bPSDat.TabIndex = 262;
            this.dcim31bPSDat.TabStop = false;
            this.dcim31bPSDat.Tag = "31bPSDat";
            // 
            // dced31bPSDat
            // 
            this.dced31bPSDat.Location = new System.Drawing.Point(23, 1486);
            this.dced31bPSDat.Name = "dced31bPSDat";
            this.dced31bPSDat.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced31bPSDat.OcxState")));
            this.dced31bPSDat.Size = new System.Drawing.Size(75, 18);
            this.dced31bPSDat.TabIndex = 263;
            this.dced31bPSDat.Tag = "31bPSDat";
            // 
            // label31bPSDat
            // 
            this.label31bPSDat.AutoSize = true;
            this.label31bPSDat.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31bPSDat.Location = new System.Drawing.Point(20, 1452);
            this.label31bPSDat.Name = "label31bPSDat";
            this.label31bPSDat.Size = new System.Drawing.Size(177, 13);
            this.label31bPSDat.TabIndex = 261;
            this.label31bPSDat.Tag = "31bPSDat";
            this.label31bPSDat.Text = "31b. Physician Signature date";
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.Text = "notifyIcon1";
            this.notifyIcon1.Visible = true;
            // 
            // PClaim_8
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.BackColor = System.Drawing.Color.LightCyan;
            this.ClientSize = new System.Drawing.Size(1008, 1612);
            this.ContentSize = new System.Drawing.Size(1024, 1650);
            this.Controls.Add(this.label31bPSDat);
            this.Controls.Add(this.dcim31bPSDat);
            this.Controls.Add(this.dced31bPSDat);
            this.Controls.Add(this.labelEPSD);
            this.Controls.Add(this.dced21_ICDInd);
            this.Controls.Add(this.labelCD);
            this.Controls.Add(this.dced21_Diag12);
            this.Controls.Add(this.dced21_Diag11);
            this.Controls.Add(this.dced21_Diag10);
            this.Controls.Add(this.dced21_Diag9);
            this.Controls.Add(this.label63);
            this.Controls.Add(this.label64);
            this.Controls.Add(this.label65);
            this.Controls.Add(this.label66);
            this.Controls.Add(this.dced21_Diag8);
            this.Controls.Add(this.dced21_Diag7);
            this.Controls.Add(this.dced21_Diag6);
            this.Controls.Add(this.dced21_Diag5);
            this.Controls.Add(this.label58);
            this.Controls.Add(this.label60);
            this.Controls.Add(this.label61);
            this.Controls.Add(this.label62);
            this.Controls.Add(this.label19LocUse);
            this.Controls.Add(this.dcim19LocUse);
            this.Controls.Add(this.dced19LocUse);
            this.Controls.Add(this.label17qual);
            this.Controls.Add(this.dcim17qual);
            this.Controls.Add(this.dced17qual);
            this.Controls.Add(this.dcim20bLChgs);
            this.Controls.Add(this.dced20bLChgs);
            this.Controls.Add(this.label20aOutLb);
            this.Controls.Add(this.dcim20aOutLb);
            this.Controls.Add(this.cmb20aOutLb);
            this.Controls.Add(this.dcim16bDsDtT);
            this.Controls.Add(this.dced16bDsDtT);
            this.Controls.Add(this.label57);
            this.Controls.Add(this.dcim16aDsDtF);
            this.Controls.Add(this.dced16aDsDtF);
            this.Controls.Add(this.label15qual);
            this.Controls.Add(this.dcim15qual);
            this.Controls.Add(this.dced15qual);
            this.Controls.Add(this.label14aSym);
            this.Controls.Add(this.dcim14aSym);
            this.Controls.Add(this.dced14aSym);
            this.Controls.Add(this.label13InsSig);
            this.Controls.Add(this.dcim13InsSig);
            this.Controls.Add(this.cmb13InsSig);
            this.Controls.Add(this.dcim12bDtSgn);
            this.Controls.Add(this.dced12bDtSgn);
            this.Controls.Add(this.label12aPSign);
            this.Controls.Add(this.dcim12aPSign);
            this.Controls.Add(this.cmb12aPSign);
            this.Controls.Add(this.label9bOInSex);
            this.Controls.Add(this.dcim9bOInSex);
            this.Controls.Add(this.cmb9bOInSex);
            this.Controls.Add(this.label9dOIPlNm);
            this.Controls.Add(this.dcim9dOIPlNm);
            this.Controls.Add(this.dced9dOIPlNm);
            this.Controls.Add(this.label9cOIEmNm);
            this.Controls.Add(this.dcim9cOIEmNm);
            this.Controls.Add(this.dced9cOIEmNm);
            this.Controls.Add(this.label9bOInDOB);
            this.Controls.Add(this.dcim9bOInDOB);
            this.Controls.Add(this.dced9bOInDOB);
            this.Controls.Add(this.label59);
            this.Controls.Add(this.dcim9aOtInNo);
            this.Controls.Add(this.dced9aOtInNo);
            this.Controls.Add(this.label9OtInsMInit);
            this.Controls.Add(this.dcim9OtInsMInit);
            this.Controls.Add(this.dced9OtInsMInit);
            this.Controls.Add(this.label9OtInsFNam);
            this.Controls.Add(this.dcim9OtInsFNam);
            this.Controls.Add(this.dced9OtInsFNam);
            this.Controls.Add(this.label9OtInsLNam);
            this.Controls.Add(this.dcim9OtInsLNam);
            this.Controls.Add(this.dced9OtInsLNam);
            this.Controls.Add(this.label11bqual);
            this.Controls.Add(this.dcim11bqual);
            this.Controls.Add(this.dced11bqual);
            this.Controls.Add(this.label8aPStatM);
            this.Controls.Add(this.label10bautop);
            this.Controls.Add(this.dcim10bautop);
            this.Controls.Add(this.dced10bautop);
            this.Controls.Add(this.label10bPCRAA);
            this.Controls.Add(this.dcim10bPCRAA);
            this.Controls.Add(this.cmb10bPCRAA);
            this.Controls.Add(this.label10cPCROA);
            this.Controls.Add(this.dcim10cPCROA);
            this.Controls.Add(this.cmb10cPCROA);
            this.Controls.Add(this.label10aPCREm);
            this.Controls.Add(this.dcim10aPCREm);
            this.Controls.Add(this.cmb10aPCREm);
            this.Controls.Add(this.label8bPStatE);
            this.Controls.Add(this.dcim8bPStatE);
            this.Controls.Add(this.cmb8bPStatE);
            this.Controls.Add(this.dcim8aPStatM);
            this.Controls.Add(this.cmb8aPStatM);
            this.Controls.Add(this.label10dLocUs);
            this.Controls.Add(this.dcim10dLocUs);
            this.Controls.Add(this.dced10dLocUs);
            this.Controls.Add(this.dced21_Diag4);
            this.Controls.Add(this.dced21_Diag3);
            this.Controls.Add(this.dced21_Diag2);
            this.Controls.Add(this.dced21_Diag1);
            this.Controls.Add(this.label21_Diag1);
            this.Controls.Add(this.label56);
            this.Controls.Add(this.dcim23PriAth);
            this.Controls.Add(this.dced23PriAth);
            this.Controls.Add(this.label55);
            this.Controls.Add(this.dcim22bOrigR);
            this.Controls.Add(this.dced22bOrigR);
            this.Controls.Add(this.label54);
            this.Controls.Add(this.dcim22aResub);
            this.Controls.Add(this.dced22aResub);
            this.Controls.Add(this.dcim18bHpDtT);
            this.Controls.Add(this.dced18bHpDtT);
            this.Controls.Add(this.label53);
            this.Controls.Add(this.dcim18aHpDtF);
            this.Controls.Add(this.dced18aHpDtF);
            this.Controls.Add(this.dcedReMIni);
            this.Controls.Add(this.dced17ReFNam);
            this.Controls.Add(this.label52);
            this.Controls.Add(this.dcim17RefDoc);
            this.Controls.Add(this.dced17ReLNam);
            this.Controls.Add(this.label51);
            this.Controls.Add(this.dcim15HisDat);
            this.Controls.Add(this.dced15HisDat);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.dcim14SymDat);
            this.Controls.Add(this.dced14SymDat);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.dcim25bSSEIN);
            this.Controls.Add(this.cmb25bSSEIN);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.dcim11bIEmNm);
            this.Controls.Add(this.dced11bIEmNm);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.dcim6PatRela);
            this.Controls.Add(this.cmb6PatRela);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.dcim1InsType);
            this.Controls.Add(this.cmb1InsType);
            this.Controls.Add(this.lbl7IAddStr);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.dced5PAddTel);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.btnSwapNm31);
            this.Controls.Add(this.btnCopyAdd2to4);
            this.Controls.Add(this.btnCopyAdd4to2);
            this.Controls.Add(this.btnCopyNm4to2);
            this.Controls.Add(this.btnCopyNm2to4);
            this.Controls.Add(this.btnSwapNames4);
            this.Controls.Add(this.btnSwapNamesFld2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lbl7IAddSta);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.dcim7IAddStr);
            this.Controls.Add(this.lbDateFrom);
            this.Controls.Add(this.lbPlaceofService);
            this.Controls.Add(this.lbTypeofService);
            this.Controls.Add(this.lbCPT_Code);
            this.Controls.Add(this.lbDiagPointer);
            this.Controls.Add(this.lbCharges);
            this.Controls.Add(this.lbDays_Units);
            this.Controls.Add(this.lbNPI);
            this.Controls.Add(this.panLINEITEM);
            this.Controls.Add(this.btnDelpbLINEITEM);
            this.Controls.Add(this.btnInsAfterpbLINEITEM);
            this.Controls.Add(this.btnInsBeforepbLINEITEM);
            this.Controls.Add(this.label50);
            this.Controls.Add(this.label49);
            this.Controls.Add(this.label48);
            this.Controls.Add(this.label47);
            this.Controls.Add(this.label46);
            this.Controls.Add(this.label45);
            this.Controls.Add(this.label44);
            this.Controls.Add(this.label43);
            this.Controls.Add(this.label42);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dced5PAddStr);
            this.Controls.Add(this.dced5PAddCty);
            this.Controls.Add(this.dcim5PAddSta);
            this.Controls.Add(this.dced5PAddSta);
            this.Controls.Add(this.dcim5PAddZip);
            this.Controls.Add(this.dced5PAddZip);
            this.Controls.Add(this.lbl3Pat_DOB);
            this.Controls.Add(this.dcim3Pat_DOB);
            this.Controls.Add(this.dced3Pat_DOB);
            this.Controls.Add(this.lbl3aPatSex);
            this.Controls.Add(this.dcim3aPatSex);
            this.Controls.Add(this.cmb3aPatSex);
            this.Controls.Add(this.lbl1aInsrID);
            this.Controls.Add(this.dcim1aInsrID);
            this.Controls.Add(this.dced1aInsrID);
            this.Controls.Add(this.dced7IAddStr);
            this.Controls.Add(this.lbl7IAddCty);
            this.Controls.Add(this.dced7IAddCty);
            this.Controls.Add(this.dced7IAddSta);
            this.Controls.Add(this.dcim7IAddZip);
            this.Controls.Add(this.dced7IAddZip);
            this.Controls.Add(this.lbl7IAddTel);
            this.Controls.Add(this.dcim33DocAdd);
            this.Controls.Add(this.dced7IAddTel);
            this.Controls.Add(this.lbl11IPolNo);
            this.Controls.Add(this.dcim11IPolNo);
            this.Controls.Add(this.dced11IPolNo);
            this.Controls.Add(this.lbl11aInSex);
            this.Controls.Add(this.dcim11aInSex);
            this.Controls.Add(this.cmb11aInSex);
            this.Controls.Add(this.lbl11aInDOB);
            this.Controls.Add(this.dcim11aInDOB);
            this.Controls.Add(this.dced11aInDOB);
            this.Controls.Add(this.lbl11cIPlan);
            this.Controls.Add(this.dcim11cIPlan);
            this.Controls.Add(this.dced11cIPlan);
            this.Controls.Add(this.lbl11dPlOth);
            this.Controls.Add(this.dcim11dPlOth);
            this.Controls.Add(this.cmb11dPlOth);
            this.Controls.Add(this.lbl17aRfDID);
            this.Controls.Add(this.dcim17aRfDID);
            this.Controls.Add(this.dced17aRfDID);
            this.Controls.Add(this.lbl17aRfCd);
            this.Controls.Add(this.dced17aRfCd);
            this.Controls.Add(this.dcim17bRfNPI);
            this.Controls.Add(this.dced17bRfNPI);
            this.Controls.Add(this.lbl25aFedTx);
            this.Controls.Add(this.dcim25aFedTx);
            this.Controls.Add(this.dced25aFedTx);
            this.Controls.Add(this.lbl26PActNo);
            this.Controls.Add(this.dcim26PActNo);
            this.Controls.Add(this.dced26PActNo);
            this.Controls.Add(this.lbl27AccAss);
            this.Controls.Add(this.dcim27AccAss);
            this.Controls.Add(this.cmb27AccAss);
            this.Controls.Add(this.lbl28TotChg);
            this.Controls.Add(this.dcim28TotChg);
            this.Controls.Add(this.dced28TotChg);
            this.Controls.Add(this.lbl29Amt_Pd);
            this.Controls.Add(this.dcim29Amt_Pd);
            this.Controls.Add(this.dced29Amt_Pd);
            this.Controls.Add(this.lbl30BalDue);
            this.Controls.Add(this.dcim30BalDue);
            this.Controls.Add(this.dced30BalDue);
            this.Controls.Add(this.dcim32FacAdd);
            this.Controls.Add(this.dced32FacNPI);
            this.Controls.Add(this.dced32FacID);
            this.Controls.Add(this.lbl24aDtFr1);
            this.Controls.Add(this.dced2PaLName);
            this.Controls.Add(this.dced2PaFName);
            this.Controls.Add(this.dced2PaMInit);
            this.Controls.Add(this.dced4InsLNam);
            this.Controls.Add(this.dced4InsFNam);
            this.Controls.Add(this.dced4InsMIni);
            this.Controls.Add(this.dcim17ReCred);
            this.Controls.Add(this.dced17ReCred);
            this.Controls.Add(this.dcim17ReSufx);
            this.Controls.Add(this.dced17ReSufx);
            this.Controls.Add(this.dced31aPhLNm);
            this.Controls.Add(this.dced31aPhFNm);
            this.Controls.Add(this.dced31aPhIni);
            this.Controls.Add(this.dced32FacNam);
            this.Controls.Add(this.dced32F1Addr);
            this.Controls.Add(this.dced32F2Addr);
            this.Controls.Add(this.dced32FacCit);
            this.Controls.Add(this.dced32FacSta);
            this.Controls.Add(this.dced32FacZip);
            this.Controls.Add(this.dced33PhBNam);
            this.Controls.Add(this.dced33Ph1Add);
            this.Controls.Add(this.dced33Ph2Add);
            this.Controls.Add(this.dced33PhCity);
            this.Controls.Add(this.dced33PhStat);
            this.Controls.Add(this.dced33PhyZip);
            this.Controls.Add(this.dced33PhyNPI);
            this.Controls.Add(this.dced33PhyID);
            this.Controls.Add(this.lbReferenceId);
            this.Controls.Add(this.lblcopynm);
            this.Controls.Add(this.lblCopyAddress);
            this.Controls.Add(this.lblCopyAll);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.pictureBox9);
            this.Controls.Add(this.pictureBox1);
            this.MaximumSize = new System.Drawing.Size(1048, 1674);
            this.Name = "PClaim_8";
            ((System.ComponentModel.ISupportInitialize)(this.dced5PAddStr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced5PAddCty)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim5PAddSta)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced5PAddSta)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim5PAddZip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced5PAddZip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim3Pat_DOB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced3Pat_DOB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim3aPatSex)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim1aInsrID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced1aInsrID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced7IAddStr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced7IAddCty)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced7IAddSta)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim7IAddZip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced7IAddZip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim33DocAdd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced7IAddTel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim11IPolNo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced11IPolNo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim11aInSex)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim11aInDOB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced11aInDOB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim11cIPlan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced11cIPlan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim11dPlOth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim17aRfDID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced17aRfDID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced17aRfCd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim17bRfNPI)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced17bRfNPI)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim25aFedTx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced25aFedTx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim26PActNo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced26PActNo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim27AccAss)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim28TotChg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced28TotChg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim29Amt_Pd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced29Amt_Pd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim30BalDue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced30BalDue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim32FacAdd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced32FacNPI)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced32FacID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced2PaLName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced2PaFName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced2PaMInit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced4InsLNam)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced4InsFNam)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced4InsMIni)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim17ReCred)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced17ReCred)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim17ReSufx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced17ReSufx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced31aPhLNm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced31aPhFNm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced31aPhIni)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced32FacNam)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced32F1Addr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced32F2Addr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced32FacCit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced32FacSta)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced32FacZip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced33PhBNam)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced33Ph1Add)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced33Ph2Add)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced33PhCity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced33PhStat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced33PhyZip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced33PhyNPI)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced33PhyID)).EndInit();
            this.panLINEITEM.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dcimNDCQty)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedNDCQty)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimEPSDTcode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedEPSDTcode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimEPSD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedEPSD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimCharges)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimNDCType)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedNDCType)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimNDC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedNDC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimEMG_C)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedEMG_C)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimReferenceId)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedReferenceId)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimDateFrom)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedDateFrom)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimDateThru)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedDateThru)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimPlaceofService)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedPlaceofService)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimCPT_Code)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedCPT_Code)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimModifiers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedModifiers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimDiagPointer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedDiagPointer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedCharges)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimDays_Units)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedDays_Units)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimQualifier)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedQualifier)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimNPI)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedNPI)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedInfo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimInfo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim7IAddStr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced21_Diag1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced21_Diag2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced21_Diag3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced21_Diag4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced5PAddTel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim1InsType)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim6PatRela)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim11bIEmNm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced11bIEmNm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim25bSSEIN)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim14SymDat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced14SymDat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim15HisDat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced15HisDat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim17RefDoc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced17ReLNam)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced17ReFNam)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedReMIni)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim18aHpDtF)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced18aHpDtF)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim18bHpDtT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced18bHpDtT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim22aResub)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced22aResub)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim22bOrigR)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced22bOrigR)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim23PriAth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced23PriAth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim10dLocUs)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced10dLocUs)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim8aPStatM)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim8bPStatE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim10aPCREm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim10cPCROA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim10bPCRAA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim10bautop)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced10bautop)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim11bqual)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced11bqual)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim9OtInsLNam)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced9OtInsLNam)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim9OtInsFNam)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced9OtInsFNam)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim9OtInsMInit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced9OtInsMInit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim9aOtInNo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced9aOtInNo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim9bOInDOB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced9bOInDOB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim9cOIEmNm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced9cOIEmNm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim9dOIPlNm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced9dOIPlNm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim9bOInSex)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim12aPSign)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim12bDtSgn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced12bDtSgn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim13InsSig)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim14aSym)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced14aSym)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim15qual)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced15qual)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim16bDsDtT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced16bDsDtT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim16aDsDtF)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced16aDsDtF)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim20aOutLb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim20bLChgs)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced20bLChgs)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim17qual)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced17qual)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim19LocUse)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced19LocUse)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced21_Diag8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced21_Diag7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced21_Diag6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced21_Diag5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced21_Diag12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced21_Diag11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced21_Diag10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced21_Diag9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced21_ICDInd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim31bPSDat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced31bPSDat)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private AxDCEDITLib.AxDcedit dced5PAddStr;
        private AxDCEDITLib.AxDcedit dced5PAddCty;
        private AxDCIMAGELib.AxDcimage dcim5PAddSta;
        private AxDCEDITLib.AxDcedit dced5PAddSta;
        private AxDCIMAGELib.AxDcimage dcim5PAddZip;
        private AxDCEDITLib.AxDcedit dced5PAddZip;
        private System.Windows.Forms.Label lbl3Pat_DOB;
        private AxDCIMAGELib.AxDcimage dcim3Pat_DOB;
        private AxDCEDITLib.AxDcedit dced3Pat_DOB;
        private System.Windows.Forms.Label lbl3aPatSex;
        private AxDCIMAGELib.AxDcimage dcim3aPatSex;
        private System.Windows.Forms.ComboBox cmb3aPatSex;
        private System.Windows.Forms.Label lbl1aInsrID;
        private AxDCIMAGELib.AxDcimage dcim1aInsrID;
        private AxDCEDITLib.AxDcedit dced1aInsrID;
        private System.Windows.Forms.Label lbl7IAddStr;
        private AxDCEDITLib.AxDcedit dced7IAddStr;
        private System.Windows.Forms.Label lbl7IAddCty;
        private AxDCEDITLib.AxDcedit dced7IAddCty;
        private AxDCEDITLib.AxDcedit dced7IAddSta;
        private AxDCIMAGELib.AxDcimage dcim7IAddZip;
        private AxDCEDITLib.AxDcedit dced7IAddZip;
        private System.Windows.Forms.Label lbl7IAddTel;
        private AxDCIMAGELib.AxDcimage dcim33DocAdd;
        private AxDCEDITLib.AxDcedit dced7IAddTel;
        private System.Windows.Forms.Label lbl11IPolNo;
        private AxDCIMAGELib.AxDcimage dcim11IPolNo;
        private AxDCEDITLib.AxDcedit dced11IPolNo;
        private System.Windows.Forms.Label lbl11aInSex;
        private AxDCIMAGELib.AxDcimage dcim11aInSex;
        private System.Windows.Forms.ComboBox cmb11aInSex;
        private System.Windows.Forms.Label lbl11aInDOB;
        private AxDCIMAGELib.AxDcimage dcim11aInDOB;
        private AxDCEDITLib.AxDcedit dced11aInDOB;
        private System.Windows.Forms.Label lbl11cIPlan;
        private AxDCIMAGELib.AxDcimage dcim11cIPlan;
        private AxDCEDITLib.AxDcedit dced11cIPlan;
        private System.Windows.Forms.Label lbl11dPlOth;
        private AxDCIMAGELib.AxDcimage dcim11dPlOth;
        private System.Windows.Forms.ComboBox cmb11dPlOth;
        private System.Windows.Forms.Label lbl17aRfDID;
        private AxDCIMAGELib.AxDcimage dcim17aRfDID;
        private AxDCEDITLib.AxDcedit dced17aRfDID;
        private System.Windows.Forms.Label lbl17aRfCd;
        private AxDCEDITLib.AxDcedit dced17aRfCd;
        private AxDCIMAGELib.AxDcimage dcim17bRfNPI;
        private AxDCEDITLib.AxDcedit dced17bRfNPI;
        private System.Windows.Forms.Label lbl25aFedTx;
        private AxDCIMAGELib.AxDcimage dcim25aFedTx;
        private AxDCEDITLib.AxDcedit dced25aFedTx;
        private System.Windows.Forms.Label lbl26PActNo;
        private AxDCIMAGELib.AxDcimage dcim26PActNo;
        private AxDCEDITLib.AxDcedit dced26PActNo;
        private System.Windows.Forms.Label lbl27AccAss;
        private AxDCIMAGELib.AxDcimage dcim27AccAss;
        private System.Windows.Forms.ComboBox cmb27AccAss;
        private System.Windows.Forms.Label lbl28TotChg;
        private AxDCIMAGELib.AxDcimage dcim28TotChg;
        private AxDCEDITLib.AxDcedit dced28TotChg;
        private System.Windows.Forms.Label lbl29Amt_Pd;
        private AxDCIMAGELib.AxDcimage dcim29Amt_Pd;
        private AxDCEDITLib.AxDcedit dced29Amt_Pd;
        private System.Windows.Forms.Label lbl30BalDue;
        private AxDCIMAGELib.AxDcimage dcim30BalDue;
        private AxDCEDITLib.AxDcedit dced30BalDue;
        private AxDCIMAGELib.AxDcimage dcim32FacAdd;
        private AxDCEDITLib.AxDcedit dced32FacNPI;
        private AxDCEDITLib.AxDcedit dced32FacID;
        private System.Windows.Forms.Label lbl24aDtFr1;
        private AxDCEDITLib.AxDcedit dced2PaLName;
        private AxDCEDITLib.AxDcedit dced2PaFName;
        private AxDCEDITLib.AxDcedit dced2PaMInit;
        private AxDCEDITLib.AxDcedit dced4InsLNam;
        private AxDCEDITLib.AxDcedit dced4InsFNam;
        private AxDCEDITLib.AxDcedit dced4InsMIni;
        private AxDCIMAGELib.AxDcimage dcim17ReCred;
        private AxDCEDITLib.AxDcedit dced17ReCred;
        private AxDCIMAGELib.AxDcimage dcim17ReSufx;
        private AxDCEDITLib.AxDcedit dced17ReSufx;
        private AxDCEDITLib.AxDcedit dced31aPhLNm;
        private AxDCEDITLib.AxDcedit dced31aPhFNm;
        private AxDCEDITLib.AxDcedit dced31aPhIni;
        private AxDCEDITLib.AxDcedit dced32FacNam;
        private AxDCEDITLib.AxDcedit dced32F1Addr;
        private AxDCEDITLib.AxDcedit dced32F2Addr;
        private AxDCEDITLib.AxDcedit dced32FacCit;
        private AxDCEDITLib.AxDcedit dced32FacSta;
        private AxDCEDITLib.AxDcedit dced32FacZip;
        private AxDCEDITLib.AxDcedit dced33PhBNam;
        private AxDCEDITLib.AxDcedit dced33Ph1Add;
        private AxDCEDITLib.AxDcedit dced33Ph2Add;
        private AxDCEDITLib.AxDcedit dced33PhCity;
        private AxDCEDITLib.AxDcedit dced33PhStat;
        private AxDCEDITLib.AxDcedit dced33PhyZip;
        private AxDCEDITLib.AxDcedit dced33PhyNPI;
        private AxDCEDITLib.AxDcedit dced33PhyID;
        private System.Windows.Forms.Label lbReferenceId;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label lbDateFrom;
        private System.Windows.Forms.Label lbPlaceofService;
        private System.Windows.Forms.Label lbTypeofService;
        private System.Windows.Forms.Label lbCPT_Code;
        private System.Windows.Forms.Label lbDiagPointer;
        private System.Windows.Forms.Label lbCharges;
        private System.Windows.Forms.Label lbDays_Units;
        private System.Windows.Forms.Label lbNPI;
        private System.Windows.Forms.Panel panLINEITEM;
        private AxDCIMAGELib.AxDcimage dcimDateFrom;
        private AxDCEDITLib.AxDcedit dcedDateFrom;
        private AxDCIMAGELib.AxDcimage dcimDateThru;
        private AxDCEDITLib.AxDcedit dcedDateThru;
        private AxDCIMAGELib.AxDcimage dcimPlaceofService;
        private AxDCEDITLib.AxDcedit dcedPlaceofService;
        private AxDCIMAGELib.AxDcimage dcimCPT_Code;
        private AxDCEDITLib.AxDcedit dcedCPT_Code;
        private AxDCIMAGELib.AxDcimage dcimModifiers;
        private AxDCEDITLib.AxDcedit dcedModifiers;
        private AxDCIMAGELib.AxDcimage dcimDiagPointer;
        private AxDCEDITLib.AxDcedit dcedDiagPointer;
        private AxDCIMAGELib.AxDcimage dcimCharges;
        private AxDCEDITLib.AxDcedit dcedCharges;
        private AxDCIMAGELib.AxDcimage dcimDays_Units;
        private AxDCEDITLib.AxDcedit dcedDays_Units;
        private AxDCIMAGELib.AxDcimage dcimQualifier;
        private AxDCEDITLib.AxDcedit dcedQualifier;
        private AxDCIMAGELib.AxDcimage dcimNPI;
        private AxDCEDITLib.AxDcedit dcedNPI;
        private AxDCEDITLib.AxDcedit dcedInfo;
        private AxDCIMAGELib.AxDcimage dcimInfo;
        private System.Windows.Forms.Button btnDelpbLINEITEM;
        private System.Windows.Forms.Button btnInsAfterpbLINEITEM;
        private System.Windows.Forms.Button btnInsBeforepbLINEITEM;
        private AxDCIMAGELib.AxDcimage dcimReferenceId;
        private AxDCEDITLib.AxDcedit dcedReferenceId;
        private AxDCIMAGELib.AxDcimage dcimEMG_C;
        private AxDCEDITLib.AxDcedit dcedEMG_C;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label21_Diag1;
        private AxDCIMAGELib.AxDcimage dcim7IAddStr;
        private System.Windows.Forms.Label lbl7IAddSta;
        private AxDCEDITLib.AxDcedit dced21_Diag1;
        private AxDCEDITLib.AxDcedit dced21_Diag2;
        private AxDCEDITLib.AxDcedit dced21_Diag3;
        private AxDCEDITLib.AxDcedit dced21_Diag4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnSwapNamesFld2;
        private System.Windows.Forms.Button btnSwapNames4;
        private System.Windows.Forms.Button btnCopyNm2to4;
        private System.Windows.Forms.Button btnCopyNm4to2;
        private System.Windows.Forms.Button btnCopyAdd4to2;
        private System.Windows.Forms.Button btnCopyAdd2to4;
        private System.Windows.Forms.Button btnSwapNm31;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Label lblcopynm;
        private System.Windows.Forms.Label lblCopyAddress;
        private System.Windows.Forms.Label label11;
        private AxDCEDITLib.AxDcedit dced5PAddTel;
        private System.Windows.Forms.Label lblCopyAll;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label12;
        private AxDCIMAGELib.AxDcimage dcim1InsType;
        private System.Windows.Forms.ComboBox cmb1InsType;
        private System.Windows.Forms.Label label13;
        private AxDCIMAGELib.AxDcimage dcim6PatRela;
        private System.Windows.Forms.ComboBox cmb6PatRela;
        private System.Windows.Forms.Label label14;
        private AxDCIMAGELib.AxDcimage dcim11bIEmNm;
        private AxDCEDITLib.AxDcedit dced11bIEmNm;
        private System.Windows.Forms.Label label15;
        private AxDCIMAGELib.AxDcimage dcim25bSSEIN;
        private System.Windows.Forms.ComboBox cmb25bSSEIN;
        private AxDCIMAGELib.AxDcimage dcimNDCType;
        private AxDCEDITLib.AxDcedit dcedNDCType;
        private AxDCIMAGELib.AxDcimage dcimNDC;
        private AxDCEDITLib.AxDcedit dcedNDC;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private AxDCIMAGELib.AxDcimage dcim14SymDat;
        private AxDCEDITLib.AxDcedit dced14SymDat;
        private System.Windows.Forms.Label label51;
        private AxDCIMAGELib.AxDcimage dcim15HisDat;
        private AxDCEDITLib.AxDcedit dced15HisDat;
        private System.Windows.Forms.Label label52;
        private AxDCIMAGELib.AxDcimage dcim17RefDoc;
        private AxDCEDITLib.AxDcedit dced17ReLNam;
        private AxDCEDITLib.AxDcedit dced17ReFNam;
        private AxDCEDITLib.AxDcedit dcedReMIni;
        private System.Windows.Forms.Label label53;
        private AxDCIMAGELib.AxDcimage dcim18aHpDtF;
        private AxDCEDITLib.AxDcedit dced18aHpDtF;
        private AxDCIMAGELib.AxDcimage dcim18bHpDtT;
        private AxDCEDITLib.AxDcedit dced18bHpDtT;
        private System.Windows.Forms.Label label54;
        private AxDCIMAGELib.AxDcimage dcim22aResub;
        private AxDCEDITLib.AxDcedit dced22aResub;
        private System.Windows.Forms.Label label55;
        private AxDCIMAGELib.AxDcimage dcim22bOrigR;
        private AxDCEDITLib.AxDcedit dced22bOrigR;
        private System.Windows.Forms.Label label56;
        private AxDCIMAGELib.AxDcimage dcim23PriAth;
        private AxDCEDITLib.AxDcedit dced23PriAth;
        private AxDCIMAGELib.AxDcimage dcim10dLocUs;
        private AxDCEDITLib.AxDcedit dced10dLocUs;
        private System.Windows.Forms.Label label10dLocUs;
        private System.Windows.Forms.Label label8aPStatM;
        private AxDCIMAGELib.AxDcimage dcim8aPStatM;
        private System.Windows.Forms.ComboBox cmb8aPStatM;
        private System.Windows.Forms.Label label8bPStatE;
        private AxDCIMAGELib.AxDcimage dcim8bPStatE;
        private System.Windows.Forms.ComboBox cmb8bPStatE;
        private System.Windows.Forms.Label label10aPCREm;
        private AxDCIMAGELib.AxDcimage dcim10aPCREm;
        private System.Windows.Forms.ComboBox cmb10aPCREm;
        private System.Windows.Forms.Label label10cPCROA;
        private AxDCIMAGELib.AxDcimage dcim10cPCROA;
        private System.Windows.Forms.ComboBox cmb10cPCROA;
        private System.Windows.Forms.Label label10bPCRAA;
        private AxDCIMAGELib.AxDcimage dcim10bPCRAA;
        private System.Windows.Forms.ComboBox cmb10bPCRAA;
        private System.Windows.Forms.Label label10bautop;
        private AxDCIMAGELib.AxDcimage dcim10bautop;
        private AxDCEDITLib.AxDcedit dced10bautop;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label label11bqual;
        private AxDCIMAGELib.AxDcimage dcim11bqual;
        private AxDCEDITLib.AxDcedit dced11bqual;
        private System.Windows.Forms.Label label9OtInsLNam;
        private AxDCIMAGELib.AxDcimage dcim9OtInsLNam;
        private AxDCEDITLib.AxDcedit dced9OtInsLNam;
        private System.Windows.Forms.Label label9OtInsFNam;
        private AxDCIMAGELib.AxDcimage dcim9OtInsFNam;
        private AxDCEDITLib.AxDcedit dced9OtInsFNam;
        private System.Windows.Forms.Label label9OtInsMInit;
        private AxDCIMAGELib.AxDcimage dcim9OtInsMInit;
        private AxDCEDITLib.AxDcedit dced9OtInsMInit;
        private System.Windows.Forms.Label label59;
        private AxDCIMAGELib.AxDcimage dcim9aOtInNo;
        private AxDCEDITLib.AxDcedit dced9aOtInNo;
        private System.Windows.Forms.Label label9bOInDOB;
        private AxDCIMAGELib.AxDcimage dcim9bOInDOB;
        private AxDCEDITLib.AxDcedit dced9bOInDOB;
        private System.Windows.Forms.Label label9cOIEmNm;
        private AxDCIMAGELib.AxDcimage dcim9cOIEmNm;
        private AxDCEDITLib.AxDcedit dced9cOIEmNm;
        private System.Windows.Forms.Label label9dOIPlNm;
        private AxDCIMAGELib.AxDcimage dcim9dOIPlNm;
        private AxDCEDITLib.AxDcedit dced9dOIPlNm;
        private System.Windows.Forms.Label label9bOInSex;
        private AxDCIMAGELib.AxDcimage dcim9bOInSex;
        private System.Windows.Forms.ComboBox cmb9bOInSex;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Label label12aPSign;
        private AxDCIMAGELib.AxDcimage dcim12aPSign;
        private System.Windows.Forms.ComboBox cmb12aPSign;
        private AxDCIMAGELib.AxDcimage dcim12bDtSgn;
        private AxDCEDITLib.AxDcedit dced12bDtSgn;
        private System.Windows.Forms.Label label13InsSig;
        private AxDCIMAGELib.AxDcimage dcim13InsSig;
        private System.Windows.Forms.ComboBox cmb13InsSig;
        private AxDCIMAGELib.AxDcimage dcim14aSym;
        private AxDCEDITLib.AxDcedit dced14aSym;
        private System.Windows.Forms.Label label14aSym;
        private System.Windows.Forms.Label label15qual;
        private AxDCIMAGELib.AxDcimage dcim15qual;
        private AxDCEDITLib.AxDcedit dced15qual;
        private AxDCIMAGELib.AxDcimage dcim16bDsDtT;
        private AxDCEDITLib.AxDcedit dced16bDsDtT;
        private System.Windows.Forms.Label label57;
        private AxDCIMAGELib.AxDcimage dcim16aDsDtF;
        private AxDCEDITLib.AxDcedit dced16aDsDtF;
        private System.Windows.Forms.Label label20aOutLb;
        private AxDCIMAGELib.AxDcimage dcim20aOutLb;
        private System.Windows.Forms.ComboBox cmb20aOutLb;
        private AxDCIMAGELib.AxDcimage dcim20bLChgs;
        private AxDCEDITLib.AxDcedit dced20bLChgs;
        private System.Windows.Forms.Label label17qual;
        private AxDCIMAGELib.AxDcimage dcim17qual;
        private AxDCEDITLib.AxDcedit dced17qual;
        private System.Windows.Forms.Label label19LocUse;
        private AxDCIMAGELib.AxDcimage dcim19LocUse;
        private AxDCEDITLib.AxDcedit dced19LocUse;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private AxDCEDITLib.AxDcedit dced21_Diag8;
        private AxDCEDITLib.AxDcedit dced21_Diag7;
        private AxDCEDITLib.AxDcedit dced21_Diag6;
        private AxDCEDITLib.AxDcedit dced21_Diag5;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
        private AxDCEDITLib.AxDcedit dced21_Diag12;
        private AxDCEDITLib.AxDcedit dced21_Diag11;
        private AxDCEDITLib.AxDcedit dced21_Diag10;
        private AxDCEDITLib.AxDcedit dced21_Diag9;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label66;
        private AxDCEDITLib.AxDcedit dced21_ICDInd;
        private System.Windows.Forms.Label labelCD;
        private AxDCIMAGELib.AxDcimage dcimEPSDTcode;
        private AxDCEDITLib.AxDcedit dcedEPSDTcode;
        private AxDCIMAGELib.AxDcimage dcimEPSD;
        private AxDCEDITLib.AxDcedit dcedEPSD;
        private System.Windows.Forms.Label labelEPSD;
        private AxDCIMAGELib.AxDcimage dcim31bPSDat;
        private AxDCEDITLib.AxDcedit dced31bPSDat;
        private System.Windows.Forms.Label label31bPSDat;
        private System.Windows.Forms.NotifyIcon notifyIcon1;
        private AxDCIMAGELib.AxDcimage dcimNDCQty;
        private AxDCEDITLib.AxDcedit dcedNDCQty;
                        
    }
}
                