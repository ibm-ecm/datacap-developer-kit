
namespace MedicalClaimsPanels
{
    partial class IClaim
    {
        /// 
        /// Required designer variable.
        /// 
        private System.ComponentModel.IContainer components = null;

        /// 
        /// Clean up any resources being used.
        /// 
        /// true if managed resources should be disposed; otherwise, false.
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// 
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(IClaim));
            this.lbl1fcynmad = new System.Windows.Forms.Label();
            this.dcim1fcynmad = new AxDCIMAGELib.AxDcimage();
            this.lbl1provnam = new System.Windows.Forms.Label();
            this.dced1provnam = new AxDCEDITLib.AxDcedit();
            this.lbl1provadd = new System.Windows.Forms.Label();
            this.dced1provadd = new AxDCEDITLib.AxDcedit();
            this.lbl1provcit = new System.Windows.Forms.Label();
            this.dced1provcit = new AxDCEDITLib.AxDcedit();
            this.lbl1provsta = new System.Windows.Forms.Label();
            this.dced1provsta = new AxDCEDITLib.AxDcedit();
            this.lbl1provzip = new System.Windows.Forms.Label();
            this.dced1provzip = new AxDCEDITLib.AxDcedit();
            this.lbl3apctlnm = new System.Windows.Forms.Label();
            this.dcim3apctlnm = new AxDCIMAGELib.AxDcimage();
            this.dced3apctlnm = new AxDCEDITLib.AxDcedit();
            this.lbl3bmdrcnm = new System.Windows.Forms.Label();
            this.dcim3bmdrcnm = new AxDCIMAGELib.AxDcimage();
            this.dced3bmdrcnm = new AxDCEDITLib.AxDcedit();
            this.lbl4typbill = new System.Windows.Forms.Label();
            this.dcim4typbill = new AxDCIMAGELib.AxDcimage();
            this.dced4typbill = new AxDCEDITLib.AxDcedit();
            this.lbl5fedtxnm = new System.Windows.Forms.Label();
            this.dcim5fedtxnm = new AxDCIMAGELib.AxDcimage();
            this.dced5fedtxnm = new AxDCEDITLib.AxDcedit();
            this.lbl6scpfrom = new System.Windows.Forms.Label();
            this.dcim6scpfrom = new AxDCIMAGELib.AxDcimage();
            this.dced6scpfrom = new AxDCEDITLib.AxDcedit();
            this.dcim6scpthru = new AxDCIMAGELib.AxDcimage();
            this.dced6scpthru = new AxDCEDITLib.AxDcedit();
            this.lbl8ptnmid = new System.Windows.Forms.Label();
            this.dcim8ptnmid = new AxDCIMAGELib.AxDcimage();
            this.dced8ptnmid = new AxDCEDITLib.AxDcedit();
            this.lbl8ptnm = new System.Windows.Forms.Label();
            this.dcim8ptnm = new AxDCIMAGELib.AxDcimage();
            this.lbl8plname = new System.Windows.Forms.Label();
            this.dced8plname = new AxDCEDITLib.AxDcedit();
            this.lbl8pfname = new System.Windows.Forms.Label();
            this.dced8pfname = new AxDCEDITLib.AxDcedit();
            this.lbl8pminit = new System.Windows.Forms.Label();
            this.dced8pminit = new AxDCEDITLib.AxDcedit();
            this.lbl9paddstr = new System.Windows.Forms.Label();
            this.dcim9paddstr = new AxDCIMAGELib.AxDcimage();
            this.dced9paddstr = new AxDCEDITLib.AxDcedit();
            this.lbl9paddcty = new System.Windows.Forms.Label();
            this.dcim9paddcty = new AxDCIMAGELib.AxDcimage();
            this.dced9paddcty = new AxDCEDITLib.AxDcedit();
            this.lbl9paddsta = new System.Windows.Forms.Label();
            this.dcim9paddsta = new AxDCIMAGELib.AxDcimage();
            this.dced9paddsta = new AxDCEDITLib.AxDcedit();
            this.lbl9paddzip = new System.Windows.Forms.Label();
            this.dcim9paddzip = new AxDCIMAGELib.AxDcimage();
            this.dced9paddzip = new AxDCEDITLib.AxDcedit();
            this.lbl9paddccd = new System.Windows.Forms.Label();
            this.dcim9paddccd = new AxDCIMAGELib.AxDcimage();
            this.dced9paddccd = new AxDCEDITLib.AxDcedit();
            this.lbl10pbdate = new System.Windows.Forms.Label();
            this.dcim10pbdate = new AxDCIMAGELib.AxDcimage();
            this.dced10pbdate = new AxDCEDITLib.AxDcedit();
            this.lbl11psex = new System.Windows.Forms.Label();
            this.dcim11psex = new AxDCIMAGELib.AxDcimage();
            this.dced11psex = new AxDCEDITLib.AxDcedit();
            this.lbl12admdte = new System.Windows.Forms.Label();
            this.dcim12admdte = new AxDCIMAGELib.AxDcimage();
            this.dced12admdte = new AxDCEDITLib.AxDcedit();
            this.lbl13admhr = new System.Windows.Forms.Label();
            this.dcim13admhr = new AxDCIMAGELib.AxDcimage();
            this.dced13admhr = new AxDCEDITLib.AxDcedit();
            this.lbl14admtyp = new System.Windows.Forms.Label();
            this.dcim14admtyp = new AxDCIMAGELib.AxDcimage();
            this.dced14admtyp = new AxDCEDITLib.AxDcedit();
            this.lbl16dhr = new System.Windows.Forms.Label();
            this.dcim16dhr = new AxDCIMAGELib.AxDcimage();
            this.dced16dhr = new AxDCEDITLib.AxDcedit();
            this.lbl17stat = new System.Windows.Forms.Label();
            this.dcim17stat = new AxDCIMAGELib.AxDcimage();
            this.dced17stat = new AxDCEDITLib.AxDcedit();
            this.lbl31aocrcd = new System.Windows.Forms.Label();
            this.dcim31aocrcd = new AxDCIMAGELib.AxDcimage();
            this.dced31aocrcd = new AxDCEDITLib.AxDcedit();
            this.dcim31aocrdt = new AxDCIMAGELib.AxDcimage();
            this.dced31aocrdt = new AxDCEDITLib.AxDcedit();
            this.dcim31bocrcd = new AxDCIMAGELib.AxDcimage();
            this.dced31bocrcd = new AxDCEDITLib.AxDcedit();
            this.dcim31bocrdt = new AxDCIMAGELib.AxDcimage();
            this.dced31bocrdt = new AxDCEDITLib.AxDcedit();
            this.lbl32aocrcd = new System.Windows.Forms.Label();
            this.dcim32aocrcd = new AxDCIMAGELib.AxDcimage();
            this.dced32aocrcd = new AxDCEDITLib.AxDcedit();
            this.dcim32aocrdt = new AxDCIMAGELib.AxDcimage();
            this.dced32aocrdt = new AxDCEDITLib.AxDcedit();
            this.dcim32bocrcd = new AxDCIMAGELib.AxDcimage();
            this.dced32bocrcd = new AxDCEDITLib.AxDcedit();
            this.dcim32bocrdt = new AxDCIMAGELib.AxDcimage();
            this.dced32bocrdt = new AxDCEDITLib.AxDcedit();
            this.lbl36aospcd = new System.Windows.Forms.Label();
            this.dcim36aospcd = new AxDCIMAGELib.AxDcimage();
            this.dced36aospcd = new AxDCEDITLib.AxDcedit();
            this.dcim36aospfr = new AxDCIMAGELib.AxDcimage();
            this.dced36aospfr = new AxDCEDITLib.AxDcedit();
            this.dcim36aospth = new AxDCIMAGELib.AxDcimage();
            this.dced36aospth = new AxDCEDITLib.AxDcedit();
            this.dcim36bospcd = new AxDCIMAGELib.AxDcimage();
            this.dced36bospcd = new AxDCEDITLib.AxDcedit();
            this.dcim36bospfr = new AxDCIMAGELib.AxDcimage();
            this.dced36bospfr = new AxDCEDITLib.AxDcedit();
            this.dcim36bospth = new AxDCIMAGELib.AxDcimage();
            this.dced36bospth = new AxDCEDITLib.AxDcedit();
            this.lbl39avlcd = new System.Windows.Forms.Label();
            this.dcim39avlcd = new AxDCIMAGELib.AxDcimage();
            this.dced39avlcd = new AxDCEDITLib.AxDcedit();
            this.dcim39avlamt = new AxDCIMAGELib.AxDcimage();
            this.dced39avlamt = new AxDCEDITLib.AxDcedit();
            this.dcim39bvlcd = new AxDCIMAGELib.AxDcimage();
            this.dced39bvlcd = new AxDCEDITLib.AxDcedit();
            this.dcim39bvlamt = new AxDCIMAGELib.AxDcimage();
            this.dced39bvlamt = new AxDCEDITLib.AxDcedit();
            this.dcim39cvlcd = new AxDCIMAGELib.AxDcimage();
            this.dced39cvlcd = new AxDCEDITLib.AxDcedit();
            this.dcim39cvlamt = new AxDCIMAGELib.AxDcimage();
            this.dced39cvlamt = new AxDCEDITLib.AxDcedit();
            this.dcim39dvlcd = new AxDCIMAGELib.AxDcimage();
            this.dced39dvlcd = new AxDCEDITLib.AxDcedit();
            this.dcim39dvlamt = new AxDCIMAGELib.AxDcimage();
            this.dced39dvlamt = new AxDCEDITLib.AxDcedit();
            this.lbl40avlcd = new System.Windows.Forms.Label();
            this.dcim40avlcd = new AxDCIMAGELib.AxDcimage();
            this.dced40avlcd = new AxDCEDITLib.AxDcedit();
            this.dcim40avlamt = new AxDCIMAGELib.AxDcimage();
            this.dced40avlamt = new AxDCEDITLib.AxDcedit();
            this.dcim40bvlcd = new AxDCIMAGELib.AxDcimage();
            this.dced40bvlcd = new AxDCEDITLib.AxDcedit();
            this.dcim40bvlamt = new AxDCIMAGELib.AxDcimage();
            this.dced40bvlamt = new AxDCEDITLib.AxDcedit();
            this.dcim40cvlcd = new AxDCIMAGELib.AxDcimage();
            this.dced40cvlcd = new AxDCEDITLib.AxDcedit();
            this.dcim40cvlamt = new AxDCIMAGELib.AxDcimage();
            this.dced40cvlamt = new AxDCEDITLib.AxDcedit();
            this.dcim40dvlcd = new AxDCIMAGELib.AxDcimage();
            this.dced40dvlcd = new AxDCEDITLib.AxDcedit();
            this.dcim40dvlamt = new AxDCIMAGELib.AxDcimage();
            this.dced40dvlamt = new AxDCEDITLib.AxDcedit();
            this.dcim41avlcd = new AxDCIMAGELib.AxDcimage();
            this.dced41avlcd = new AxDCEDITLib.AxDcedit();
            this.dcim41avlamt = new AxDCIMAGELib.AxDcimage();
            this.dced41avlamt = new AxDCEDITLib.AxDcedit();
            this.lbl41bvlcd = new System.Windows.Forms.Label();
            this.dcim41bvlcd = new AxDCIMAGELib.AxDcimage();
            this.dced41bvlcd = new AxDCEDITLib.AxDcedit();
            this.dcim41bvlamt = new AxDCIMAGELib.AxDcimage();
            this.dced41bvlamt = new AxDCEDITLib.AxDcedit();
            this.dcim41cvlcd = new AxDCIMAGELib.AxDcimage();
            this.dced41cvlcd = new AxDCEDITLib.AxDcedit();
            this.dcim41cvlamt = new AxDCIMAGELib.AxDcimage();
            this.dced41cvlamt = new AxDCEDITLib.AxDcedit();
            this.dcim41dvlcd = new AxDCIMAGELib.AxDcimage();
            this.dced41dvlcd = new AxDCEDITLib.AxDcedit();
            this.dcim41dvlamt = new AxDCIMAGELib.AxDcimage();
            this.dced41dvlamt = new AxDCEDITLib.AxDcedit();
            this.dcim50apayer = new AxDCIMAGELib.AxDcimage();
            this.dced50apayer = new AxDCEDITLib.AxDcedit();
            this.dcim50bpayer = new AxDCIMAGELib.AxDcimage();
            this.dced50bpayer = new AxDCEDITLib.AxDcedit();
            this.lbl50cpayer = new System.Windows.Forms.Label();
            this.dcim50cpayer = new AxDCIMAGELib.AxDcimage();
            this.dced50cpayer = new AxDCEDITLib.AxDcedit();
            this.dcim51aprvno = new AxDCIMAGELib.AxDcimage();
            this.dced51aprvno = new AxDCEDITLib.AxDcedit();
            this.dcim51bprvno = new AxDCIMAGELib.AxDcimage();
            this.dced51bprvno = new AxDCEDITLib.AxDcedit();
            this.lbl51cprvno = new System.Windows.Forms.Label();
            this.dcim51cprvno = new AxDCIMAGELib.AxDcimage();
            this.dced51cprvno = new AxDCEDITLib.AxDcedit();
            this.lbl56npi = new System.Windows.Forms.Label();
            this.dcim56npi = new AxDCIMAGELib.AxDcimage();
            this.dced56npi = new AxDCEDITLib.AxDcedit();
            this.dcim58ainsnm = new AxDCIMAGELib.AxDcimage();
            this.lbl58alname = new System.Windows.Forms.Label();
            this.dced58alname = new AxDCEDITLib.AxDcedit();
            this.lbl58afname = new System.Windows.Forms.Label();
            this.dced58afname = new AxDCEDITLib.AxDcedit();
            this.lbl58aminit = new System.Windows.Forms.Label();
            this.dced58aminit = new AxDCEDITLib.AxDcedit();
            this.lbl58binsnm = new System.Windows.Forms.Label();
            this.dcim58binsnm = new AxDCIMAGELib.AxDcimage();
            this.lbl58blname = new System.Windows.Forms.Label();
            this.dced58blname = new AxDCEDITLib.AxDcedit();
            this.lbl58bfname = new System.Windows.Forms.Label();
            this.dced58bfname = new AxDCEDITLib.AxDcedit();
            this.lbl58bminit = new System.Windows.Forms.Label();
            this.dced58bminit = new AxDCEDITLib.AxDcedit();
            this.dcim58cinsnm = new AxDCIMAGELib.AxDcimage();
            this.lbl58clname = new System.Windows.Forms.Label();
            this.dced58clname = new AxDCEDITLib.AxDcedit();
            this.dced58cfname = new AxDCEDITLib.AxDcedit();
            this.dced58cminit = new AxDCEDITLib.AxDcedit();
            this.dcim60acshi = new AxDCIMAGELib.AxDcimage();
            this.dced60acshi = new AxDCEDITLib.AxDcedit();
            this.dcim60bcshi = new AxDCIMAGELib.AxDcimage();
            this.dced60bcshi = new AxDCEDITLib.AxDcedit();
            this.lbl60ccshi = new System.Windows.Forms.Label();
            this.dcim60ccshi = new AxDCIMAGELib.AxDcimage();
            this.dced60ccshi = new AxDCEDITLib.AxDcedit();
            this.dcim66dxverq = new AxDCIMAGELib.AxDcimage();
            this.dced66dxverq = new AxDCEDITLib.AxDcedit();
            this.lbl67prdgcd = new System.Windows.Forms.Label();
            this.dcim67prdgcd = new AxDCIMAGELib.AxDcimage();
            this.dced67prdgcd = new AxDCEDITLib.AxDcedit();
            this.lbl67aothdg = new System.Windows.Forms.Label();
            this.dcim67aothdg = new AxDCIMAGELib.AxDcimage();
            this.dced67aothdg = new AxDCEDITLib.AxDcedit();
            this.lbl67bothdg = new System.Windows.Forms.Label();
            this.dcim67bothdg = new AxDCIMAGELib.AxDcimage();
            this.dced67bothdg = new AxDCEDITLib.AxDcedit();
            this.lbl67cothdg = new System.Windows.Forms.Label();
            this.dcim67cothdg = new AxDCIMAGELib.AxDcimage();
            this.dced67cothdg = new AxDCEDITLib.AxDcedit();
            this.lbl67dothdg = new System.Windows.Forms.Label();
            this.dcim67dothdg = new AxDCIMAGELib.AxDcimage();
            this.dced67dothdg = new AxDCEDITLib.AxDcedit();
            this.lbl67eothdg = new System.Windows.Forms.Label();
            this.dcim67eothdg = new AxDCIMAGELib.AxDcimage();
            this.dced67eothdg = new AxDCEDITLib.AxDcedit();
            this.lbl67fothdg = new System.Windows.Forms.Label();
            this.dcim67fothdg = new AxDCIMAGELib.AxDcimage();
            this.dced67fothdg = new AxDCEDITLib.AxDcedit();
            this.lbl67gothdg = new System.Windows.Forms.Label();
            this.dcim67gothdg = new AxDCIMAGELib.AxDcimage();
            this.dced67gothdg = new AxDCEDITLib.AxDcedit();
            this.lbl67hothdg = new System.Windows.Forms.Label();
            this.dcim67hothdg = new AxDCIMAGELib.AxDcimage();
            this.dced67hothdg = new AxDCEDITLib.AxDcedit();
            this.lbl67iothdg = new System.Windows.Forms.Label();
            this.dcim67iothdg = new AxDCIMAGELib.AxDcimage();
            this.dced67iothdg = new AxDCEDITLib.AxDcedit();
            this.lbl67jothdg = new System.Windows.Forms.Label();
            this.dcim67jothdg = new AxDCIMAGELib.AxDcimage();
            this.dced67jothdg = new AxDCEDITLib.AxDcedit();
            this.lbl67kothdg = new System.Windows.Forms.Label();
            this.dcim67kothdg = new AxDCIMAGELib.AxDcimage();
            this.dced67kothdg = new AxDCEDITLib.AxDcedit();
            this.lbl67lothdg = new System.Windows.Forms.Label();
            this.dcim67lothdg = new AxDCIMAGELib.AxDcimage();
            this.dced67lothdg = new AxDCEDITLib.AxDcedit();
            this.lbl67mothdg = new System.Windows.Forms.Label();
            this.dcim67mothdg = new AxDCIMAGELib.AxDcimage();
            this.dced67mothdg = new AxDCEDITLib.AxDcedit();
            this.lbl67nothdg = new System.Windows.Forms.Label();
            this.dcim67nothdg = new AxDCIMAGELib.AxDcimage();
            this.dced67nothdg = new AxDCEDITLib.AxDcedit();
            this.lbl67oothdg = new System.Windows.Forms.Label();
            this.dcim67oothdg = new AxDCIMAGELib.AxDcimage();
            this.dced67oothdg = new AxDCEDITLib.AxDcedit();
            this.lbl67pothdg = new System.Windows.Forms.Label();
            this.dcim67pothdg = new AxDCIMAGELib.AxDcimage();
            this.dced67pothdg = new AxDCEDITLib.AxDcedit();
            this.lbl67qothdg = new System.Windows.Forms.Label();
            this.dcim67qothdg = new AxDCIMAGELib.AxDcimage();
            this.dced67qothdg = new AxDCEDITLib.AxDcedit();
            this.dcim69amdgcd = new AxDCIMAGELib.AxDcimage();
            this.dced69amdgcd = new AxDCEDITLib.AxDcedit();
            this.dcim70arfvcd = new AxDCIMAGELib.AxDcimage();
            this.dced70arfvcd = new AxDCEDITLib.AxDcedit();
            this.dcim70brfvcd = new AxDCIMAGELib.AxDcimage();
            this.dced70brfvcd = new AxDCEDITLib.AxDcedit();
            this.dcim70crfvcd = new AxDCIMAGELib.AxDcimage();
            this.dced70crfvcd = new AxDCEDITLib.AxDcedit();
            this.dcim71ppscd = new AxDCIMAGELib.AxDcimage();
            this.dced71ppscd = new AxDCEDITLib.AxDcedit();
            this.lbl72aecicd = new System.Windows.Forms.Label();
            this.dcim72aecicd = new AxDCIMAGELib.AxDcimage();
            this.dced72aecicd = new AxDCEDITLib.AxDcedit();
            this.lbl74prprcd = new System.Windows.Forms.Label();
            this.dcim74prprcd = new AxDCIMAGELib.AxDcimage();
            this.dced74prprcd = new AxDCEDITLib.AxDcedit();
            this.dcim74prprdt = new AxDCIMAGELib.AxDcimage();
            this.dced74prprdt = new AxDCEDITLib.AxDcedit();
            this.lbl74aoprcd = new System.Windows.Forms.Label();
            this.dcim74aoprcd = new AxDCIMAGELib.AxDcimage();
            this.dced74aoprcd = new AxDCEDITLib.AxDcedit();
            this.dcim74aoprdt = new AxDCIMAGELib.AxDcimage();
            this.dced74aoprdt = new AxDCEDITLib.AxDcedit();
            this.dcim74boprcd = new AxDCIMAGELib.AxDcimage();
            this.dced74boprcd = new AxDCEDITLib.AxDcedit();
            this.lbl74boprdt = new System.Windows.Forms.Label();
            this.dcim74boprdt = new AxDCIMAGELib.AxDcimage();
            this.dced74boprdt = new AxDCEDITLib.AxDcedit();
            this.lbl74coprcd = new System.Windows.Forms.Label();
            this.dcim74coprcd = new AxDCIMAGELib.AxDcimage();
            this.dced74coprcd = new AxDCEDITLib.AxDcedit();
            this.dcim74coprdt = new AxDCIMAGELib.AxDcimage();
            this.dced74coprdt = new AxDCEDITLib.AxDcedit();
            this.lbl74doprcd = new System.Windows.Forms.Label();
            this.dcim74doprcd = new AxDCIMAGELib.AxDcimage();
            this.dced74doprcd = new AxDCEDITLib.AxDcedit();
            this.dcim74doprdt = new AxDCIMAGELib.AxDcimage();
            this.dced74doprdt = new AxDCEDITLib.AxDcedit();
            this.lbl74eoprcd = new System.Windows.Forms.Label();
            this.dcim74eoprcd = new AxDCIMAGELib.AxDcimage();
            this.dced74eoprcd = new AxDCEDITLib.AxDcedit();
            this.lbl74eoprdt = new System.Windows.Forms.Label();
            this.dcim74eoprdt = new AxDCIMAGELib.AxDcimage();
            this.dced74eoprdt = new AxDCEDITLib.AxDcedit();
            this.lbl76apnpi = new System.Windows.Forms.Label();
            this.dcim76apnpi = new AxDCIMAGELib.AxDcimage();
            this.dced76apnpi = new AxDCEDITLib.AxDcedit();
            this.lbl76apqual = new System.Windows.Forms.Label();
            this.dcim76apqual = new AxDCIMAGELib.AxDcimage();
            this.dced76apqual = new AxDCEDITLib.AxDcedit();
            this.lbl76apid = new System.Windows.Forms.Label();
            this.dcim76apid = new AxDCIMAGELib.AxDcimage();
            this.dced76apid = new AxDCEDITLib.AxDcedit();
            this.lbl76aplnm = new System.Windows.Forms.Label();
            this.dcim76aplnm = new AxDCIMAGELib.AxDcimage();
            this.dced76aplnm = new AxDCEDITLib.AxDcedit();
            this.lbl76apfnm = new System.Windows.Forms.Label();
            this.dcim76apfnm = new AxDCIMAGELib.AxDcimage();
            this.dced76apfnm = new AxDCEDITLib.AxDcedit();
            this.lbl23TotChgs = new System.Windows.Forms.Label();
            this.dcim23TotChgs = new AxDCIMAGELib.AxDcimage();
            this.dced23TotChgs = new AxDCEDITLib.AxDcedit();
            this.lbRevCode = new System.Windows.Forms.Label();
            this.lbDescription = new System.Windows.Forms.Label();
            this.lbHCPCS = new System.Windows.Forms.Label();
            this.lbServiceDate = new System.Windows.Forms.Label();
            this.lbUnits = new System.Windows.Forms.Label();
            this.lbCharges = new System.Windows.Forms.Label();
            this.lbNonCovered = new System.Windows.Forms.Label();
            this.lbLocalUse = new System.Windows.Forms.Label();
            this.panLINEITEM = new System.Windows.Forms.Panel();
            this.dcimRevCode = new AxDCIMAGELib.AxDcimage();
            this.dcedRevCode = new AxDCEDITLib.AxDcedit();
            this.dcimDescription = new AxDCIMAGELib.AxDcimage();
            this.dcedDescription = new AxDCEDITLib.AxDcedit();
            this.dcimHCPCS = new AxDCIMAGELib.AxDcimage();
            this.dcedHCPCS = new AxDCEDITLib.AxDcedit();
            this.dcimServiceDate = new AxDCIMAGELib.AxDcimage();
            this.dcedServiceDate = new AxDCEDITLib.AxDcedit();
            this.dcimUnits = new AxDCIMAGELib.AxDcimage();
            this.dcedUnits = new AxDCEDITLib.AxDcedit();
            this.dcimCharges = new AxDCIMAGELib.AxDcimage();
            this.dcedCharges = new AxDCEDITLib.AxDcedit();
            this.dcimNonCovered = new AxDCIMAGELib.AxDcimage();
            this.dcedNonCovered = new AxDCEDITLib.AxDcedit();
            this.dcimLocalUse = new AxDCIMAGELib.AxDcimage();
            this.dcedLocalUse = new AxDCEDITLib.AxDcedit();
            this.btnDelpbLINEITEM = new System.Windows.Forms.Button();
            this.btnInsAfterpbLINEITEM = new System.Windows.Forms.Button();
            this.btnInsBeforepbLINEITEM = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.picbx1 = new System.Windows.Forms.PictureBox();
            this.picbx8 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dcim1fcynmad)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced1provnam)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced1provadd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced1provcit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced1provsta)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced1provzip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim3apctlnm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced3apctlnm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim3bmdrcnm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced3bmdrcnm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim4typbill)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced4typbill)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim5fedtxnm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced5fedtxnm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim6scpfrom)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced6scpfrom)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim6scpthru)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced6scpthru)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim8ptnmid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced8ptnmid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim8ptnm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced8plname)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced8pfname)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced8pminit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim9paddstr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced9paddstr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim9paddcty)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced9paddcty)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim9paddsta)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced9paddsta)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim9paddzip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced9paddzip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim9paddccd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced9paddccd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim10pbdate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced10pbdate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim11psex)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced11psex)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim12admdte)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced12admdte)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim13admhr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced13admhr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim14admtyp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced14admtyp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim16dhr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced16dhr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim17stat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced17stat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim31aocrcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced31aocrcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim31aocrdt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced31aocrdt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim31bocrcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced31bocrcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim31bocrdt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced31bocrdt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim32aocrcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced32aocrcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim32aocrdt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced32aocrdt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim32bocrcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced32bocrcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim32bocrdt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced32bocrdt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim36aospcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced36aospcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim36aospfr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced36aospfr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim36aospth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced36aospth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim36bospcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced36bospcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim36bospfr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced36bospfr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim36bospth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced36bospth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim39avlcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced39avlcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim39avlamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced39avlamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim39bvlcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced39bvlcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim39bvlamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced39bvlamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim39cvlcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced39cvlcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim39cvlamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced39cvlamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim39dvlcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced39dvlcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim39dvlamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced39dvlamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim40avlcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced40avlcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim40avlamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced40avlamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim40bvlcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced40bvlcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim40bvlamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced40bvlamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim40cvlcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced40cvlcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim40cvlamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced40cvlamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim40dvlcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced40dvlcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim40dvlamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced40dvlamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim41avlcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced41avlcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim41avlamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced41avlamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim41bvlcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced41bvlcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim41bvlamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced41bvlamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim41cvlcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced41cvlcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim41cvlamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced41cvlamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim41dvlcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced41dvlcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim41dvlamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced41dvlamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim50apayer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced50apayer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim50bpayer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced50bpayer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim50cpayer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced50cpayer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim51aprvno)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced51aprvno)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim51bprvno)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced51bprvno)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim51cprvno)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced51cprvno)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim56npi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced56npi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim58ainsnm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced58alname)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced58afname)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced58aminit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim58binsnm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced58blname)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced58bfname)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced58bminit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim58cinsnm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced58clname)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced58cfname)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced58cminit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim60acshi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced60acshi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim60bcshi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced60bcshi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim60ccshi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced60ccshi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim66dxverq)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced66dxverq)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67prdgcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67prdgcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67aothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67aothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67bothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67bothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67cothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67cothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67dothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67dothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67eothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67eothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67fothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67fothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67gothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67gothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67hothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67hothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67iothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67iothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67jothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67jothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67kothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67kothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67lothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67lothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67mothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67mothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67nothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67nothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67oothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67oothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67pothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67pothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67qothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67qothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim69amdgcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced69amdgcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim70arfvcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced70arfvcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim70brfvcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced70brfvcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim70crfvcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced70crfvcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim71ppscd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced71ppscd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim72aecicd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced72aecicd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim74prprcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced74prprcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim74prprdt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced74prprdt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim74aoprcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced74aoprcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim74aoprdt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced74aoprdt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim74boprcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced74boprcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim74boprdt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced74boprdt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim74coprcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced74coprcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim74coprdt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced74coprdt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim74doprcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced74doprcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim74doprdt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced74doprdt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim74eoprcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced74eoprcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim74eoprdt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced74eoprdt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim76apnpi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced76apnpi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim76apqual)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced76apqual)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim76apid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced76apid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim76aplnm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced76aplnm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim76apfnm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced76apfnm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim23TotChgs)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced23TotChgs)).BeginInit();
            this.panLINEITEM.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dcimRevCode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedRevCode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimDescription)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedDescription)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimHCPCS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedHCPCS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimServiceDate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedServiceDate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimUnits)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedUnits)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimCharges)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedCharges)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimNonCovered)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedNonCovered)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimLocalUse)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedLocalUse)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl1fcynmad
            // 
            this.lbl1fcynmad.AutoSize = true;
            this.lbl1fcynmad.BackColor = System.Drawing.Color.Lavender;
            this.lbl1fcynmad.Location = new System.Drawing.Point(24, 113);
            this.lbl1fcynmad.Name = "lbl1fcynmad";
            this.lbl1fcynmad.Size = new System.Drawing.Size(75, 13);
            this.lbl1fcynmad.TabIndex = 0;
            this.lbl1fcynmad.Tag = "1fcynmad";
            this.lbl1fcynmad.Text = "Provider name";
            // 
            // dcim1fcynmad
            // 
            this.dcim1fcynmad.Location = new System.Drawing.Point(24, 40);
            this.dcim1fcynmad.Name = "dcim1fcynmad";
            this.dcim1fcynmad.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim1fcynmad.OcxState")));
            this.dcim1fcynmad.Size = new System.Drawing.Size(236, 68);
            this.dcim1fcynmad.TabIndex = 1;
            this.dcim1fcynmad.TabStop = false;
            this.dcim1fcynmad.Tag = "1fcynmad";
            // 
            // lbl1provnam
            // 
            this.lbl1provnam.AutoSize = true;
            this.lbl1provnam.BackColor = System.Drawing.Color.Lavender;
            this.lbl1provnam.Location = new System.Drawing.Point(23, 27);
            this.lbl1provnam.Name = "lbl1provnam";
            this.lbl1provnam.Size = new System.Drawing.Size(89, 13);
            this.lbl1provnam.TabIndex = 2;
            this.lbl1provnam.Tag = "1provnam";
            this.lbl1provnam.Text = "1 Facility Address";
            // 
            // dced1provnam
            // 
            this.dced1provnam.Location = new System.Drawing.Point(24, 126);
            this.dced1provnam.Name = "dced1provnam";
            this.dced1provnam.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced1provnam.OcxState")));
            this.dced1provnam.Size = new System.Drawing.Size(236, 18);
            this.dced1provnam.TabIndex = 3;
            this.dced1provnam.Tag = "1provnam";
            // 
            // lbl1provadd
            // 
            this.lbl1provadd.AutoSize = true;
            this.lbl1provadd.BackColor = System.Drawing.Color.Lavender;
            this.lbl1provadd.Location = new System.Drawing.Point(24, 149);
            this.lbl1provadd.Name = "lbl1provadd";
            this.lbl1provadd.Size = new System.Drawing.Size(45, 13);
            this.lbl1provadd.TabIndex = 4;
            this.lbl1provadd.Tag = "1provadd";
            this.lbl1provadd.Text = "Address";
            // 
            // dced1provadd
            // 
            this.dced1provadd.Location = new System.Drawing.Point(24, 162);
            this.dced1provadd.Name = "dced1provadd";
            this.dced1provadd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced1provadd.OcxState")));
            this.dced1provadd.Size = new System.Drawing.Size(236, 18);
            this.dced1provadd.TabIndex = 5;
            this.dced1provadd.Tag = "1provadd";
            // 
            // lbl1provcit
            // 
            this.lbl1provcit.AutoSize = true;
            this.lbl1provcit.BackColor = System.Drawing.Color.Lavender;
            this.lbl1provcit.Location = new System.Drawing.Point(24, 185);
            this.lbl1provcit.Name = "lbl1provcit";
            this.lbl1provcit.Size = new System.Drawing.Size(24, 13);
            this.lbl1provcit.TabIndex = 6;
            this.lbl1provcit.Tag = "1provcit";
            this.lbl1provcit.Text = "City";
            // 
            // dced1provcit
            // 
            this.dced1provcit.Location = new System.Drawing.Point(24, 198);
            this.dced1provcit.Name = "dced1provcit";
            this.dced1provcit.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced1provcit.OcxState")));
            this.dced1provcit.Size = new System.Drawing.Size(236, 18);
            this.dced1provcit.TabIndex = 7;
            this.dced1provcit.Tag = "1provcit";
            // 
            // lbl1provsta
            // 
            this.lbl1provsta.AutoSize = true;
            this.lbl1provsta.BackColor = System.Drawing.Color.Lavender;
            this.lbl1provsta.Location = new System.Drawing.Point(24, 219);
            this.lbl1provsta.Name = "lbl1provsta";
            this.lbl1provsta.Size = new System.Drawing.Size(32, 13);
            this.lbl1provsta.TabIndex = 8;
            this.lbl1provsta.Tag = "1provsta";
            this.lbl1provsta.Text = "State";
            // 
            // dced1provsta
            // 
            this.dced1provsta.Location = new System.Drawing.Point(24, 232);
            this.dced1provsta.Name = "dced1provsta";
            this.dced1provsta.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced1provsta.OcxState")));
            this.dced1provsta.Size = new System.Drawing.Size(80, 18);
            this.dced1provsta.TabIndex = 9;
            this.dced1provsta.Tag = "1provsta";
            // 
            // lbl1provzip
            // 
            this.lbl1provzip.AutoSize = true;
            this.lbl1provzip.BackColor = System.Drawing.Color.Lavender;
            this.lbl1provzip.Location = new System.Drawing.Point(116, 219);
            this.lbl1provzip.Name = "lbl1provzip";
            this.lbl1provzip.Size = new System.Drawing.Size(22, 13);
            this.lbl1provzip.TabIndex = 10;
            this.lbl1provzip.Tag = "1provzip";
            this.lbl1provzip.Text = "Zip";
            // 
            // dced1provzip
            // 
            this.dced1provzip.Location = new System.Drawing.Point(118, 232);
            this.dced1provzip.Name = "dced1provzip";
            this.dced1provzip.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced1provzip.OcxState")));
            this.dced1provzip.Size = new System.Drawing.Size(142, 18);
            this.dced1provzip.TabIndex = 11;
            this.dced1provzip.Tag = "1provzip";
            // 
            // lbl3apctlnm
            // 
            this.lbl3apctlnm.AutoSize = true;
            this.lbl3apctlnm.Location = new System.Drawing.Point(278, 28);
            this.lbl3apctlnm.Name = "lbl3apctlnm";
            this.lbl3apctlnm.Size = new System.Drawing.Size(83, 13);
            this.lbl3apctlnm.TabIndex = 33;
            this.lbl3apctlnm.Tag = "3apctlnm";
            this.lbl3apctlnm.Text = "3a Patient Ctrl #";
            // 
            // dcim3apctlnm
            // 
            this.dcim3apctlnm.Location = new System.Drawing.Point(284, 44);
            this.dcim3apctlnm.Name = "dcim3apctlnm";
            this.dcim3apctlnm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim3apctlnm.OcxState")));
            this.dcim3apctlnm.Size = new System.Drawing.Size(116, 18);
            this.dcim3apctlnm.TabIndex = 34;
            this.dcim3apctlnm.TabStop = false;
            this.dcim3apctlnm.Tag = "3apctlnm";
            // 
            // dced3apctlnm
            // 
            this.dced3apctlnm.Location = new System.Drawing.Point(284, 63);
            this.dced3apctlnm.Name = "dced3apctlnm";
            this.dced3apctlnm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced3apctlnm.OcxState")));
            this.dced3apctlnm.Size = new System.Drawing.Size(116, 18);
            this.dced3apctlnm.TabIndex = 35;
            this.dced3apctlnm.Tag = "3apctlnm";
            // 
            // lbl3bmdrcnm
            // 
            this.lbl3bmdrcnm.AutoSize = true;
            this.lbl3bmdrcnm.Location = new System.Drawing.Point(284, 93);
            this.lbl3bmdrcnm.Name = "lbl3bmdrcnm";
            this.lbl3bmdrcnm.Size = new System.Drawing.Size(94, 13);
            this.lbl3bmdrcnm.TabIndex = 36;
            this.lbl3bmdrcnm.Tag = "3bmdrcnm";
            this.lbl3bmdrcnm.Text = "3b Med. Record #";
            // 
            // dcim3bmdrcnm
            // 
            this.dcim3bmdrcnm.Location = new System.Drawing.Point(285, 109);
            this.dcim3bmdrcnm.Name = "dcim3bmdrcnm";
            this.dcim3bmdrcnm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim3bmdrcnm.OcxState")));
            this.dcim3bmdrcnm.Size = new System.Drawing.Size(116, 18);
            this.dcim3bmdrcnm.TabIndex = 37;
            this.dcim3bmdrcnm.TabStop = false;
            this.dcim3bmdrcnm.Tag = "3bmdrcnm";
            // 
            // dced3bmdrcnm
            // 
            this.dced3bmdrcnm.Location = new System.Drawing.Point(285, 128);
            this.dced3bmdrcnm.Name = "dced3bmdrcnm";
            this.dced3bmdrcnm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced3bmdrcnm.OcxState")));
            this.dced3bmdrcnm.Size = new System.Drawing.Size(116, 18);
            this.dced3bmdrcnm.TabIndex = 38;
            this.dced3bmdrcnm.Tag = "3bmdrcnm";
            // 
            // lbl4typbill
            // 
            this.lbl4typbill.AutoSize = true;
            this.lbl4typbill.Location = new System.Drawing.Point(410, 28);
            this.lbl4typbill.Name = "lbl4typbill";
            this.lbl4typbill.Size = new System.Drawing.Size(56, 13);
            this.lbl4typbill.TabIndex = 39;
            this.lbl4typbill.Tag = "4typbill";
            this.lbl4typbill.Text = "4 Bill Type";
            // 
            // dcim4typbill
            // 
            this.dcim4typbill.Location = new System.Drawing.Point(416, 44);
            this.dcim4typbill.Name = "dcim4typbill";
            this.dcim4typbill.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim4typbill.OcxState")));
            this.dcim4typbill.Size = new System.Drawing.Size(54, 18);
            this.dcim4typbill.TabIndex = 40;
            this.dcim4typbill.TabStop = false;
            this.dcim4typbill.Tag = "4typbill";
            // 
            // dced4typbill
            // 
            this.dced4typbill.Location = new System.Drawing.Point(416, 63);
            this.dced4typbill.Name = "dced4typbill";
            this.dced4typbill.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced4typbill.OcxState")));
            this.dced4typbill.Size = new System.Drawing.Size(54, 18);
            this.dced4typbill.TabIndex = 41;
            this.dced4typbill.Tag = "4typbill";
            // 
            // lbl5fedtxnm
            // 
            this.lbl5fedtxnm.AutoSize = true;
            this.lbl5fedtxnm.Location = new System.Drawing.Point(498, 28);
            this.lbl5fedtxnm.Name = "lbl5fedtxnm";
            this.lbl5fedtxnm.Size = new System.Drawing.Size(78, 13);
            this.lbl5fedtxnm.TabIndex = 42;
            this.lbl5fedtxnm.Tag = "5fedtxnm";
            this.lbl5fedtxnm.Text = "5 Fed. Tax No.";
            // 
            // dcim5fedtxnm
            // 
            this.dcim5fedtxnm.Location = new System.Drawing.Point(501, 44);
            this.dcim5fedtxnm.Name = "dcim5fedtxnm";
            this.dcim5fedtxnm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim5fedtxnm.OcxState")));
            this.dcim5fedtxnm.Size = new System.Drawing.Size(109, 18);
            this.dcim5fedtxnm.TabIndex = 43;
            this.dcim5fedtxnm.TabStop = false;
            this.dcim5fedtxnm.Tag = "5fedtxnm";
            // 
            // dced5fedtxnm
            // 
            this.dced5fedtxnm.Location = new System.Drawing.Point(501, 63);
            this.dced5fedtxnm.Name = "dced5fedtxnm";
            this.dced5fedtxnm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced5fedtxnm.OcxState")));
            this.dced5fedtxnm.Size = new System.Drawing.Size(109, 18);
            this.dced5fedtxnm.TabIndex = 44;
            this.dced5fedtxnm.Tag = "5fedtxnm";
            // 
            // lbl6scpfrom
            // 
            this.lbl6scpfrom.AutoSize = true;
            this.lbl6scpfrom.Location = new System.Drawing.Point(624, 29);
            this.lbl6scpfrom.Name = "lbl6scpfrom";
            this.lbl6scpfrom.Size = new System.Drawing.Size(141, 13);
            this.lbl6scpfrom.TabIndex = 45;
            this.lbl6scpfrom.Tag = "6scpfrom";
            this.lbl6scpfrom.Text = "6 Stmt Period From/Through";
            // 
            // dcim6scpfrom
            // 
            this.dcim6scpfrom.Location = new System.Drawing.Point(627, 44);
            this.dcim6scpfrom.Name = "dcim6scpfrom";
            this.dcim6scpfrom.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim6scpfrom.OcxState")));
            this.dcim6scpfrom.Size = new System.Drawing.Size(73, 18);
            this.dcim6scpfrom.TabIndex = 46;
            this.dcim6scpfrom.TabStop = false;
            this.dcim6scpfrom.Tag = "6scpfrom";
            // 
            // dced6scpfrom
            // 
            this.dced6scpfrom.Location = new System.Drawing.Point(627, 63);
            this.dced6scpfrom.Name = "dced6scpfrom";
            this.dced6scpfrom.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced6scpfrom.OcxState")));
            this.dced6scpfrom.Size = new System.Drawing.Size(73, 18);
            this.dced6scpfrom.TabIndex = 47;
            this.dced6scpfrom.Tag = "6scpfrom";
            // 
            // dcim6scpthru
            // 
            this.dcim6scpthru.Location = new System.Drawing.Point(704, 44);
            this.dcim6scpthru.Name = "dcim6scpthru";
            this.dcim6scpthru.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim6scpthru.OcxState")));
            this.dcim6scpthru.Size = new System.Drawing.Size(73, 18);
            this.dcim6scpthru.TabIndex = 49;
            this.dcim6scpthru.TabStop = false;
            this.dcim6scpthru.Tag = "6scpthru";
            // 
            // dced6scpthru
            // 
            this.dced6scpthru.Location = new System.Drawing.Point(704, 63);
            this.dced6scpthru.Name = "dced6scpthru";
            this.dced6scpthru.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced6scpthru.OcxState")));
            this.dced6scpthru.Size = new System.Drawing.Size(73, 18);
            this.dced6scpthru.TabIndex = 50;
            this.dced6scpthru.Tag = "6scpthru";
            // 
            // lbl8ptnmid
            // 
            this.lbl8ptnmid.AutoSize = true;
            this.lbl8ptnmid.Location = new System.Drawing.Point(417, 93);
            this.lbl8ptnmid.Name = "lbl8ptnmid";
            this.lbl8ptnmid.Size = new System.Drawing.Size(69, 13);
            this.lbl8ptnmid.TabIndex = 54;
            this.lbl8ptnmid.Tag = "8ptnmid";
            this.lbl8ptnmid.Text = "8a Patient ID";
            // 
            // dcim8ptnmid
            // 
            this.dcim8ptnmid.Location = new System.Drawing.Point(416, 109);
            this.dcim8ptnmid.Name = "dcim8ptnmid";
            this.dcim8ptnmid.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim8ptnmid.OcxState")));
            this.dcim8ptnmid.Size = new System.Drawing.Size(122, 18);
            this.dcim8ptnmid.TabIndex = 55;
            this.dcim8ptnmid.TabStop = false;
            this.dcim8ptnmid.Tag = "8ptnmid";
            // 
            // dced8ptnmid
            // 
            this.dced8ptnmid.Location = new System.Drawing.Point(416, 128);
            this.dced8ptnmid.Name = "dced8ptnmid";
            this.dced8ptnmid.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced8ptnmid.OcxState")));
            this.dced8ptnmid.Size = new System.Drawing.Size(122, 18);
            this.dced8ptnmid.TabIndex = 56;
            this.dced8ptnmid.Tag = "8ptnmid";
            // 
            // lbl8ptnm
            // 
            this.lbl8ptnm.AutoSize = true;
            this.lbl8ptnm.BackColor = System.Drawing.Color.Lavender;
            this.lbl8ptnm.Location = new System.Drawing.Point(280, 158);
            this.lbl8ptnm.Name = "lbl8ptnm";
            this.lbl8ptnm.Size = new System.Drawing.Size(80, 13);
            this.lbl8ptnm.TabIndex = 57;
            this.lbl8ptnm.Tag = "8ptnm";
            this.lbl8ptnm.Text = "8 Patient Name";
            // 
            // dcim8ptnm
            // 
            this.dcim8ptnm.Location = new System.Drawing.Point(282, 171);
            this.dcim8ptnm.Name = "dcim8ptnm";
            this.dcim8ptnm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim8ptnm.OcxState")));
            this.dcim8ptnm.Size = new System.Drawing.Size(254, 18);
            this.dcim8ptnm.TabIndex = 58;
            this.dcim8ptnm.TabStop = false;
            this.dcim8ptnm.Tag = "8ptnm";
            // 
            // lbl8plname
            // 
            this.lbl8plname.AutoSize = true;
            this.lbl8plname.BackColor = System.Drawing.Color.Lavender;
            this.lbl8plname.Location = new System.Drawing.Point(282, 188);
            this.lbl8plname.Name = "lbl8plname";
            this.lbl8plname.Size = new System.Drawing.Size(56, 13);
            this.lbl8plname.TabIndex = 59;
            this.lbl8plname.Tag = "8plname";
            this.lbl8plname.Text = "Last name";
            // 
            // dced8plname
            // 
            this.dced8plname.Location = new System.Drawing.Point(282, 200);
            this.dced8plname.Name = "dced8plname";
            this.dced8plname.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced8plname.OcxState")));
            this.dced8plname.Size = new System.Drawing.Size(254, 18);
            this.dced8plname.TabIndex = 60;
            this.dced8plname.Tag = "8plname";
            // 
            // lbl8pfname
            // 
            this.lbl8pfname.AutoSize = true;
            this.lbl8pfname.BackColor = System.Drawing.Color.Lavender;
            this.lbl8pfname.Location = new System.Drawing.Point(282, 221);
            this.lbl8pfname.Name = "lbl8pfname";
            this.lbl8pfname.Size = new System.Drawing.Size(55, 13);
            this.lbl8pfname.TabIndex = 61;
            this.lbl8pfname.Tag = "8pfname";
            this.lbl8pfname.Text = "First name";
            // 
            // dced8pfname
            // 
            this.dced8pfname.Location = new System.Drawing.Point(282, 234);
            this.dced8pfname.Name = "dced8pfname";
            this.dced8pfname.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced8pfname.OcxState")));
            this.dced8pfname.Size = new System.Drawing.Size(198, 18);
            this.dced8pfname.TabIndex = 62;
            this.dced8pfname.Tag = "8pfname";
            // 
            // lbl8pminit
            // 
            this.lbl8pminit.AutoSize = true;
            this.lbl8pminit.BackColor = System.Drawing.Color.Lavender;
            this.lbl8pminit.Location = new System.Drawing.Point(492, 221);
            this.lbl8pminit.Name = "lbl8pminit";
            this.lbl8pminit.Size = new System.Drawing.Size(19, 13);
            this.lbl8pminit.TabIndex = 63;
            this.lbl8pminit.Tag = "8pminit";
            this.lbl8pminit.Text = "MI";
            // 
            // dced8pminit
            // 
            this.dced8pminit.Location = new System.Drawing.Point(492, 234);
            this.dced8pminit.Name = "dced8pminit";
            this.dced8pminit.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced8pminit.OcxState")));
            this.dced8pminit.Size = new System.Drawing.Size(44, 18);
            this.dced8pminit.TabIndex = 64;
            this.dced8pminit.Tag = "8pminit";
            // 
            // lbl9paddstr
            // 
            this.lbl9paddstr.AutoSize = true;
            this.lbl9paddstr.BackColor = System.Drawing.Color.Lavender;
            this.lbl9paddstr.Location = new System.Drawing.Point(558, 97);
            this.lbl9paddstr.Name = "lbl9paddstr";
            this.lbl9paddstr.Size = new System.Drawing.Size(90, 13);
            this.lbl9paddstr.TabIndex = 65;
            this.lbl9paddstr.Tag = "9paddstr";
            this.lbl9paddstr.Text = "9 Patient Address";
            // 
            // dcim9paddstr
            // 
            this.dcim9paddstr.Location = new System.Drawing.Point(558, 109);
            this.dcim9paddstr.Name = "dcim9paddstr";
            this.dcim9paddstr.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim9paddstr.OcxState")));
            this.dcim9paddstr.Size = new System.Drawing.Size(211, 18);
            this.dcim9paddstr.TabIndex = 66;
            this.dcim9paddstr.TabStop = false;
            this.dcim9paddstr.Tag = "9paddstr";
            // 
            // dced9paddstr
            // 
            this.dced9paddstr.Location = new System.Drawing.Point(558, 128);
            this.dced9paddstr.Name = "dced9paddstr";
            this.dced9paddstr.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced9paddstr.OcxState")));
            this.dced9paddstr.Size = new System.Drawing.Size(211, 18);
            this.dced9paddstr.TabIndex = 67;
            this.dced9paddstr.Tag = "9paddstr";
            // 
            // lbl9paddcty
            // 
            this.lbl9paddcty.AutoSize = true;
            this.lbl9paddcty.BackColor = System.Drawing.Color.Lavender;
            this.lbl9paddcty.Location = new System.Drawing.Point(556, 148);
            this.lbl9paddcty.Name = "lbl9paddcty";
            this.lbl9paddcty.Size = new System.Drawing.Size(24, 13);
            this.lbl9paddcty.TabIndex = 68;
            this.lbl9paddcty.Tag = "9paddcty";
            this.lbl9paddcty.Text = "City";
            // 
            // dcim9paddcty
            // 
            this.dcim9paddcty.Location = new System.Drawing.Point(558, 161);
            this.dcim9paddcty.Name = "dcim9paddcty";
            this.dcim9paddcty.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim9paddcty.OcxState")));
            this.dcim9paddcty.Size = new System.Drawing.Size(211, 18);
            this.dcim9paddcty.TabIndex = 69;
            this.dcim9paddcty.TabStop = false;
            this.dcim9paddcty.Tag = "9paddcty";
            // 
            // dced9paddcty
            // 
            this.dced9paddcty.Location = new System.Drawing.Point(558, 180);
            this.dced9paddcty.Name = "dced9paddcty";
            this.dced9paddcty.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced9paddcty.OcxState")));
            this.dced9paddcty.Size = new System.Drawing.Size(211, 18);
            this.dced9paddcty.TabIndex = 70;
            this.dced9paddcty.Tag = "9paddcty";
            // 
            // lbl9paddsta
            // 
            this.lbl9paddsta.AutoSize = true;
            this.lbl9paddsta.BackColor = System.Drawing.Color.Lavender;
            this.lbl9paddsta.Location = new System.Drawing.Point(558, 200);
            this.lbl9paddsta.Name = "lbl9paddsta";
            this.lbl9paddsta.Size = new System.Drawing.Size(32, 13);
            this.lbl9paddsta.TabIndex = 71;
            this.lbl9paddsta.Tag = "9paddsta";
            this.lbl9paddsta.Text = "State";
            // 
            // dcim9paddsta
            // 
            this.dcim9paddsta.Location = new System.Drawing.Point(558, 213);
            this.dcim9paddsta.Name = "dcim9paddsta";
            this.dcim9paddsta.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim9paddsta.OcxState")));
            this.dcim9paddsta.Size = new System.Drawing.Size(48, 18);
            this.dcim9paddsta.TabIndex = 72;
            this.dcim9paddsta.TabStop = false;
            this.dcim9paddsta.Tag = "9paddsta";
            // 
            // dced9paddsta
            // 
            this.dced9paddsta.Location = new System.Drawing.Point(558, 232);
            this.dced9paddsta.Name = "dced9paddsta";
            this.dced9paddsta.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced9paddsta.OcxState")));
            this.dced9paddsta.Size = new System.Drawing.Size(48, 18);
            this.dced9paddsta.TabIndex = 73;
            this.dced9paddsta.Tag = "9paddsta";
            // 
            // lbl9paddzip
            // 
            this.lbl9paddzip.AutoSize = true;
            this.lbl9paddzip.BackColor = System.Drawing.Color.Lavender;
            this.lbl9paddzip.Location = new System.Drawing.Point(608, 200);
            this.lbl9paddzip.Name = "lbl9paddzip";
            this.lbl9paddzip.Size = new System.Drawing.Size(22, 13);
            this.lbl9paddzip.TabIndex = 74;
            this.lbl9paddzip.Tag = "9paddzip";
            this.lbl9paddzip.Text = "Zip";
            // 
            // dcim9paddzip
            // 
            this.dcim9paddzip.Location = new System.Drawing.Point(610, 213);
            this.dcim9paddzip.Name = "dcim9paddzip";
            this.dcim9paddzip.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim9paddzip.OcxState")));
            this.dcim9paddzip.Size = new System.Drawing.Size(103, 18);
            this.dcim9paddzip.TabIndex = 75;
            this.dcim9paddzip.TabStop = false;
            this.dcim9paddzip.Tag = "9paddzip";
            // 
            // dced9paddzip
            // 
            this.dced9paddzip.Location = new System.Drawing.Point(610, 232);
            this.dced9paddzip.Name = "dced9paddzip";
            this.dced9paddzip.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced9paddzip.OcxState")));
            this.dced9paddzip.Size = new System.Drawing.Size(103, 18);
            this.dced9paddzip.TabIndex = 76;
            this.dced9paddzip.Tag = "9paddzip";
            // 
            // lbl9paddccd
            // 
            this.lbl9paddccd.AutoSize = true;
            this.lbl9paddccd.BackColor = System.Drawing.Color.Lavender;
            this.lbl9paddccd.Location = new System.Drawing.Point(718, 201);
            this.lbl9paddccd.Name = "lbl9paddccd";
            this.lbl9paddccd.Size = new System.Drawing.Size(29, 13);
            this.lbl9paddccd.TabIndex = 77;
            this.lbl9paddccd.Tag = "9paddccd";
            this.lbl9paddccd.Text = "CCD";
            // 
            // dcim9paddccd
            // 
            this.dcim9paddccd.Location = new System.Drawing.Point(719, 213);
            this.dcim9paddccd.Name = "dcim9paddccd";
            this.dcim9paddccd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim9paddccd.OcxState")));
            this.dcim9paddccd.Size = new System.Drawing.Size(50, 18);
            this.dcim9paddccd.TabIndex = 78;
            this.dcim9paddccd.TabStop = false;
            this.dcim9paddccd.Tag = "9paddccd";
            // 
            // dced9paddccd
            // 
            this.dced9paddccd.Location = new System.Drawing.Point(719, 232);
            this.dced9paddccd.Name = "dced9paddccd";
            this.dced9paddccd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced9paddccd.OcxState")));
            this.dced9paddccd.Size = new System.Drawing.Size(50, 18);
            this.dced9paddccd.TabIndex = 79;
            this.dced9paddccd.Tag = "9paddccd";
            // 
            // lbl10pbdate
            // 
            this.lbl10pbdate.AutoSize = true;
            this.lbl10pbdate.Location = new System.Drawing.Point(19, 265);
            this.lbl10pbdate.Name = "lbl10pbdate";
            this.lbl10pbdate.Size = new System.Drawing.Size(64, 13);
            this.lbl10pbdate.TabIndex = 80;
            this.lbl10pbdate.Tag = "10pbdate";
            this.lbl10pbdate.Text = "10 Birthdate";
            // 
            // dcim10pbdate
            // 
            this.dcim10pbdate.Location = new System.Drawing.Point(22, 278);
            this.dcim10pbdate.Name = "dcim10pbdate";
            this.dcim10pbdate.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim10pbdate.OcxState")));
            this.dcim10pbdate.Size = new System.Drawing.Size(73, 18);
            this.dcim10pbdate.TabIndex = 81;
            this.dcim10pbdate.TabStop = false;
            this.dcim10pbdate.Tag = "10pbdate";
            // 
            // dced10pbdate
            // 
            this.dced10pbdate.Location = new System.Drawing.Point(22, 297);
            this.dced10pbdate.Name = "dced10pbdate";
            this.dced10pbdate.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced10pbdate.OcxState")));
            this.dced10pbdate.Size = new System.Drawing.Size(73, 18);
            this.dced10pbdate.TabIndex = 82;
            this.dced10pbdate.Tag = "10pbdate";
            // 
            // lbl11psex
            // 
            this.lbl11psex.AutoSize = true;
            this.lbl11psex.Location = new System.Drawing.Point(99, 264);
            this.lbl11psex.Name = "lbl11psex";
            this.lbl11psex.Size = new System.Drawing.Size(40, 13);
            this.lbl11psex.TabIndex = 83;
            this.lbl11psex.Tag = "11psex";
            this.lbl11psex.Text = "11 Sex";
            // 
            // dcim11psex
            // 
            this.dcim11psex.Location = new System.Drawing.Point(102, 278);
            this.dcim11psex.Name = "dcim11psex";
            this.dcim11psex.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim11psex.OcxState")));
            this.dcim11psex.Size = new System.Drawing.Size(44, 18);
            this.dcim11psex.TabIndex = 84;
            this.dcim11psex.TabStop = false;
            this.dcim11psex.Tag = "11psex";
            // 
            // dced11psex
            // 
            this.dced11psex.Location = new System.Drawing.Point(102, 297);
            this.dced11psex.Name = "dced11psex";
            this.dced11psex.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced11psex.OcxState")));
            this.dced11psex.Size = new System.Drawing.Size(44, 18);
            this.dced11psex.TabIndex = 85;
            this.dced11psex.Tag = "11psex";
            // 
            // lbl12admdte
            // 
            this.lbl12admdte.AutoSize = true;
            this.lbl12admdte.Location = new System.Drawing.Point(150, 265);
            this.lbl12admdte.Name = "lbl12admdte";
            this.lbl12admdte.Size = new System.Drawing.Size(45, 13);
            this.lbl12admdte.TabIndex = 86;
            this.lbl12admdte.Tag = "12admdte";
            this.lbl12admdte.Text = "12 Date";
            // 
            // dcim12admdte
            // 
            this.dcim12admdte.Location = new System.Drawing.Point(153, 278);
            this.dcim12admdte.Name = "dcim12admdte";
            this.dcim12admdte.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim12admdte.OcxState")));
            this.dcim12admdte.Size = new System.Drawing.Size(73, 18);
            this.dcim12admdte.TabIndex = 87;
            this.dcim12admdte.TabStop = false;
            this.dcim12admdte.Tag = "12admdte";
            // 
            // dced12admdte
            // 
            this.dced12admdte.Location = new System.Drawing.Point(153, 297);
            this.dced12admdte.Name = "dced12admdte";
            this.dced12admdte.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced12admdte.OcxState")));
            this.dced12admdte.Size = new System.Drawing.Size(73, 18);
            this.dced12admdte.TabIndex = 88;
            this.dced12admdte.Tag = "12admdte";
            // 
            // lbl13admhr
            // 
            this.lbl13admhr.AutoSize = true;
            this.lbl13admhr.Location = new System.Drawing.Point(278, 264);
            this.lbl13admhr.Name = "lbl13admhr";
            this.lbl13admhr.Size = new System.Drawing.Size(46, 13);
            this.lbl13admhr.TabIndex = 92;
            this.lbl13admhr.Tag = "13admhr";
            this.lbl13admhr.Text = "14 Type";
            // 
            // dcim13admhr
            // 
            this.dcim13admhr.Location = new System.Drawing.Point(233, 278);
            this.dcim13admhr.Name = "dcim13admhr";
            this.dcim13admhr.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim13admhr.OcxState")));
            this.dcim13admhr.Size = new System.Drawing.Size(44, 18);
            this.dcim13admhr.TabIndex = 90;
            this.dcim13admhr.TabStop = false;
            this.dcim13admhr.Tag = "13admhr";
            // 
            // dced13admhr
            // 
            this.dced13admhr.Location = new System.Drawing.Point(233, 297);
            this.dced13admhr.Name = "dced13admhr";
            this.dced13admhr.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced13admhr.OcxState")));
            this.dced13admhr.Size = new System.Drawing.Size(44, 18);
            this.dced13admhr.TabIndex = 91;
            this.dced13admhr.Tag = "13admhr";
            // 
            // lbl14admtyp
            // 
            this.lbl14admtyp.AutoSize = true;
            this.lbl14admtyp.Location = new System.Drawing.Point(230, 265);
            this.lbl14admtyp.Name = "lbl14admtyp";
            this.lbl14admtyp.Size = new System.Drawing.Size(38, 13);
            this.lbl14admtyp.TabIndex = 89;
            this.lbl14admtyp.Tag = "14admtyp";
            this.lbl14admtyp.Text = "13 HR";
            // 
            // dcim14admtyp
            // 
            this.dcim14admtyp.Location = new System.Drawing.Point(284, 278);
            this.dcim14admtyp.Name = "dcim14admtyp";
            this.dcim14admtyp.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim14admtyp.OcxState")));
            this.dcim14admtyp.Size = new System.Drawing.Size(44, 18);
            this.dcim14admtyp.TabIndex = 93;
            this.dcim14admtyp.TabStop = false;
            this.dcim14admtyp.Tag = "14admtyp";
            // 
            // dced14admtyp
            // 
            this.dced14admtyp.Location = new System.Drawing.Point(284, 297);
            this.dced14admtyp.Name = "dced14admtyp";
            this.dced14admtyp.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced14admtyp.OcxState")));
            this.dced14admtyp.Size = new System.Drawing.Size(44, 18);
            this.dced14admtyp.TabIndex = 94;
            this.dced14admtyp.Tag = "14admtyp";
            // 
            // lbl16dhr
            // 
            this.lbl16dhr.AutoSize = true;
            this.lbl16dhr.Location = new System.Drawing.Point(330, 265);
            this.lbl16dhr.Name = "lbl16dhr";
            this.lbl16dhr.Size = new System.Drawing.Size(49, 13);
            this.lbl16dhr.TabIndex = 98;
            this.lbl16dhr.Tag = "16dhr";
            this.lbl16dhr.Text = "16 D HR";
            // 
            // dcim16dhr
            // 
            this.dcim16dhr.Location = new System.Drawing.Point(335, 278);
            this.dcim16dhr.Name = "dcim16dhr";
            this.dcim16dhr.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim16dhr.OcxState")));
            this.dcim16dhr.Size = new System.Drawing.Size(44, 18);
            this.dcim16dhr.TabIndex = 99;
            this.dcim16dhr.TabStop = false;
            this.dcim16dhr.Tag = "16dhr";
            // 
            // dced16dhr
            // 
            this.dced16dhr.Location = new System.Drawing.Point(335, 297);
            this.dced16dhr.Name = "dced16dhr";
            this.dced16dhr.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced16dhr.OcxState")));
            this.dced16dhr.Size = new System.Drawing.Size(44, 18);
            this.dced16dhr.TabIndex = 100;
            this.dced16dhr.Tag = "16dhr";
            // 
            // lbl17stat
            // 
            this.lbl17stat.AutoSize = true;
            this.lbl17stat.Location = new System.Drawing.Point(383, 264);
            this.lbl17stat.Name = "lbl17stat";
            this.lbl17stat.Size = new System.Drawing.Size(41, 13);
            this.lbl17stat.TabIndex = 101;
            this.lbl17stat.Tag = "17stat";
            this.lbl17stat.Text = "17 Stat";
            // 
            // dcim17stat
            // 
            this.dcim17stat.Location = new System.Drawing.Point(386, 278);
            this.dcim17stat.Name = "dcim17stat";
            this.dcim17stat.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim17stat.OcxState")));
            this.dcim17stat.Size = new System.Drawing.Size(44, 18);
            this.dcim17stat.TabIndex = 102;
            this.dcim17stat.TabStop = false;
            this.dcim17stat.Tag = "17stat";
            // 
            // dced17stat
            // 
            this.dced17stat.Location = new System.Drawing.Point(386, 297);
            this.dced17stat.Name = "dced17stat";
            this.dced17stat.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced17stat.OcxState")));
            this.dced17stat.Size = new System.Drawing.Size(44, 18);
            this.dced17stat.TabIndex = 103;
            this.dced17stat.Tag = "17stat";
            // 
            // lbl31aocrcd
            // 
            this.lbl31aocrcd.AutoSize = true;
            this.lbl31aocrcd.Location = new System.Drawing.Point(29, 321);
            this.lbl31aocrcd.Name = "lbl31aocrcd";
            this.lbl31aocrcd.Size = new System.Drawing.Size(135, 13);
            this.lbl31aocrcd.TabIndex = 131;
            this.lbl31aocrcd.Tag = "31aocrcd";
            this.lbl31aocrcd.Text = "31 Occurrence Code, Date";
            // 
            // dcim31aocrcd
            // 
            this.dcim31aocrcd.Location = new System.Drawing.Point(32, 336);
            this.dcim31aocrcd.Name = "dcim31aocrcd";
            this.dcim31aocrcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim31aocrcd.OcxState")));
            this.dcim31aocrcd.Size = new System.Drawing.Size(47, 18);
            this.dcim31aocrcd.TabIndex = 132;
            this.dcim31aocrcd.TabStop = false;
            this.dcim31aocrcd.Tag = "31aocrcd";
            // 
            // dced31aocrcd
            // 
            this.dced31aocrcd.Location = new System.Drawing.Point(32, 355);
            this.dced31aocrcd.Name = "dced31aocrcd";
            this.dced31aocrcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced31aocrcd.OcxState")));
            this.dced31aocrcd.Size = new System.Drawing.Size(47, 18);
            this.dced31aocrcd.TabIndex = 133;
            this.dced31aocrcd.Tag = "31aocrcd";
            // 
            // dcim31aocrdt
            // 
            this.dcim31aocrdt.Location = new System.Drawing.Point(85, 336);
            this.dcim31aocrdt.Name = "dcim31aocrdt";
            this.dcim31aocrdt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim31aocrdt.OcxState")));
            this.dcim31aocrdt.Size = new System.Drawing.Size(79, 18);
            this.dcim31aocrdt.TabIndex = 135;
            this.dcim31aocrdt.TabStop = false;
            this.dcim31aocrdt.Tag = "31aocrdt";
            // 
            // dced31aocrdt
            // 
            this.dced31aocrdt.Location = new System.Drawing.Point(85, 355);
            this.dced31aocrdt.Name = "dced31aocrdt";
            this.dced31aocrdt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced31aocrdt.OcxState")));
            this.dced31aocrdt.Size = new System.Drawing.Size(79, 18);
            this.dced31aocrdt.TabIndex = 136;
            this.dced31aocrdt.Tag = "31aocrdt";
            // 
            // dcim31bocrcd
            // 
            this.dcim31bocrcd.Location = new System.Drawing.Point(32, 378);
            this.dcim31bocrcd.Name = "dcim31bocrcd";
            this.dcim31bocrcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim31bocrcd.OcxState")));
            this.dcim31bocrcd.Size = new System.Drawing.Size(47, 18);
            this.dcim31bocrcd.TabIndex = 138;
            this.dcim31bocrcd.TabStop = false;
            this.dcim31bocrcd.Tag = "31bocrcd";
            // 
            // dced31bocrcd
            // 
            this.dced31bocrcd.Location = new System.Drawing.Point(32, 397);
            this.dced31bocrcd.Name = "dced31bocrcd";
            this.dced31bocrcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced31bocrcd.OcxState")));
            this.dced31bocrcd.Size = new System.Drawing.Size(47, 18);
            this.dced31bocrcd.TabIndex = 139;
            this.dced31bocrcd.Tag = "31bocrcd";
            // 
            // dcim31bocrdt
            // 
            this.dcim31bocrdt.Location = new System.Drawing.Point(85, 378);
            this.dcim31bocrdt.Name = "dcim31bocrdt";
            this.dcim31bocrdt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim31bocrdt.OcxState")));
            this.dcim31bocrdt.Size = new System.Drawing.Size(79, 18);
            this.dcim31bocrdt.TabIndex = 141;
            this.dcim31bocrdt.TabStop = false;
            this.dcim31bocrdt.Tag = "31bocrdt";
            // 
            // dced31bocrdt
            // 
            this.dced31bocrdt.Location = new System.Drawing.Point(85, 397);
            this.dced31bocrdt.Name = "dced31bocrdt";
            this.dced31bocrdt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced31bocrdt.OcxState")));
            this.dced31bocrdt.Size = new System.Drawing.Size(79, 18);
            this.dced31bocrdt.TabIndex = 142;
            this.dced31bocrdt.Tag = "31bocrdt";
            // 
            // lbl32aocrcd
            // 
            this.lbl32aocrcd.AutoSize = true;
            this.lbl32aocrcd.Location = new System.Drawing.Point(207, 321);
            this.lbl32aocrcd.Name = "lbl32aocrcd";
            this.lbl32aocrcd.Size = new System.Drawing.Size(135, 13);
            this.lbl32aocrcd.TabIndex = 143;
            this.lbl32aocrcd.Tag = "32aocrcd";
            this.lbl32aocrcd.Text = "32 Occurrence Code, Date";
            // 
            // dcim32aocrcd
            // 
            this.dcim32aocrcd.Location = new System.Drawing.Point(209, 336);
            this.dcim32aocrcd.Name = "dcim32aocrcd";
            this.dcim32aocrcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim32aocrcd.OcxState")));
            this.dcim32aocrcd.Size = new System.Drawing.Size(53, 18);
            this.dcim32aocrcd.TabIndex = 144;
            this.dcim32aocrcd.TabStop = false;
            this.dcim32aocrcd.Tag = "32aocrcd";
            // 
            // dced32aocrcd
            // 
            this.dced32aocrcd.Location = new System.Drawing.Point(209, 355);
            this.dced32aocrcd.Name = "dced32aocrcd";
            this.dced32aocrcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced32aocrcd.OcxState")));
            this.dced32aocrcd.Size = new System.Drawing.Size(53, 18);
            this.dced32aocrcd.TabIndex = 145;
            this.dced32aocrcd.Tag = "32aocrcd";
            // 
            // dcim32aocrdt
            // 
            this.dcim32aocrdt.Location = new System.Drawing.Point(268, 336);
            this.dcim32aocrdt.Name = "dcim32aocrdt";
            this.dcim32aocrdt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim32aocrdt.OcxState")));
            this.dcim32aocrdt.Size = new System.Drawing.Size(79, 18);
            this.dcim32aocrdt.TabIndex = 147;
            this.dcim32aocrdt.TabStop = false;
            this.dcim32aocrdt.Tag = "32aocrdt";
            // 
            // dced32aocrdt
            // 
            this.dced32aocrdt.Location = new System.Drawing.Point(268, 355);
            this.dced32aocrdt.Name = "dced32aocrdt";
            this.dced32aocrdt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced32aocrdt.OcxState")));
            this.dced32aocrdt.Size = new System.Drawing.Size(79, 18);
            this.dced32aocrdt.TabIndex = 148;
            this.dced32aocrdt.Tag = "32aocrdt";
            // 
            // dcim32bocrcd
            // 
            this.dcim32bocrcd.Location = new System.Drawing.Point(209, 378);
            this.dcim32bocrcd.Name = "dcim32bocrcd";
            this.dcim32bocrcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim32bocrcd.OcxState")));
            this.dcim32bocrcd.Size = new System.Drawing.Size(53, 18);
            this.dcim32bocrcd.TabIndex = 150;
            this.dcim32bocrcd.TabStop = false;
            this.dcim32bocrcd.Tag = "32bocrcd";
            // 
            // dced32bocrcd
            // 
            this.dced32bocrcd.Location = new System.Drawing.Point(209, 397);
            this.dced32bocrcd.Name = "dced32bocrcd";
            this.dced32bocrcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced32bocrcd.OcxState")));
            this.dced32bocrcd.Size = new System.Drawing.Size(53, 18);
            this.dced32bocrcd.TabIndex = 151;
            this.dced32bocrcd.Tag = "32bocrcd";
            // 
            // dcim32bocrdt
            // 
            this.dcim32bocrdt.Location = new System.Drawing.Point(268, 378);
            this.dcim32bocrdt.Name = "dcim32bocrdt";
            this.dcim32bocrdt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim32bocrdt.OcxState")));
            this.dcim32bocrdt.Size = new System.Drawing.Size(79, 18);
            this.dcim32bocrdt.TabIndex = 153;
            this.dcim32bocrdt.TabStop = false;
            this.dcim32bocrdt.Tag = "32bocrdt";
            // 
            // dced32bocrdt
            // 
            this.dced32bocrdt.Location = new System.Drawing.Point(268, 397);
            this.dced32bocrdt.Name = "dced32bocrdt";
            this.dced32bocrdt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced32bocrdt.OcxState")));
            this.dced32bocrdt.Size = new System.Drawing.Size(79, 18);
            this.dced32bocrdt.TabIndex = 154;
            this.dced32bocrdt.Tag = "32bocrdt";
            // 
            // lbl36aospcd
            // 
            this.lbl36aospcd.AutoSize = true;
            this.lbl36aospcd.Location = new System.Drawing.Point(47, 423);
            this.lbl36aospcd.Name = "lbl36aospcd";
            this.lbl36aospcd.Size = new System.Drawing.Size(211, 13);
            this.lbl36aospcd.TabIndex = 197;
            this.lbl36aospcd.Tag = "36aospcd";
            this.lbl36aospcd.Text = "36 Occurrence Span, Code, From/Through";
            // 
            // dcim36aospcd
            // 
            this.dcim36aospcd.Location = new System.Drawing.Point(50, 438);
            this.dcim36aospcd.Name = "dcim36aospcd";
            this.dcim36aospcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim36aospcd.OcxState")));
            this.dcim36aospcd.Size = new System.Drawing.Size(92, 18);
            this.dcim36aospcd.TabIndex = 198;
            this.dcim36aospcd.TabStop = false;
            this.dcim36aospcd.Tag = "36aospcd";
            // 
            // dced36aospcd
            // 
            this.dced36aospcd.Location = new System.Drawing.Point(50, 457);
            this.dced36aospcd.Name = "dced36aospcd";
            this.dced36aospcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced36aospcd.OcxState")));
            this.dced36aospcd.Size = new System.Drawing.Size(92, 18);
            this.dced36aospcd.TabIndex = 199;
            this.dced36aospcd.Tag = "36aospcd";
            // 
            // dcim36aospfr
            // 
            this.dcim36aospfr.Location = new System.Drawing.Point(159, 438);
            this.dcim36aospfr.Name = "dcim36aospfr";
            this.dcim36aospfr.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim36aospfr.OcxState")));
            this.dcim36aospfr.Size = new System.Drawing.Size(81, 18);
            this.dcim36aospfr.TabIndex = 201;
            this.dcim36aospfr.TabStop = false;
            this.dcim36aospfr.Tag = "36aospfr";
            // 
            // dced36aospfr
            // 
            this.dced36aospfr.Location = new System.Drawing.Point(159, 457);
            this.dced36aospfr.Name = "dced36aospfr";
            this.dced36aospfr.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced36aospfr.OcxState")));
            this.dced36aospfr.Size = new System.Drawing.Size(81, 18);
            this.dced36aospfr.TabIndex = 202;
            this.dced36aospfr.Tag = "36aospfr";
            // 
            // dcim36aospth
            // 
            this.dcim36aospth.Location = new System.Drawing.Point(246, 438);
            this.dcim36aospth.Name = "dcim36aospth";
            this.dcim36aospth.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim36aospth.OcxState")));
            this.dcim36aospth.Size = new System.Drawing.Size(78, 18);
            this.dcim36aospth.TabIndex = 204;
            this.dcim36aospth.TabStop = false;
            this.dcim36aospth.Tag = "36aospth";
            // 
            // dced36aospth
            // 
            this.dced36aospth.Location = new System.Drawing.Point(246, 457);
            this.dced36aospth.Name = "dced36aospth";
            this.dced36aospth.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced36aospth.OcxState")));
            this.dced36aospth.Size = new System.Drawing.Size(78, 18);
            this.dced36aospth.TabIndex = 205;
            this.dced36aospth.Tag = "36aospth";
            // 
            // dcim36bospcd
            // 
            this.dcim36bospcd.Location = new System.Drawing.Point(50, 481);
            this.dcim36bospcd.Name = "dcim36bospcd";
            this.dcim36bospcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim36bospcd.OcxState")));
            this.dcim36bospcd.Size = new System.Drawing.Size(92, 18);
            this.dcim36bospcd.TabIndex = 207;
            this.dcim36bospcd.TabStop = false;
            this.dcim36bospcd.Tag = "36bospcd";
            // 
            // dced36bospcd
            // 
            this.dced36bospcd.Location = new System.Drawing.Point(50, 500);
            this.dced36bospcd.Name = "dced36bospcd";
            this.dced36bospcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced36bospcd.OcxState")));
            this.dced36bospcd.Size = new System.Drawing.Size(92, 18);
            this.dced36bospcd.TabIndex = 208;
            this.dced36bospcd.Tag = "36bospcd";
            // 
            // dcim36bospfr
            // 
            this.dcim36bospfr.Location = new System.Drawing.Point(159, 481);
            this.dcim36bospfr.Name = "dcim36bospfr";
            this.dcim36bospfr.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim36bospfr.OcxState")));
            this.dcim36bospfr.Size = new System.Drawing.Size(81, 18);
            this.dcim36bospfr.TabIndex = 210;
            this.dcim36bospfr.TabStop = false;
            this.dcim36bospfr.Tag = "36bospfr";
            // 
            // dced36bospfr
            // 
            this.dced36bospfr.Location = new System.Drawing.Point(159, 500);
            this.dced36bospfr.Name = "dced36bospfr";
            this.dced36bospfr.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced36bospfr.OcxState")));
            this.dced36bospfr.Size = new System.Drawing.Size(81, 18);
            this.dced36bospfr.TabIndex = 211;
            this.dced36bospfr.Tag = "36bospfr";
            // 
            // dcim36bospth
            // 
            this.dcim36bospth.Location = new System.Drawing.Point(246, 481);
            this.dcim36bospth.Name = "dcim36bospth";
            this.dcim36bospth.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim36bospth.OcxState")));
            this.dcim36bospth.Size = new System.Drawing.Size(78, 18);
            this.dcim36bospth.TabIndex = 213;
            this.dcim36bospth.TabStop = false;
            this.dcim36bospth.Tag = "36bospth";
            // 
            // dced36bospth
            // 
            this.dced36bospth.Location = new System.Drawing.Point(246, 500);
            this.dced36bospth.Name = "dced36bospth";
            this.dced36bospth.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced36bospth.OcxState")));
            this.dced36bospth.Size = new System.Drawing.Size(78, 18);
            this.dced36bospth.TabIndex = 214;
            this.dced36bospth.Tag = "36bospth";
            // 
            // lbl39avlcd
            // 
            this.lbl39avlcd.AutoSize = true;
            this.lbl39avlcd.Location = new System.Drawing.Point(374, 330);
            this.lbl39avlcd.Name = "lbl39avlcd";
            this.lbl39avlcd.Size = new System.Drawing.Size(119, 13);
            this.lbl39avlcd.TabIndex = 215;
            this.lbl39avlcd.Tag = "39avlcd";
            this.lbl39avlcd.Text = "39 Value Code, Amount";
            // 
            // dcim39avlcd
            // 
            this.dcim39avlcd.Location = new System.Drawing.Point(379, 346);
            this.dcim39avlcd.Name = "dcim39avlcd";
            this.dcim39avlcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim39avlcd.OcxState")));
            this.dcim39avlcd.Size = new System.Drawing.Size(36, 18);
            this.dcim39avlcd.TabIndex = 216;
            this.dcim39avlcd.TabStop = false;
            this.dcim39avlcd.Tag = "39avlcd";
            // 
            // dced39avlcd
            // 
            this.dced39avlcd.Location = new System.Drawing.Point(379, 365);
            this.dced39avlcd.Name = "dced39avlcd";
            this.dced39avlcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced39avlcd.OcxState")));
            this.dced39avlcd.Size = new System.Drawing.Size(36, 18);
            this.dced39avlcd.TabIndex = 217;
            this.dced39avlcd.Tag = "39avlcd";
            // 
            // dcim39avlamt
            // 
            this.dcim39avlamt.Location = new System.Drawing.Point(421, 346);
            this.dcim39avlamt.Name = "dcim39avlamt";
            this.dcim39avlamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim39avlamt.OcxState")));
            this.dcim39avlamt.Size = new System.Drawing.Size(78, 18);
            this.dcim39avlamt.TabIndex = 219;
            this.dcim39avlamt.TabStop = false;
            this.dcim39avlamt.Tag = "39avlamt";
            // 
            // dced39avlamt
            // 
            this.dced39avlamt.Location = new System.Drawing.Point(421, 365);
            this.dced39avlamt.Name = "dced39avlamt";
            this.dced39avlamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced39avlamt.OcxState")));
            this.dced39avlamt.Size = new System.Drawing.Size(78, 18);
            this.dced39avlamt.TabIndex = 220;
            this.dced39avlamt.Tag = "39avlamt";
            // 
            // dcim39bvlcd
            // 
            this.dcim39bvlcd.Location = new System.Drawing.Point(379, 388);
            this.dcim39bvlcd.Name = "dcim39bvlcd";
            this.dcim39bvlcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim39bvlcd.OcxState")));
            this.dcim39bvlcd.Size = new System.Drawing.Size(36, 18);
            this.dcim39bvlcd.TabIndex = 222;
            this.dcim39bvlcd.TabStop = false;
            this.dcim39bvlcd.Tag = "39bvlcd";
            // 
            // dced39bvlcd
            // 
            this.dced39bvlcd.Location = new System.Drawing.Point(379, 407);
            this.dced39bvlcd.Name = "dced39bvlcd";
            this.dced39bvlcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced39bvlcd.OcxState")));
            this.dced39bvlcd.Size = new System.Drawing.Size(36, 18);
            this.dced39bvlcd.TabIndex = 223;
            this.dced39bvlcd.Tag = "39bvlcd";
            // 
            // dcim39bvlamt
            // 
            this.dcim39bvlamt.Location = new System.Drawing.Point(421, 388);
            this.dcim39bvlamt.Name = "dcim39bvlamt";
            this.dcim39bvlamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim39bvlamt.OcxState")));
            this.dcim39bvlamt.Size = new System.Drawing.Size(78, 18);
            this.dcim39bvlamt.TabIndex = 225;
            this.dcim39bvlamt.TabStop = false;
            this.dcim39bvlamt.Tag = "39bvlamt";
            // 
            // dced39bvlamt
            // 
            this.dced39bvlamt.Location = new System.Drawing.Point(421, 407);
            this.dced39bvlamt.Name = "dced39bvlamt";
            this.dced39bvlamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced39bvlamt.OcxState")));
            this.dced39bvlamt.Size = new System.Drawing.Size(78, 18);
            this.dced39bvlamt.TabIndex = 226;
            this.dced39bvlamt.Tag = "39bvlamt";
            // 
            // dcim39cvlcd
            // 
            this.dcim39cvlcd.Location = new System.Drawing.Point(379, 431);
            this.dcim39cvlcd.Name = "dcim39cvlcd";
            this.dcim39cvlcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim39cvlcd.OcxState")));
            this.dcim39cvlcd.Size = new System.Drawing.Size(36, 18);
            this.dcim39cvlcd.TabIndex = 228;
            this.dcim39cvlcd.TabStop = false;
            this.dcim39cvlcd.Tag = "39cvlcd";
            // 
            // dced39cvlcd
            // 
            this.dced39cvlcd.Location = new System.Drawing.Point(379, 450);
            this.dced39cvlcd.Name = "dced39cvlcd";
            this.dced39cvlcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced39cvlcd.OcxState")));
            this.dced39cvlcd.Size = new System.Drawing.Size(36, 18);
            this.dced39cvlcd.TabIndex = 229;
            this.dced39cvlcd.Tag = "39cvlcd";
            // 
            // dcim39cvlamt
            // 
            this.dcim39cvlamt.Location = new System.Drawing.Point(421, 431);
            this.dcim39cvlamt.Name = "dcim39cvlamt";
            this.dcim39cvlamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim39cvlamt.OcxState")));
            this.dcim39cvlamt.Size = new System.Drawing.Size(78, 18);
            this.dcim39cvlamt.TabIndex = 231;
            this.dcim39cvlamt.TabStop = false;
            this.dcim39cvlamt.Tag = "39cvlamt";
            // 
            // dced39cvlamt
            // 
            this.dced39cvlamt.Location = new System.Drawing.Point(421, 450);
            this.dced39cvlamt.Name = "dced39cvlamt";
            this.dced39cvlamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced39cvlamt.OcxState")));
            this.dced39cvlamt.Size = new System.Drawing.Size(78, 18);
            this.dced39cvlamt.TabIndex = 232;
            this.dced39cvlamt.Tag = "39cvlamt";
            // 
            // dcim39dvlcd
            // 
            this.dcim39dvlcd.Location = new System.Drawing.Point(379, 474);
            this.dcim39dvlcd.Name = "dcim39dvlcd";
            this.dcim39dvlcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim39dvlcd.OcxState")));
            this.dcim39dvlcd.Size = new System.Drawing.Size(36, 18);
            this.dcim39dvlcd.TabIndex = 234;
            this.dcim39dvlcd.TabStop = false;
            this.dcim39dvlcd.Tag = "39dvlcd";
            // 
            // dced39dvlcd
            // 
            this.dced39dvlcd.Location = new System.Drawing.Point(379, 493);
            this.dced39dvlcd.Name = "dced39dvlcd";
            this.dced39dvlcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced39dvlcd.OcxState")));
            this.dced39dvlcd.Size = new System.Drawing.Size(36, 18);
            this.dced39dvlcd.TabIndex = 235;
            this.dced39dvlcd.Tag = "39dvlcd";
            // 
            // dcim39dvlamt
            // 
            this.dcim39dvlamt.Location = new System.Drawing.Point(421, 474);
            this.dcim39dvlamt.Name = "dcim39dvlamt";
            this.dcim39dvlamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim39dvlamt.OcxState")));
            this.dcim39dvlamt.Size = new System.Drawing.Size(78, 18);
            this.dcim39dvlamt.TabIndex = 237;
            this.dcim39dvlamt.TabStop = false;
            this.dcim39dvlamt.Tag = "39dvlamt";
            // 
            // dced39dvlamt
            // 
            this.dced39dvlamt.Location = new System.Drawing.Point(421, 493);
            this.dced39dvlamt.Name = "dced39dvlamt";
            this.dced39dvlamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced39dvlamt.OcxState")));
            this.dced39dvlamt.Size = new System.Drawing.Size(78, 18);
            this.dced39dvlamt.TabIndex = 238;
            this.dced39dvlamt.Tag = "39dvlamt";
            // 
            // lbl40avlcd
            // 
            this.lbl40avlcd.AutoSize = true;
            this.lbl40avlcd.Location = new System.Drawing.Point(517, 330);
            this.lbl40avlcd.Name = "lbl40avlcd";
            this.lbl40avlcd.Size = new System.Drawing.Size(119, 13);
            this.lbl40avlcd.TabIndex = 239;
            this.lbl40avlcd.Tag = "40avlcd";
            this.lbl40avlcd.Text = "40 Value Code, Amount";
            // 
            // dcim40avlcd
            // 
            this.dcim40avlcd.Location = new System.Drawing.Point(516, 346);
            this.dcim40avlcd.Name = "dcim40avlcd";
            this.dcim40avlcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim40avlcd.OcxState")));
            this.dcim40avlcd.Size = new System.Drawing.Size(36, 18);
            this.dcim40avlcd.TabIndex = 240;
            this.dcim40avlcd.TabStop = false;
            this.dcim40avlcd.Tag = "40avlcd";
            // 
            // dced40avlcd
            // 
            this.dced40avlcd.Location = new System.Drawing.Point(516, 365);
            this.dced40avlcd.Name = "dced40avlcd";
            this.dced40avlcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced40avlcd.OcxState")));
            this.dced40avlcd.Size = new System.Drawing.Size(36, 18);
            this.dced40avlcd.TabIndex = 241;
            this.dced40avlcd.Tag = "40avlcd";
            // 
            // dcim40avlamt
            // 
            this.dcim40avlamt.Location = new System.Drawing.Point(558, 346);
            this.dcim40avlamt.Name = "dcim40avlamt";
            this.dcim40avlamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim40avlamt.OcxState")));
            this.dcim40avlamt.Size = new System.Drawing.Size(78, 18);
            this.dcim40avlamt.TabIndex = 243;
            this.dcim40avlamt.TabStop = false;
            this.dcim40avlamt.Tag = "40avlamt";
            // 
            // dced40avlamt
            // 
            this.dced40avlamt.Location = new System.Drawing.Point(558, 365);
            this.dced40avlamt.Name = "dced40avlamt";
            this.dced40avlamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced40avlamt.OcxState")));
            this.dced40avlamt.Size = new System.Drawing.Size(78, 18);
            this.dced40avlamt.TabIndex = 244;
            this.dced40avlamt.Tag = "40avlamt";
            // 
            // dcim40bvlcd
            // 
            this.dcim40bvlcd.Location = new System.Drawing.Point(516, 388);
            this.dcim40bvlcd.Name = "dcim40bvlcd";
            this.dcim40bvlcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim40bvlcd.OcxState")));
            this.dcim40bvlcd.Size = new System.Drawing.Size(36, 18);
            this.dcim40bvlcd.TabIndex = 246;
            this.dcim40bvlcd.TabStop = false;
            this.dcim40bvlcd.Tag = "40bvlcd";
            // 
            // dced40bvlcd
            // 
            this.dced40bvlcd.Location = new System.Drawing.Point(516, 407);
            this.dced40bvlcd.Name = "dced40bvlcd";
            this.dced40bvlcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced40bvlcd.OcxState")));
            this.dced40bvlcd.Size = new System.Drawing.Size(36, 18);
            this.dced40bvlcd.TabIndex = 247;
            this.dced40bvlcd.Tag = "40bvlcd";
            // 
            // dcim40bvlamt
            // 
            this.dcim40bvlamt.Location = new System.Drawing.Point(558, 388);
            this.dcim40bvlamt.Name = "dcim40bvlamt";
            this.dcim40bvlamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim40bvlamt.OcxState")));
            this.dcim40bvlamt.Size = new System.Drawing.Size(78, 18);
            this.dcim40bvlamt.TabIndex = 249;
            this.dcim40bvlamt.TabStop = false;
            this.dcim40bvlamt.Tag = "40bvlamt";
            // 
            // dced40bvlamt
            // 
            this.dced40bvlamt.Location = new System.Drawing.Point(558, 407);
            this.dced40bvlamt.Name = "dced40bvlamt";
            this.dced40bvlamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced40bvlamt.OcxState")));
            this.dced40bvlamt.Size = new System.Drawing.Size(78, 18);
            this.dced40bvlamt.TabIndex = 250;
            this.dced40bvlamt.Tag = "40bvlamt";
            // 
            // dcim40cvlcd
            // 
            this.dcim40cvlcd.Location = new System.Drawing.Point(516, 431);
            this.dcim40cvlcd.Name = "dcim40cvlcd";
            this.dcim40cvlcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim40cvlcd.OcxState")));
            this.dcim40cvlcd.Size = new System.Drawing.Size(36, 18);
            this.dcim40cvlcd.TabIndex = 252;
            this.dcim40cvlcd.TabStop = false;
            this.dcim40cvlcd.Tag = "40cvlcd";
            // 
            // dced40cvlcd
            // 
            this.dced40cvlcd.Location = new System.Drawing.Point(516, 450);
            this.dced40cvlcd.Name = "dced40cvlcd";
            this.dced40cvlcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced40cvlcd.OcxState")));
            this.dced40cvlcd.Size = new System.Drawing.Size(36, 18);
            this.dced40cvlcd.TabIndex = 253;
            this.dced40cvlcd.Tag = "40cvlcd";
            // 
            // dcim40cvlamt
            // 
            this.dcim40cvlamt.Location = new System.Drawing.Point(558, 431);
            this.dcim40cvlamt.Name = "dcim40cvlamt";
            this.dcim40cvlamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim40cvlamt.OcxState")));
            this.dcim40cvlamt.Size = new System.Drawing.Size(78, 18);
            this.dcim40cvlamt.TabIndex = 255;
            this.dcim40cvlamt.TabStop = false;
            this.dcim40cvlamt.Tag = "40cvlamt";
            // 
            // dced40cvlamt
            // 
            this.dced40cvlamt.Location = new System.Drawing.Point(558, 450);
            this.dced40cvlamt.Name = "dced40cvlamt";
            this.dced40cvlamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced40cvlamt.OcxState")));
            this.dced40cvlamt.Size = new System.Drawing.Size(78, 18);
            this.dced40cvlamt.TabIndex = 256;
            this.dced40cvlamt.Tag = "40cvlamt";
            // 
            // dcim40dvlcd
            // 
            this.dcim40dvlcd.Location = new System.Drawing.Point(516, 474);
            this.dcim40dvlcd.Name = "dcim40dvlcd";
            this.dcim40dvlcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim40dvlcd.OcxState")));
            this.dcim40dvlcd.Size = new System.Drawing.Size(36, 18);
            this.dcim40dvlcd.TabIndex = 258;
            this.dcim40dvlcd.TabStop = false;
            this.dcim40dvlcd.Tag = "40dvlcd";
            // 
            // dced40dvlcd
            // 
            this.dced40dvlcd.Location = new System.Drawing.Point(516, 493);
            this.dced40dvlcd.Name = "dced40dvlcd";
            this.dced40dvlcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced40dvlcd.OcxState")));
            this.dced40dvlcd.Size = new System.Drawing.Size(36, 18);
            this.dced40dvlcd.TabIndex = 259;
            this.dced40dvlcd.Tag = "40dvlcd";
            // 
            // dcim40dvlamt
            // 
            this.dcim40dvlamt.Location = new System.Drawing.Point(558, 474);
            this.dcim40dvlamt.Name = "dcim40dvlamt";
            this.dcim40dvlamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim40dvlamt.OcxState")));
            this.dcim40dvlamt.Size = new System.Drawing.Size(78, 18);
            this.dcim40dvlamt.TabIndex = 261;
            this.dcim40dvlamt.TabStop = false;
            this.dcim40dvlamt.Tag = "40dvlamt";
            // 
            // dced40dvlamt
            // 
            this.dced40dvlamt.Location = new System.Drawing.Point(558, 493);
            this.dced40dvlamt.Name = "dced40dvlamt";
            this.dced40dvlamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced40dvlamt.OcxState")));
            this.dced40dvlamt.Size = new System.Drawing.Size(78, 18);
            this.dced40dvlamt.TabIndex = 262;
            this.dced40dvlamt.Tag = "40dvlamt";
            // 
            // dcim41avlcd
            // 
            this.dcim41avlcd.Location = new System.Drawing.Point(651, 346);
            this.dcim41avlcd.Name = "dcim41avlcd";
            this.dcim41avlcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim41avlcd.OcxState")));
            this.dcim41avlcd.Size = new System.Drawing.Size(36, 18);
            this.dcim41avlcd.TabIndex = 264;
            this.dcim41avlcd.TabStop = false;
            this.dcim41avlcd.Tag = "41avlcd";
            // 
            // dced41avlcd
            // 
            this.dced41avlcd.Location = new System.Drawing.Point(651, 365);
            this.dced41avlcd.Name = "dced41avlcd";
            this.dced41avlcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced41avlcd.OcxState")));
            this.dced41avlcd.Size = new System.Drawing.Size(36, 18);
            this.dced41avlcd.TabIndex = 265;
            this.dced41avlcd.Tag = "41avlcd";
            // 
            // dcim41avlamt
            // 
            this.dcim41avlamt.Location = new System.Drawing.Point(693, 346);
            this.dcim41avlamt.Name = "dcim41avlamt";
            this.dcim41avlamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim41avlamt.OcxState")));
            this.dcim41avlamt.Size = new System.Drawing.Size(78, 18);
            this.dcim41avlamt.TabIndex = 267;
            this.dcim41avlamt.TabStop = false;
            this.dcim41avlamt.Tag = "41avlamt";
            // 
            // dced41avlamt
            // 
            this.dced41avlamt.Location = new System.Drawing.Point(693, 365);
            this.dced41avlamt.Name = "dced41avlamt";
            this.dced41avlamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced41avlamt.OcxState")));
            this.dced41avlamt.Size = new System.Drawing.Size(78, 18);
            this.dced41avlamt.TabIndex = 268;
            this.dced41avlamt.Tag = "41avlamt";
            // 
            // lbl41bvlcd
            // 
            this.lbl41bvlcd.AutoSize = true;
            this.lbl41bvlcd.Location = new System.Drawing.Point(651, 329);
            this.lbl41bvlcd.Name = "lbl41bvlcd";
            this.lbl41bvlcd.Size = new System.Drawing.Size(119, 13);
            this.lbl41bvlcd.TabIndex = 269;
            this.lbl41bvlcd.Tag = "41bvlcd";
            this.lbl41bvlcd.Text = "41 Value Code, Amount";
            // 
            // dcim41bvlcd
            // 
            this.dcim41bvlcd.Location = new System.Drawing.Point(651, 388);
            this.dcim41bvlcd.Name = "dcim41bvlcd";
            this.dcim41bvlcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim41bvlcd.OcxState")));
            this.dcim41bvlcd.Size = new System.Drawing.Size(36, 18);
            this.dcim41bvlcd.TabIndex = 270;
            this.dcim41bvlcd.TabStop = false;
            this.dcim41bvlcd.Tag = "41bvlcd";
            // 
            // dced41bvlcd
            // 
            this.dced41bvlcd.Location = new System.Drawing.Point(651, 407);
            this.dced41bvlcd.Name = "dced41bvlcd";
            this.dced41bvlcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced41bvlcd.OcxState")));
            this.dced41bvlcd.Size = new System.Drawing.Size(36, 18);
            this.dced41bvlcd.TabIndex = 271;
            this.dced41bvlcd.Tag = "41bvlcd";
            // 
            // dcim41bvlamt
            // 
            this.dcim41bvlamt.Location = new System.Drawing.Point(693, 388);
            this.dcim41bvlamt.Name = "dcim41bvlamt";
            this.dcim41bvlamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim41bvlamt.OcxState")));
            this.dcim41bvlamt.Size = new System.Drawing.Size(78, 18);
            this.dcim41bvlamt.TabIndex = 273;
            this.dcim41bvlamt.TabStop = false;
            this.dcim41bvlamt.Tag = "41bvlamt";
            // 
            // dced41bvlamt
            // 
            this.dced41bvlamt.Location = new System.Drawing.Point(693, 407);
            this.dced41bvlamt.Name = "dced41bvlamt";
            this.dced41bvlamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced41bvlamt.OcxState")));
            this.dced41bvlamt.Size = new System.Drawing.Size(78, 18);
            this.dced41bvlamt.TabIndex = 274;
            this.dced41bvlamt.Tag = "41bvlamt";
            // 
            // dcim41cvlcd
            // 
            this.dcim41cvlcd.Location = new System.Drawing.Point(651, 431);
            this.dcim41cvlcd.Name = "dcim41cvlcd";
            this.dcim41cvlcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim41cvlcd.OcxState")));
            this.dcim41cvlcd.Size = new System.Drawing.Size(36, 18);
            this.dcim41cvlcd.TabIndex = 276;
            this.dcim41cvlcd.TabStop = false;
            this.dcim41cvlcd.Tag = "41cvlcd";
            // 
            // dced41cvlcd
            // 
            this.dced41cvlcd.Location = new System.Drawing.Point(651, 450);
            this.dced41cvlcd.Name = "dced41cvlcd";
            this.dced41cvlcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced41cvlcd.OcxState")));
            this.dced41cvlcd.Size = new System.Drawing.Size(36, 18);
            this.dced41cvlcd.TabIndex = 277;
            this.dced41cvlcd.Tag = "41cvlcd";
            // 
            // dcim41cvlamt
            // 
            this.dcim41cvlamt.Location = new System.Drawing.Point(693, 431);
            this.dcim41cvlamt.Name = "dcim41cvlamt";
            this.dcim41cvlamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim41cvlamt.OcxState")));
            this.dcim41cvlamt.Size = new System.Drawing.Size(78, 18);
            this.dcim41cvlamt.TabIndex = 279;
            this.dcim41cvlamt.TabStop = false;
            this.dcim41cvlamt.Tag = "41cvlamt";
            // 
            // dced41cvlamt
            // 
            this.dced41cvlamt.Location = new System.Drawing.Point(693, 450);
            this.dced41cvlamt.Name = "dced41cvlamt";
            this.dced41cvlamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced41cvlamt.OcxState")));
            this.dced41cvlamt.Size = new System.Drawing.Size(78, 18);
            this.dced41cvlamt.TabIndex = 280;
            this.dced41cvlamt.Tag = "41cvlamt";
            // 
            // dcim41dvlcd
            // 
            this.dcim41dvlcd.Location = new System.Drawing.Point(651, 474);
            this.dcim41dvlcd.Name = "dcim41dvlcd";
            this.dcim41dvlcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim41dvlcd.OcxState")));
            this.dcim41dvlcd.Size = new System.Drawing.Size(36, 18);
            this.dcim41dvlcd.TabIndex = 282;
            this.dcim41dvlcd.TabStop = false;
            this.dcim41dvlcd.Tag = "41dvlcd";
            // 
            // dced41dvlcd
            // 
            this.dced41dvlcd.Location = new System.Drawing.Point(651, 493);
            this.dced41dvlcd.Name = "dced41dvlcd";
            this.dced41dvlcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced41dvlcd.OcxState")));
            this.dced41dvlcd.Size = new System.Drawing.Size(36, 18);
            this.dced41dvlcd.TabIndex = 283;
            this.dced41dvlcd.Tag = "41dvlcd";
            // 
            // dcim41dvlamt
            // 
            this.dcim41dvlamt.Location = new System.Drawing.Point(693, 474);
            this.dcim41dvlamt.Name = "dcim41dvlamt";
            this.dcim41dvlamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim41dvlamt.OcxState")));
            this.dcim41dvlamt.Size = new System.Drawing.Size(78, 18);
            this.dcim41dvlamt.TabIndex = 285;
            this.dcim41dvlamt.TabStop = false;
            this.dcim41dvlamt.Tag = "41dvlamt";
            // 
            // dced41dvlamt
            // 
            this.dced41dvlamt.Location = new System.Drawing.Point(693, 493);
            this.dced41dvlamt.Name = "dced41dvlamt";
            this.dced41dvlamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced41dvlamt.OcxState")));
            this.dced41dvlamt.Size = new System.Drawing.Size(78, 18);
            this.dced41dvlamt.TabIndex = 286;
            this.dced41dvlamt.Tag = "41dvlamt";
            // 
            // dcim50apayer
            // 
            this.dcim50apayer.Location = new System.Drawing.Point(36, 882);
            this.dcim50apayer.Name = "dcim50apayer";
            this.dcim50apayer.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim50apayer.OcxState")));
            this.dcim50apayer.Size = new System.Drawing.Size(156, 18);
            this.dcim50apayer.TabIndex = 300;
            this.dcim50apayer.TabStop = false;
            this.dcim50apayer.Tag = "50apayer";
            // 
            // dced50apayer
            // 
            this.dced50apayer.Location = new System.Drawing.Point(36, 901);
            this.dced50apayer.Name = "dced50apayer";
            this.dced50apayer.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced50apayer.OcxState")));
            this.dced50apayer.Size = new System.Drawing.Size(156, 18);
            this.dced50apayer.TabIndex = 301;
            this.dced50apayer.Tag = "50apayer";
            // 
            // dcim50bpayer
            // 
            this.dcim50bpayer.Location = new System.Drawing.Point(36, 929);
            this.dcim50bpayer.Name = "dcim50bpayer";
            this.dcim50bpayer.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim50bpayer.OcxState")));
            this.dcim50bpayer.Size = new System.Drawing.Size(156, 18);
            this.dcim50bpayer.TabIndex = 311;
            this.dcim50bpayer.TabStop = false;
            this.dcim50bpayer.Tag = "50bpayer";
            // 
            // dced50bpayer
            // 
            this.dced50bpayer.Location = new System.Drawing.Point(36, 948);
            this.dced50bpayer.Name = "dced50bpayer";
            this.dced50bpayer.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced50bpayer.OcxState")));
            this.dced50bpayer.Size = new System.Drawing.Size(156, 18);
            this.dced50bpayer.TabIndex = 312;
            this.dced50bpayer.Tag = "50bpayer";
            // 
            // lbl50cpayer
            // 
            this.lbl50cpayer.AutoSize = true;
            this.lbl50cpayer.BackColor = System.Drawing.Color.Lavender;
            this.lbl50cpayer.Location = new System.Drawing.Point(35, 868);
            this.lbl50cpayer.Name = "lbl50cpayer";
            this.lbl50cpayer.Size = new System.Drawing.Size(52, 13);
            this.lbl50cpayer.TabIndex = 299;
            this.lbl50cpayer.Tag = "50cpayer";
            this.lbl50cpayer.Text = "50  Payer";
            // 
            // dcim50cpayer
            // 
            this.dcim50cpayer.Location = new System.Drawing.Point(36, 977);
            this.dcim50cpayer.Name = "dcim50cpayer";
            this.dcim50cpayer.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim50cpayer.OcxState")));
            this.dcim50cpayer.Size = new System.Drawing.Size(156, 18);
            this.dcim50cpayer.TabIndex = 321;
            this.dcim50cpayer.TabStop = false;
            this.dcim50cpayer.Tag = "50cpayer";
            // 
            // dced50cpayer
            // 
            this.dced50cpayer.Location = new System.Drawing.Point(36, 996);
            this.dced50cpayer.Name = "dced50cpayer";
            this.dced50cpayer.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced50cpayer.OcxState")));
            this.dced50cpayer.Size = new System.Drawing.Size(156, 18);
            this.dced50cpayer.TabIndex = 322;
            this.dced50cpayer.Tag = "50cpayer";
            // 
            // dcim51aprvno
            // 
            this.dcim51aprvno.Location = new System.Drawing.Point(216, 882);
            this.dcim51aprvno.Name = "dcim51aprvno";
            this.dcim51aprvno.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim51aprvno.OcxState")));
            this.dcim51aprvno.Size = new System.Drawing.Size(162, 18);
            this.dcim51aprvno.TabIndex = 303;
            this.dcim51aprvno.TabStop = false;
            this.dcim51aprvno.Tag = "51aprvno";
            // 
            // dced51aprvno
            // 
            this.dced51aprvno.Location = new System.Drawing.Point(216, 901);
            this.dced51aprvno.Name = "dced51aprvno";
            this.dced51aprvno.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced51aprvno.OcxState")));
            this.dced51aprvno.Size = new System.Drawing.Size(162, 18);
            this.dced51aprvno.TabIndex = 304;
            this.dced51aprvno.Tag = "51aprvno";
            // 
            // dcim51bprvno
            // 
            this.dcim51bprvno.Location = new System.Drawing.Point(216, 929);
            this.dcim51bprvno.Name = "dcim51bprvno";
            this.dcim51bprvno.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim51bprvno.OcxState")));
            this.dcim51bprvno.Size = new System.Drawing.Size(162, 18);
            this.dcim51bprvno.TabIndex = 313;
            this.dcim51bprvno.TabStop = false;
            this.dcim51bprvno.Tag = "51bprvno";
            // 
            // dced51bprvno
            // 
            this.dced51bprvno.Location = new System.Drawing.Point(216, 948);
            this.dced51bprvno.Name = "dced51bprvno";
            this.dced51bprvno.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced51bprvno.OcxState")));
            this.dced51bprvno.Size = new System.Drawing.Size(162, 18);
            this.dced51bprvno.TabIndex = 314;
            this.dced51bprvno.Tag = "51bprvno";
            // 
            // lbl51cprvno
            // 
            this.lbl51cprvno.AutoSize = true;
            this.lbl51cprvno.BackColor = System.Drawing.Color.Lavender;
            this.lbl51cprvno.Location = new System.Drawing.Point(215, 869);
            this.lbl51cprvno.Name = "lbl51cprvno";
            this.lbl51cprvno.Size = new System.Drawing.Size(84, 13);
            this.lbl51cprvno.TabIndex = 302;
            this.lbl51cprvno.Tag = "51cprvno";
            this.lbl51cprvno.Text = "51  Provider No.";
            // 
            // dcim51cprvno
            // 
            this.dcim51cprvno.Location = new System.Drawing.Point(216, 977);
            this.dcim51cprvno.Name = "dcim51cprvno";
            this.dcim51cprvno.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim51cprvno.OcxState")));
            this.dcim51cprvno.Size = new System.Drawing.Size(162, 18);
            this.dcim51cprvno.TabIndex = 323;
            this.dcim51cprvno.TabStop = false;
            this.dcim51cprvno.Tag = "51cprvno";
            // 
            // dced51cprvno
            // 
            this.dced51cprvno.Location = new System.Drawing.Point(216, 996);
            this.dced51cprvno.Name = "dced51cprvno";
            this.dced51cprvno.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced51cprvno.OcxState")));
            this.dced51cprvno.Size = new System.Drawing.Size(162, 18);
            this.dced51cprvno.TabIndex = 324;
            this.dced51cprvno.Tag = "51cprvno";
            // 
            // lbl56npi
            // 
            this.lbl56npi.AutoSize = true;
            this.lbl56npi.Location = new System.Drawing.Point(674, 804);
            this.lbl56npi.Name = "lbl56npi";
            this.lbl56npi.Size = new System.Drawing.Size(40, 13);
            this.lbl56npi.TabIndex = 296;
            this.lbl56npi.Tag = "56npi";
            this.lbl56npi.Text = "56 NPI";
            // 
            // dcim56npi
            // 
            this.dcim56npi.Location = new System.Drawing.Point(680, 820);
            this.dcim56npi.Name = "dcim56npi";
            this.dcim56npi.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim56npi.OcxState")));
            this.dcim56npi.Size = new System.Drawing.Size(96, 18);
            this.dcim56npi.TabIndex = 297;
            this.dcim56npi.TabStop = false;
            this.dcim56npi.Tag = "56npi";
            // 
            // dced56npi
            // 
            this.dced56npi.Location = new System.Drawing.Point(680, 839);
            this.dced56npi.Name = "dced56npi";
            this.dced56npi.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced56npi.OcxState")));
            this.dced56npi.Size = new System.Drawing.Size(96, 18);
            this.dced56npi.TabIndex = 298;
            this.dced56npi.Tag = "56npi";
            // 
            // dcim58ainsnm
            // 
            this.dcim58ainsnm.Location = new System.Drawing.Point(398, 882);
            this.dcim58ainsnm.Name = "dcim58ainsnm";
            this.dcim58ainsnm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim58ainsnm.OcxState")));
            this.dcim58ainsnm.Size = new System.Drawing.Size(233, 18);
            this.dcim58ainsnm.TabIndex = 305;
            this.dcim58ainsnm.TabStop = false;
            this.dcim58ainsnm.Tag = "58ainsnm";
            // 
            // lbl58alname
            // 
            this.lbl58alname.AutoSize = true;
            this.lbl58alname.BackColor = System.Drawing.Color.Lavender;
            this.lbl58alname.Location = new System.Drawing.Point(14, 1175);
            this.lbl58alname.Name = "lbl58alname";
            this.lbl58alname.Size = new System.Drawing.Size(34, 13);
            this.lbl58alname.TabIndex = 358;
            this.lbl58alname.Tag = "58alname";
            this.lbl58alname.Text = "66DX";
            // 
            // dced58alname
            // 
            this.dced58alname.Location = new System.Drawing.Point(398, 901);
            this.dced58alname.Name = "dced58alname";
            this.dced58alname.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced58alname.OcxState")));
            this.dced58alname.Size = new System.Drawing.Size(102, 18);
            this.dced58alname.TabIndex = 306;
            this.dced58alname.Tag = "58alname";
            // 
            // lbl58afname
            // 
            this.lbl58afname.AutoSize = true;
            this.lbl58afname.BackColor = System.Drawing.Color.Lavender;
            this.lbl58afname.Location = new System.Drawing.Point(59, 1175);
            this.lbl58afname.Name = "lbl58afname";
            this.lbl58afname.Size = new System.Drawing.Size(66, 13);
            this.lbl58afname.TabIndex = 360;
            this.lbl58afname.Tag = "58afname";
            this.lbl58afname.Text = "69 Admit DX";
            // 
            // dced58afname
            // 
            this.dced58afname.Location = new System.Drawing.Point(504, 901);
            this.dced58afname.Name = "dced58afname";
            this.dced58afname.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced58afname.OcxState")));
            this.dced58afname.Size = new System.Drawing.Size(90, 18);
            this.dced58afname.TabIndex = 307;
            this.dced58afname.Tag = "58afname";
            // 
            // lbl58aminit
            // 
            this.lbl58aminit.AutoSize = true;
            this.lbl58aminit.BackColor = System.Drawing.Color.Lavender;
            this.lbl58aminit.Location = new System.Drawing.Point(126, 1175);
            this.lbl58aminit.Name = "lbl58aminit";
            this.lbl58aminit.Size = new System.Drawing.Size(75, 13);
            this.lbl58aminit.TabIndex = 362;
            this.lbl58aminit.Tag = "58aminit";
            this.lbl58aminit.Text = "70A Resn. DX";
            // 
            // dced58aminit
            // 
            this.dced58aminit.Location = new System.Drawing.Point(600, 901);
            this.dced58aminit.Name = "dced58aminit";
            this.dced58aminit.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced58aminit.OcxState")));
            this.dced58aminit.Size = new System.Drawing.Size(31, 18);
            this.dced58aminit.TabIndex = 308;
            this.dced58aminit.Tag = "58aminit";
            // 
            // lbl58binsnm
            // 
            this.lbl58binsnm.AutoSize = true;
            this.lbl58binsnm.BackColor = System.Drawing.Color.Lavender;
            this.lbl58binsnm.Location = new System.Drawing.Point(395, 869);
            this.lbl58binsnm.Name = "lbl58binsnm";
            this.lbl58binsnm.Size = new System.Drawing.Size(198, 13);
            this.lbl58binsnm.TabIndex = 366;
            this.lbl58binsnm.Tag = "58binsnm";
            this.lbl58binsnm.Text = "58  Insured\'s Last Name, First Name , MI";
            // 
            // dcim58binsnm
            // 
            this.dcim58binsnm.Location = new System.Drawing.Point(396, 929);
            this.dcim58binsnm.Name = "dcim58binsnm";
            this.dcim58binsnm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim58binsnm.OcxState")));
            this.dcim58binsnm.Size = new System.Drawing.Size(233, 20);
            this.dcim58binsnm.TabIndex = 315;
            this.dcim58binsnm.TabStop = false;
            this.dcim58binsnm.Tag = "58binsnm";
            // 
            // lbl58blname
            // 
            this.lbl58blname.AutoSize = true;
            this.lbl58blname.BackColor = System.Drawing.Color.Lavender;
            this.lbl58blname.Location = new System.Drawing.Point(198, 1175);
            this.lbl58blname.Name = "lbl58blname";
            this.lbl58blname.Size = new System.Drawing.Size(75, 13);
            this.lbl58blname.TabIndex = 368;
            this.lbl58blname.Tag = "58blname";
            this.lbl58blname.Text = "70B Resn. DX";
            // 
            // dced58blname
            // 
            this.dced58blname.Location = new System.Drawing.Point(396, 950);
            this.dced58blname.Name = "dced58blname";
            this.dced58blname.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced58blname.OcxState")));
            this.dced58blname.Size = new System.Drawing.Size(102, 18);
            this.dced58blname.TabIndex = 316;
            this.dced58blname.Tag = "58blname";
            // 
            // lbl58bfname
            // 
            this.lbl58bfname.AutoSize = true;
            this.lbl58bfname.BackColor = System.Drawing.Color.Lavender;
            this.lbl58bfname.Location = new System.Drawing.Point(270, 1175);
            this.lbl58bfname.Name = "lbl58bfname";
            this.lbl58bfname.Size = new System.Drawing.Size(75, 13);
            this.lbl58bfname.TabIndex = 370;
            this.lbl58bfname.Tag = "58bfname";
            this.lbl58bfname.Text = "70C Resn. DX";
            // 
            // dced58bfname
            // 
            this.dced58bfname.Location = new System.Drawing.Point(504, 950);
            this.dced58bfname.Name = "dced58bfname";
            this.dced58bfname.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced58bfname.OcxState")));
            this.dced58bfname.Size = new System.Drawing.Size(90, 18);
            this.dced58bfname.TabIndex = 317;
            this.dced58bfname.Tag = "58bfname";
            // 
            // lbl58bminit
            // 
            this.lbl58bminit.AutoSize = true;
            this.lbl58bminit.BackColor = System.Drawing.Color.Lavender;
            this.lbl58bminit.Location = new System.Drawing.Point(344, 1175);
            this.lbl58bminit.Name = "lbl58bminit";
            this.lbl58bminit.Size = new System.Drawing.Size(72, 13);
            this.lbl58bminit.TabIndex = 372;
            this.lbl58bminit.Tag = "58bminit";
            this.lbl58bminit.Text = "71 PPS/DRG";
            // 
            // dced58bminit
            // 
            this.dced58bminit.Location = new System.Drawing.Point(598, 950);
            this.dced58bminit.Name = "dced58bminit";
            this.dced58bminit.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced58bminit.OcxState")));
            this.dced58bminit.Size = new System.Drawing.Size(31, 18);
            this.dced58bminit.TabIndex = 318;
            this.dced58bminit.Tag = "58bminit";
            // 
            // dcim58cinsnm
            // 
            this.dcim58cinsnm.Location = new System.Drawing.Point(396, 977);
            this.dcim58cinsnm.Name = "dcim58cinsnm";
            this.dcim58cinsnm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim58cinsnm.OcxState")));
            this.dcim58cinsnm.Size = new System.Drawing.Size(233, 20);
            this.dcim58cinsnm.TabIndex = 325;
            this.dcim58cinsnm.TabStop = false;
            this.dcim58cinsnm.Tag = "58cinsnm";
            // 
            // lbl58clname
            // 
            this.lbl58clname.AutoSize = true;
            this.lbl58clname.BackColor = System.Drawing.Color.Lavender;
            this.lbl58clname.Location = new System.Drawing.Point(418, 1175);
            this.lbl58clname.Name = "lbl58clname";
            this.lbl58clname.Size = new System.Drawing.Size(68, 13);
            this.lbl58clname.TabIndex = 378;
            this.lbl58clname.Tag = "58clname";
            this.lbl58clname.Text = "72 EDI Code";
            // 
            // dced58clname
            // 
            this.dced58clname.Location = new System.Drawing.Point(396, 998);
            this.dced58clname.Name = "dced58clname";
            this.dced58clname.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced58clname.OcxState")));
            this.dced58clname.Size = new System.Drawing.Size(102, 18);
            this.dced58clname.TabIndex = 326;
            this.dced58clname.Tag = "58clname";
            // 
            // dced58cfname
            // 
            this.dced58cfname.Location = new System.Drawing.Point(504, 998);
            this.dced58cfname.Name = "dced58cfname";
            this.dced58cfname.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced58cfname.OcxState")));
            this.dced58cfname.Size = new System.Drawing.Size(90, 18);
            this.dced58cfname.TabIndex = 327;
            this.dced58cfname.Tag = "58cfname";
            // 
            // dced58cminit
            // 
            this.dced58cminit.Location = new System.Drawing.Point(598, 998);
            this.dced58cminit.Name = "dced58cminit";
            this.dced58cminit.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced58cminit.OcxState")));
            this.dced58cminit.Size = new System.Drawing.Size(31, 18);
            this.dced58cminit.TabIndex = 328;
            this.dced58cminit.Tag = "58cminit";
            // 
            // dcim60acshi
            // 
            this.dcim60acshi.Location = new System.Drawing.Point(649, 884);
            this.dcim60acshi.Name = "dcim60acshi";
            this.dcim60acshi.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim60acshi.OcxState")));
            this.dcim60acshi.Size = new System.Drawing.Size(122, 18);
            this.dcim60acshi.TabIndex = 309;
            this.dcim60acshi.TabStop = false;
            this.dcim60acshi.Tag = "60acshi";
            // 
            // dced60acshi
            // 
            this.dced60acshi.Location = new System.Drawing.Point(649, 903);
            this.dced60acshi.Name = "dced60acshi";
            this.dced60acshi.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced60acshi.OcxState")));
            this.dced60acshi.Size = new System.Drawing.Size(122, 18);
            this.dced60acshi.TabIndex = 310;
            this.dced60acshi.Tag = "60acshi";
            // 
            // dcim60bcshi
            // 
            this.dcim60bcshi.Location = new System.Drawing.Point(649, 931);
            this.dcim60bcshi.Name = "dcim60bcshi";
            this.dcim60bcshi.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim60bcshi.OcxState")));
            this.dcim60bcshi.Size = new System.Drawing.Size(122, 18);
            this.dcim60bcshi.TabIndex = 319;
            this.dcim60bcshi.TabStop = false;
            this.dcim60bcshi.Tag = "60bcshi";
            // 
            // dced60bcshi
            // 
            this.dced60bcshi.Location = new System.Drawing.Point(649, 950);
            this.dced60bcshi.Name = "dced60bcshi";
            this.dced60bcshi.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced60bcshi.OcxState")));
            this.dced60bcshi.Size = new System.Drawing.Size(122, 18);
            this.dced60bcshi.TabIndex = 320;
            this.dced60bcshi.Tag = "60bcshi";
            // 
            // lbl60ccshi
            // 
            this.lbl60ccshi.AutoSize = true;
            this.lbl60ccshi.BackColor = System.Drawing.Color.Lavender;
            this.lbl60ccshi.Location = new System.Drawing.Point(649, 868);
            this.lbl60ccshi.Name = "lbl60ccshi";
            this.lbl60ccshi.Size = new System.Drawing.Size(115, 13);
            this.lbl60ccshi.TabIndex = 401;
            this.lbl60ccshi.Tag = "60ccshi";
            this.lbl60ccshi.Text = "60 Insured\'s Unique ID";
            // 
            // dcim60ccshi
            // 
            this.dcim60ccshi.Location = new System.Drawing.Point(649, 977);
            this.dcim60ccshi.Name = "dcim60ccshi";
            this.dcim60ccshi.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim60ccshi.OcxState")));
            this.dcim60ccshi.Size = new System.Drawing.Size(122, 18);
            this.dcim60ccshi.TabIndex = 329;
            this.dcim60ccshi.TabStop = false;
            this.dcim60ccshi.Tag = "60ccshi";
            // 
            // dced60ccshi
            // 
            this.dced60ccshi.Location = new System.Drawing.Point(649, 997);
            this.dced60ccshi.Name = "dced60ccshi";
            this.dced60ccshi.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced60ccshi.OcxState")));
            this.dced60ccshi.Size = new System.Drawing.Size(122, 18);
            this.dced60ccshi.TabIndex = 330;
            this.dced60ccshi.Tag = "60ccshi";
            // 
            // dcim66dxverq
            // 
            this.dcim66dxverq.Location = new System.Drawing.Point(17, 1188);
            this.dcim66dxverq.Name = "dcim66dxverq";
            this.dcim66dxverq.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim66dxverq.OcxState")));
            this.dcim66dxverq.Size = new System.Drawing.Size(31, 18);
            this.dcim66dxverq.TabIndex = 432;
            this.dcim66dxverq.TabStop = false;
            this.dcim66dxverq.Tag = "66dxverq";
            // 
            // dced66dxverq
            // 
            this.dced66dxverq.Location = new System.Drawing.Point(17, 1207);
            this.dced66dxverq.Name = "dced66dxverq";
            this.dced66dxverq.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced66dxverq.OcxState")));
            this.dced66dxverq.Size = new System.Drawing.Size(31, 18);
            this.dced66dxverq.TabIndex = 433;
            this.dced66dxverq.Tag = "66dxverq";
            // 
            // lbl67prdgcd
            // 
            this.lbl67prdgcd.AutoSize = true;
            this.lbl67prdgcd.BackColor = System.Drawing.Color.Lavender;
            this.lbl67prdgcd.Location = new System.Drawing.Point(16, 1055);
            this.lbl67prdgcd.Name = "lbl67prdgcd";
            this.lbl67prdgcd.Size = new System.Drawing.Size(72, 13);
            this.lbl67prdgcd.TabIndex = 434;
            this.lbl67prdgcd.Tag = "67prdgcd";
            this.lbl67prdgcd.Text = "Prin. Diag. Cd";
            // 
            // dcim67prdgcd
            // 
            this.dcim67prdgcd.Location = new System.Drawing.Point(18, 1068);
            this.dcim67prdgcd.Name = "dcim67prdgcd";
            this.dcim67prdgcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim67prdgcd.OcxState")));
            this.dcim67prdgcd.Size = new System.Drawing.Size(66, 18);
            this.dcim67prdgcd.TabIndex = 435;
            this.dcim67prdgcd.TabStop = false;
            this.dcim67prdgcd.Tag = "67prdgcd";
            // 
            // dced67prdgcd
            // 
            this.dced67prdgcd.Location = new System.Drawing.Point(18, 1087);
            this.dced67prdgcd.Name = "dced67prdgcd";
            this.dced67prdgcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced67prdgcd.OcxState")));
            this.dced67prdgcd.Size = new System.Drawing.Size(66, 18);
            this.dced67prdgcd.TabIndex = 436;
            this.dced67prdgcd.Tag = "67prdgcd";
            // 
            // lbl67aothdg
            // 
            this.lbl67aothdg.AutoSize = true;
            this.lbl67aothdg.BackColor = System.Drawing.Color.Lavender;
            this.lbl67aothdg.Location = new System.Drawing.Point(119, 1052);
            this.lbl67aothdg.Name = "lbl67aothdg";
            this.lbl67aothdg.Size = new System.Drawing.Size(13, 13);
            this.lbl67aothdg.TabIndex = 437;
            this.lbl67aothdg.Tag = "67aothdg";
            this.lbl67aothdg.Text = "a";
            // 
            // dcim67aothdg
            // 
            this.dcim67aothdg.Location = new System.Drawing.Point(90, 1068);
            this.dcim67aothdg.Name = "dcim67aothdg";
            this.dcim67aothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim67aothdg.OcxState")));
            this.dcim67aothdg.Size = new System.Drawing.Size(66, 18);
            this.dcim67aothdg.TabIndex = 438;
            this.dcim67aothdg.TabStop = false;
            this.dcim67aothdg.Tag = "67aothdg";
            // 
            // dced67aothdg
            // 
            this.dced67aothdg.Location = new System.Drawing.Point(90, 1087);
            this.dced67aothdg.Name = "dced67aothdg";
            this.dced67aothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced67aothdg.OcxState")));
            this.dced67aothdg.Size = new System.Drawing.Size(66, 18);
            this.dced67aothdg.TabIndex = 439;
            this.dced67aothdg.Tag = "67aothdg";
            // 
            // lbl67bothdg
            // 
            this.lbl67bothdg.AutoSize = true;
            this.lbl67bothdg.BackColor = System.Drawing.Color.Lavender;
            this.lbl67bothdg.Location = new System.Drawing.Point(192, 1052);
            this.lbl67bothdg.Name = "lbl67bothdg";
            this.lbl67bothdg.Size = new System.Drawing.Size(13, 13);
            this.lbl67bothdg.TabIndex = 440;
            this.lbl67bothdg.Tag = "67bothdg";
            this.lbl67bothdg.Text = "b";
            // 
            // dcim67bothdg
            // 
            this.dcim67bothdg.Location = new System.Drawing.Point(162, 1068);
            this.dcim67bothdg.Name = "dcim67bothdg";
            this.dcim67bothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim67bothdg.OcxState")));
            this.dcim67bothdg.Size = new System.Drawing.Size(66, 18);
            this.dcim67bothdg.TabIndex = 441;
            this.dcim67bothdg.TabStop = false;
            this.dcim67bothdg.Tag = "67bothdg";
            // 
            // dced67bothdg
            // 
            this.dced67bothdg.Location = new System.Drawing.Point(162, 1087);
            this.dced67bothdg.Name = "dced67bothdg";
            this.dced67bothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced67bothdg.OcxState")));
            this.dced67bothdg.Size = new System.Drawing.Size(66, 18);
            this.dced67bothdg.TabIndex = 442;
            this.dced67bothdg.Tag = "67bothdg";
            // 
            // lbl67cothdg
            // 
            this.lbl67cothdg.AutoSize = true;
            this.lbl67cothdg.BackColor = System.Drawing.Color.Lavender;
            this.lbl67cothdg.Location = new System.Drawing.Point(264, 1052);
            this.lbl67cothdg.Name = "lbl67cothdg";
            this.lbl67cothdg.Size = new System.Drawing.Size(13, 13);
            this.lbl67cothdg.TabIndex = 443;
            this.lbl67cothdg.Tag = "67cothdg";
            this.lbl67cothdg.Text = "c";
            // 
            // dcim67cothdg
            // 
            this.dcim67cothdg.Location = new System.Drawing.Point(234, 1068);
            this.dcim67cothdg.Name = "dcim67cothdg";
            this.dcim67cothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim67cothdg.OcxState")));
            this.dcim67cothdg.Size = new System.Drawing.Size(66, 18);
            this.dcim67cothdg.TabIndex = 444;
            this.dcim67cothdg.TabStop = false;
            this.dcim67cothdg.Tag = "67cothdg";
            // 
            // dced67cothdg
            // 
            this.dced67cothdg.Location = new System.Drawing.Point(234, 1087);
            this.dced67cothdg.Name = "dced67cothdg";
            this.dced67cothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced67cothdg.OcxState")));
            this.dced67cothdg.Size = new System.Drawing.Size(66, 18);
            this.dced67cothdg.TabIndex = 445;
            this.dced67cothdg.Tag = "67cothdg";
            // 
            // lbl67dothdg
            // 
            this.lbl67dothdg.AutoSize = true;
            this.lbl67dothdg.BackColor = System.Drawing.Color.Lavender;
            this.lbl67dothdg.Location = new System.Drawing.Point(339, 1052);
            this.lbl67dothdg.Name = "lbl67dothdg";
            this.lbl67dothdg.Size = new System.Drawing.Size(13, 13);
            this.lbl67dothdg.TabIndex = 446;
            this.lbl67dothdg.Tag = "67dothdg";
            this.lbl67dothdg.Text = "d";
            // 
            // dcim67dothdg
            // 
            this.dcim67dothdg.Location = new System.Drawing.Point(312, 1068);
            this.dcim67dothdg.Name = "dcim67dothdg";
            this.dcim67dothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim67dothdg.OcxState")));
            this.dcim67dothdg.Size = new System.Drawing.Size(66, 18);
            this.dcim67dothdg.TabIndex = 447;
            this.dcim67dothdg.TabStop = false;
            this.dcim67dothdg.Tag = "67dothdg";
            // 
            // dced67dothdg
            // 
            this.dced67dothdg.Location = new System.Drawing.Point(312, 1087);
            this.dced67dothdg.Name = "dced67dothdg";
            this.dced67dothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced67dothdg.OcxState")));
            this.dced67dothdg.Size = new System.Drawing.Size(66, 18);
            this.dced67dothdg.TabIndex = 448;
            this.dced67dothdg.Tag = "67dothdg";
            // 
            // lbl67eothdg
            // 
            this.lbl67eothdg.AutoSize = true;
            this.lbl67eothdg.BackColor = System.Drawing.Color.Lavender;
            this.lbl67eothdg.Location = new System.Drawing.Point(420, 1052);
            this.lbl67eothdg.Name = "lbl67eothdg";
            this.lbl67eothdg.Size = new System.Drawing.Size(13, 13);
            this.lbl67eothdg.TabIndex = 449;
            this.lbl67eothdg.Tag = "67eothdg";
            this.lbl67eothdg.Text = "e";
            // 
            // dcim67eothdg
            // 
            this.dcim67eothdg.Location = new System.Drawing.Point(390, 1068);
            this.dcim67eothdg.Name = "dcim67eothdg";
            this.dcim67eothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim67eothdg.OcxState")));
            this.dcim67eothdg.Size = new System.Drawing.Size(66, 18);
            this.dcim67eothdg.TabIndex = 450;
            this.dcim67eothdg.TabStop = false;
            this.dcim67eothdg.Tag = "67eothdg";
            // 
            // dced67eothdg
            // 
            this.dced67eothdg.Location = new System.Drawing.Point(390, 1087);
            this.dced67eothdg.Name = "dced67eothdg";
            this.dced67eothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced67eothdg.OcxState")));
            this.dced67eothdg.Size = new System.Drawing.Size(66, 18);
            this.dced67eothdg.TabIndex = 451;
            this.dced67eothdg.Tag = "67eothdg";
            // 
            // lbl67fothdg
            // 
            this.lbl67fothdg.AutoSize = true;
            this.lbl67fothdg.BackColor = System.Drawing.Color.Lavender;
            this.lbl67fothdg.Location = new System.Drawing.Point(498, 1052);
            this.lbl67fothdg.Name = "lbl67fothdg";
            this.lbl67fothdg.Size = new System.Drawing.Size(10, 13);
            this.lbl67fothdg.TabIndex = 452;
            this.lbl67fothdg.Tag = "67fothdg";
            this.lbl67fothdg.Text = "f";
            // 
            // dcim67fothdg
            // 
            this.dcim67fothdg.Location = new System.Drawing.Point(468, 1068);
            this.dcim67fothdg.Name = "dcim67fothdg";
            this.dcim67fothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim67fothdg.OcxState")));
            this.dcim67fothdg.Size = new System.Drawing.Size(66, 18);
            this.dcim67fothdg.TabIndex = 453;
            this.dcim67fothdg.TabStop = false;
            this.dcim67fothdg.Tag = "67fothdg";
            // 
            // dced67fothdg
            // 
            this.dced67fothdg.Location = new System.Drawing.Point(468, 1087);
            this.dced67fothdg.Name = "dced67fothdg";
            this.dced67fothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced67fothdg.OcxState")));
            this.dced67fothdg.Size = new System.Drawing.Size(66, 18);
            this.dced67fothdg.TabIndex = 454;
            this.dced67fothdg.Tag = "67fothdg";
            // 
            // lbl67gothdg
            // 
            this.lbl67gothdg.AutoSize = true;
            this.lbl67gothdg.BackColor = System.Drawing.Color.Lavender;
            this.lbl67gothdg.Location = new System.Drawing.Point(577, 1052);
            this.lbl67gothdg.Name = "lbl67gothdg";
            this.lbl67gothdg.Size = new System.Drawing.Size(13, 13);
            this.lbl67gothdg.TabIndex = 455;
            this.lbl67gothdg.Tag = "67gothdg";
            this.lbl67gothdg.Text = "g";
            // 
            // dcim67gothdg
            // 
            this.dcim67gothdg.Location = new System.Drawing.Point(549, 1068);
            this.dcim67gothdg.Name = "dcim67gothdg";
            this.dcim67gothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim67gothdg.OcxState")));
            this.dcim67gothdg.Size = new System.Drawing.Size(66, 18);
            this.dcim67gothdg.TabIndex = 456;
            this.dcim67gothdg.TabStop = false;
            this.dcim67gothdg.Tag = "67gothdg";
            // 
            // dced67gothdg
            // 
            this.dced67gothdg.Location = new System.Drawing.Point(549, 1087);
            this.dced67gothdg.Name = "dced67gothdg";
            this.dced67gothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced67gothdg.OcxState")));
            this.dced67gothdg.Size = new System.Drawing.Size(66, 18);
            this.dced67gothdg.TabIndex = 457;
            this.dced67gothdg.Tag = "67gothdg";
            // 
            // lbl67hothdg
            // 
            this.lbl67hothdg.AutoSize = true;
            this.lbl67hothdg.BackColor = System.Drawing.Color.Lavender;
            this.lbl67hothdg.Location = new System.Drawing.Point(657, 1052);
            this.lbl67hothdg.Name = "lbl67hothdg";
            this.lbl67hothdg.Size = new System.Drawing.Size(13, 13);
            this.lbl67hothdg.TabIndex = 458;
            this.lbl67hothdg.Tag = "67hothdg";
            this.lbl67hothdg.Text = "h";
            // 
            // dcim67hothdg
            // 
            this.dcim67hothdg.Location = new System.Drawing.Point(627, 1068);
            this.dcim67hothdg.Name = "dcim67hothdg";
            this.dcim67hothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim67hothdg.OcxState")));
            this.dcim67hothdg.Size = new System.Drawing.Size(66, 18);
            this.dcim67hothdg.TabIndex = 459;
            this.dcim67hothdg.TabStop = false;
            this.dcim67hothdg.Tag = "67hothdg";
            // 
            // dced67hothdg
            // 
            this.dced67hothdg.Location = new System.Drawing.Point(627, 1087);
            this.dced67hothdg.Name = "dced67hothdg";
            this.dced67hothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced67hothdg.OcxState")));
            this.dced67hothdg.Size = new System.Drawing.Size(66, 18);
            this.dced67hothdg.TabIndex = 460;
            this.dced67hothdg.Tag = "67hothdg";
            // 
            // lbl67iothdg
            // 
            this.lbl67iothdg.AutoSize = true;
            this.lbl67iothdg.BackColor = System.Drawing.Color.Lavender;
            this.lbl67iothdg.Location = new System.Drawing.Point(42, 1108);
            this.lbl67iothdg.Name = "lbl67iothdg";
            this.lbl67iothdg.Size = new System.Drawing.Size(9, 13);
            this.lbl67iothdg.TabIndex = 461;
            this.lbl67iothdg.Tag = "67iothdg";
            this.lbl67iothdg.Text = "i";
            // 
            // dcim67iothdg
            // 
            this.dcim67iothdg.Location = new System.Drawing.Point(18, 1122);
            this.dcim67iothdg.Name = "dcim67iothdg";
            this.dcim67iothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim67iothdg.OcxState")));
            this.dcim67iothdg.Size = new System.Drawing.Size(66, 18);
            this.dcim67iothdg.TabIndex = 462;
            this.dcim67iothdg.TabStop = false;
            this.dcim67iothdg.Tag = "67iothdg";
            // 
            // dced67iothdg
            // 
            this.dced67iothdg.Location = new System.Drawing.Point(18, 1141);
            this.dced67iothdg.Name = "dced67iothdg";
            this.dced67iothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced67iothdg.OcxState")));
            this.dced67iothdg.Size = new System.Drawing.Size(66, 18);
            this.dced67iothdg.TabIndex = 463;
            this.dced67iothdg.Tag = "67iothdg";
            // 
            // lbl67jothdg
            // 
            this.lbl67jothdg.AutoSize = true;
            this.lbl67jothdg.BackColor = System.Drawing.Color.Lavender;
            this.lbl67jothdg.Location = new System.Drawing.Point(119, 1108);
            this.lbl67jothdg.Name = "lbl67jothdg";
            this.lbl67jothdg.Size = new System.Drawing.Size(9, 13);
            this.lbl67jothdg.TabIndex = 464;
            this.lbl67jothdg.Tag = "67jothdg";
            this.lbl67jothdg.Text = "j";
            // 
            // dcim67jothdg
            // 
            this.dcim67jothdg.Location = new System.Drawing.Point(90, 1122);
            this.dcim67jothdg.Name = "dcim67jothdg";
            this.dcim67jothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim67jothdg.OcxState")));
            this.dcim67jothdg.Size = new System.Drawing.Size(66, 18);
            this.dcim67jothdg.TabIndex = 465;
            this.dcim67jothdg.TabStop = false;
            this.dcim67jothdg.Tag = "67jothdg";
            // 
            // dced67jothdg
            // 
            this.dced67jothdg.Location = new System.Drawing.Point(90, 1141);
            this.dced67jothdg.Name = "dced67jothdg";
            this.dced67jothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced67jothdg.OcxState")));
            this.dced67jothdg.Size = new System.Drawing.Size(66, 18);
            this.dced67jothdg.TabIndex = 466;
            this.dced67jothdg.Tag = "67jothdg";
            // 
            // lbl67kothdg
            // 
            this.lbl67kothdg.AutoSize = true;
            this.lbl67kothdg.BackColor = System.Drawing.Color.Lavender;
            this.lbl67kothdg.Location = new System.Drawing.Point(192, 1108);
            this.lbl67kothdg.Name = "lbl67kothdg";
            this.lbl67kothdg.Size = new System.Drawing.Size(13, 13);
            this.lbl67kothdg.TabIndex = 467;
            this.lbl67kothdg.Tag = "67kothdg";
            this.lbl67kothdg.Text = "k";
            // 
            // dcim67kothdg
            // 
            this.dcim67kothdg.Location = new System.Drawing.Point(162, 1122);
            this.dcim67kothdg.Name = "dcim67kothdg";
            this.dcim67kothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim67kothdg.OcxState")));
            this.dcim67kothdg.Size = new System.Drawing.Size(66, 18);
            this.dcim67kothdg.TabIndex = 468;
            this.dcim67kothdg.TabStop = false;
            this.dcim67kothdg.Tag = "67kothdg";
            // 
            // dced67kothdg
            // 
            this.dced67kothdg.Location = new System.Drawing.Point(162, 1141);
            this.dced67kothdg.Name = "dced67kothdg";
            this.dced67kothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced67kothdg.OcxState")));
            this.dced67kothdg.Size = new System.Drawing.Size(66, 18);
            this.dced67kothdg.TabIndex = 469;
            this.dced67kothdg.Tag = "67kothdg";
            // 
            // lbl67lothdg
            // 
            this.lbl67lothdg.AutoSize = true;
            this.lbl67lothdg.BackColor = System.Drawing.Color.Lavender;
            this.lbl67lothdg.Location = new System.Drawing.Point(264, 1108);
            this.lbl67lothdg.Name = "lbl67lothdg";
            this.lbl67lothdg.Size = new System.Drawing.Size(9, 13);
            this.lbl67lothdg.TabIndex = 470;
            this.lbl67lothdg.Tag = "67lothdg";
            this.lbl67lothdg.Text = "l";
            // 
            // dcim67lothdg
            // 
            this.dcim67lothdg.Location = new System.Drawing.Point(234, 1122);
            this.dcim67lothdg.Name = "dcim67lothdg";
            this.dcim67lothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim67lothdg.OcxState")));
            this.dcim67lothdg.Size = new System.Drawing.Size(66, 18);
            this.dcim67lothdg.TabIndex = 471;
            this.dcim67lothdg.TabStop = false;
            this.dcim67lothdg.Tag = "67lothdg";
            // 
            // dced67lothdg
            // 
            this.dced67lothdg.Location = new System.Drawing.Point(234, 1141);
            this.dced67lothdg.Name = "dced67lothdg";
            this.dced67lothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced67lothdg.OcxState")));
            this.dced67lothdg.Size = new System.Drawing.Size(66, 18);
            this.dced67lothdg.TabIndex = 472;
            this.dced67lothdg.Tag = "67lothdg";
            // 
            // lbl67mothdg
            // 
            this.lbl67mothdg.AutoSize = true;
            this.lbl67mothdg.BackColor = System.Drawing.Color.Lavender;
            this.lbl67mothdg.Location = new System.Drawing.Point(335, 1108);
            this.lbl67mothdg.Name = "lbl67mothdg";
            this.lbl67mothdg.Size = new System.Drawing.Size(15, 13);
            this.lbl67mothdg.TabIndex = 473;
            this.lbl67mothdg.Tag = "67mothdg";
            this.lbl67mothdg.Text = "m";
            // 
            // dcim67mothdg
            // 
            this.dcim67mothdg.Location = new System.Drawing.Point(312, 1122);
            this.dcim67mothdg.Name = "dcim67mothdg";
            this.dcim67mothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim67mothdg.OcxState")));
            this.dcim67mothdg.Size = new System.Drawing.Size(66, 18);
            this.dcim67mothdg.TabIndex = 474;
            this.dcim67mothdg.TabStop = false;
            this.dcim67mothdg.Tag = "67mothdg";
            // 
            // dced67mothdg
            // 
            this.dced67mothdg.Location = new System.Drawing.Point(312, 1141);
            this.dced67mothdg.Name = "dced67mothdg";
            this.dced67mothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced67mothdg.OcxState")));
            this.dced67mothdg.Size = new System.Drawing.Size(66, 18);
            this.dced67mothdg.TabIndex = 475;
            this.dced67mothdg.Tag = "67mothdg";
            // 
            // lbl67nothdg
            // 
            this.lbl67nothdg.AutoSize = true;
            this.lbl67nothdg.BackColor = System.Drawing.Color.Lavender;
            this.lbl67nothdg.Location = new System.Drawing.Point(420, 1108);
            this.lbl67nothdg.Name = "lbl67nothdg";
            this.lbl67nothdg.Size = new System.Drawing.Size(13, 13);
            this.lbl67nothdg.TabIndex = 476;
            this.lbl67nothdg.Tag = "67nothdg";
            this.lbl67nothdg.Text = "n";
            // 
            // dcim67nothdg
            // 
            this.dcim67nothdg.Location = new System.Drawing.Point(390, 1122);
            this.dcim67nothdg.Name = "dcim67nothdg";
            this.dcim67nothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim67nothdg.OcxState")));
            this.dcim67nothdg.Size = new System.Drawing.Size(66, 18);
            this.dcim67nothdg.TabIndex = 477;
            this.dcim67nothdg.TabStop = false;
            this.dcim67nothdg.Tag = "67nothdg";
            // 
            // dced67nothdg
            // 
            this.dced67nothdg.Location = new System.Drawing.Point(390, 1141);
            this.dced67nothdg.Name = "dced67nothdg";
            this.dced67nothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced67nothdg.OcxState")));
            this.dced67nothdg.Size = new System.Drawing.Size(66, 18);
            this.dced67nothdg.TabIndex = 478;
            this.dced67nothdg.Tag = "67nothdg";
            // 
            // lbl67oothdg
            // 
            this.lbl67oothdg.AutoSize = true;
            this.lbl67oothdg.BackColor = System.Drawing.Color.Lavender;
            this.lbl67oothdg.Location = new System.Drawing.Point(498, 1108);
            this.lbl67oothdg.Name = "lbl67oothdg";
            this.lbl67oothdg.Size = new System.Drawing.Size(13, 13);
            this.lbl67oothdg.TabIndex = 479;
            this.lbl67oothdg.Tag = "67oothdg";
            this.lbl67oothdg.Text = "o";
            // 
            // dcim67oothdg
            // 
            this.dcim67oothdg.Location = new System.Drawing.Point(468, 1122);
            this.dcim67oothdg.Name = "dcim67oothdg";
            this.dcim67oothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim67oothdg.OcxState")));
            this.dcim67oothdg.Size = new System.Drawing.Size(66, 18);
            this.dcim67oothdg.TabIndex = 480;
            this.dcim67oothdg.TabStop = false;
            this.dcim67oothdg.Tag = "67oothdg";
            // 
            // dced67oothdg
            // 
            this.dced67oothdg.Location = new System.Drawing.Point(468, 1141);
            this.dced67oothdg.Name = "dced67oothdg";
            this.dced67oothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced67oothdg.OcxState")));
            this.dced67oothdg.Size = new System.Drawing.Size(66, 18);
            this.dced67oothdg.TabIndex = 481;
            this.dced67oothdg.Tag = "67oothdg";
            // 
            // lbl67pothdg
            // 
            this.lbl67pothdg.AutoSize = true;
            this.lbl67pothdg.BackColor = System.Drawing.Color.Lavender;
            this.lbl67pothdg.Location = new System.Drawing.Point(577, 1108);
            this.lbl67pothdg.Name = "lbl67pothdg";
            this.lbl67pothdg.Size = new System.Drawing.Size(13, 13);
            this.lbl67pothdg.TabIndex = 482;
            this.lbl67pothdg.Tag = "67pothdg";
            this.lbl67pothdg.Text = "p";
            // 
            // dcim67pothdg
            // 
            this.dcim67pothdg.Location = new System.Drawing.Point(549, 1122);
            this.dcim67pothdg.Name = "dcim67pothdg";
            this.dcim67pothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim67pothdg.OcxState")));
            this.dcim67pothdg.Size = new System.Drawing.Size(66, 18);
            this.dcim67pothdg.TabIndex = 483;
            this.dcim67pothdg.TabStop = false;
            this.dcim67pothdg.Tag = "67pothdg";
            // 
            // dced67pothdg
            // 
            this.dced67pothdg.Location = new System.Drawing.Point(549, 1141);
            this.dced67pothdg.Name = "dced67pothdg";
            this.dced67pothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced67pothdg.OcxState")));
            this.dced67pothdg.Size = new System.Drawing.Size(66, 18);
            this.dced67pothdg.TabIndex = 484;
            this.dced67pothdg.Tag = "67pothdg";
            // 
            // lbl67qothdg
            // 
            this.lbl67qothdg.AutoSize = true;
            this.lbl67qothdg.BackColor = System.Drawing.Color.Lavender;
            this.lbl67qothdg.Location = new System.Drawing.Point(657, 1108);
            this.lbl67qothdg.Name = "lbl67qothdg";
            this.lbl67qothdg.Size = new System.Drawing.Size(13, 13);
            this.lbl67qothdg.TabIndex = 485;
            this.lbl67qothdg.Tag = "67qothdg";
            this.lbl67qothdg.Text = "q";
            // 
            // dcim67qothdg
            // 
            this.dcim67qothdg.Location = new System.Drawing.Point(627, 1122);
            this.dcim67qothdg.Name = "dcim67qothdg";
            this.dcim67qothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim67qothdg.OcxState")));
            this.dcim67qothdg.Size = new System.Drawing.Size(66, 18);
            this.dcim67qothdg.TabIndex = 486;
            this.dcim67qothdg.TabStop = false;
            this.dcim67qothdg.Tag = "67qothdg";
            // 
            // dced67qothdg
            // 
            this.dced67qothdg.Location = new System.Drawing.Point(627, 1141);
            this.dced67qothdg.Name = "dced67qothdg";
            this.dced67qothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced67qothdg.OcxState")));
            this.dced67qothdg.Size = new System.Drawing.Size(66, 18);
            this.dced67qothdg.TabIndex = 487;
            this.dced67qothdg.Tag = "67qothdg";
            // 
            // dcim69amdgcd
            // 
            this.dcim69amdgcd.Location = new System.Drawing.Point(58, 1188);
            this.dcim69amdgcd.Name = "dcim69amdgcd";
            this.dcim69amdgcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim69amdgcd.OcxState")));
            this.dcim69amdgcd.Size = new System.Drawing.Size(66, 18);
            this.dcim69amdgcd.TabIndex = 495;
            this.dcim69amdgcd.TabStop = false;
            this.dcim69amdgcd.Tag = "69amdgcd";
            // 
            // dced69amdgcd
            // 
            this.dced69amdgcd.Location = new System.Drawing.Point(58, 1207);
            this.dced69amdgcd.Name = "dced69amdgcd";
            this.dced69amdgcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced69amdgcd.OcxState")));
            this.dced69amdgcd.Size = new System.Drawing.Size(66, 18);
            this.dced69amdgcd.TabIndex = 496;
            this.dced69amdgcd.Tag = "69amdgcd";
            // 
            // dcim70arfvcd
            // 
            this.dcim70arfvcd.Location = new System.Drawing.Point(130, 1188);
            this.dcim70arfvcd.Name = "dcim70arfvcd";
            this.dcim70arfvcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim70arfvcd.OcxState")));
            this.dcim70arfvcd.Size = new System.Drawing.Size(66, 18);
            this.dcim70arfvcd.TabIndex = 498;
            this.dcim70arfvcd.TabStop = false;
            this.dcim70arfvcd.Tag = "70arfvcd";
            // 
            // dced70arfvcd
            // 
            this.dced70arfvcd.Location = new System.Drawing.Point(130, 1207);
            this.dced70arfvcd.Name = "dced70arfvcd";
            this.dced70arfvcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced70arfvcd.OcxState")));
            this.dced70arfvcd.Size = new System.Drawing.Size(66, 18);
            this.dced70arfvcd.TabIndex = 499;
            this.dced70arfvcd.Tag = "70arfvcd";
            // 
            // dcim70brfvcd
            // 
            this.dcim70brfvcd.Location = new System.Drawing.Point(202, 1188);
            this.dcim70brfvcd.Name = "dcim70brfvcd";
            this.dcim70brfvcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim70brfvcd.OcxState")));
            this.dcim70brfvcd.Size = new System.Drawing.Size(66, 18);
            this.dcim70brfvcd.TabIndex = 501;
            this.dcim70brfvcd.TabStop = false;
            this.dcim70brfvcd.Tag = "70brfvcd";
            // 
            // dced70brfvcd
            // 
            this.dced70brfvcd.Location = new System.Drawing.Point(202, 1207);
            this.dced70brfvcd.Name = "dced70brfvcd";
            this.dced70brfvcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced70brfvcd.OcxState")));
            this.dced70brfvcd.Size = new System.Drawing.Size(66, 18);
            this.dced70brfvcd.TabIndex = 502;
            this.dced70brfvcd.Tag = "70brfvcd";
            // 
            // dcim70crfvcd
            // 
            this.dcim70crfvcd.Location = new System.Drawing.Point(274, 1188);
            this.dcim70crfvcd.Name = "dcim70crfvcd";
            this.dcim70crfvcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim70crfvcd.OcxState")));
            this.dcim70crfvcd.Size = new System.Drawing.Size(66, 18);
            this.dcim70crfvcd.TabIndex = 504;
            this.dcim70crfvcd.TabStop = false;
            this.dcim70crfvcd.Tag = "70crfvcd";
            // 
            // dced70crfvcd
            // 
            this.dced70crfvcd.Location = new System.Drawing.Point(274, 1207);
            this.dced70crfvcd.Name = "dced70crfvcd";
            this.dced70crfvcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced70crfvcd.OcxState")));
            this.dced70crfvcd.Size = new System.Drawing.Size(66, 18);
            this.dced70crfvcd.TabIndex = 505;
            this.dced70crfvcd.Tag = "70crfvcd";
            // 
            // dcim71ppscd
            // 
            this.dcim71ppscd.Location = new System.Drawing.Point(346, 1188);
            this.dcim71ppscd.Name = "dcim71ppscd";
            this.dcim71ppscd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim71ppscd.OcxState")));
            this.dcim71ppscd.Size = new System.Drawing.Size(66, 18);
            this.dcim71ppscd.TabIndex = 507;
            this.dcim71ppscd.TabStop = false;
            this.dcim71ppscd.Tag = "71ppscd";
            // 
            // dced71ppscd
            // 
            this.dced71ppscd.Location = new System.Drawing.Point(346, 1207);
            this.dced71ppscd.Name = "dced71ppscd";
            this.dced71ppscd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced71ppscd.OcxState")));
            this.dced71ppscd.Size = new System.Drawing.Size(66, 18);
            this.dced71ppscd.TabIndex = 508;
            this.dced71ppscd.Tag = "71ppscd";
            // 
            // lbl72aecicd
            // 
            this.lbl72aecicd.AutoSize = true;
            this.lbl72aecicd.BackColor = System.Drawing.Color.Lavender;
            this.lbl72aecicd.Location = new System.Drawing.Point(18, 1039);
            this.lbl72aecicd.Name = "lbl72aecicd";
            this.lbl72aecicd.Size = new System.Drawing.Size(101, 13);
            this.lbl72aecicd.TabIndex = 509;
            this.lbl72aecicd.Tag = "72aecicd";
            this.lbl72aecicd.Text = "67 Diagnosis Codes";
            // 
            // dcim72aecicd
            // 
            this.dcim72aecicd.Location = new System.Drawing.Point(418, 1188);
            this.dcim72aecicd.Name = "dcim72aecicd";
            this.dcim72aecicd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim72aecicd.OcxState")));
            this.dcim72aecicd.Size = new System.Drawing.Size(66, 18);
            this.dcim72aecicd.TabIndex = 510;
            this.dcim72aecicd.TabStop = false;
            this.dcim72aecicd.Tag = "72aecicd";
            // 
            // dced72aecicd
            // 
            this.dced72aecicd.Location = new System.Drawing.Point(418, 1207);
            this.dced72aecicd.Name = "dced72aecicd";
            this.dced72aecicd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced72aecicd.OcxState")));
            this.dced72aecicd.Size = new System.Drawing.Size(66, 18);
            this.dced72aecicd.TabIndex = 511;
            this.dced72aecicd.Tag = "72aecicd";
            // 
            // lbl74prprcd
            // 
            this.lbl74prprcd.AutoSize = true;
            this.lbl74prprcd.BackColor = System.Drawing.Color.Lavender;
            this.lbl74prprcd.Location = new System.Drawing.Point(16, 1261);
            this.lbl74prprcd.Name = "lbl74prprcd";
            this.lbl74prprcd.Size = new System.Drawing.Size(131, 13);
            this.lbl74prprcd.TabIndex = 521;
            this.lbl74prprcd.Tag = "74prprcd";
            this.lbl74prprcd.Text = "Prin. Proc. Code and Date";
            // 
            // dcim74prprcd
            // 
            this.dcim74prprcd.Location = new System.Drawing.Point(18, 1274);
            this.dcim74prprcd.Name = "dcim74prprcd";
            this.dcim74prprcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim74prprcd.OcxState")));
            this.dcim74prprcd.Size = new System.Drawing.Size(66, 18);
            this.dcim74prprcd.TabIndex = 522;
            this.dcim74prprcd.TabStop = false;
            this.dcim74prprcd.Tag = "74prprcd";
            // 
            // dced74prprcd
            // 
            this.dced74prprcd.Location = new System.Drawing.Point(18, 1293);
            this.dced74prprcd.Name = "dced74prprcd";
            this.dced74prprcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced74prprcd.OcxState")));
            this.dced74prprcd.Size = new System.Drawing.Size(66, 18);
            this.dced74prprcd.TabIndex = 523;
            this.dced74prprcd.Tag = "74prprcd";
            // 
            // dcim74prprdt
            // 
            this.dcim74prprdt.Location = new System.Drawing.Point(85, 1274);
            this.dcim74prprdt.Name = "dcim74prprdt";
            this.dcim74prprdt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim74prprdt.OcxState")));
            this.dcim74prprdt.Size = new System.Drawing.Size(66, 18);
            this.dcim74prprdt.TabIndex = 525;
            this.dcim74prprdt.TabStop = false;
            this.dcim74prprdt.Tag = "74prprdt";
            // 
            // dced74prprdt
            // 
            this.dced74prprdt.Location = new System.Drawing.Point(85, 1293);
            this.dced74prprdt.Name = "dced74prprdt";
            this.dced74prprdt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced74prprdt.OcxState")));
            this.dced74prprdt.Size = new System.Drawing.Size(66, 18);
            this.dced74prprdt.TabIndex = 526;
            this.dced74prprdt.Tag = "74prprdt";
            // 
            // lbl74aoprcd
            // 
            this.lbl74aoprcd.AutoSize = true;
            this.lbl74aoprcd.BackColor = System.Drawing.Color.Lavender;
            this.lbl74aoprcd.Location = new System.Drawing.Point(168, 1261);
            this.lbl74aoprcd.Name = "lbl74aoprcd";
            this.lbl74aoprcd.Size = new System.Drawing.Size(13, 13);
            this.lbl74aoprcd.TabIndex = 527;
            this.lbl74aoprcd.Tag = "74aoprcd";
            this.lbl74aoprcd.Text = "a";
            // 
            // dcim74aoprcd
            // 
            this.dcim74aoprcd.Location = new System.Drawing.Point(162, 1274);
            this.dcim74aoprcd.Name = "dcim74aoprcd";
            this.dcim74aoprcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim74aoprcd.OcxState")));
            this.dcim74aoprcd.Size = new System.Drawing.Size(66, 18);
            this.dcim74aoprcd.TabIndex = 528;
            this.dcim74aoprcd.TabStop = false;
            this.dcim74aoprcd.Tag = "74aoprcd";
            // 
            // dced74aoprcd
            // 
            this.dced74aoprcd.Location = new System.Drawing.Point(162, 1293);
            this.dced74aoprcd.Name = "dced74aoprcd";
            this.dced74aoprcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced74aoprcd.OcxState")));
            this.dced74aoprcd.Size = new System.Drawing.Size(66, 18);
            this.dced74aoprcd.TabIndex = 529;
            this.dced74aoprcd.Tag = "74aoprcd";
            // 
            // dcim74aoprdt
            // 
            this.dcim74aoprdt.Location = new System.Drawing.Point(229, 1274);
            this.dcim74aoprdt.Name = "dcim74aoprdt";
            this.dcim74aoprdt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim74aoprdt.OcxState")));
            this.dcim74aoprdt.Size = new System.Drawing.Size(66, 18);
            this.dcim74aoprdt.TabIndex = 531;
            this.dcim74aoprdt.TabStop = false;
            this.dcim74aoprdt.Tag = "74aoprdt";
            // 
            // dced74aoprdt
            // 
            this.dced74aoprdt.Location = new System.Drawing.Point(229, 1293);
            this.dced74aoprdt.Name = "dced74aoprdt";
            this.dced74aoprdt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced74aoprdt.OcxState")));
            this.dced74aoprdt.Size = new System.Drawing.Size(66, 18);
            this.dced74aoprdt.TabIndex = 532;
            this.dced74aoprdt.Tag = "74aoprdt";
            // 
            // dcim74boprcd
            // 
            this.dcim74boprcd.Location = new System.Drawing.Point(312, 1274);
            this.dcim74boprcd.Name = "dcim74boprcd";
            this.dcim74boprcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim74boprcd.OcxState")));
            this.dcim74boprcd.Size = new System.Drawing.Size(66, 18);
            this.dcim74boprcd.TabIndex = 534;
            this.dcim74boprcd.TabStop = false;
            this.dcim74boprcd.Tag = "74boprcd";
            // 
            // dced74boprcd
            // 
            this.dced74boprcd.Location = new System.Drawing.Point(312, 1293);
            this.dced74boprcd.Name = "dced74boprcd";
            this.dced74boprcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced74boprcd.OcxState")));
            this.dced74boprcd.Size = new System.Drawing.Size(66, 18);
            this.dced74boprcd.TabIndex = 535;
            this.dced74boprcd.Tag = "74boprcd";
            // 
            // lbl74boprdt
            // 
            this.lbl74boprdt.AutoSize = true;
            this.lbl74boprdt.BackColor = System.Drawing.Color.Lavender;
            this.lbl74boprdt.Location = new System.Drawing.Point(318, 1261);
            this.lbl74boprdt.Name = "lbl74boprdt";
            this.lbl74boprdt.Size = new System.Drawing.Size(13, 13);
            this.lbl74boprdt.TabIndex = 536;
            this.lbl74boprdt.Tag = "74boprdt";
            this.lbl74boprdt.Text = "b";
            // 
            // dcim74boprdt
            // 
            this.dcim74boprdt.Location = new System.Drawing.Point(379, 1274);
            this.dcim74boprdt.Name = "dcim74boprdt";
            this.dcim74boprdt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim74boprdt.OcxState")));
            this.dcim74boprdt.Size = new System.Drawing.Size(66, 18);
            this.dcim74boprdt.TabIndex = 537;
            this.dcim74boprdt.TabStop = false;
            this.dcim74boprdt.Tag = "74boprdt";
            // 
            // dced74boprdt
            // 
            this.dced74boprdt.Location = new System.Drawing.Point(379, 1293);
            this.dced74boprdt.Name = "dced74boprdt";
            this.dced74boprdt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced74boprdt.OcxState")));
            this.dced74boprdt.Size = new System.Drawing.Size(66, 18);
            this.dced74boprdt.TabIndex = 538;
            this.dced74boprdt.Tag = "74boprdt";
            // 
            // lbl74coprcd
            // 
            this.lbl74coprcd.AutoSize = true;
            this.lbl74coprcd.BackColor = System.Drawing.Color.Lavender;
            this.lbl74coprcd.Location = new System.Drawing.Point(25, 1318);
            this.lbl74coprcd.Name = "lbl74coprcd";
            this.lbl74coprcd.Size = new System.Drawing.Size(13, 13);
            this.lbl74coprcd.TabIndex = 539;
            this.lbl74coprcd.Tag = "74coprcd";
            this.lbl74coprcd.Text = "c";
            // 
            // dcim74coprcd
            // 
            this.dcim74coprcd.Location = new System.Drawing.Point(18, 1331);
            this.dcim74coprcd.Name = "dcim74coprcd";
            this.dcim74coprcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim74coprcd.OcxState")));
            this.dcim74coprcd.Size = new System.Drawing.Size(66, 18);
            this.dcim74coprcd.TabIndex = 540;
            this.dcim74coprcd.TabStop = false;
            this.dcim74coprcd.Tag = "74coprcd";
            // 
            // dced74coprcd
            // 
            this.dced74coprcd.Location = new System.Drawing.Point(18, 1350);
            this.dced74coprcd.Name = "dced74coprcd";
            this.dced74coprcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced74coprcd.OcxState")));
            this.dced74coprcd.Size = new System.Drawing.Size(66, 18);
            this.dced74coprcd.TabIndex = 541;
            this.dced74coprcd.Tag = "74coprcd";
            // 
            // dcim74coprdt
            // 
            this.dcim74coprdt.Location = new System.Drawing.Point(85, 1331);
            this.dcim74coprdt.Name = "dcim74coprdt";
            this.dcim74coprdt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim74coprdt.OcxState")));
            this.dcim74coprdt.Size = new System.Drawing.Size(66, 18);
            this.dcim74coprdt.TabIndex = 543;
            this.dcim74coprdt.TabStop = false;
            this.dcim74coprdt.Tag = "74coprdt";
            // 
            // dced74coprdt
            // 
            this.dced74coprdt.Location = new System.Drawing.Point(85, 1350);
            this.dced74coprdt.Name = "dced74coprdt";
            this.dced74coprdt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced74coprdt.OcxState")));
            this.dced74coprdt.Size = new System.Drawing.Size(66, 18);
            this.dced74coprdt.TabIndex = 544;
            this.dced74coprdt.Tag = "74coprdt";
            // 
            // lbl74doprcd
            // 
            this.lbl74doprcd.AutoSize = true;
            this.lbl74doprcd.BackColor = System.Drawing.Color.Lavender;
            this.lbl74doprcd.Location = new System.Drawing.Point(168, 1318);
            this.lbl74doprcd.Name = "lbl74doprcd";
            this.lbl74doprcd.Size = new System.Drawing.Size(13, 13);
            this.lbl74doprcd.TabIndex = 545;
            this.lbl74doprcd.Tag = "74doprcd";
            this.lbl74doprcd.Text = "d";
            // 
            // dcim74doprcd
            // 
            this.dcim74doprcd.Location = new System.Drawing.Point(162, 1331);
            this.dcim74doprcd.Name = "dcim74doprcd";
            this.dcim74doprcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim74doprcd.OcxState")));
            this.dcim74doprcd.Size = new System.Drawing.Size(66, 18);
            this.dcim74doprcd.TabIndex = 546;
            this.dcim74doprcd.TabStop = false;
            this.dcim74doprcd.Tag = "74doprcd";
            // 
            // dced74doprcd
            // 
            this.dced74doprcd.Location = new System.Drawing.Point(162, 1350);
            this.dced74doprcd.Name = "dced74doprcd";
            this.dced74doprcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced74doprcd.OcxState")));
            this.dced74doprcd.Size = new System.Drawing.Size(66, 18);
            this.dced74doprcd.TabIndex = 547;
            this.dced74doprcd.Tag = "74doprcd";
            // 
            // dcim74doprdt
            // 
            this.dcim74doprdt.Location = new System.Drawing.Point(229, 1331);
            this.dcim74doprdt.Name = "dcim74doprdt";
            this.dcim74doprdt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim74doprdt.OcxState")));
            this.dcim74doprdt.Size = new System.Drawing.Size(66, 18);
            this.dcim74doprdt.TabIndex = 549;
            this.dcim74doprdt.TabStop = false;
            this.dcim74doprdt.Tag = "74doprdt";
            // 
            // dced74doprdt
            // 
            this.dced74doprdt.Location = new System.Drawing.Point(229, 1350);
            this.dced74doprdt.Name = "dced74doprdt";
            this.dced74doprdt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced74doprdt.OcxState")));
            this.dced74doprdt.Size = new System.Drawing.Size(66, 18);
            this.dced74doprdt.TabIndex = 550;
            this.dced74doprdt.Tag = "74doprdt";
            // 
            // lbl74eoprcd
            // 
            this.lbl74eoprcd.AutoSize = true;
            this.lbl74eoprcd.BackColor = System.Drawing.Color.Lavender;
            this.lbl74eoprcd.Location = new System.Drawing.Point(318, 1318);
            this.lbl74eoprcd.Name = "lbl74eoprcd";
            this.lbl74eoprcd.Size = new System.Drawing.Size(13, 13);
            this.lbl74eoprcd.TabIndex = 551;
            this.lbl74eoprcd.Tag = "74eoprcd";
            this.lbl74eoprcd.Text = "e";
            // 
            // dcim74eoprcd
            // 
            this.dcim74eoprcd.Location = new System.Drawing.Point(312, 1331);
            this.dcim74eoprcd.Name = "dcim74eoprcd";
            this.dcim74eoprcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim74eoprcd.OcxState")));
            this.dcim74eoprcd.Size = new System.Drawing.Size(66, 18);
            this.dcim74eoprcd.TabIndex = 552;
            this.dcim74eoprcd.TabStop = false;
            this.dcim74eoprcd.Tag = "74eoprcd";
            // 
            // dced74eoprcd
            // 
            this.dced74eoprcd.Location = new System.Drawing.Point(312, 1350);
            this.dced74eoprcd.Name = "dced74eoprcd";
            this.dced74eoprcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced74eoprcd.OcxState")));
            this.dced74eoprcd.Size = new System.Drawing.Size(66, 18);
            this.dced74eoprcd.TabIndex = 553;
            this.dced74eoprcd.Tag = "74eoprcd";
            // 
            // lbl74eoprdt
            // 
            this.lbl74eoprdt.AutoSize = true;
            this.lbl74eoprdt.BackColor = System.Drawing.Color.Lavender;
            this.lbl74eoprdt.Location = new System.Drawing.Point(16, 1245);
            this.lbl74eoprdt.Name = "lbl74eoprdt";
            this.lbl74eoprdt.Size = new System.Drawing.Size(156, 13);
            this.lbl74eoprdt.TabIndex = 554;
            this.lbl74eoprdt.Tag = "74eoprdt";
            this.lbl74eoprdt.Text = "74 Procedure Codes and Dates";
            // 
            // dcim74eoprdt
            // 
            this.dcim74eoprdt.Location = new System.Drawing.Point(379, 1331);
            this.dcim74eoprdt.Name = "dcim74eoprdt";
            this.dcim74eoprdt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim74eoprdt.OcxState")));
            this.dcim74eoprdt.Size = new System.Drawing.Size(66, 18);
            this.dcim74eoprdt.TabIndex = 555;
            this.dcim74eoprdt.TabStop = false;
            this.dcim74eoprdt.Tag = "74eoprdt";
            // 
            // dced74eoprdt
            // 
            this.dced74eoprdt.Location = new System.Drawing.Point(379, 1350);
            this.dced74eoprdt.Name = "dced74eoprdt";
            this.dced74eoprdt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced74eoprdt.OcxState")));
            this.dced74eoprdt.Size = new System.Drawing.Size(66, 18);
            this.dced74eoprdt.TabIndex = 556;
            this.dced74eoprdt.Tag = "74eoprdt";
            // 
            // lbl76apnpi
            // 
            this.lbl76apnpi.AutoSize = true;
            this.lbl76apnpi.BackColor = System.Drawing.Color.Lavender;
            this.lbl76apnpi.Location = new System.Drawing.Point(480, 1258);
            this.lbl76apnpi.Name = "lbl76apnpi";
            this.lbl76apnpi.Size = new System.Drawing.Size(25, 13);
            this.lbl76apnpi.TabIndex = 569;
            this.lbl76apnpi.Tag = "76apnpi";
            this.lbl76apnpi.Text = "NPI";
            // 
            // dcim76apnpi
            // 
            this.dcim76apnpi.Location = new System.Drawing.Point(480, 1271);
            this.dcim76apnpi.Name = "dcim76apnpi";
            this.dcim76apnpi.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim76apnpi.OcxState")));
            this.dcim76apnpi.Size = new System.Drawing.Size(101, 18);
            this.dcim76apnpi.TabIndex = 570;
            this.dcim76apnpi.TabStop = false;
            this.dcim76apnpi.Tag = "76apnpi";
            // 
            // dced76apnpi
            // 
            this.dced76apnpi.Location = new System.Drawing.Point(480, 1290);
            this.dced76apnpi.Name = "dced76apnpi";
            this.dced76apnpi.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced76apnpi.OcxState")));
            this.dced76apnpi.Size = new System.Drawing.Size(101, 18);
            this.dced76apnpi.TabIndex = 571;
            this.dced76apnpi.Tag = "76apnpi";
            // 
            // lbl76apqual
            // 
            this.lbl76apqual.AutoSize = true;
            this.lbl76apqual.BackColor = System.Drawing.Color.Lavender;
            this.lbl76apqual.Location = new System.Drawing.Point(585, 1258);
            this.lbl76apqual.Name = "lbl76apqual";
            this.lbl76apqual.Size = new System.Drawing.Size(32, 13);
            this.lbl76apqual.TabIndex = 572;
            this.lbl76apqual.Tag = "76apqual";
            this.lbl76apqual.Text = "Qual.";
            // 
            // dcim76apqual
            // 
            this.dcim76apqual.Location = new System.Drawing.Point(585, 1271);
            this.dcim76apqual.Name = "dcim76apqual";
            this.dcim76apqual.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim76apqual.OcxState")));
            this.dcim76apqual.Size = new System.Drawing.Size(40, 18);
            this.dcim76apqual.TabIndex = 573;
            this.dcim76apqual.TabStop = false;
            this.dcim76apqual.Tag = "76apqual";
            // 
            // dced76apqual
            // 
            this.dced76apqual.Location = new System.Drawing.Point(585, 1290);
            this.dced76apqual.Name = "dced76apqual";
            this.dced76apqual.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced76apqual.OcxState")));
            this.dced76apqual.Size = new System.Drawing.Size(40, 18);
            this.dced76apqual.TabIndex = 574;
            this.dced76apqual.Tag = "76apqual";
            // 
            // lbl76apid
            // 
            this.lbl76apid.AutoSize = true;
            this.lbl76apid.BackColor = System.Drawing.Color.Lavender;
            this.lbl76apid.Location = new System.Drawing.Point(630, 1258);
            this.lbl76apid.Name = "lbl76apid";
            this.lbl76apid.Size = new System.Drawing.Size(18, 13);
            this.lbl76apid.TabIndex = 575;
            this.lbl76apid.Tag = "76apid";
            this.lbl76apid.Text = "ID";
            // 
            // dcim76apid
            // 
            this.dcim76apid.Location = new System.Drawing.Point(631, 1271);
            this.dcim76apid.Name = "dcim76apid";
            this.dcim76apid.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim76apid.OcxState")));
            this.dcim76apid.Size = new System.Drawing.Size(106, 18);
            this.dcim76apid.TabIndex = 576;
            this.dcim76apid.TabStop = false;
            this.dcim76apid.Tag = "76apid";
            // 
            // dced76apid
            // 
            this.dced76apid.Location = new System.Drawing.Point(631, 1290);
            this.dced76apid.Name = "dced76apid";
            this.dced76apid.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced76apid.OcxState")));
            this.dced76apid.Size = new System.Drawing.Size(106, 18);
            this.dced76apid.TabIndex = 577;
            this.dced76apid.Tag = "76apid";
            // 
            // lbl76aplnm
            // 
            this.lbl76aplnm.AutoSize = true;
            this.lbl76aplnm.BackColor = System.Drawing.Color.Lavender;
            this.lbl76aplnm.Location = new System.Drawing.Point(480, 1318);
            this.lbl76aplnm.Name = "lbl76aplnm";
            this.lbl76aplnm.Size = new System.Drawing.Size(58, 13);
            this.lbl76aplnm.TabIndex = 578;
            this.lbl76aplnm.Tag = "76aplnm";
            this.lbl76aplnm.Text = "Last Name";
            // 
            // dcim76aplnm
            // 
            this.dcim76aplnm.Location = new System.Drawing.Point(480, 1331);
            this.dcim76aplnm.Name = "dcim76aplnm";
            this.dcim76aplnm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim76aplnm.OcxState")));
            this.dcim76aplnm.Size = new System.Drawing.Size(134, 18);
            this.dcim76aplnm.TabIndex = 579;
            this.dcim76aplnm.TabStop = false;
            this.dcim76aplnm.Tag = "76aplnm";
            // 
            // dced76aplnm
            // 
            this.dced76aplnm.Location = new System.Drawing.Point(480, 1350);
            this.dced76aplnm.Name = "dced76aplnm";
            this.dced76aplnm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced76aplnm.OcxState")));
            this.dced76aplnm.Size = new System.Drawing.Size(134, 18);
            this.dced76aplnm.TabIndex = 580;
            this.dced76aplnm.Tag = "76aplnm";
            // 
            // lbl76apfnm
            // 
            this.lbl76apfnm.AutoSize = true;
            this.lbl76apfnm.BackColor = System.Drawing.Color.Lavender;
            this.lbl76apfnm.Location = new System.Drawing.Point(616, 1318);
            this.lbl76apfnm.Name = "lbl76apfnm";
            this.lbl76apfnm.Size = new System.Drawing.Size(57, 13);
            this.lbl76apfnm.TabIndex = 581;
            this.lbl76apfnm.Tag = "76apfnm";
            this.lbl76apfnm.Text = "First Name";
            // 
            // dcim76apfnm
            // 
            this.dcim76apfnm.Location = new System.Drawing.Point(619, 1331);
            this.dcim76apfnm.Name = "dcim76apfnm";
            this.dcim76apfnm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim76apfnm.OcxState")));
            this.dcim76apfnm.Size = new System.Drawing.Size(119, 18);
            this.dcim76apfnm.TabIndex = 582;
            this.dcim76apfnm.TabStop = false;
            this.dcim76apfnm.Tag = "76apfnm";
            // 
            // dced76apfnm
            // 
            this.dced76apfnm.Location = new System.Drawing.Point(619, 1350);
            this.dced76apfnm.Name = "dced76apfnm";
            this.dced76apfnm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced76apfnm.OcxState")));
            this.dced76apfnm.Size = new System.Drawing.Size(119, 18);
            this.dced76apfnm.TabIndex = 583;
            this.dced76apfnm.Tag = "76apfnm";
            // 
            // lbl23TotChgs
            // 
            this.lbl23TotChgs.AutoSize = true;
            this.lbl23TotChgs.Location = new System.Drawing.Point(554, 804);
            this.lbl23TotChgs.Name = "lbl23TotChgs";
            this.lbl23TotChgs.Size = new System.Drawing.Size(73, 13);
            this.lbl23TotChgs.TabIndex = 293;
            this.lbl23TotChgs.Tag = "23TotChgs";
            this.lbl23TotChgs.Text = "Total Charges";
            // 
            // dcim23TotChgs
            // 
            this.dcim23TotChgs.Location = new System.Drawing.Point(560, 820);
            this.dcim23TotChgs.Name = "dcim23TotChgs";
            this.dcim23TotChgs.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim23TotChgs.OcxState")));
            this.dcim23TotChgs.Size = new System.Drawing.Size(90, 18);
            this.dcim23TotChgs.TabIndex = 294;
            this.dcim23TotChgs.TabStop = false;
            this.dcim23TotChgs.Tag = "23TotChgs";
            // 
            // dced23TotChgs
            // 
            this.dced23TotChgs.Location = new System.Drawing.Point(560, 839);
            this.dced23TotChgs.Name = "dced23TotChgs";
            this.dced23TotChgs.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced23TotChgs.OcxState")));
            this.dced23TotChgs.Size = new System.Drawing.Size(90, 18);
            this.dced23TotChgs.TabIndex = 295;
            this.dced23TotChgs.Tag = "23TotChgs";
            // 
            // lbRevCode
            // 
            this.lbRevCode.AutoSize = true;
            this.lbRevCode.Location = new System.Drawing.Point(17, 530);
            this.lbRevCode.Name = "lbRevCode";
            this.lbRevCode.Size = new System.Drawing.Size(52, 13);
            this.lbRevCode.TabIndex = 689;
            this.lbRevCode.Tag = "RevCode";
            this.lbRevCode.Text = "RevCode";
            // 
            // lbDescription
            // 
            this.lbDescription.AutoSize = true;
            this.lbDescription.Location = new System.Drawing.Point(407, 531);
            this.lbDescription.Name = "lbDescription";
            this.lbDescription.Size = new System.Drawing.Size(60, 13);
            this.lbDescription.TabIndex = 690;
            this.lbDescription.Tag = "Description";
            this.lbDescription.Text = "Description";
            // 
            // lbHCPCS
            // 
            this.lbHCPCS.AutoSize = true;
            this.lbHCPCS.Location = new System.Drawing.Point(75, 530);
            this.lbHCPCS.Name = "lbHCPCS";
            this.lbHCPCS.Size = new System.Drawing.Size(43, 13);
            this.lbHCPCS.TabIndex = 691;
            this.lbHCPCS.Tag = "HCPCS";
            this.lbHCPCS.Text = "HCPCS";
            // 
            // lbServiceDate
            // 
            this.lbServiceDate.AutoSize = true;
            this.lbServiceDate.Location = new System.Drawing.Point(147, 530);
            this.lbServiceDate.Name = "lbServiceDate";
            this.lbServiceDate.Size = new System.Drawing.Size(66, 13);
            this.lbServiceDate.TabIndex = 693;
            this.lbServiceDate.Tag = "ServiceDate";
            this.lbServiceDate.Text = "ServiceDate";
            // 
            // lbUnits
            // 
            this.lbUnits.AutoSize = true;
            this.lbUnits.Location = new System.Drawing.Point(226, 531);
            this.lbUnits.Name = "lbUnits";
            this.lbUnits.Size = new System.Drawing.Size(31, 13);
            this.lbUnits.TabIndex = 694;
            this.lbUnits.Tag = "Units";
            this.lbUnits.Text = "Units";
            // 
            // lbCharges
            // 
            this.lbCharges.AutoSize = true;
            this.lbCharges.Location = new System.Drawing.Point(283, 531);
            this.lbCharges.Name = "lbCharges";
            this.lbCharges.Size = new System.Drawing.Size(46, 13);
            this.lbCharges.TabIndex = 695;
            this.lbCharges.Tag = "Charges";
            this.lbCharges.Text = "Charges";
            // 
            // lbNonCovered
            // 
            this.lbNonCovered.AutoSize = true;
            this.lbNonCovered.Location = new System.Drawing.Point(631, 531);
            this.lbNonCovered.Name = "lbNonCovered";
            this.lbNonCovered.Size = new System.Drawing.Size(67, 13);
            this.lbNonCovered.TabIndex = 696;
            this.lbNonCovered.Tag = "NonCovered";
            this.lbNonCovered.Text = "NonCovered";
            // 
            // lbLocalUse
            // 
            this.lbLocalUse.AutoSize = true;
            this.lbLocalUse.Location = new System.Drawing.Point(714, 531);
            this.lbLocalUse.Name = "lbLocalUse";
            this.lbLocalUse.Size = new System.Drawing.Size(52, 13);
            this.lbLocalUse.TabIndex = 697;
            this.lbLocalUse.Tag = "LocalUse";
            this.lbLocalUse.Text = "LocalUse";
            // 
            // panLINEITEM
            // 
            this.panLINEITEM.AutoScroll = true;
            this.panLINEITEM.BackColor = System.Drawing.Color.Beige;
            this.panLINEITEM.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panLINEITEM.Controls.Add(this.dcimRevCode);
            this.panLINEITEM.Controls.Add(this.dcedRevCode);
            this.panLINEITEM.Controls.Add(this.dcimDescription);
            this.panLINEITEM.Controls.Add(this.dcedDescription);
            this.panLINEITEM.Controls.Add(this.dcimHCPCS);
            this.panLINEITEM.Controls.Add(this.dcedHCPCS);
            this.panLINEITEM.Controls.Add(this.dcimServiceDate);
            this.panLINEITEM.Controls.Add(this.dcedServiceDate);
            this.panLINEITEM.Controls.Add(this.dcimUnits);
            this.panLINEITEM.Controls.Add(this.dcedUnits);
            this.panLINEITEM.Controls.Add(this.dcimCharges);
            this.panLINEITEM.Controls.Add(this.dcedCharges);
            this.panLINEITEM.Controls.Add(this.dcimNonCovered);
            this.panLINEITEM.Controls.Add(this.dcedNonCovered);
            this.panLINEITEM.Controls.Add(this.dcimLocalUse);
            this.panLINEITEM.Controls.Add(this.dcedLocalUse);
            this.panLINEITEM.Location = new System.Drawing.Point(18, 544);
            this.panLINEITEM.Name = "panLINEITEM";
            this.panLINEITEM.Size = new System.Drawing.Size(759, 254);
            this.panLINEITEM.TabIndex = 287;
            this.panLINEITEM.Tag = "LINEITEM";
            // 
            // dcimRevCode
            // 
            this.dcimRevCode.Location = new System.Drawing.Point(0, 0);
            this.dcimRevCode.Name = "dcimRevCode";
            this.dcimRevCode.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimRevCode.OcxState")));
            this.dcimRevCode.Size = new System.Drawing.Size(42, 18);
            this.dcimRevCode.TabIndex = 0;
            this.dcimRevCode.TabStop = false;
            this.dcimRevCode.Tag = "RevCode";
            // 
            // dcedRevCode
            // 
            this.dcedRevCode.Location = new System.Drawing.Point(0, 17);
            this.dcedRevCode.Name = "dcedRevCode";
            this.dcedRevCode.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedRevCode.OcxState")));
            this.dcedRevCode.Size = new System.Drawing.Size(42, 18);
            this.dcedRevCode.TabIndex = 1;
            this.dcedRevCode.Tag = "RevCode";
            // 
            // dcimDescription
            // 
            this.dcimDescription.Location = new System.Drawing.Point(325, 0);
            this.dcimDescription.Name = "dcimDescription";
            this.dcimDescription.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimDescription.OcxState")));
            this.dcimDescription.Size = new System.Drawing.Size(280, 18);
            this.dcimDescription.TabIndex = 10;
            this.dcimDescription.TabStop = false;
            this.dcimDescription.Tag = "Description";
            // 
            // dcedDescription
            // 
            this.dcedDescription.Location = new System.Drawing.Point(325, 17);
            this.dcedDescription.Name = "dcedDescription";
            this.dcedDescription.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedDescription.OcxState")));
            this.dcedDescription.Size = new System.Drawing.Size(280, 18);
            this.dcedDescription.TabIndex = 11;
            this.dcedDescription.Tag = "Description";
            // 
            // dcimHCPCS
            // 
            this.dcimHCPCS.Location = new System.Drawing.Point(42, 0);
            this.dcimHCPCS.Name = "dcimHCPCS";
            this.dcimHCPCS.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimHCPCS.OcxState")));
            this.dcimHCPCS.Size = new System.Drawing.Size(80, 18);
            this.dcimHCPCS.TabIndex = 2;
            this.dcimHCPCS.TabStop = false;
            this.dcimHCPCS.Tag = "HCPCS";
            // 
            // dcedHCPCS
            // 
            this.dcedHCPCS.Location = new System.Drawing.Point(42, 17);
            this.dcedHCPCS.Name = "dcedHCPCS";
            this.dcedHCPCS.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedHCPCS.OcxState")));
            this.dcedHCPCS.Size = new System.Drawing.Size(80, 18);
            this.dcedHCPCS.TabIndex = 3;
            this.dcedHCPCS.Tag = "HCPCS";
            // 
            // dcimServiceDate
            // 
            this.dcimServiceDate.Location = new System.Drawing.Point(122, 0);
            this.dcimServiceDate.Name = "dcimServiceDate";
            this.dcimServiceDate.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimServiceDate.OcxState")));
            this.dcimServiceDate.Size = new System.Drawing.Size(80, 18);
            this.dcimServiceDate.TabIndex = 4;
            this.dcimServiceDate.TabStop = false;
            this.dcimServiceDate.Tag = "ServiceDate";
            // 
            // dcedServiceDate
            // 
            this.dcedServiceDate.Location = new System.Drawing.Point(122, 17);
            this.dcedServiceDate.Name = "dcedServiceDate";
            this.dcedServiceDate.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedServiceDate.OcxState")));
            this.dcedServiceDate.Size = new System.Drawing.Size(80, 18);
            this.dcedServiceDate.TabIndex = 5;
            this.dcedServiceDate.Tag = "ServiceDate";
            // 
            // dcimUnits
            // 
            this.dcimUnits.Location = new System.Drawing.Point(202, 0);
            this.dcimUnits.Name = "dcimUnits";
            this.dcimUnits.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimUnits.OcxState")));
            this.dcimUnits.Size = new System.Drawing.Size(40, 18);
            this.dcimUnits.TabIndex = 6;
            this.dcimUnits.TabStop = false;
            this.dcimUnits.Tag = "Units";
            // 
            // dcedUnits
            // 
            this.dcedUnits.Location = new System.Drawing.Point(202, 17);
            this.dcedUnits.Name = "dcedUnits";
            this.dcedUnits.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedUnits.OcxState")));
            this.dcedUnits.Size = new System.Drawing.Size(40, 18);
            this.dcedUnits.TabIndex = 7;
            this.dcedUnits.Tag = "Units";
            // 
            // dcimCharges
            // 
            this.dcimCharges.Location = new System.Drawing.Point(242, 0);
            this.dcimCharges.Name = "dcimCharges";
            this.dcimCharges.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimCharges.OcxState")));
            this.dcimCharges.Size = new System.Drawing.Size(83, 18);
            this.dcimCharges.TabIndex = 8;
            this.dcimCharges.TabStop = false;
            this.dcimCharges.Tag = "Charges";
            // 
            // dcedCharges
            // 
            this.dcedCharges.Location = new System.Drawing.Point(242, 17);
            this.dcedCharges.Name = "dcedCharges";
            this.dcedCharges.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedCharges.OcxState")));
            this.dcedCharges.Size = new System.Drawing.Size(83, 18);
            this.dcedCharges.TabIndex = 9;
            this.dcedCharges.Tag = "Charges";
            // 
            // dcimNonCovered
            // 
            this.dcimNonCovered.Location = new System.Drawing.Point(605, 0);
            this.dcimNonCovered.Name = "dcimNonCovered";
            this.dcimNonCovered.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimNonCovered.OcxState")));
            this.dcimNonCovered.Size = new System.Drawing.Size(83, 18);
            this.dcimNonCovered.TabIndex = 14;
            this.dcimNonCovered.TabStop = false;
            this.dcimNonCovered.Tag = "NonCovered";
            // 
            // dcedNonCovered
            // 
            this.dcedNonCovered.Location = new System.Drawing.Point(605, 17);
            this.dcedNonCovered.Name = "dcedNonCovered";
            this.dcedNonCovered.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedNonCovered.OcxState")));
            this.dcedNonCovered.Size = new System.Drawing.Size(83, 18);
            this.dcedNonCovered.TabIndex = 15;
            this.dcedNonCovered.Tag = "NonCovered";
            // 
            // dcimLocalUse
            // 
            this.dcimLocalUse.Location = new System.Drawing.Point(688, 0);
            this.dcimLocalUse.Name = "dcimLocalUse";
            this.dcimLocalUse.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimLocalUse.OcxState")));
            this.dcimLocalUse.Size = new System.Drawing.Size(65, 18);
            this.dcimLocalUse.TabIndex = 16;
            this.dcimLocalUse.TabStop = false;
            this.dcimLocalUse.Tag = "LocalUse";
            // 
            // dcedLocalUse
            // 
            this.dcedLocalUse.Location = new System.Drawing.Point(688, 17);
            this.dcedLocalUse.Name = "dcedLocalUse";
            this.dcedLocalUse.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedLocalUse.OcxState")));
            this.dcedLocalUse.Size = new System.Drawing.Size(65, 18);
            this.dcedLocalUse.TabIndex = 17;
            this.dcedLocalUse.Tag = "LocalUse";
            // 
            // btnDelpbLINEITEM
            // 
            this.btnDelpbLINEITEM.Location = new System.Drawing.Point(183, 804);
            this.btnDelpbLINEITEM.Name = "btnDelpbLINEITEM";
            this.btnDelpbLINEITEM.Size = new System.Drawing.Size(74, 26);
            this.btnDelpbLINEITEM.TabIndex = 292;
            this.btnDelpbLINEITEM.Tag = "LINEITEM";
            this.btnDelpbLINEITEM.Text = "Delete";
            this.btnDelpbLINEITEM.UseVisualStyleBackColor = true;
            // 
            // btnInsAfterpbLINEITEM
            // 
            this.btnInsAfterpbLINEITEM.Location = new System.Drawing.Point(105, 804);
            this.btnInsAfterpbLINEITEM.Name = "btnInsAfterpbLINEITEM";
            this.btnInsAfterpbLINEITEM.Size = new System.Drawing.Size(76, 26);
            this.btnInsAfterpbLINEITEM.TabIndex = 291;
            this.btnInsAfterpbLINEITEM.Tag = "LINEITEM";
            this.btnInsAfterpbLINEITEM.Text = "Append";
            this.btnInsAfterpbLINEITEM.UseVisualStyleBackColor = true;
            // 
            // btnInsBeforepbLINEITEM
            // 
            this.btnInsBeforepbLINEITEM.Location = new System.Drawing.Point(22, 804);
            this.btnInsBeforepbLINEITEM.Name = "btnInsBeforepbLINEITEM";
            this.btnInsBeforepbLINEITEM.Size = new System.Drawing.Size(77, 26);
            this.btnInsBeforepbLINEITEM.TabIndex = 290;
            this.btnInsBeforepbLINEITEM.Tag = "LINEITEM";
            this.btnInsBeforepbLINEITEM.Text = "Insert";
            this.btnInsBeforepbLINEITEM.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(1222, 4155);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 13);
            this.label1.TabIndex = 708;
            this.label1.Tag = "8ptnmid";
            this.label1.Text = "8a Patient ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Lavender;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(11, 884);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(21, 20);
            this.label2.TabIndex = 714;
            this.label2.Text = "A";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Lavender;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(10, 927);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(21, 20);
            this.label3.TabIndex = 715;
            this.label3.Text = "B";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Lavender;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(11, 975);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(21, 20);
            this.label4.TabIndex = 716;
            this.label4.Text = "C";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Lavender;
            this.label5.Location = new System.Drawing.Point(481, 1245);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(115, 13);
            this.label5.TabIndex = 718;
            this.label5.Text = "76 Attending Physician";
            // 
            // picbx1
            // 
            this.picbx1.BackColor = System.Drawing.Color.Lavender;
            this.picbx1.Location = new System.Drawing.Point(18, 25);
            this.picbx1.Name = "picbx1";
            this.picbx1.Size = new System.Drawing.Size(249, 235);
            this.picbx1.TabIndex = 709;
            this.picbx1.TabStop = false;
            // 
            // picbx8
            // 
            this.picbx8.BackColor = System.Drawing.Color.Lavender;
            this.picbx8.Location = new System.Drawing.Point(278, 157);
            this.picbx8.Name = "picbx8";
            this.picbx8.Size = new System.Drawing.Size(264, 103);
            this.picbx8.TabIndex = 710;
            this.picbx8.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Lavender;
            this.pictureBox1.Location = new System.Drawing.Point(550, 96);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(228, 164);
            this.pictureBox1.TabIndex = 711;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Lavender;
            this.pictureBox2.Location = new System.Drawing.Point(9, 1034);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(694, 200);
            this.pictureBox2.TabIndex = 712;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Lavender;
            this.pictureBox3.Location = new System.Drawing.Point(8, 864);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(771, 162);
            this.pictureBox3.TabIndex = 713;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Lavender;
            this.pictureBox4.Location = new System.Drawing.Point(11, 1244);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(444, 131);
            this.pictureBox4.TabIndex = 717;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.Lavender;
            this.pictureBox5.Location = new System.Drawing.Point(474, 1244);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(274, 130);
            this.pictureBox5.TabIndex = 719;
            this.pictureBox5.TabStop = false;
            // 
            // IClaim
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.BackColor = System.Drawing.Color.MintCream;
            this.ClientSize = new System.Drawing.Size(790, 1412);
            this.ContentSize = new System.Drawing.Size(806, 1450);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnDelpbLINEITEM);
            this.Controls.Add(this.btnInsAfterpbLINEITEM);
            this.Controls.Add(this.btnInsBeforepbLINEITEM);
            this.Controls.Add(this.dcim1fcynmad);
            this.Controls.Add(this.lbl1provnam);
            this.Controls.Add(this.dced1provnam);
            this.Controls.Add(this.dced1provadd);
            this.Controls.Add(this.dced1provcit);
            this.Controls.Add(this.dced1provsta);
            this.Controls.Add(this.lbl3apctlnm);
            this.Controls.Add(this.dcim3apctlnm);
            this.Controls.Add(this.dced3apctlnm);
            this.Controls.Add(this.lbl3bmdrcnm);
            this.Controls.Add(this.dcim3bmdrcnm);
            this.Controls.Add(this.dced3bmdrcnm);
            this.Controls.Add(this.lbl4typbill);
            this.Controls.Add(this.dcim4typbill);
            this.Controls.Add(this.dced4typbill);
            this.Controls.Add(this.lbl5fedtxnm);
            this.Controls.Add(this.dcim5fedtxnm);
            this.Controls.Add(this.dced5fedtxnm);
            this.Controls.Add(this.lbl6scpfrom);
            this.Controls.Add(this.dcim6scpfrom);
            this.Controls.Add(this.dced6scpfrom);
            this.Controls.Add(this.dcim6scpthru);
            this.Controls.Add(this.dced6scpthru);
            this.Controls.Add(this.lbl8ptnmid);
            this.Controls.Add(this.dcim8ptnmid);
            this.Controls.Add(this.dced8ptnmid);
            this.Controls.Add(this.lbl8ptnm);
            this.Controls.Add(this.dcim8ptnm);
            this.Controls.Add(this.dced8plname);
            this.Controls.Add(this.dced8pfname);
            this.Controls.Add(this.dced8pminit);
            this.Controls.Add(this.dcim9paddstr);
            this.Controls.Add(this.dced9paddstr);
            this.Controls.Add(this.dcim9paddcty);
            this.Controls.Add(this.dced9paddcty);
            this.Controls.Add(this.dcim9paddsta);
            this.Controls.Add(this.dced9paddsta);
            this.Controls.Add(this.dcim9paddzip);
            this.Controls.Add(this.dced9paddzip);
            this.Controls.Add(this.dcim9paddccd);
            this.Controls.Add(this.dced9paddccd);
            this.Controls.Add(this.lbl10pbdate);
            this.Controls.Add(this.dcim10pbdate);
            this.Controls.Add(this.dced10pbdate);
            this.Controls.Add(this.lbl11psex);
            this.Controls.Add(this.dcim11psex);
            this.Controls.Add(this.dced11psex);
            this.Controls.Add(this.lbl12admdte);
            this.Controls.Add(this.dcim12admdte);
            this.Controls.Add(this.dced12admdte);
            this.Controls.Add(this.lbl13admhr);
            this.Controls.Add(this.dcim13admhr);
            this.Controls.Add(this.dced13admhr);
            this.Controls.Add(this.lbl14admtyp);
            this.Controls.Add(this.dcim14admtyp);
            this.Controls.Add(this.dced14admtyp);
            this.Controls.Add(this.lbl16dhr);
            this.Controls.Add(this.dcim16dhr);
            this.Controls.Add(this.dced16dhr);
            this.Controls.Add(this.lbl17stat);
            this.Controls.Add(this.dcim17stat);
            this.Controls.Add(this.dced17stat);
            this.Controls.Add(this.lbl31aocrcd);
            this.Controls.Add(this.dcim31aocrcd);
            this.Controls.Add(this.dced31aocrcd);
            this.Controls.Add(this.dcim31aocrdt);
            this.Controls.Add(this.dced31aocrdt);
            this.Controls.Add(this.dcim31bocrcd);
            this.Controls.Add(this.dced31bocrcd);
            this.Controls.Add(this.dcim31bocrdt);
            this.Controls.Add(this.dced31bocrdt);
            this.Controls.Add(this.lbl32aocrcd);
            this.Controls.Add(this.dcim32aocrcd);
            this.Controls.Add(this.dced32aocrcd);
            this.Controls.Add(this.dcim32aocrdt);
            this.Controls.Add(this.dced32aocrdt);
            this.Controls.Add(this.dcim32bocrcd);
            this.Controls.Add(this.dced32bocrcd);
            this.Controls.Add(this.dcim32bocrdt);
            this.Controls.Add(this.dced32bocrdt);
            this.Controls.Add(this.lbl36aospcd);
            this.Controls.Add(this.dcim36aospcd);
            this.Controls.Add(this.dced36aospcd);
            this.Controls.Add(this.dcim36aospfr);
            this.Controls.Add(this.dced36aospfr);
            this.Controls.Add(this.dcim36aospth);
            this.Controls.Add(this.dced36aospth);
            this.Controls.Add(this.dcim36bospcd);
            this.Controls.Add(this.dced36bospcd);
            this.Controls.Add(this.dcim36bospfr);
            this.Controls.Add(this.dced36bospfr);
            this.Controls.Add(this.dcim36bospth);
            this.Controls.Add(this.dced36bospth);
            this.Controls.Add(this.lbl39avlcd);
            this.Controls.Add(this.dcim39avlcd);
            this.Controls.Add(this.dced39avlcd);
            this.Controls.Add(this.dcim39avlamt);
            this.Controls.Add(this.dced39avlamt);
            this.Controls.Add(this.dcim39bvlcd);
            this.Controls.Add(this.dced39bvlcd);
            this.Controls.Add(this.dcim39bvlamt);
            this.Controls.Add(this.dced39bvlamt);
            this.Controls.Add(this.dcim39cvlcd);
            this.Controls.Add(this.dced39cvlcd);
            this.Controls.Add(this.dcim39cvlamt);
            this.Controls.Add(this.dced39cvlamt);
            this.Controls.Add(this.dcim39dvlcd);
            this.Controls.Add(this.dced39dvlcd);
            this.Controls.Add(this.dcim39dvlamt);
            this.Controls.Add(this.dced39dvlamt);
            this.Controls.Add(this.lbl40avlcd);
            this.Controls.Add(this.dcim40avlcd);
            this.Controls.Add(this.dced40avlcd);
            this.Controls.Add(this.dcim40avlamt);
            this.Controls.Add(this.dced40avlamt);
            this.Controls.Add(this.dcim40bvlcd);
            this.Controls.Add(this.dced40bvlcd);
            this.Controls.Add(this.dcim40bvlamt);
            this.Controls.Add(this.dced40bvlamt);
            this.Controls.Add(this.dcim40cvlcd);
            this.Controls.Add(this.dced40cvlcd);
            this.Controls.Add(this.dcim40cvlamt);
            this.Controls.Add(this.dced40cvlamt);
            this.Controls.Add(this.dcim40dvlcd);
            this.Controls.Add(this.dced40dvlcd);
            this.Controls.Add(this.dcim40dvlamt);
            this.Controls.Add(this.dced40dvlamt);
            this.Controls.Add(this.dcim41avlcd);
            this.Controls.Add(this.dced41avlcd);
            this.Controls.Add(this.dcim41avlamt);
            this.Controls.Add(this.dced41avlamt);
            this.Controls.Add(this.lbl41bvlcd);
            this.Controls.Add(this.dcim41bvlcd);
            this.Controls.Add(this.dced41bvlcd);
            this.Controls.Add(this.dcim41bvlamt);
            this.Controls.Add(this.dced41bvlamt);
            this.Controls.Add(this.dcim41cvlcd);
            this.Controls.Add(this.dced41cvlcd);
            this.Controls.Add(this.dcim41cvlamt);
            this.Controls.Add(this.dced41cvlamt);
            this.Controls.Add(this.dcim41dvlcd);
            this.Controls.Add(this.dced41dvlcd);
            this.Controls.Add(this.dcim41dvlamt);
            this.Controls.Add(this.dced41dvlamt);
            this.Controls.Add(this.dcim50apayer);
            this.Controls.Add(this.dced50apayer);
            this.Controls.Add(this.dcim50bpayer);
            this.Controls.Add(this.dced50bpayer);
            this.Controls.Add(this.lbl50cpayer);
            this.Controls.Add(this.dcim50cpayer);
            this.Controls.Add(this.dced50cpayer);
            this.Controls.Add(this.dcim51aprvno);
            this.Controls.Add(this.dced51aprvno);
            this.Controls.Add(this.dcim51bprvno);
            this.Controls.Add(this.dced51bprvno);
            this.Controls.Add(this.lbl51cprvno);
            this.Controls.Add(this.dcim51cprvno);
            this.Controls.Add(this.dced51cprvno);
            this.Controls.Add(this.lbl56npi);
            this.Controls.Add(this.dcim56npi);
            this.Controls.Add(this.dced56npi);
            this.Controls.Add(this.dcim58ainsnm);
            this.Controls.Add(this.lbl58alname);
            this.Controls.Add(this.dced58alname);
            this.Controls.Add(this.lbl58afname);
            this.Controls.Add(this.dced58afname);
            this.Controls.Add(this.lbl58aminit);
            this.Controls.Add(this.dced58aminit);
            this.Controls.Add(this.lbl58binsnm);
            this.Controls.Add(this.dcim58binsnm);
            this.Controls.Add(this.lbl58blname);
            this.Controls.Add(this.dced58blname);
            this.Controls.Add(this.lbl58bfname);
            this.Controls.Add(this.dced58bfname);
            this.Controls.Add(this.lbl58bminit);
            this.Controls.Add(this.dced58bminit);
            this.Controls.Add(this.dcim58cinsnm);
            this.Controls.Add(this.lbl58clname);
            this.Controls.Add(this.dced58clname);
            this.Controls.Add(this.dced58cfname);
            this.Controls.Add(this.dced58cminit);
            this.Controls.Add(this.dcim60acshi);
            this.Controls.Add(this.dced60acshi);
            this.Controls.Add(this.dcim60bcshi);
            this.Controls.Add(this.dced60bcshi);
            this.Controls.Add(this.lbl60ccshi);
            this.Controls.Add(this.dcim60ccshi);
            this.Controls.Add(this.dced60ccshi);
            this.Controls.Add(this.dcim66dxverq);
            this.Controls.Add(this.dced66dxverq);
            this.Controls.Add(this.lbl67prdgcd);
            this.Controls.Add(this.dcim67prdgcd);
            this.Controls.Add(this.dced67prdgcd);
            this.Controls.Add(this.lbl67aothdg);
            this.Controls.Add(this.dcim67aothdg);
            this.Controls.Add(this.dced67aothdg);
            this.Controls.Add(this.lbl67bothdg);
            this.Controls.Add(this.dcim67bothdg);
            this.Controls.Add(this.dced67bothdg);
            this.Controls.Add(this.lbl67cothdg);
            this.Controls.Add(this.dcim67cothdg);
            this.Controls.Add(this.dced67cothdg);
            this.Controls.Add(this.lbl67dothdg);
            this.Controls.Add(this.dcim67dothdg);
            this.Controls.Add(this.dced67dothdg);
            this.Controls.Add(this.lbl67eothdg);
            this.Controls.Add(this.dcim67eothdg);
            this.Controls.Add(this.dced67eothdg);
            this.Controls.Add(this.lbl67fothdg);
            this.Controls.Add(this.dcim67fothdg);
            this.Controls.Add(this.dced67fothdg);
            this.Controls.Add(this.lbl67gothdg);
            this.Controls.Add(this.dcim67gothdg);
            this.Controls.Add(this.dced67gothdg);
            this.Controls.Add(this.lbl67hothdg);
            this.Controls.Add(this.dcim67hothdg);
            this.Controls.Add(this.dced67hothdg);
            this.Controls.Add(this.lbl67iothdg);
            this.Controls.Add(this.dcim67iothdg);
            this.Controls.Add(this.dced67iothdg);
            this.Controls.Add(this.lbl67jothdg);
            this.Controls.Add(this.dcim67jothdg);
            this.Controls.Add(this.dced67jothdg);
            this.Controls.Add(this.lbl67kothdg);
            this.Controls.Add(this.dcim67kothdg);
            this.Controls.Add(this.dced67kothdg);
            this.Controls.Add(this.lbl67lothdg);
            this.Controls.Add(this.dcim67lothdg);
            this.Controls.Add(this.dced67lothdg);
            this.Controls.Add(this.lbl67mothdg);
            this.Controls.Add(this.dcim67mothdg);
            this.Controls.Add(this.dced67mothdg);
            this.Controls.Add(this.lbl67nothdg);
            this.Controls.Add(this.dcim67nothdg);
            this.Controls.Add(this.dced67nothdg);
            this.Controls.Add(this.lbl67oothdg);
            this.Controls.Add(this.dcim67oothdg);
            this.Controls.Add(this.dced67oothdg);
            this.Controls.Add(this.lbl67pothdg);
            this.Controls.Add(this.dcim67pothdg);
            this.Controls.Add(this.dced67pothdg);
            this.Controls.Add(this.lbl67qothdg);
            this.Controls.Add(this.dcim67qothdg);
            this.Controls.Add(this.dced67qothdg);
            this.Controls.Add(this.dcim69amdgcd);
            this.Controls.Add(this.dced69amdgcd);
            this.Controls.Add(this.dcim70arfvcd);
            this.Controls.Add(this.dced70arfvcd);
            this.Controls.Add(this.dcim70brfvcd);
            this.Controls.Add(this.dced70brfvcd);
            this.Controls.Add(this.dcim70crfvcd);
            this.Controls.Add(this.dced70crfvcd);
            this.Controls.Add(this.dcim71ppscd);
            this.Controls.Add(this.dced71ppscd);
            this.Controls.Add(this.lbl72aecicd);
            this.Controls.Add(this.dcim72aecicd);
            this.Controls.Add(this.dced72aecicd);
            this.Controls.Add(this.lbl74prprcd);
            this.Controls.Add(this.dcim74prprcd);
            this.Controls.Add(this.dced74prprcd);
            this.Controls.Add(this.dcim74prprdt);
            this.Controls.Add(this.dced74prprdt);
            this.Controls.Add(this.lbl74aoprcd);
            this.Controls.Add(this.dcim74aoprcd);
            this.Controls.Add(this.dced74aoprcd);
            this.Controls.Add(this.dcim74aoprdt);
            this.Controls.Add(this.dced74aoprdt);
            this.Controls.Add(this.dcim74boprcd);
            this.Controls.Add(this.dced74boprcd);
            this.Controls.Add(this.lbl74boprdt);
            this.Controls.Add(this.dcim74boprdt);
            this.Controls.Add(this.dced74boprdt);
            this.Controls.Add(this.lbl74coprcd);
            this.Controls.Add(this.dcim74coprcd);
            this.Controls.Add(this.dced74coprcd);
            this.Controls.Add(this.dcim74coprdt);
            this.Controls.Add(this.dced74coprdt);
            this.Controls.Add(this.lbl74doprcd);
            this.Controls.Add(this.dcim74doprcd);
            this.Controls.Add(this.dced74doprcd);
            this.Controls.Add(this.dcim74doprdt);
            this.Controls.Add(this.dced74doprdt);
            this.Controls.Add(this.lbl74eoprcd);
            this.Controls.Add(this.dcim74eoprcd);
            this.Controls.Add(this.dced74eoprcd);
            this.Controls.Add(this.lbl74eoprdt);
            this.Controls.Add(this.dcim74eoprdt);
            this.Controls.Add(this.dced74eoprdt);
            this.Controls.Add(this.lbl76apnpi);
            this.Controls.Add(this.dcim76apnpi);
            this.Controls.Add(this.dced76apnpi);
            this.Controls.Add(this.lbl76apqual);
            this.Controls.Add(this.dcim76apqual);
            this.Controls.Add(this.dced76apqual);
            this.Controls.Add(this.lbl76apid);
            this.Controls.Add(this.dcim76apid);
            this.Controls.Add(this.dced76apid);
            this.Controls.Add(this.lbl76aplnm);
            this.Controls.Add(this.dcim76aplnm);
            this.Controls.Add(this.dced76aplnm);
            this.Controls.Add(this.lbl76apfnm);
            this.Controls.Add(this.dcim76apfnm);
            this.Controls.Add(this.dced76apfnm);
            this.Controls.Add(this.lbl23TotChgs);
            this.Controls.Add(this.dcim23TotChgs);
            this.Controls.Add(this.dced23TotChgs);
            this.Controls.Add(this.lbRevCode);
            this.Controls.Add(this.lbDescription);
            this.Controls.Add(this.lbHCPCS);
            this.Controls.Add(this.lbServiceDate);
            this.Controls.Add(this.lbUnits);
            this.Controls.Add(this.lbCharges);
            this.Controls.Add(this.lbNonCovered);
            this.Controls.Add(this.lbLocalUse);
            this.Controls.Add(this.panLINEITEM);
            this.Controls.Add(this.lbl1fcynmad);
            this.Controls.Add(this.lbl1provadd);
            this.Controls.Add(this.lbl1provcit);
            this.Controls.Add(this.lbl1provsta);
            this.Controls.Add(this.dced1provzip);
            this.Controls.Add(this.lbl1provzip);
            this.Controls.Add(this.lbl8plname);
            this.Controls.Add(this.lbl8pfname);
            this.Controls.Add(this.lbl8pminit);
            this.Controls.Add(this.lbl9paddstr);
            this.Controls.Add(this.lbl9paddcty);
            this.Controls.Add(this.lbl9paddsta);
            this.Controls.Add(this.lbl9paddzip);
            this.Controls.Add(this.lbl9paddccd);
            this.Controls.Add(this.picbx1);
            this.Controls.Add(this.picbx8);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox5);
            this.MaximumSize = new System.Drawing.Size(830, 1474);
            this.Name = "IClaim";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.dcim1fcynmad)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced1provnam)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced1provadd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced1provcit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced1provsta)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced1provzip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim3apctlnm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced3apctlnm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim3bmdrcnm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced3bmdrcnm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim4typbill)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced4typbill)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim5fedtxnm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced5fedtxnm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim6scpfrom)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced6scpfrom)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim6scpthru)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced6scpthru)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim8ptnmid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced8ptnmid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim8ptnm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced8plname)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced8pfname)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced8pminit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim9paddstr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced9paddstr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim9paddcty)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced9paddcty)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim9paddsta)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced9paddsta)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim9paddzip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced9paddzip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim9paddccd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced9paddccd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim10pbdate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced10pbdate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim11psex)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced11psex)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim12admdte)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced12admdte)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim13admhr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced13admhr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim14admtyp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced14admtyp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim16dhr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced16dhr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim17stat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced17stat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim31aocrcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced31aocrcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim31aocrdt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced31aocrdt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim31bocrcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced31bocrcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim31bocrdt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced31bocrdt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim32aocrcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced32aocrcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim32aocrdt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced32aocrdt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim32bocrcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced32bocrcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim32bocrdt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced32bocrdt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim36aospcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced36aospcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim36aospfr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced36aospfr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim36aospth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced36aospth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim36bospcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced36bospcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim36bospfr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced36bospfr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim36bospth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced36bospth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim39avlcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced39avlcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim39avlamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced39avlamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim39bvlcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced39bvlcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim39bvlamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced39bvlamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim39cvlcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced39cvlcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim39cvlamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced39cvlamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim39dvlcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced39dvlcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim39dvlamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced39dvlamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim40avlcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced40avlcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim40avlamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced40avlamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim40bvlcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced40bvlcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim40bvlamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced40bvlamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim40cvlcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced40cvlcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim40cvlamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced40cvlamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim40dvlcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced40dvlcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim40dvlamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced40dvlamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim41avlcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced41avlcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim41avlamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced41avlamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim41bvlcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced41bvlcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim41bvlamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced41bvlamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim41cvlcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced41cvlcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim41cvlamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced41cvlamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim41dvlcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced41dvlcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim41dvlamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced41dvlamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim50apayer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced50apayer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim50bpayer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced50bpayer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim50cpayer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced50cpayer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim51aprvno)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced51aprvno)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim51bprvno)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced51bprvno)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim51cprvno)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced51cprvno)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim56npi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced56npi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim58ainsnm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced58alname)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced58afname)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced58aminit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim58binsnm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced58blname)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced58bfname)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced58bminit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim58cinsnm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced58clname)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced58cfname)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced58cminit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim60acshi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced60acshi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim60bcshi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced60bcshi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim60ccshi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced60ccshi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim66dxverq)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced66dxverq)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67prdgcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67prdgcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67aothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67aothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67bothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67bothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67cothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67cothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67dothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67dothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67eothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67eothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67fothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67fothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67gothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67gothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67hothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67hothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67iothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67iothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67jothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67jothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67kothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67kothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67lothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67lothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67mothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67mothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67nothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67nothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67oothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67oothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67pothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67pothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67qothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67qothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim69amdgcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced69amdgcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim70arfvcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced70arfvcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim70brfvcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced70brfvcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim70crfvcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced70crfvcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim71ppscd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced71ppscd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim72aecicd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced72aecicd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim74prprcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced74prprcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim74prprdt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced74prprdt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim74aoprcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced74aoprcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim74aoprdt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced74aoprdt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim74boprcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced74boprcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim74boprdt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced74boprdt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim74coprcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced74coprcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim74coprdt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced74coprdt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim74doprcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced74doprcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim74doprdt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced74doprdt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim74eoprcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced74eoprcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim74eoprdt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced74eoprdt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim76apnpi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced76apnpi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim76apqual)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced76apqual)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim76apid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced76apid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim76aplnm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced76aplnm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim76apfnm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced76apfnm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim23TotChgs)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced23TotChgs)).EndInit();
            this.panLINEITEM.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dcimRevCode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedRevCode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimDescription)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedDescription)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimHCPCS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedHCPCS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimServiceDate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedServiceDate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimUnits)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedUnits)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimCharges)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedCharges)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimNonCovered)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedNonCovered)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimLocalUse)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedLocalUse)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
                        private System.Windows.Forms.Label lbl1fcynmad;
                                private AxDCIMAGELib.AxDcimage dcim1fcynmad;
                                private System.Windows.Forms.Label lbl1provnam;
                                private AxDCEDITLib.AxDcedit dced1provnam;
                                private System.Windows.Forms.Label lbl1provadd;
                                private AxDCEDITLib.AxDcedit dced1provadd;
                                private System.Windows.Forms.Label lbl1provcit;
                                private AxDCEDITLib.AxDcedit dced1provcit;
                                private System.Windows.Forms.Label lbl1provsta;
                                private AxDCEDITLib.AxDcedit dced1provsta;
                                private System.Windows.Forms.Label lbl1provzip;
                                private AxDCEDITLib.AxDcedit dced1provzip;
                                private System.Windows.Forms.Label lbl3apctlnm;
                                private AxDCIMAGELib.AxDcimage dcim3apctlnm;
                                private AxDCEDITLib.AxDcedit dced3apctlnm;
                                private System.Windows.Forms.Label lbl3bmdrcnm;
                                private AxDCIMAGELib.AxDcimage dcim3bmdrcnm;
                                private AxDCEDITLib.AxDcedit dced3bmdrcnm;
                                private System.Windows.Forms.Label lbl4typbill;
                                private AxDCIMAGELib.AxDcimage dcim4typbill;
                                private AxDCEDITLib.AxDcedit dced4typbill;
                                private System.Windows.Forms.Label lbl5fedtxnm;
                                private AxDCIMAGELib.AxDcimage dcim5fedtxnm;
                                private AxDCEDITLib.AxDcedit dced5fedtxnm;
                                private System.Windows.Forms.Label lbl6scpfrom;
                                private AxDCIMAGELib.AxDcimage dcim6scpfrom;
                                private AxDCEDITLib.AxDcedit dced6scpfrom;
                                private AxDCIMAGELib.AxDcimage dcim6scpthru;
                                private AxDCEDITLib.AxDcedit dced6scpthru;
                                private System.Windows.Forms.Label lbl8ptnmid;
                                private AxDCIMAGELib.AxDcimage dcim8ptnmid;
                                private AxDCEDITLib.AxDcedit dced8ptnmid;
                                private System.Windows.Forms.Label lbl8ptnm;
                                private AxDCIMAGELib.AxDcimage dcim8ptnm;
                                private System.Windows.Forms.Label lbl8plname;
                                private AxDCEDITLib.AxDcedit dced8plname;
                                private System.Windows.Forms.Label lbl8pfname;
                                private AxDCEDITLib.AxDcedit dced8pfname;
                                private System.Windows.Forms.Label lbl8pminit;
                                private AxDCEDITLib.AxDcedit dced8pminit;
                                private System.Windows.Forms.Label lbl9paddstr;
                                private AxDCIMAGELib.AxDcimage dcim9paddstr;
                                private AxDCEDITLib.AxDcedit dced9paddstr;
                                private System.Windows.Forms.Label lbl9paddcty;
                                private AxDCIMAGELib.AxDcimage dcim9paddcty;
                                private AxDCEDITLib.AxDcedit dced9paddcty;
                                private System.Windows.Forms.Label lbl9paddsta;
                                private AxDCIMAGELib.AxDcimage dcim9paddsta;
                                private AxDCEDITLib.AxDcedit dced9paddsta;
                                private System.Windows.Forms.Label lbl9paddzip;
                                private AxDCIMAGELib.AxDcimage dcim9paddzip;
                                private AxDCEDITLib.AxDcedit dced9paddzip;
                                private System.Windows.Forms.Label lbl9paddccd;
                                private AxDCIMAGELib.AxDcimage dcim9paddccd;
                                private AxDCEDITLib.AxDcedit dced9paddccd;
                                private System.Windows.Forms.Label lbl10pbdate;
                                private AxDCIMAGELib.AxDcimage dcim10pbdate;
                                private AxDCEDITLib.AxDcedit dced10pbdate;
                                private System.Windows.Forms.Label lbl11psex;
                                private AxDCIMAGELib.AxDcimage dcim11psex;
                                private AxDCEDITLib.AxDcedit dced11psex;
                                private System.Windows.Forms.Label lbl12admdte;
                                private AxDCIMAGELib.AxDcimage dcim12admdte;
                                private AxDCEDITLib.AxDcedit dced12admdte;
                                private System.Windows.Forms.Label lbl13admhr;
                                private AxDCIMAGELib.AxDcimage dcim13admhr;
                                private AxDCEDITLib.AxDcedit dced13admhr;
                                private System.Windows.Forms.Label lbl14admtyp;
                                private AxDCIMAGELib.AxDcimage dcim14admtyp;
        private AxDCEDITLib.AxDcedit dced14admtyp;
                                private System.Windows.Forms.Label lbl16dhr;
                                private AxDCIMAGELib.AxDcimage dcim16dhr;
                                private AxDCEDITLib.AxDcedit dced16dhr;
                                private System.Windows.Forms.Label lbl17stat;
                                private AxDCIMAGELib.AxDcimage dcim17stat;
        private AxDCEDITLib.AxDcedit dced17stat;
                                private System.Windows.Forms.Label lbl31aocrcd;
                                private AxDCIMAGELib.AxDcimage dcim31aocrcd;
        private AxDCEDITLib.AxDcedit dced31aocrcd;
                                private AxDCIMAGELib.AxDcimage dcim31aocrdt;
        private AxDCEDITLib.AxDcedit dced31aocrdt;
                                private AxDCIMAGELib.AxDcimage dcim31bocrcd;
        private AxDCEDITLib.AxDcedit dced31bocrcd;
                                private AxDCIMAGELib.AxDcimage dcim31bocrdt;
                                private AxDCEDITLib.AxDcedit dced31bocrdt;
                                private System.Windows.Forms.Label lbl32aocrcd;
                                private AxDCIMAGELib.AxDcimage dcim32aocrcd;
        private AxDCEDITLib.AxDcedit dced32aocrcd;
                                private AxDCIMAGELib.AxDcimage dcim32aocrdt;
        private AxDCEDITLib.AxDcedit dced32aocrdt;
                                private AxDCIMAGELib.AxDcimage dcim32bocrcd;
        private AxDCEDITLib.AxDcedit dced32bocrcd;
                                private AxDCIMAGELib.AxDcimage dcim32bocrdt;
        private AxDCEDITLib.AxDcedit dced32bocrdt;
                                private System.Windows.Forms.Label lbl36aospcd;
                                private AxDCIMAGELib.AxDcimage dcim36aospcd;
        private AxDCEDITLib.AxDcedit dced36aospcd;
                                private AxDCIMAGELib.AxDcimage dcim36aospfr;
        private AxDCEDITLib.AxDcedit dced36aospfr;
                                private AxDCIMAGELib.AxDcimage dcim36aospth;
        private AxDCEDITLib.AxDcedit dced36aospth;
                                private AxDCIMAGELib.AxDcimage dcim36bospcd;
        private AxDCEDITLib.AxDcedit dced36bospcd;
                                private AxDCIMAGELib.AxDcimage dcim36bospfr;
        private AxDCEDITLib.AxDcedit dced36bospfr;
                                private AxDCIMAGELib.AxDcimage dcim36bospth;
                                private AxDCEDITLib.AxDcedit dced36bospth;
                                private System.Windows.Forms.Label lbl39avlcd;
                                private AxDCIMAGELib.AxDcimage dcim39avlcd;
        private AxDCEDITLib.AxDcedit dced39avlcd;
                                private AxDCIMAGELib.AxDcimage dcim39avlamt;
        private AxDCEDITLib.AxDcedit dced39avlamt;
                                private AxDCIMAGELib.AxDcimage dcim39bvlcd;
        private AxDCEDITLib.AxDcedit dced39bvlcd;
                                private AxDCIMAGELib.AxDcimage dcim39bvlamt;
        private AxDCEDITLib.AxDcedit dced39bvlamt;
                                private AxDCIMAGELib.AxDcimage dcim39cvlcd;
        private AxDCEDITLib.AxDcedit dced39cvlcd;
                                private AxDCIMAGELib.AxDcimage dcim39cvlamt;
        private AxDCEDITLib.AxDcedit dced39cvlamt;
                                private AxDCIMAGELib.AxDcimage dcim39dvlcd;
        private AxDCEDITLib.AxDcedit dced39dvlcd;
                                private AxDCIMAGELib.AxDcimage dcim39dvlamt;
                                private AxDCEDITLib.AxDcedit dced39dvlamt;
                                private System.Windows.Forms.Label lbl40avlcd;
                                private AxDCIMAGELib.AxDcimage dcim40avlcd;
        private AxDCEDITLib.AxDcedit dced40avlcd;
                                private AxDCIMAGELib.AxDcimage dcim40avlamt;
        private AxDCEDITLib.AxDcedit dced40avlamt;
                                private AxDCIMAGELib.AxDcimage dcim40bvlcd;
        private AxDCEDITLib.AxDcedit dced40bvlcd;
                                private AxDCIMAGELib.AxDcimage dcim40bvlamt;
        private AxDCEDITLib.AxDcedit dced40bvlamt;
                                private AxDCIMAGELib.AxDcimage dcim40cvlcd;
        private AxDCEDITLib.AxDcedit dced40cvlcd;
                                private AxDCIMAGELib.AxDcimage dcim40cvlamt;
        private AxDCEDITLib.AxDcedit dced40cvlamt;
                                private AxDCIMAGELib.AxDcimage dcim40dvlcd;
        private AxDCEDITLib.AxDcedit dced40dvlcd;
                                private AxDCIMAGELib.AxDcimage dcim40dvlamt;
        private AxDCEDITLib.AxDcedit dced40dvlamt;
                                private AxDCIMAGELib.AxDcimage dcim41avlcd;
        private AxDCEDITLib.AxDcedit dced41avlcd;
                                private AxDCIMAGELib.AxDcimage dcim41avlamt;
                                private AxDCEDITLib.AxDcedit dced41avlamt;
                                private System.Windows.Forms.Label lbl41bvlcd;
                                private AxDCIMAGELib.AxDcimage dcim41bvlcd;
        private AxDCEDITLib.AxDcedit dced41bvlcd;
                                private AxDCIMAGELib.AxDcimage dcim41bvlamt;
        private AxDCEDITLib.AxDcedit dced41bvlamt;
                                private AxDCIMAGELib.AxDcimage dcim41cvlcd;
        private AxDCEDITLib.AxDcedit dced41cvlcd;
                                private AxDCIMAGELib.AxDcimage dcim41cvlamt;
        private AxDCEDITLib.AxDcedit dced41cvlamt;
                                private AxDCIMAGELib.AxDcimage dcim41dvlcd;
        private AxDCEDITLib.AxDcedit dced41dvlcd;
                                private AxDCIMAGELib.AxDcimage dcim41dvlamt;
        private AxDCEDITLib.AxDcedit dced41dvlamt;
                                private AxDCIMAGELib.AxDcimage dcim50apayer;
        private AxDCEDITLib.AxDcedit dced50apayer;
                                private AxDCIMAGELib.AxDcimage dcim50bpayer;
                                private AxDCEDITLib.AxDcedit dced50bpayer;
                                private System.Windows.Forms.Label lbl50cpayer;
                                private AxDCIMAGELib.AxDcimage dcim50cpayer;
        private AxDCEDITLib.AxDcedit dced50cpayer;
                                private AxDCIMAGELib.AxDcimage dcim51aprvno;
        private AxDCEDITLib.AxDcedit dced51aprvno;
                                private AxDCIMAGELib.AxDcimage dcim51bprvno;
                                private AxDCEDITLib.AxDcedit dced51bprvno;
                                private System.Windows.Forms.Label lbl51cprvno;
                                private AxDCIMAGELib.AxDcimage dcim51cprvno;
        private AxDCEDITLib.AxDcedit dced51cprvno;
                                private System.Windows.Forms.Label lbl56npi;
                                private AxDCIMAGELib.AxDcimage dcim56npi;
        private AxDCEDITLib.AxDcedit dced56npi;
                                private AxDCIMAGELib.AxDcimage dcim58ainsnm;
                                private System.Windows.Forms.Label lbl58alname;
                                private AxDCEDITLib.AxDcedit dced58alname;
                                private System.Windows.Forms.Label lbl58afname;
                                private AxDCEDITLib.AxDcedit dced58afname;
                                private System.Windows.Forms.Label lbl58aminit;
        private AxDCEDITLib.AxDcedit dced58aminit;
                                private System.Windows.Forms.Label lbl58binsnm;
                                private AxDCIMAGELib.AxDcimage dcim58binsnm;
                                private System.Windows.Forms.Label lbl58blname;
                                private AxDCEDITLib.AxDcedit dced58blname;
                                private System.Windows.Forms.Label lbl58bfname;
                                private AxDCEDITLib.AxDcedit dced58bfname;
                                private System.Windows.Forms.Label lbl58bminit;
        private AxDCEDITLib.AxDcedit dced58bminit;
                                private AxDCIMAGELib.AxDcimage dcim58cinsnm;
                                private System.Windows.Forms.Label lbl58clname;
        private AxDCEDITLib.AxDcedit dced58clname;
        private AxDCEDITLib.AxDcedit dced58cfname;
        private AxDCEDITLib.AxDcedit dced58cminit;
                                private AxDCIMAGELib.AxDcimage dcim60acshi;
        private AxDCEDITLib.AxDcedit dced60acshi;
                                private AxDCIMAGELib.AxDcimage dcim60bcshi;
                                private AxDCEDITLib.AxDcedit dced60bcshi;
                                private System.Windows.Forms.Label lbl60ccshi;
                                private AxDCIMAGELib.AxDcimage dcim60ccshi;
        private AxDCEDITLib.AxDcedit dced60ccshi;
                                private AxDCIMAGELib.AxDcimage dcim66dxverq;
                                private AxDCEDITLib.AxDcedit dced66dxverq;
                                private System.Windows.Forms.Label lbl67prdgcd;
                                private AxDCIMAGELib.AxDcimage dcim67prdgcd;
                                private AxDCEDITLib.AxDcedit dced67prdgcd;
                                private System.Windows.Forms.Label lbl67aothdg;
                                private AxDCIMAGELib.AxDcimage dcim67aothdg;
                                private AxDCEDITLib.AxDcedit dced67aothdg;
                                private System.Windows.Forms.Label lbl67bothdg;
                                private AxDCIMAGELib.AxDcimage dcim67bothdg;
                                private AxDCEDITLib.AxDcedit dced67bothdg;
                                private System.Windows.Forms.Label lbl67cothdg;
                                private AxDCIMAGELib.AxDcimage dcim67cothdg;
                                private AxDCEDITLib.AxDcedit dced67cothdg;
                                private System.Windows.Forms.Label lbl67dothdg;
                                private AxDCIMAGELib.AxDcimage dcim67dothdg;
                                private AxDCEDITLib.AxDcedit dced67dothdg;
                                private System.Windows.Forms.Label lbl67eothdg;
                                private AxDCIMAGELib.AxDcimage dcim67eothdg;
                                private AxDCEDITLib.AxDcedit dced67eothdg;
                                private System.Windows.Forms.Label lbl67fothdg;
                                private AxDCIMAGELib.AxDcimage dcim67fothdg;
                                private AxDCEDITLib.AxDcedit dced67fothdg;
                                private System.Windows.Forms.Label lbl67gothdg;
                                private AxDCIMAGELib.AxDcimage dcim67gothdg;
                                private AxDCEDITLib.AxDcedit dced67gothdg;
                                private System.Windows.Forms.Label lbl67hothdg;
                                private AxDCIMAGELib.AxDcimage dcim67hothdg;
                                private AxDCEDITLib.AxDcedit dced67hothdg;
                                private System.Windows.Forms.Label lbl67iothdg;
                                private AxDCIMAGELib.AxDcimage dcim67iothdg;
                                private AxDCEDITLib.AxDcedit dced67iothdg;
                                private System.Windows.Forms.Label lbl67jothdg;
                                private AxDCIMAGELib.AxDcimage dcim67jothdg;
                                private AxDCEDITLib.AxDcedit dced67jothdg;
                                private System.Windows.Forms.Label lbl67kothdg;
                                private AxDCIMAGELib.AxDcimage dcim67kothdg;
                                private AxDCEDITLib.AxDcedit dced67kothdg;
                                private System.Windows.Forms.Label lbl67lothdg;
                                private AxDCIMAGELib.AxDcimage dcim67lothdg;
                                private AxDCEDITLib.AxDcedit dced67lothdg;
                                private System.Windows.Forms.Label lbl67mothdg;
                                private AxDCIMAGELib.AxDcimage dcim67mothdg;
                                private AxDCEDITLib.AxDcedit dced67mothdg;
                                private System.Windows.Forms.Label lbl67nothdg;
                                private AxDCIMAGELib.AxDcimage dcim67nothdg;
                                private AxDCEDITLib.AxDcedit dced67nothdg;
                                private System.Windows.Forms.Label lbl67oothdg;
                                private AxDCIMAGELib.AxDcimage dcim67oothdg;
                                private AxDCEDITLib.AxDcedit dced67oothdg;
                                private System.Windows.Forms.Label lbl67pothdg;
                                private AxDCIMAGELib.AxDcimage dcim67pothdg;
                                private AxDCEDITLib.AxDcedit dced67pothdg;
                                private System.Windows.Forms.Label lbl67qothdg;
                                private AxDCIMAGELib.AxDcimage dcim67qothdg;
        private AxDCEDITLib.AxDcedit dced67qothdg;
                                private AxDCIMAGELib.AxDcimage dcim69amdgcd;
        private AxDCEDITLib.AxDcedit dced69amdgcd;
                                private AxDCIMAGELib.AxDcimage dcim70arfvcd;
        private AxDCEDITLib.AxDcedit dced70arfvcd;
                                private AxDCIMAGELib.AxDcimage dcim70brfvcd;
        private AxDCEDITLib.AxDcedit dced70brfvcd;
                                private AxDCIMAGELib.AxDcimage dcim70crfvcd;
        private AxDCEDITLib.AxDcedit dced70crfvcd;
                                private AxDCIMAGELib.AxDcimage dcim71ppscd;
                                private AxDCEDITLib.AxDcedit dced71ppscd;
                                private System.Windows.Forms.Label lbl72aecicd;
                                private AxDCIMAGELib.AxDcimage dcim72aecicd;
        private AxDCEDITLib.AxDcedit dced72aecicd;
                                private System.Windows.Forms.Label lbl74prprcd;
                                private AxDCIMAGELib.AxDcimage dcim74prprcd;
        private AxDCEDITLib.AxDcedit dced74prprcd;
                                private AxDCIMAGELib.AxDcimage dcim74prprdt;
                                private AxDCEDITLib.AxDcedit dced74prprdt;
                                private System.Windows.Forms.Label lbl74aoprcd;
                                private AxDCIMAGELib.AxDcimage dcim74aoprcd;
        private AxDCEDITLib.AxDcedit dced74aoprcd;
                                private AxDCIMAGELib.AxDcimage dcim74aoprdt;
        private AxDCEDITLib.AxDcedit dced74aoprdt;
                                private AxDCIMAGELib.AxDcimage dcim74boprcd;
                                private AxDCEDITLib.AxDcedit dced74boprcd;
                                private System.Windows.Forms.Label lbl74boprdt;
                                private AxDCIMAGELib.AxDcimage dcim74boprdt;
                                private AxDCEDITLib.AxDcedit dced74boprdt;
                                private System.Windows.Forms.Label lbl74coprcd;
                                private AxDCIMAGELib.AxDcimage dcim74coprcd;
        private AxDCEDITLib.AxDcedit dced74coprcd;
                                private AxDCIMAGELib.AxDcimage dcim74coprdt;
                                private AxDCEDITLib.AxDcedit dced74coprdt;
                                private System.Windows.Forms.Label lbl74doprcd;
                                private AxDCIMAGELib.AxDcimage dcim74doprcd;
        private AxDCEDITLib.AxDcedit dced74doprcd;
                                private AxDCIMAGELib.AxDcimage dcim74doprdt;
                                private AxDCEDITLib.AxDcedit dced74doprdt;
                                private System.Windows.Forms.Label lbl74eoprcd;
                                private AxDCIMAGELib.AxDcimage dcim74eoprcd;
                                private AxDCEDITLib.AxDcedit dced74eoprcd;
                                private System.Windows.Forms.Label lbl74eoprdt;
                                private AxDCIMAGELib.AxDcimage dcim74eoprdt;
        private AxDCEDITLib.AxDcedit dced74eoprdt;
                                private System.Windows.Forms.Label lbl76apnpi;
                                private AxDCIMAGELib.AxDcimage dcim76apnpi;
                                private AxDCEDITLib.AxDcedit dced76apnpi;
                                private System.Windows.Forms.Label lbl76apqual;
                                private AxDCIMAGELib.AxDcimage dcim76apqual;
                                private AxDCEDITLib.AxDcedit dced76apqual;
                                private System.Windows.Forms.Label lbl76apid;
                                private AxDCIMAGELib.AxDcimage dcim76apid;
                                private AxDCEDITLib.AxDcedit dced76apid;
                                private System.Windows.Forms.Label lbl76aplnm;
                                private AxDCIMAGELib.AxDcimage dcim76aplnm;
                                private AxDCEDITLib.AxDcedit dced76aplnm;
                                private System.Windows.Forms.Label lbl76apfnm;
                                private AxDCIMAGELib.AxDcimage dcim76apfnm;
        private AxDCEDITLib.AxDcedit dced76apfnm;
                                private System.Windows.Forms.Label lbl23TotChgs;
                                private AxDCIMAGELib.AxDcimage dcim23TotChgs;
                                private AxDCEDITLib.AxDcedit dced23TotChgs;
                                private System.Windows.Forms.Label lbRevCode;
                                private System.Windows.Forms.Label lbDescription;
        private System.Windows.Forms.Label lbHCPCS;
                                private System.Windows.Forms.Label lbServiceDate;
                                private System.Windows.Forms.Label lbUnits;
                                private System.Windows.Forms.Label lbCharges;
                                private System.Windows.Forms.Label lbNonCovered;
        private System.Windows.Forms.Label lbLocalUse;
        private System.Windows.Forms.Panel panLINEITEM;
                                private AxDCIMAGELib.AxDcimage dcimRevCode;
                                private AxDCEDITLib.AxDcedit dcedRevCode;
                                private AxDCIMAGELib.AxDcimage dcimDescription;
                                private AxDCEDITLib.AxDcedit dcedDescription;
                                private AxDCIMAGELib.AxDcimage dcimHCPCS;
        private AxDCEDITLib.AxDcedit dcedHCPCS;
                                private AxDCIMAGELib.AxDcimage dcimServiceDate;
                                private AxDCEDITLib.AxDcedit dcedServiceDate;
                                private AxDCIMAGELib.AxDcimage dcimUnits;
                                private AxDCEDITLib.AxDcedit dcedUnits;
                                private AxDCIMAGELib.AxDcimage dcimCharges;
                                private AxDCEDITLib.AxDcedit dcedCharges;
                                private AxDCIMAGELib.AxDcimage dcimNonCovered;
                                private AxDCEDITLib.AxDcedit dcedNonCovered;
                                private AxDCIMAGELib.AxDcimage dcimLocalUse;
                                private AxDCEDITLib.AxDcedit dcedLocalUse;
        private System.Windows.Forms.Button btnDelpbLINEITEM;
        private System.Windows.Forms.Button btnInsAfterpbLINEITEM;
        private System.Windows.Forms.Button btnInsBeforepbLINEITEM;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox picbx1;
        private System.Windows.Forms.PictureBox picbx8;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox5;
                        
    }
}
                