﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("DotScanPanels")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("IBM")]
[assembly: AssemblyProduct("IBM Datacap")]
[assembly: AssemblyCopyright("© Copyright IBM Corp. 2010, 2018")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("79e13cbe-181b-4cc9-ae5b-9411f1a95f18")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Revision and Build Numbers 
// by using the '*' as shown below:
[assembly: AssemblyVersion("9.0.0.0")]
[assembly: AssemblyFileVersion("9.1.6.22")]

/// 9.1.6.22 5/17/2019 SSahu 187165 
/// Added updated translated resources for pt-br

/// 9.1.6.21 5/15/2019 SSahu 187165 
/// Added updated translated files for Italy

/// 9.1.6.20 5/15/2019 SSahu 187165 
/// Added updated translated files for arabic

/// 9.1.6.19 5/10/2019 SSahu 187165 
/// Added updated translated files for coratian

/// 9.1.6.18 5/9/2019 SSahu 187165 
/// Added translated files for japanese

/// 9.1.6.17 5/3/2019 SSahu 187165 
/// Added translated files

/// Version 9.1.6.16 PNaik 26/04/2019 185875
/// Revert back code changes
///
/// Version 9.1.6.15 RohitZ 02/27/2019 185856
/// If you try to scan in more than 500 images in vscan, a scan limit exceeded prompt will get shown to user.
///
/// Version 9.1.6.14 vjagadha 02/21/2019 186120
/// Fixed issue - Scanned pages table have images with  prefix "tt" instead of "TM"
/// 
/// Version 9.1.6.13 PNaik 02/11/2019 185942
/// Added code to make the scan textbox empty on each insert button click.
///
/// Version 9.1.6.12 PNaik 02/01/2019 185875
/// Vscan panel fails to scan in more pages after clicking on Browse icon again and selecting additional pages
///
/// Version 9.1.5.11 RohitZ 1/15/2019 185248
/// Selecting large number of images for deleting in DcDesktop Scan panel results in unresponsiveness and exceptions
///
/// Version 9.1.5.10 PNaik 10/04/2018 183312
/// On drag drop node should get highlighted
///
/// Version 9.1.4.9 PNaik 06/05/2018 181472
/// Reverting back multi select using ctr on batch view
///
/// Version 9.1.4.8 PNaik 06/25/2018 181472
/// Added code for ctrl select-deselect in verify batch view 
/// 
/// Version 9.1.4.7 Vkandasamy 05/18/2018 179283
/// recreate List<string[]> after drag n drop in Vscan
/// 
/// Version 9.1.4.6 Vkandasamy 05/18/2018 179283
/// cleaned up code to make it more efficient after deleting thumbnails
///
/// Version 9.1.4.5 Vjagadha 05/18/2018 180777
/// Fixed issue - Batch tree viewer displays the images ingested through vscan in descending order 
/// 
/// Version 9.1.4.4 Vkandasamy 05/17/2018 179283
/// lstImages now uses a List<string[]> to keep track of the properties of the pages in the batch to display in list control
///
/// Version 9.1.4.3 Vkandasamy 05/08/2018 179283
/// reorder the lstImages after delete in Imageview
///
///  Version 9.1.4.2 Vjagadha 04/12/2018 179980
///  Changes done to restore type-ahead on dropdown lists
///
/// Version 9.1.4.1 Vkandasamy 04/05/2018 179286
/// reorder the existing lstImages instead of creating a new one after a drag and drop
///
/// Version 9.1.4.0 Vkandasamy 04/04/2018 179283
/// update lstImages items after page delete in batchform
///
/// Version 9.1.3.5 Pnaik 12/04/2017 172361 
/// Removed PreFilterMessage-delete from Vscan, ISISScan, TWAINScan Handled in ImageForm.
///
/// Version 9.1.3.4 Pnaik 11/29/2017 172361 
/// Called Application.RemoveMessageFilter(this) in endbatch() as PreFilterMessage keeps getting called eventhough vscan page is closed.
///
/// Version 9.1.3.3 Pnaik 11/15/2017 172361 
/// Attached events batchform.DragDropCompleted in twainscan and isisscan
///
/// Version 9.1.3.2 Pnaik 11/10/2017 172362 
/// Commented code PreFilterMessage - btnRemove.Enabled in TWAINScan, Vscan, ISISScan as when user clicks on delete button from batchview it should get called.
///
/// Version 9.1.3.1 Vkandasamy 09/07/2017 173626
/// perf issues: when adding new images, called LoadThumbs with reload=false
///  
/// Version 9.1.3.0 Vkandasamy 09/06/2017 173626
/// perf issues: (a)prevent the toolstrip combobox at the top of batch view from being refilled for each new page added during scan time
///  (b) tweaked LoadThumbs to not reload, but change the selection when the sel on batch view changes.
///  
/// Version 9.1.1.6 VKandasamy 02/03/2017 162960
/// Selecting single file on root folder cause all images to be brought in.
///
/// 9.1.0.5 160629 12/07/2016 RFerin Update German Batch to Stapel
///
/// Version 9.1.0.4 VKandasamy 09/22/2016 152456
/// Roll forward changes in 9.0.1 FP2 that were after the new stream
//
// 9.1.0.3 09/16/2016 156082
// Removed duplicate start panel reference.
//
// 9.0.1.12 01/13/2016 139166 RFerin 
// When thumbnail viewer is initially off and then enabled, the thumbnails do not appear until you click on an image in the list.
//
// Version 9.0.0.10 Updated 07/13/2015 VKandasamy Defect 41384