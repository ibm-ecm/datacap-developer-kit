// Licensed Materials - Property of IBM
// 5725-C15
// � Copyright IBM Corp. 1994, 2012 All Rights Reserved
// 
// US Government Users Restricted Rights - Use, duplication or
// disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using System.IO;
using dcDTlib;
using dcScanISIS;

namespace DotScanPanels
{
    public partial class ISISScan : dcDTlib.dotPanelBase, IMessageFilter
    {
        static System.Windows.Forms.Timer myTimer = new System.Windows.Forms.Timer();

        static ScanISIS dcScan;// = new ScanISIS();
        string[] dcfiletypes = { "Tiff", "Bmp", "Jpeg", "Png", "Jp2" };
        private string sBarcodeSepValue = "";
        private string sBarcodeSepType = "";
        private bool bStartNewDocWithNextFrontImage = false;
        private bool bStartNewDocNext = false;
        private bool bClassUpdateInProgress = false;
        static string sRescanIDs = string.Empty;
        static int numRescanPages = 0;
        static int rescanCount = 0;
        static string sRescanPageType = "Other";
               
        // batch variables from startbatch / runtime DCO (bit currently used)
        public int nED = 0;
        public int nEP = 0;
        public int nAD = 0;
        public int nAP = 0;

        public ISISScan()
        {
            InitializeComponent();
            try
            {
                dcScan = new ScanISIS();
                dcScan.scannerstate = new ScanState(this.GetScanState);
                // Make adjustments for controls that are not automatically laid out for RTL display.
                if (System.Threading.Thread.CurrentThread.CurrentCulture.TextInfo.IsRightToLeft)
                {
                    OrderGroupboxControlsForRTL(grpScanner);
                    OrderGroupboxControlsForRTL(grpEndorser);
                    OrderGroupboxControlsForRTL(grpStorage);
                    OrderRadioControlsForRTL(grpContrast.Controls[0], grpContrast.Controls[1], grpContrast.Width);
                    grpContrast.Controls[2].Left = grpContrast.Width - (grpContrast.Controls[2].Left + grpContrast.Controls[2].Width);
                    OrderRadioControlsForRTL(grpBrightness.Controls[0], grpBrightness.Controls[1], grpBrightness.Width);
                    grpBrightness.Controls[2].Left = grpBrightness.Width - (grpBrightness.Controls[2].Left + grpBrightness.Controls[2].Width);
                }
            }
            catch(Exception ex)
            {
                // string sMeg = ex.Message
                pWeb.aTM.WriteLogString(4, "ISISScan() : Exception Message : " + ex.Message);
            }
        }

        private void GetScanState(int st)
        {
            if (st == 1)
                bScanInProgress = true;
            else
                bScanInProgress = false;

            //UpdateScanControls();
            UpdateUI();

            if (bScanInProgress == false)
            {
                // when done, update the selection-dependent buttons like join, split, insert, etc
                XmlNode xPage;
                string sSelectedID = GetFirstSelectedPageID();
                xPage = xNodeByID(sSelectedID);
                if (xPage != null)
                    UpdateEnabledPositionDependent(xPage);

                Application.UseWaitCursor = false;
                Cursor.Current = Cursors.Default;
            }
            else
            {
                Application.UseWaitCursor = true;
                Cursor.Current = Cursors.WaitCursor;
            }
        }

       public override bool StartBatch()
        {
            bool bRes = base.StartBatch();
            ImageForm.Clear();
            dcScan.XBatch = dcTask.BatchXML;
            dcScan.BatchFolder = dcTask.BatchDir;
            dcScan.BatchID = dcTask.BatchID;
            dcScan.AppdataFolder = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData) + '\\' + "IBM";
            string taskoperator = dcTask.Operator;

            dcScan.SettingsFolder = "";
            dcScan.SettingsFile = "";

            BatchForm.SelectionChange -= new System.EventHandler(BatchForm_OnSelectionChange);
            BatchForm.SelectionChange += new System.EventHandler(BatchForm_OnSelectionChange);

            //172361 : On batchview drag drop, refresh thumbnail view. Attach event
            BatchForm.DragDropCompleted -= new System.EventHandler(BatchForm_OnDragDropCompleted);
            BatchForm.DragDropCompleted += new System.EventHandler(BatchForm_OnDragDropCompleted);

            BatchForm.TypeChange -= new System.EventHandler(BatchForm_OnTypeChange);
            BatchForm.TypeChange += new System.EventHandler(BatchForm_OnTypeChange);

            ImageForm.MoveImage -= new System.EventHandler(ImageForm_OnMoveImage);
            ImageForm.MoveImage += new System.EventHandler(ImageForm_OnMoveImage);

            Application.AddMessageFilter(this); // to catch keystrokes

            myTimer.Tick += new EventHandler(TimerEventProcessor);  // to handle timer callbacks for multi-file replace

            if (dcTask.sFPDSN != null)
            {
                bClassUpdateInProgress = true;
                bRes = LoadFingerprintDB(dcTask.sFPDSN, listPageClass);  // generate list of pagetypes, doctypes, HostIDs
                bClassUpdateInProgress = false;
            }

            init_statuses();                                    // initialize fixup globals, controls, settings, markers
            init_fixup_controls();                              // enable/show or disable/hide fixup related controls based on sCheckStructure flag
            populate_fixup_status(listPageStatus);
            populate_fixup_types(listPageType);

            XmlNode xBatch = dcTask.BatchXML.SelectSingleNode("B"); //??
            XmlNode xN = xBatch.SelectSingleNode("V[@n='ED']"); //??

            XmlNode xParent = dcTask.BatchXML.DocumentElement;
            XmlNode xLastPage = null;

            // start task with first page in batch selected
            if (xParent.SelectSingleNode("D") != null)
                xParent = xParent.SelectSingleNode("D[1]");
            xLastPage = xParent.SelectSingleNode("P[1]");

            try
            {
                if (xLastPage != null && xLastPage.Name == "P")
                {
                    BatchForm.SelectTreeNode(xLastPage.Attributes["id"].Value); // select the last page in batch 
                }
            }
            catch (Exception ex)
            {
                dcTask.WriteLog("StartBatch() : Error loading batch or image view: " + ex.Message);
            }

            // INITIALIZE SCANNING

            dcScan.addimagefile =  new ProcessImageFile(this.ProcessNewImageFile); // set callback fcn for scanning
            bUndoableRescan = dcTask.GetTaskSettingString("UndoableRescan").Equals("1") ? true : false;
            dcScan.UndoableRescan = bUndoableRescan;
            string scount = dcTask.GetTaskSettingString("ScanAheadCount");
            dcScan.ScanAheadCount = Convert.ToInt16(scount);
            sBarcodeSepValue = dcTask.GetTaskSettingString("BCSepValue");
            sBarcodeSepType = dcTask.GetTaskSettingString("BCSepType");
            string sTmp;
            sTmp = dcTask.GetTaskSettingString("BCEndDoc");
            if (sTmp == "1")
                bStartNewDocWithNextFrontImage = true;

            dcScan.writelogmsg = new WriteLogMsg(this.WriteISISLogMsg);
            try
            {
                string sUseBatchSettings = dcTask.GetTaskSettingString("UseBatchSettings");
                if (sUseBatchSettings != "1")
                {
                    // for use case where different scanner will pick up batch on hold
                    // we don't want to use previous batch settings
                    // so we delete them so dcscanisis won't load them
                    try
                    {
                        File.Delete(Path.Combine(dcTask.BatchDir, "scanisis.xml"));
                    }
                    catch (Exception ex)
                    {
                        pWeb.aTM.WriteLogString(4, "StartBatch() : Exception Message : " + ex.Message);
                    }
                }
                string sScannerSettingsFile = dcTask.GetTaskSettingString("ScannerSettingsFile");
                if (sScannerSettingsFile != "")
                {
                    dcScan.SettingsFile = Path.GetFileName(sScannerSettingsFile);
                    dcScan.SettingsFolder = Path.GetDirectoryName(sScannerSettingsFile);
                }

                if (dcScan.InitializeScanner())
                {
                    UpdateControls();
                }
            }
            catch (Exception ex)
            {
                dcTask.WriteLog("Scanner initialization exception " + ex.Message);
            }
            bScanInProgress = false;
            UpdateUI();
            ImageForm.savedThumbStateToggle = "";
            if (ImageForm.AreThumbsEnabled())
                ImageForm.LoadThumbs(GetFirstSelectedPageID(), true);
            btnScan.Focus();
            if (bCheckStructure) // go to first problem
            {
                textFixupMsg.Text = "";
                FindNextProblem(true, ref textFixupMsg);
            }
            return bRes;
        }

        //172361 : On batchview drag drop, refresh thumbnail view
        private void BatchForm_OnDragDropCompleted(Object src, EventArgs e)
        {
            XmlNode xPage = (XmlNode)src;
            //183312
            BatchForm.SelectTreeNode(xPage.Attributes["id"].Value);
            ImageForm.LoadThumbs(xPage.Attributes["id"].Value, true);
        }


        public override bool EndBatch(String Status)
        {
            Application.RemoveMessageFilter(this);
            myTimer.Tick -= TimerEventProcessor;
            if (bScanInProgress)
            {
                dcScan.CancelScan = true;
                System.Threading.Thread.Sleep(1000);
                bScanInProgress = false;
            }

            ImageForm.Clear();
            anchor_deinit();

            BatchForm.SelectionChange -= new System.EventHandler(BatchForm_OnSelectionChange);
            BatchForm.SelectionChange -= new System.EventHandler(BatchForm_OnSelectionChange);

            //172361 : On batchview drag drop, refresh thumbnail view. Detach
            BatchForm.DragDropCompleted -= new System.EventHandler(BatchForm_OnDragDropCompleted);

            BatchForm.TypeChange -= new System.EventHandler(BatchForm_OnTypeChange);
            BatchForm.TypeChange -= new System.EventHandler(BatchForm_OnTypeChange);

            ImageForm.MoveImage -= new System.EventHandler(ImageForm_OnMoveImage);
            ImageForm.MoveImage -= new System.EventHandler(ImageForm_OnMoveImage);

            return base.EndBatch(Status);
        }
       
        // Batch tree view selection was changed - update UI for newly selected page, doc, or batch node
        private void BatchForm_OnSelectionChange(Object src, EventArgs e)
        {
            bool bSelectedTypeChanged = false;  // do we need to repopulate "Type" dropdown?
            if (bSelChange_InProgress)
                return;
            textFixupMsg.Text = "";
            if (dcScan.ScanningInProgress)
            {
                bSuppressPageTypeChange = false;
                return;
            }
            bSelChange_InProgress = true;

            // FIXUP
            XmlNode pPage = (XmlNode)src;
            if (pPage.Name != "P" && pPage.Name != "D")
            {
                btnSplit.Enabled = false;
                btnJoin.Enabled = false;
                listPageType.Enabled = false;
                listPageStatus.Enabled = false;
                listPageClass.Enabled = false;
                bSelChange_InProgress = false;
                return;
            }

            listPageType.Enabled = true;
            listPageStatus.Enabled = true;
            listPageClass.Enabled = true;

            dcTask.WriteLog("SelChange: " + pPage.Attributes["id"].Value);
            dcTask.WriteLog("Old type: " + sSelectedDCOType + ", New type: " + pPage.Name);

            bSelectedTypeChanged = (sSelectedDCOType != pPage.Name);
            sSelectedDCOType = pPage.Name;  // P or D selected
            sSelectedIDs = pPage.Attributes["id"].Value;
            if (bSelectedTypeChanged)
            {
                populate_fixup_types(listPageType);
                populate_fixup_status(listPageStatus);
            }
            // 'comments'
            if (bCheckStructure)
            {
                XmlNode pNode = pPage.SelectSingleNode("V[@n='comments']");
                if (pNode != null)
                    textFixupMsg.Text = pNode.InnerText;
                else
                    textFixupMsg.Text = "";
            }

            if (pPage.Name == "P")
            {
                ImageForm.ImageSelect(pPage);
                if (ImageForm.AreThumbsEnabled())
                    ImageForm.LoadThumbs(pPage.Attributes["id"].Value, false);

                // display page type, page status
                // display FP class / hostname of this image
                int nSel;
                string sTemp;

                sTemp = pPage.SelectSingleNode("V[@n='TYPE']").InnerText;
                nSel = listPageType.FindStringExact(pWeb.GetTranslatedLabel("pagetype",sTemp));
                bSuppressPageTypeChange = true;
                listPageType.SelectedIndex = nSel;
                bSuppressPageTypeChange = false;

                sTemp = pPage.SelectSingleNode("V[@n='STATUS']").InnerText;
                update_status_control((int)Convert.ToInt16(sTemp), listPageStatus);

                // update page class if needed
                XmlNode pFPNode = pPage.SelectSingleNode("V[@n='TemplateID']");
                if (pFPNode != null)
                {
                    string sFPID = pFPNode.InnerText;
                    UpdatePageClass(pPage, sFPID);
                }
                else
                    UpdatePageClass(pPage, "");
            }
            else if (pPage.Name == "D")
            {
                // display doc type and status
                string sTemp = pPage.SelectSingleNode("V[@n='TYPE']").InnerText;
                int nSel = listPageType.FindStringExact(pWeb.GetTranslatedLabel("doctype", sTemp));
                bSuppressPageTypeChange = true;
                listPageType.SelectedIndex = nSel;
                bSuppressPageTypeChange = false;

                sTemp = pPage.SelectSingleNode("V[@n='STATUS']").InnerText;
                update_status_control((int)Convert.ToInt16(sTemp), listPageStatus);
                UpdatePageClass(pPage, "");
                // select first page in doc
            }

            BatchForm.ExpandAll();

            bSuppressPageTypeChange = false;

            XmlNode xPage = (XmlNode)src;

            UpdateEnabledPositionDependent(xPage);  // update the selection dependent buttons


            // if thumbnails enabled, and selected document is not currently displayed, display in thumbnails
            string sDocID = string.Empty;
            if (xPage.Name == "D") sDocID = xPage.Attributes["id"].Value;
            else if (xPage.Name == "P")
            {
                XmlNode xParent = xPage.ParentNode;
                if (xParent.Name == "D") sDocID = xParent.Attributes["id"].Value;
            }

            // done
            bSelChange_InProgress = false;
            return;
        }

        // update enabled status of Split, Join, MoveUp, MoveDn, and Insert
        void UpdateEnabledPositionDependent(XmlNode xPage)
        {
            if (xPage.Name != "P")
            {
                // if document selected, and not first, enable Join
                btnSplit.Enabled = false;
                btnMoveUp.Enabled = (xDocPrev(xPage) != null);
                btnJoin.Enabled = (xDocPrev(xPage) != null) && bJoinEnabled;
                btnMoveDn.Enabled = (xDocNext(xPage) != null);
                btnRemove.Enabled = false;  // if we allow deleting docs: (dcTask.BatchXML.SelectNodes(".//D").Count > 1);
                btnInsert.Enabled = (xDocPrev(xPage) != null);
            }
            else
            {
                int i;
                // Page selected, enable/disable controls as needed
                XmlNodeList xPages = dcTask.BatchXML.SelectNodes(".//P");
                for (i = 0; i < xPages.Count; i++)
                {
                    if (xPage == xPages[i])
                        break;
                }
                btnMoveDn.Enabled = (i > -1 && i < (xPages.Count-1));   // should be same as xPage.NextSibling?
                btnMoveUp.Enabled = (i > -1 && i > 0);
                btnRemove.Enabled = (xPages.Count > 1 && i > -1);
                btnRescan.Enabled = (txtScanner.Text != string.Empty) && (i > -1);
                btnInsert.Enabled = (txtScanner.Text != string.Empty) && (i > -1);
                XmlNode xPrev;
                for (xPrev = xPage.PreviousSibling; xPrev != null && xPrev.Name != "P" && xPrev.Name != "D"; xPrev = xPrev.PreviousSibling) ;
                btnSplit.Enabled = (i > 0 && xPrev != null && xPrev.Name == "P") && bSplitEnabled;
                XmlNode xParent = xPage.ParentNode;
                if (xParent == null || !IsDocNode(xParent) || xParent.PreviousSibling == null || xParent.PreviousSibling.Name != "D")
                    btnJoin.Enabled = false;
                else
                    btnJoin.Enabled = bJoinEnabled;
            }
        }
        public bool UpdatePageClass(XmlNode pPage, string sFPID)    // update FP class (hostname) given a selected FingerprintID
        {
            if (!bShowFPClass || listPageClass.Items.Count <= 0)
                return false;

            string sTemp = "";
            string sPageType = "";

            if (sPageClasses != null) for (int i = 0; i < sPageClasses.Length; i++)
                {
                    if (sPageClasses[i].spc_FPtemplateID != null)
                    {
                        for (int j = 0; j < sPageClasses[i].spc_FPtemplateID.Length; j++)
                        {
                            if (sPageClasses[i].spc_FPtemplateID[j].ToString() == sFPID)
                            {
                                sTemp = sPageClasses[i].spc_hostName;
                                sPageType = sPageClasses[i].spc_FPtemplateID[0];

                                bClassUpdateInProgress = true;
                                int nSel = listPageClass.FindStringExact(sTemp);
                                listPageClass.SelectedIndex = nSel >= 0 ? nSel : 0;     // 0 is the null class
                                bClassUpdateInProgress = false;

                                return true;
                            }
                        }
                    }
                }
            listPageClass.SelectedIndex = 0;
            return true;
        }

        private void BatchForm_OnTypeChange(Object src, EventArgs e)
        {
            // THIS IS NOT USED
            XmlNode xPage = (XmlNode)src;
            if (xPage.Name != "P")
                return;
            XmlNodeList xPages = dcTask.BatchXML.SelectNodes(".//P");
            int i = 0;
            for (i = 0; i < xPages.Count; i++)
            {
                if (xPage == xPages[i])
                    break;
            }
            ImageForm.SetThumbText(xPage.SelectSingleNode("V[@n='TYPE']").InnerText, i);
        }

        private void btnSelectScanner_Click(object sender, EventArgs e)
        {
            try
            {
                if (!dcScan.SelectScanner())
                    return;
            }
            catch (Exception ex)
            {
                ShowScanError(ex);
                return;
            }
            
            //save to user's appdatafolder
            // SaveSettings(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + '\\' + "IBM");
            
            txtScanner.Text = dcScan.ScannerName;

            UpdateControls();
            UpdateUI();
        }
               
        private void UpdateControls()
        {
            Cursor.Current = Cursors.WaitCursor;
            int index;
            txtScanner.Text = dcScan.ScannerName;
            UpdateScanControls();

            chkMultiple.Checked = dcScan.MultiCheck;
            txtExpected.Value = dcScan.Expectedpages;
            txtExpected.Enabled = dcScan.MultiCheck;

            cbPaperSource.Items.Clear();
            try
            {
                foreach (string source in dcScan.PaperSources)
                {
                    cbPaperSource.Items.Add(source);
                }
            }
            catch { return;  }
            index = -1;
            index = cbPaperSource.FindString(dcScan.PaperSource);
            cbPaperSource.SelectedIndex = (index == -1) ? 0 : index;

            cbDotsPerInch.Items.Clear();
            try
            {
                foreach (int dpi in dcScan.Resolutions)
                {
                    cbDotsPerInch.Items.Add(dpi.ToString());
                }
            }
            catch (Exception ex)
            {
                pWeb.aTM.WriteLogString(4, "UpdateControls() : Exception Message : " + ex.Message);
            }
            index = -1;
            index = cbDotsPerInch.FindString(dcScan.ResolutionXY.ToString());
            cbDotsPerInch.SelectedIndex = (index == -1) ? 0 : index;

            // Color
            cbColorMode.Items.Clear();
            List<string> colors = dcScan.ColFormats;
            foreach (string cols in colors)
            {
                cbColorMode.Items.Add(cols);
            }
            cbColorMode.Select();

            index = -1;
            index = cbColorMode.FindString(dcScan.ScanColorMode);
            cbColorMode.SelectedIndex = (index == -1) ? 0 : index;

            UpdateFileTypes();

            int min, max, step;
            // brightness
            rdoBrightnessAuto.Enabled = rdoBrightnessManual.Enabled = trackBrightness.Enabled = lblBrightnessVal.Visible = false;
            if (dcScan.GetBrightnessManual(out min, out max, out step))
            {
                int brightVal = dcScan.BrightnessValue;
                rdoBrightnessAuto.Enabled = (min < 0) ? true : false;

                if (max > 0)
                {
                    trackBrightness.Minimum = 0;
                    trackBrightness.Maximum = max;
                    rdoBrightnessManual.Enabled = true;
                    if (brightVal > 0)
                    {
                        trackBrightness.Value = brightVal;
                        rdoBrightnessManual.Checked = trackBrightness.Enabled = true;
                        lblBrightnessVal.Text = dcScan.BrightnessValue.ToString();
                        lblBrightnessVal.Visible = true;
                    }
                    else
                    {
                        rdoBrightnessAuto.Checked = true;
                        trackBrightness.Enabled = false;
                        lblBrightnessVal.Text = "";
                        lblBrightnessVal.Visible = false;
                    }
                }
                else
                {
                    rdoBrightnessManual.Checked = trackBrightness.Enabled = false;
                    rdoBrightnessManual.Enabled = lblBrightnessVal.Visible = false;
                }
            }

            // contrast
            rdoContrastAuto.Enabled = rdoContrastManual.Enabled = trackContrast.Enabled = lblContrastVal.Visible = false;
            if (dcScan.GetContrastManual(out min, out max, out step))
            {
                int contrastVal = dcScan.ContrastValue;
                rdoContrastAuto.Enabled = (min < 0) ? true : false;

                if (max > 0)
                {
                    trackContrast.Minimum = 0;
                    trackContrast.Maximum = max;
                    rdoContrastManual.Enabled = true;
                    if (contrastVal > 0)
                    {
                        trackContrast.Value = contrastVal;
                        rdoContrastManual.Checked = trackContrast.Enabled = true;
                        lblContrastVal.Text = dcScan.ContrastValue.ToString();
                        lblContrastVal.Visible = true;
                    }
                    else
                    {
                        rdoContrastAuto.Checked = true;
                        trackContrast.Enabled = false;
                        lblContrastVal.Text = "";
                        lblContrastVal.Visible = false;
                    }
                }
                else
                {
                    rdoContrastManual.Checked = trackContrast.Enabled = false;
                    rdoContrastManual.Enabled = lblContrastVal.Visible = false;
                }
            }

            // Endorser
            grpEndorser.Visible = false;
            int endorserCount = dcScan.EndorsersAvailable();
            if (endorserCount > 0)
            {
                grpEndorser.Visible = true;
                chkEndorseBatchID.Visible = chkEndorseBatchID.Enabled = true;
                txtEndorserFormat.Visible = txtEndorserFormat.Enabled =
                        lblEndorserFormat.Visible = lblEndorserFormat.Enabled = true;

                chkEndorseBatchID.Checked = dcScan.EndorseBatchID;
                txtEndorserFormat.Text = dcScan.EndorserFormatString;
            }       
            Cursor.Current = Cursors.Default;
        }

        private void UpdateFileTypes()
        {
            cbCompression.Enabled = cbFileType.Enabled = true;

            string oldFiletype = dcScan.FileType;

            cbFileType.Items.Clear();
            List<string> filetypes = dcScan.FileTypes;
            foreach (string ft in filetypes)
            {
                foreach (string type in dcfiletypes)
                {
                    if (ft.ToLower().Equals(type.ToLower()))
                    {
                        cbFileType.Items.Add(ft);
                        break;
                    }
                }
            }

            int id = -1;
            if (!oldFiletype.Equals(""))
            {
                if (dcScan.BitDepth > 1)
                {
                    foreach (string sft in cbFileType.Items)
                    {
                        if (sft.Equals(oldFiletype))
                        {
                            cbFileType.SelectedItem = sft;
                            id = cbFileType.SelectedIndex;
                            break;
                        }
                    }
                }
                else
                {
                    id = cbFileType.FindString("Tiff");
                    cbFileType.SelectedIndex = id;
                }
                if (id > -1)
                    dcScan.FileType = cbFileType.SelectedItem.ToString();
            }
            // Do default selection
           int index = -1;
            if (id == -1 && cbFileType.Items.Count != 0)
            {// default to JPEG, as most color images are expected to be stored as JPEG
                if (dcScan.BitDepth > 1)//|| dcScan.MultiStream)
                {
                    index = cbFileType.FindString("Jpeg");
                    cbFileType.SelectedIndex = index;  // default to JPEG, as most color images are expected to be stored as JPEG
                }
                else
                {
                    index = cbFileType.FindString("Tiff");
                    cbFileType.SelectedIndex = index;
                }
                if (index >= 0)
                    dcScan.FileType = cbFileType.SelectedItem.ToString();
            }
        }

        private void UpdateCompressions()
        {
            cbCompression.Items.Clear();
            List<string> compModes = new List<string>();
            string temp = "";
            if ( cbFileType.SelectedItem != null)
                temp = cbFileType.SelectedItem.ToString();
            if (temp != "")
            {
                dcScan.FileType = temp;
                compModes = dcScan.CompressionModes;

                if (compModes.Count > 0)
                {
                    foreach (string comp in compModes)
                    {
                        cbCompression.Items.Add(comp.ToString());
                    }
                    cbCompression.Select();
                    int index;
                    if (dcScan.BitDepth == 1)
                    {
                        index = cbCompression.FindString("G4");
                        cbCompression.SelectedIndex = index;
                    }
                    else
                    {
                        index = cbCompression.FindString(dcScan.Compression);
                        if (index >= 0)
                            cbCompression.SelectedIndex = index;
                        else
                        {
                            index = cbCompression.FindString("Jpeg");
                            if (index >= 0)
                                cbCompression.SelectedIndex = index;
                            else
                                cbCompression.SelectedIndex = 0;
                        }
                    }
                    dcScan.Compression = cbCompression.SelectedItem.ToString();
                }
            }
        }

        public void init_fixup_controls()
        {
            btnNextProb.Visible = btnNextProb.Enabled = bCheckStructure;
            textFixupMsg.Visible = bCheckStructure; // WAS also setting enabled, now always disabled
            lblComment.Visible = lblComment.Enabled = bCheckStructure;

            listPageClass.Visible = listPageClass.Enabled = bShowFPClass;
            lblClass.Visible = lblClass.Enabled = bShowFPClass;
        }
        private void btnCancel_Click(object sender, EventArgs e)
        {
            int nCount = dcTask.BatchXML.SelectNodes(".//P").Count;
            if (nCount > 0)
                if (MessageBox.Show(string.Format(Properties.Resources.msgConfirmCancel_Text, nCount),
                                    Properties.Resources.msgConfirmCance_Title, MessageBoxButtons.YesNo,
                                    MessageBoxIcon.None, MessageBoxDefaultButton.Button1, GetMsgRTL()) != DialogResult.Yes)
                    return;
            Status = "canceled";
            OnComplete(this, new TaskStatusEventArgs(Status));

        }

        void UpdateScanControls()
        {
            btnSelectScanner.Enabled = (dcScan.ScanningInProgress == false && bScanInProgress == false);
            btnScan.Enabled = btnRescan.Enabled =
                chkMultiple.Enabled = cbDotsPerInch.Enabled = btnConfigureScanner.Enabled =
                cbPaperSource.Enabled = cbColorMode.Enabled = (txtScanner.Text != string.Empty && dcScan.ScanningInProgress == false && bScanInProgress == false);

            if (txtScanner.Text != string.Empty && dcScan.ScanningInProgress == false && bScanInProgress == false)
            {
                string sID = BatchForm.GetSelID();
                if (sID == "")
                {
                    btnMoveDn.Enabled = btnMoveUp.Enabled = btnInsert.Enabled = btnRescan.Enabled = btnRemove.Enabled = btnOpen.Enabled = false;
                }
                else
                {
                    btnRescan.Enabled = btnRemove.Enabled = btnOpen.Enabled = true;
                    // need to determine from selected page, whether Insert, MoveUp or MoveDown are enabled.
                    // btnMoveDn.Enabled = btnMoveUp.Enabled = btnInsert.Enabled = 
                }
            }
        }

        void UpdateUI()
        {
            if (txtScanner.Text == string.Empty)
            {
                btnScan.Enabled = btnRescan.Enabled = btnConfigureScanner.Enabled = cbCompression.Enabled =
                cbPaperSource.Enabled =
                cbFileType.Enabled = btnInsert.Enabled =
                chkMultiple.Enabled = txtExpected.Enabled = cbDotsPerInch.Enabled =
                trackBrightness.Enabled = trackContrast.Enabled =
                rdoBrightnessAuto.Enabled = rdoBrightnessManual.Enabled =
                rdoContrastAuto.Enabled = rdoContrastManual.Enabled = cbColorMode.Enabled = false;
                return;
            }

            UpdateScanControls();

            cbColorMode.Enabled = !dcScan.MultiStream;
            if (this.menuStrip1.Items.Count > 1)
                this.menuStrip1.Items.RemoveAt(1);
            string fname = Path.GetFileNameWithoutExtension(dcScan.SettingsFile);
            if (fname != "" && fname != "scanisis")
                this.menuStrip1.Items.Add(fname);

            // Page selected, enable/disable controls as needed

            btnSTOPScan.Enabled = bScanInProgress;
            btnOpen.Enabled = !bScanInProgress;
            btnRemove.Enabled = !bScanInProgress;
            btnCancel.Enabled = !bScanInProgress;
            btnFinish.Enabled = !bScanInProgress;

            cbCompression.Enabled = cbFileType.Enabled = (!bScanInProgress && dcScan.BitDepth > 1);

            if (dcTask.BatchXML.SelectNodes(".//P").Count == 0)
                btnSplit.Enabled = btnJoin.Enabled = false;
        }

        private void ShowScanError(Exception ex)
        {
            string xmsg = string.Format(Properties.Resources.msgScannerError, ex.Message, ex.InnerException == null ? "" : ex.InnerException.Message);
            MessageBox.Show(xmsg, Properties.Resources.titleScannerError, MessageBoxButtons.OK,
                            MessageBoxIcon.None, MessageBoxDefaultButton.Button1, GetMsgRTL());
            dcTask.WriteLog(xmsg);
        }

        private void btnScan_Click(object sender, EventArgs e)
        {
            dcScan.RescanImage = false;
            dcScan.MultiCheck = chkMultiple.Checked;
            dcScan.Expectedpages = (int)txtExpected.Value;
            int numpages = dcTask.BatchXML.SelectNodes(".//P").Count;
            if (chkMultiple.Checked && dcScan.Expectedpages > 0 && numpages >= dcScan.Expectedpages)
            {
                MessageBox.Show(string.Format(Properties.Resources.msgExpectedNumberinBatch_Text), string.Format(Properties.Resources.titleNoScan_Title),
                                MessageBoxButtons.OK, MessageBoxIcon.None, MessageBoxDefaultButton.Button1, GetMsgRTL());
                return;
            }
            UpdateUI();
            btnSTOPScan.Enabled = true;
            insertMode = false;

            try
            {
                dcScan.ScanAhead = true;
                dcScan.ImageInsertPosition = -1; // lstImages.SelectedIndices.Count > 0 ? lstImages.SelectedIndices[0] : -1;
                // dcTask.WriteLog("Start scanning");
                dcScan.StartScanning(true);
                // dcTask.WriteLog("Returned from scanning");
            }
            catch (Exception ex)
            {
                ShowScanError(ex);
            }
            //SaveSettings(dcTask.BatchDir);
            UpdateUI();
        }


        private void btnConfigureScanner_Click(object sender, EventArgs e)
        {
            try
            {
                if (dcScan.ConfigureScanner(this.Handle))
                {
                    UpdateControls();
                    UpdateUI();
                }
            }
            catch (Exception ex)
            {
                pWeb.aTM.WriteLogString(4, "btnConfigureScanner_Click() : Exception Message : " + ex.Message);
            }
        }

        private void btnMoveUp_Click(object sender, EventArgs e)
        {
            MoveUp();
        }

        private void btnMoveDn_Click(object sender, EventArgs e)
        {
            MoveDown();
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            RemoveSelectedImages();
        }

        private void cbFileType_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateCompressions();
        }

        private void cbCompression_SelectedIndexChanged(object sender, EventArgs e)
        {
            string temp = cbCompression.SelectedItem.ToString();
            if (temp != null)
            {
                dcScan.Compression = temp;
            }
        }


        private void btnRescan_Click(object sender, EventArgs e)
        {
            // REPLACE button clicked

            sRescanIDs = BatchForm.GetSelID();

            numRescanPages = sRescanIDs.Split(',').Length;
            string nName = "";
            nName = xNodeByID(sRescanIDs.Split(',')[0]).Name;
            if (nName != "P")
            {
                dcTask.WriteLog("ISISPanel:btnRescan_Click: Need to select a page (P) for Replace.  Selected node was a " + nName);
                return;
            }
            rescanCount = 0;
            undopageID = "";
            dcTask.WriteLog("ISISPanel:Rescan_Click: Images selected for Replace: " + sRescanIDs);
            // looks like rescan does not remove the page (and associated files), but overwrites.  Need to delete associated if we are in fixup.
            try
            {
                // ImageForm.Clear();
                UpdateUI();
                btnSTOPScan.Enabled = true;
                dcScan.RescanImage = true;
                //dcScan.Expectedpages = 1;  // don't do this here, it will change the Expectedpages val
                dcScan.ImageInsertPosition = GetSelectedPagePosition();
                sRescanPageType = GetSelectedPageType();

                Cursor.Current = Cursors.WaitCursor;
                // dcTask.WriteLog("Start rescanning");
                dcScan.StartScanning(true);
                // dcTask.WriteLog("Returned from rescanning");
                UpdateUI();
            }
            catch { }
        }

        private void cbPaperSource_SelectedIndexChanged(object sender, EventArgs e)
        {
            dcScan.PaperSource = cbPaperSource.SelectedItem.ToString();
        }

        private void cbDotsPerInch_SelectedIndexChanged(object sender, EventArgs e)
        {
            dcScan.ResolutionXY = Convert.ToInt32(cbDotsPerInch.SelectedItem.ToString());
        }

        private void trackBrightness_Scroll(object sender, EventArgs e)
        {
            dcScan.BrightnessValue = trackBrightness.Value;
            lblBrightnessVal.Text = trackBrightness.Value.ToString();
        }

        private void rdoBrightnessAuto_CheckedChanged(object sender, EventArgs e)
        {
            trackBrightness.Enabled = lblBrightnessVal.Visible = rdoBrightnessManual.Checked;

            if (rdoBrightnessAuto.Checked)
                dcScan.BrightnessAuto = true;
            else
                dcScan.BrightnessValue = trackBrightness.Value;
        }

        private void rdoContrastAuto_CheckedChanged(object sender, EventArgs e)
        {
            trackContrast.Enabled = lblContrastVal.Visible = rdoContrastManual.Checked;
        }

        private void trackContrast_Scroll(object sender, EventArgs e)
        {
            dcScan.ContrastValue = trackContrast.Value;
            lblContrastVal.Text = trackContrast.Value.ToString();
        }

        bool insertMode = false;
        XmlNode xRefNode = null;
        private void btnInsert_Click(object sender, EventArgs e)
        {
            UpdateUI();
            dcScan.RescanImage = false;
            btnSTOPScan.Enabled = true;
            insertMode = true;
            dcScan.ScanAhead = true;

            //dcScan.ImageInsertPosition = lstImages.SelectedIndices.Count > 0 ? lstImages.SelectedIndices[0] : -1;
            string sSelectedID = GetFirstSelectedPageID();
            xRefNode = xNodeByID(sSelectedID);
            dcScan.ImageInsertPosition = GetSelectedPagePosition();
            dcScan.Expectedpages = (int)txtExpected.Value;
            // dcTask.WriteLog("Start insert scanning");
            dcScan.StartScanning(true);
            // dcTask.WriteLog("Returned from insert scanning");
            UpdateUI();
        }

        // drag and drop?
        private void ImageForm_OnMoveImage(Object src, EventArgs e)
        {
            int nFrom = ((Size)src).Width;
            int nTo = ((Size)src).Height;
            MoveImage(nFrom, nTo);
        }

        public bool SaveSettings(string foldername)
        {
            dcTask.WriteLog("Save scanner settings to: " + foldername); // TODO - add filename dcScan.SettingsFile
            try
            {
                dcScan.SaveScannerConfigToXML(foldername);
            }
            catch (Exception ex)
            {
                dcTask.WriteLog("SaveSettings() : Save failed: " + ex.Message);
            }
            return true;
        }

        public bool LoadSettings(string foldername, string filename)
        {
            dcTask.WriteLog("Load scanner settings from: " + foldername + " file: " + filename);

            dcScan.SettingsFolder = foldername;
            // if (filename != "")
            //    dcScan.SettingsFile = filename;
            try
            {
                if (dcScan.LoadSavedScannerConfig())
                {
                    //if (this.menuStrip1.Items.Count > 1)
                    //    this.menuStrip1.Items.RemoveAt(1);
                    //if (filename != "")
                    //    this.menuStrip1.Items.Add(filename);
                    UpdateControls();
                    UpdateUI();
                    return true;
                }
            }
            catch (Exception ex)
            {
                dcTask.WriteLog("LoadSettings() : Load failed: " + ex.Message);
            }
            // log here
            return false;
        }

        private void saveUnderBatchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveSettings(dcTask.BatchDir);
        }

        private void saveUserSettingsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string userAppdataFolder = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + '\\' + "IBM";
            SaveSettings(userAppdataFolder);
        }

        private void saveAsStationSettingsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string allAppdataFolder = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData) + '\\' + "IBM";
            SaveSettings(allAppdataFolder);
        }

        private void loadBatchSettingsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LoadSettings(dcTask.BatchDir, "Batch");
        }

        private void loadUserSettingsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string userAppdataFolder = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + '\\' + "IBM";
            LoadSettings(userAppdataFolder, "User");
        }

        private void loadStationSettingsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string allAppdataFolder = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData) + '\\' + "IBM";
            LoadSettings(allAppdataFolder, "Station");
        }

        private void chkEndorseBatchID_CheckedChanged(object sender, EventArgs e)
        {
            dcScan.EndorseBatchID = chkEndorseBatchID.Checked;
        }

        private void saveAsCustomSettingsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string filename = "";
            SaveFileDialog saveFileDlg = new SaveFileDialog();
            saveFileDlg.Filter = "XML files (*.xml)|*.xml";
            saveFileDlg.FilterIndex = 0;
            saveFileDlg.DefaultExt = "xml";
            saveFileDlg.RestoreDirectory = true;
            saveFileDlg.AddExtension = true;
            saveFileDlg.InitialDirectory = @"C:/";
            saveFileDlg.FileName = null;
            saveFileDlg.Title = Properties.Resources.dlgSaveCustomScan_Title;

            if (saveFileDlg.ShowDialog() == DialogResult.OK)
            {
                filename = saveFileDlg.FileName;
                dcScan.SettingsFile = Path.GetFileName(filename);
                SaveSettings(Path.GetDirectoryName(filename));
            }
        }

        private void loadCustomSettingsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string filename = "";
            OpenFileDialog openFileDlg = new OpenFileDialog();
            openFileDlg.Filter = "XML files (*.xml)|*.xml";
            openFileDlg.DefaultExt = "xml";
            openFileDlg.FilterIndex = 0;
            openFileDlg.RestoreDirectory = true;
            openFileDlg.InitialDirectory = @"C:/";
            openFileDlg.FileName = null;
            openFileDlg.Title = Properties.Resources.dlgLoadCustomScan_Title;

            if (openFileDlg.ShowDialog() == DialogResult.OK)
            {
                filename = openFileDlg.FileName;
                dcScan.SettingsFile = Path.GetFileName(filename);
                LoadSettings(Path.GetDirectoryName(filename), Path.GetFileName(filename));
                string dest = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + '\\' + "IBM", "scanisis.xml");
                File.Copy(filename, dest, true);
            }
        }


        // Finish clicked 
        // validate batch
        // must have at least one page
        // if structure invalid, put on hold
        private void btnFinish_Click(object sender, EventArgs e)
        {
            FinishClick(textFixupMsg);
        }

        // Delete page or doc
        private void btn_Delete_Click(object sender, EventArgs e)
        {
            RemoveSelectedImages();
        }

        private void btnNextProb_Click(object sender, EventArgs e)
        {
            // clear the Comment field
            textFixupMsg.Text = "";
            FindNextProblem(true, ref textFixupMsg);
        }

        private void btnHold_Click(object sender, EventArgs e)
        {
            Status = "hold";
            OnComplete(this, new TaskStatusEventArgs(Status));
        }

        private bool CheckCount()
        {
            bool bIsValid = true;
            string msg = "";

            if (bCheckCount != true)
                return bIsValid;

            int nDocs = dcTask.BatchXML.DocumentElement.SelectNodes("D").Count;
            int nPages = dcTask.BatchXML.DocumentElement.SelectNodes("P").Count;

            if (nAD > 0)
            {
                if (nDocs != nAD)
                {
                    msg = "Doc count: " + nDocs + " does not match adjusted: " + nAD;
                }
            }
            else if (nED > 0)
            {
                if (nDocs != nED)
                {
                    msg = "Doc count: " + nDocs + " does not match expected: " + nED;
                }
            }

            if (nAP > 0)
            {
                if (nPages != nAP)
                {
                    if (msg != "")
                    {
                        msg = msg + "\n" + "Page count: " + nPages + " does not match adjusted: " + nAP;
                    }
                    else
                    {
                        msg = "Page count " + nPages + " does not match adjusted " + nAP;
                    }
                }
            }
            else
            {
                if (nEP > 0)
                {
                    if (nPages != nEP)
                    {
                        if (msg != "")
                        {
                            msg = msg + "\n" + "Page count: " + nPages + " does not match expected: " + nEP;
                        }
                        else
                        {
                            msg = "Page count " + nPages + " does not match expected " + nEP;
                        }
                    }
                }
            }

            if (msg == "")
                return bIsValid;
            bIsValid = false;
            /*
	msg = msg & vbCrlf & vbCrlf & "*** Set adjusted counts to actual? ***"
	
	retn = CInt(blockMsgBox(msg, 1, "Reset Count")) ' buttons: OK (reset) or Cancel (don't reset)
	
	If retn = 1 Then	' user clicked OK
		Pilot.ExpectedDocs = nD ' set in Engine DB tmbatch table
		Pilot.ExpectedPages = nP

		DCO.Variable("AD") = nD
		DCO.Variable("AP") = nP
'		Pilot.SaveData(DCO) ' saves data from controls to memory
'		DCO.Write(Pilot.DCOFile) would write out to batch, not needed
		' DCO is automatically written at end of batch		
		WriteLog("Override, setting Adjusted Docs/Pages = Expected Docs/Pages")
		WriteLog("Adjusted Docs set to: " & nD)
		WriteLog("Adjusted Pages set to: " & nP)
		CheckCount = True
	End If
             * */

            return bIsValid;
        }


        private void listPageStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            // update page or doc status in Batch runtime XML
            string sID = BatchForm.GetSelID();
            int nSel = CountSelected();
            if (nSel != 1)
                return;
            XmlNode pNode = dcTask.BatchXML.SelectSingleNode(".//*[@id='" + sID + "']");
            if (pNode == null) return;
            string sStatus = listPageStatus.Text;
            int nStatus = LookupIntStatus(sStatus);
            if (nStatus > -1)
            {
                XmlNode pStatusNode = pNode.SelectSingleNode("V[@n='STATUS']");
                if (pStatusNode != null)
                    pStatusNode.InnerText = nStatus.ToString();
            }
        }

        // User updated page class via combo
        private void listPageClass_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (bClassUpdateInProgress)
                return;

            string sID = sSelectedIDs;  // last selected node ID from batch tree - page or doc
            if (sID == "")
                return;

            XmlNode xPage = dcTask.BatchXML.SelectSingleNode(".//*[@id='" + sID + "']"); //  XML node in runtime DCO
            if (xPage == null || xPage.Name != "P")
            {
                bClassUpdateInProgress = true;
                listPageClass.SelectedIndex = 0;    // clear it
                bClassUpdateInProgress = false;
                return;
            }
            string sNewClass = listPageClass.Text;
            sNewClass = pWeb.GetUnTranslatedLabel("doctype", sNewClass);

            if (sNewClass == "")
            {
                XmlNode xTemplateVar = xPage.SelectSingleNode("V[@n='TemplateID']");
                if (xTemplateVar == null)
                    return;
                xPage.RemoveChild(xTemplateVar);
            }
            else
            {
                // given new page type
                // find (first) matching fingerprint ID and set TemplateID variable in XML along with page type
                // sPageClasses pPageClass;
                ReplacePageClass(xPage, sNewClass);
            }
        }

        // user changed class selection - now update the page FPID and page type as well as updating the page type displayed
        public bool ReplacePageClass(XmlNode xPage, string sNewClass)
        {
            // find any/all FPs that match this page class
            string sFPID = First_FPID_from_FPClass(sNewClass);
            // then update the FP (TemplateID) with a matching one
            if (sFPID == "")
                return false;     // this should not be possible
            XmlNode xTemplateVar = xPage.SelectSingleNode("V[@n='TemplateID']");
            if (xTemplateVar == null)
            {
                XmlElement xVar = (XmlElement)dcTask.BatchXML.CreateElement("V");
                xVar.SetAttribute("n", "TemplateID");
                xVar.InnerText = sFPID;
                xPage.AppendChild(xVar);
            }
            else
                xTemplateVar.InnerText = sFPID;

            // might need to find pagetype for this FP and set if different?? not done in ifixup.
            return true;
        }

        private void listPageType_SelectionChangeCommitted(object sender, EventArgs e)  // page/doc type dropdown new selection BY the USER
        {
            // only works for combo box not list box
        }

        private bool bSuppressPageTypeChange = false;
        private void listPageType_SelectedIndexChanged(object sender, EventArgs e)  // page/doc type dropdown new selection
        {
            if (bSuppressPageTypeChange)
            {
                bSuppressPageTypeChange = false;
                return;
            }

            // update page or doc type in Batch runtime XML
            string sID = BatchForm.GetSelID();

            XmlNode pNode = dcTask.BatchXML.SelectSingleNode(".//*[@id='" + sID + "']");
            if (pNode == null)
                return;
            string sNewType = listPageType.Text;
            string sNewType_u = pWeb.GetUnTranslatedLabel("pagetype", sNewType);
            XmlNode xTmp = pNode.SelectSingleNode("V[@n='TYPE']");
            string sOldType = "";
            if (xTmp != null)
                sOldType = xTmp.InnerText;
            dcTask.WriteLog("Type change? ID=" + sID + " old=" + sOldType + " new=" + sNewType_u);
            if (sOldType == sNewType_u)
                return;
            pNode.SelectSingleNode("V[@n='TYPE']").InnerText = sNewType_u;    // update type in batch XML
            if (pNode.SelectSingleNode("V[@n='DATAFILE']") != null)
                pNode.RemoveChild(pNode.SelectSingleNode("V[@n='DATAFILE']"));  // remove data if pagetype changed

            if (pNode.Name == "P")
            {
                string sFname = ImageFilePath(pNode);
                Delete_Page_AuxFiles(sFname, false);
            }
            // must either reload batch tree or update the tree node as in cmbType_SelectedIndexChanged()            
            //BatchForm.LoadBatch(sID);
            BatchForm.UpdateNode(pNode);
            ImageForm.LoadThumbs(GetFirstSelectedPageID(), false);       //defect 56102

        }

        private int LookupIntStatus(string sStatus)
        {
            if (sSelectedDCOType == "P")
            {
                foreach (tStatus pStatus in sPageStatuses)
                {
                    if (pStatus.sStatus == sStatus)
                        return (pStatus.nStatus);
                }
            }
            else
            {
                foreach (tStatus pStatus in sDocStatuses)
                {
                    if (pStatus.sStatus == sStatus)
                        return (pStatus.nStatus);
                }
            }
            return (-1);
        }

        private void btnRotateLeft_Click(object sender, EventArgs e)
        {
            Rotate_Selected(270);
        }


        private void btnRotateRight_Click(object sender, EventArgs e)
        {
            Rotate_Selected(90);
        }

        private void btnFlip_Click(object sender, EventArgs e)
        {
            Rotate_Selected(180);
        }

        private void btnJoin_Click(object sender, EventArgs e)
        {
            JoinHere();
        }

        private void btnSplit_Click(object sender, EventArgs e)
        {
            SplitHere();
        }

        private void btnSTOPScan_Click(object sender, EventArgs e)
        {
            dcScan.CancelScan = true;
        }

        private void cbColorMode_SelectedIndexChanged(object sender, EventArgs e)
        {
            string temp = "";
            if (cbColorMode.SelectedItem != null)
                temp = cbColorMode.SelectedItem.ToString();
            if (temp != "")
            {
                dcScan.ScanColorMode = temp;
            }
            else
                return;

            UpdateFileTypes();
            UpdateCompressions();
            UpdateUI();
            cbColorMode.Focus();
        }

        private void btnOpen_Click(object sender, EventArgs e)
        {
            ImportFile();  // call base class
        }

         const bool FASTENOUGH = true;
         const bool FASTENOUGH2 = false;

        //private void ProcessNewImageFile(XmlElement xPage, int insertPos, string[] listitems)
        private void ProcessNewImageFile(XmlElement xPage, int insertPos)
        {
            dcTask.WriteLog("ProcessNewImage " + xPage.Attributes["id"].Value);

            if (dcScan.RescanImage)
            {
                // single page rescanned
                if (!sRescanPageType.Equals("Other"))
                {
                    xPage.SelectSingleNode("V[@n='TYPE']").InnerText = sRescanPageType;
                    string sFname = ImageFilePath(xPage);
                    if (!bUndoableRescan)
                        Delete_Page_AuxFiles(sFname, true);
                }

                ImageForm.RemoveAt(insertPos);
                string sNewPath = Path.Combine(dcScan.BatchFolder, xPage.SelectSingleNode("V[@n='IMAGEFILE']").InnerText);
                ImageForm.InsertAt(sNewPath, insertPos);    // this puts the thumbnail in (??!)

                dcTask.WriteLog("Replaced IMAGEFILE " + xPage.SelectSingleNode("V[@n='IMAGEFILE']").InnerText);

                ImageForm.LoadThumbs(xPage.Attributes["id"].Value, false);
                ImageForm.SetThumbText(xPage.SelectSingleNode("V[@n='TYPE']").InnerText, insertPos);

                if (sRescanIDs.IndexOf(",") > -1)
                {
                    rescanCount++;
                    if (rescanCount == numRescanPages)
                    {
                        dcScan.ImageInsertPosition -= rescanCount - 1;
                        rescanCount = 0;
                    }
                    else
                        dcScan.ImageInsertPosition++;
                    // setup a callback timer to process once the scanner is available
                    myTimer.Interval = 100;// Sets the timer interval to .1 seconds.
                    myTimer.Enabled = true;
                    return;
                }

                //dcScan.RescanImage = false;
                //sRescanIDs = "";
                Cursor.Current = Cursors.Default;
                dcTask.WriteLog("ISISPanel: ProcessNewImage: Rescan End");
                return;
            }

            XmlNode xParent = null;
            if (insertMode)
            {
                // insert page where selection
                if (IsDocNode(xRefNode))
                {
                    // add to end of previous document
                    xParent = xDocPrev(xRefNode);
                    if (xParent == null)
                        return;
                    xParent.AppendChild(xPage);
                }
                else
                {
                    xParent = xRefNode.ParentNode;
                    xParent.InsertBefore(xPage, xRefNode);
                }

            }
            else
            {
                xParent = dcTask.BatchXML.DocumentElement;
                // not insert to mid batch - append to end of batch
                if (xParent.SelectSingleNode("D") != null)
                    xParent = xParent.SelectSingleNode("D[last()]");
                xParent.AppendChild(xPage);

            }
            dcTask.WriteLog("Scan IMAGEFILE " + xPage.SelectSingleNode("V[@n='IMAGEFILE']").InnerText);
            BatchForm.DeselectTreeNodes();
            BatchForm.SelectTreeNode(xPage.Attributes["id"].Value);
            if (!sBarcodeSepValue.Equals("") || !sBarcodeSepType.Equals("") || bStartNewDocNext)   // if barcode separator value/type provided in task settings
            {
                if (StartNewDoc(xPage, xParent))    // compare with scanner read barcode and create new document if needed
                    dcTask.WriteLog("ISISPanel: ProcessNewImage: Started new Doc");
            }
            ImageForm.AddPage(xPage);
            BatchForm.AddPage(xPage);
        }


        // This is the method to run when the timer is raised.
        private void TimerEventProcessor(Object myObject, EventArgs myEventArgs)
        {
            myTimer.Stop();

            if (dcScan.ScanningInProgress || bScanInProgress)
            {
                myTimer.Enabled = true;
                return;
            }

            for (int iComma = sRescanIDs.IndexOf(","); iComma > -1; iComma = sRescanIDs.IndexOf(","))
            {
                //  more selected images to rescan (multiple rescan)
                sRescanIDs = sRescanIDs.Substring(iComma + 1);
                int iNextComma = sRescanIDs.IndexOf(",");
                string sID = (iNextComma > -1) ? sRescanIDs.Substring(0, iNextComma) : sRescanIDs;
                XmlNode xNextRescanPage = xNodeByID(sID);
                if (xNextRescanPage == null || !IsPageNode(xNextRescanPage))
                    continue;
                dcScan.ImageInsertPosition = GetxPagePosition(xNextRescanPage);
                if (dcScan.ImageInsertPosition == 0)
                    continue;
                btnSTOPScan.Enabled = true;
                dcScan.RescanImage = true;
                // dcTask.WriteLog("Start timer rescan scanning");
                dcScan.StartScanning(true);
                // dcTask.WriteLog("Return from timer scanning");
                UpdateUI();
                Cursor.Current = Cursors.Default;
                return;
            }
        }

        private bool StartNewDoc(XmlNode xPage, XmlNode xParent)
        {
            bool bStartDocNow = false;
            if (dcTask.BatchXML.SelectNodes(".//P").Count == 1)
                return false;

            if (bStartNewDocNext)
            {
                XmlNode xSide = xPage.SelectSingleNode("V[@n='Side']");
                if (xSide.InnerText.Equals("Back"))                        // ignore the reverse of the bar/patch code
                    return false;
            }
            else
            {
                XmlNode xnum = xPage.SelectSingleNode("V[@n='NumBarcodes']");
                int num = 0;
                if (xnum == null)
                    return false;
                else
                    num = Convert.ToInt16(xnum.InnerText);

                XmlNode xbc = null;
                XmlNode xbctype = null;

                if (num == 0)
                    return false;
                else
                {
                    for (int i = 0; i < num; i++)
                    {
                        xbc = xPage.SelectSingleNode("V[@n='GetBarcode" + i + "']");
                        xbctype = xPage.SelectSingleNode("V[@n='CodeName" + i + "']");
                        if (xbc.InnerText.Equals(sBarcodeSepValue, StringComparison.CurrentCultureIgnoreCase)
                                || xbctype.InnerText.Equals(sBarcodeSepType, StringComparison.CurrentCultureIgnoreCase))
                        {
                            if (bStartNewDocWithNextFrontImage == true)
                            {
                                bStartNewDocNext = true;
                                return false;
                            }
                            bStartDocNow = true;

                            break;
                        }
                    }
                }
            }

            if (bStartDocNow || bStartNewDocNext)
            {
                XmlElement xNewDoc = (XmlElement)dcTask.BatchXML.CreateElement("D");
                xNewDoc.SetAttribute("id", "new");
                XmlElement xTmp = dcTask.BatchXML.CreateElement("V");
                xTmp.SetAttribute("n", "TYPE");
                xTmp.InnerText = "";
                xNewDoc.AppendChild(xTmp);
                xTmp = dcTask.BatchXML.CreateElement("V");
                xTmp.SetAttribute("n", "STATUS");
                xTmp.InnerText = "0";
                xNewDoc.AppendChild(xTmp);
                xNewDoc = (XmlElement)dcTask.BatchXML.DocumentElement.InsertAfter(xNewDoc, xParent);
                xNewDoc.AppendChild(xPage);

                XmlNodeList xDocs = dcTask.BatchXML.SelectNodes(".//D");
                int nId = 0;
                foreach (XmlNode xDoc in xDocs)
                {
                    nId++;
                    string sNewID = nId.ToString();
                    while (sNewID.Length < 2)
                        sNewID = "0" + sNewID;
                    sNewID = dcTask.BatchID + "." + sNewID;
                    xDoc.Attributes["id"].Value = sNewID;
                }
                BatchForm.LoadBatch(xPage.Attributes["id"].Value);

                bStartDocNow = false;
                bStartNewDocNext = false;

                return true;
            }

            return false;
        }

        public string sMarkID = "";
        bool bInReview = false;

        private void MarkPageReview(string asComment)
        {
            // user hit hotkey - either display dropdown list; or update batch XML with new comment and disable dropdown list
            if (bCheckStructure == false)
                return;
            if (bInReview)
            {
                // update the comment in the fixup message and batch XML
                string sComment = cbxMarkList.Text;
                textFixupMsg.Visible = true;
                textFixupMsg.Text = sComment;
                cbxMarkList.Enabled = false;
                cbxMarkList.Visible = false;
                BatchForm.FlagNodeComment(sComment, GetFirstSelectedPageID());   // set the comment variable in the batch XML
                bInReview = false;
                BatchForm.SetBatchFocus();  // for OCC issue 80
                return;
            }
            bInReview = true;
            string sID = GetFirstSelectedPageID();
            XmlNode xNode = xNodeByID(sID);
            if (xNode == null || !IsPageNode(xNode))
                return;

            // DPS[0] is "mark for review" status by convention
            BatchForm.FlagNodeStatus(0, sID);   // flag page for review
            string sStatus = xNode.SelectSingleNode("V[@n='STATUS']").InnerText; // get numeric value DPS[0] that was just set
            update_status_control(Convert.ToInt32(sStatus), listPageStatus);  // update page status dropdown value

            if (pPageMarker == null || pPageMarker.Length < 1)
                return;

            sMarkID = sID;
            // display dropdown list of possible comments
            // textFixupMsg.Enabled = false;
            textFixupMsg.Visible = false;
            cbxMarkList.Enabled = true;
            cbxMarkList.Visible = true;
            // get string to mark by displaying dropdown list
            cbxMarkList.Items.Clear();
            cbxMarkList.Text = "";
            foreach (tStatus sMarker in pPageMarker)
            {
                cbxMarkList.Items.Add(sMarker.sStatus);
                if (sMarker.sStatus == asComment)
                    cbxMarkList.SelectedText = asComment;
            }
            cbxMarkList.Select();
            cbxMarkList.Focus();
        }

        private void cbxMarkList_SelectedIndexChanged(object sender, EventArgs e)
        {
        }
        private void cbxMarkList_LostFocus(object sender, EventArgs e)
        {
            // dcTask.WriteLog("Comment lost focus");
        }
        private void cbxMarkList_TextChanged(object sender, EventArgs e)
        {
            // dcTask.WriteLog("Comment text changed");
        }

        private void settingsToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        public bool PreFilterMessage(ref Message m)
        {
            if (m.Msg == 256) // WM_KEYDOWN
            {
                // handle hotkeys to set pagetype, switch to batch tree view, etc
                // return true if this key has been handled, false if we want to pass it along

                if ((Control.ModifierKeys & (Keys.Control | Keys.Alt | Keys.Shift)) == 0)    // No ctrl/Alt/Shift held down
                {
                    switch ((int)m.WParam)
                    {
                        case (int)Keys.F6:
                            if(!bScanInProgress)
                                btnFinish_Click(null, null);
                            return true;
                        case (int)Keys.F5:
                            RefreshUI();
                            UpdateScanControls();
                            return true;
                        case (int)Keys.Left:       // Left Arrow
                            if (BatchForm.ContainsFocus)
                                return true;        // causes crash in batch view
                            break;
                        case (int)Keys.Right:       // Right Arrow
                            if (BatchForm.ContainsFocus)
                                return true;        // causes crash in batch view
                            break;
                        // Handled in Imageform
                        //case (int)Keys.Delete:       // Delete = Remove image
                        //    //if (btnRemove.Enabled) // 172362 - when user clicks on delete button from batchview
                        //       // btnRemove_Click(null, null);
                        //    return true;
                        case (int)Keys.Insert:       // Insert = Insert scanned images
                            if (btnInsert.Enabled)
                                btnInsert_Click(null, null);
                            return true;
                    }
                }

                const int VK_CONTROL = 0x11;        // control keycode


                if ((Control.ModifierKeys & (Keys.Control | Keys.Alt | Keys.Shift)) == Keys.Control)    // Ctrl only held down
                {
                    switch ((int)m.WParam)
                    {
                        case (int)Keys.Z:  // Ctrl-Z = Cancel batch
                            if (!bScanInProgress)
                                btnCancel_Click(null, null);
                            return true;
                        case (int)Keys.Q:  // Ctrl-Q = Hold batch
                            if (!bScanInProgress)
                            {
                                Status = "hold";
                                OnComplete(this, new TaskStatusEventArgs(Status));
                            }
                            return true;
                        case (int)Keys.B: // CTRL-B = focus on Batch Tree
                            BatchForm.SetBatchFocus();
                            return true;
                        case (int)Keys.C: // CTRL-C = Stop Scanning
                            if (btnSTOPScan.Enabled)
                                btnSTOPScan_Click(null, null);
                            return true;
                        case (int)Keys.D: // CTRL-D = Delete (Remove)
                            if (btnRemove.Enabled)
                                btnRemove_Click(null, null);
                            return true;
                        case (int)Keys.F: // CTRL-F = Flip - rotate 180
                            if (btnFlip.Enabled)
                                btnFlip_Click(null, null);
                            return true;
                        case (int)Keys.L: // CTRL-L = rotate Left (90 CCW)
                            if (btnRotateLeft.Enabled)
                                btnRotateLeft_Click(null, null);
                            return true;
                        case (int)Keys.O: // CTRL-O = Open
                            if (btnOpen.Enabled)
                                btnOpen_Click(null, null);
                            return true;
                        case (int)Keys.P: // CTRL-P = Replace (rescan)
                            if (btnRescan.Enabled)
                                btnRescan_Click(null, null);
                            return true;
                        case (int)Keys.R: // CTRL-R = rotate Right (90 CW)
                            if (btnRotateRight.Enabled)
                                btnRotateRight_Click(null, null);
                            return true;
                        case (int)Keys.S:       // CTRL-S = focus on Scan Panel
                            this.Focus();
                            return true;
                        case (int)Keys.T:        // CTRL-T = toggle thumbnail view
                            ImageForm.ToggleThumbs();
                            return true;
                        case (int)Keys.U:          // CTRL-U = Undo Rescan
                            if (!bScanInProgress && bUndoableRescan)
                                UndoRescan();
                            return true;
                        case (int)Keys.Y:          // CTRL-Y = Redo Rescan
                            if (!bScanInProgress && bUndoableRescan)
                                RedoRescan();
                            return true;
                        case (int)Keys.F8:       // CTRL-F8 = pop up page type
                            listPageType.Focus();
                            listPageType.DroppedDown = true;
                            return true;
                        case (int)Keys.F9:       // CTRL-F9 = mark page for review, with optional comment
                            MarkPageReview("");
                            return true;
                        case (int)Keys.Up:       // CTRL-UPARROW = Move Up
                            if (btnMoveUp.Enabled)
                                btnMoveUp_Click(null, null);
                            return true;
                        case (int)Keys.Down:       // CTRL-DOWNARROW = Move Down
                            if (btnMoveDn.Enabled)
                                btnMoveDn_Click(null, null);
                            return true;
                        case (int)VK_CONTROL:     // Control by itself
                            return false;
                        default:

                            tStatus[] sStatuses = (sSelectedDCOType == "D" ? sDocStatuses : sPageStatuses);
                            if (sStatuses != null) foreach (tStatus pStatus in sStatuses)
                                {
                                    if ((int)pStatus.cShortcut == (int)m.WParam)
                                    {
                                        int nSel = listPageStatus.FindStringExact(pStatus.sStatus);
                                        if (nSel >= 0)
                                        {
                                            listPageStatus.SelectedIndex = nSel;
                                            return true;
                                        }
                                    }
                                }
                            if (pPageMarker != null) foreach (tStatus pStatus in pPageMarker)
                                {
                                    if ((int)pStatus.cShortcut == (int)m.WParam)
                                        MarkPageReview(pStatus.sStatus);
                                }
                            break;
                    }
                }

                //if ((int)m.LParam == 983041 && (int)m.WParam == 9 && (Control.ModifierKeys & Keys.Shift) != Keys.Shift)    // VK_TAB=9 LParam=0xF0001 (count=1,OEM scancode=F)
            }
            return false;
        }

        private void txtEndorserFormat_TextChanged(object sender, EventArgs e)
        {
            dcScan.EndorserFormatString = txtEndorserFormat.Text;
        }

        private void chkMultiple_CheckedChanged(object sender, EventArgs e)
        {
            dcScan.MultiCheck = chkMultiple.Checked;
            txtExpected.Enabled = chkMultiple.Checked;
        }

        private void txtExpected_ValueChanged(object sender, EventArgs e)
        {
            dcScan.Expectedpages = (int)txtExpected.Value;
        }

        public void WriteISISLogMsg(string caller, int lvl, string msgfmt = "", string[] fmtArgs = null)
        {
            string outmsg = msgfmt;
            if (fmtArgs != null)
                outmsg = string.Format(msgfmt, fmtArgs);

            if (lvl >= 7)
                dcTask.WriteLog(caller + ":Verbose: " + outmsg);
            else if (lvl <= 3)
                dcTask.WriteLog(caller + ":Error: " + outmsg);
            else
                dcTask.WriteLog(caller + ":Info: " + outmsg);
        }

        private void grpScanner_Layout(object sender, LayoutEventArgs e)
        {
        }

        private void grpBrightness_Layout(object sender, LayoutEventArgs e)
        {
        }

        private void grpContrast_Layout(object sender, LayoutEventArgs e)
        {
        }

        private void grpEndorser_Layout(object sender, LayoutEventArgs e)
        {
        }

        private void grpStorage_Layout(object sender, LayoutEventArgs e)
        {
        }
    }
}
