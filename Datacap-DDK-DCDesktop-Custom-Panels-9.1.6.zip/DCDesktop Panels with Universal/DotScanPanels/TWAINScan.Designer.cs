﻿namespace DotScanPanels
{
    partial class TWAINScan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TWAINScan));
            this.grpScanner = new System.Windows.Forms.GroupBox();
            this.btnConfigureScanner = new System.Windows.Forms.Button();
            this.btnSelectScanner = new System.Windows.Forms.Button();
            this.lblScannerName = new System.Windows.Forms.Label();
            this.txtScanner = new System.Windows.Forms.TextBox();
            this.btnFinish = new System.Windows.Forms.Button();
            this.btnRescan = new System.Windows.Forms.Button();
            this.grpStorage = new System.Windows.Forms.GroupBox();
            this.cbCompression = new System.Windows.Forms.ComboBox();
            this.lblCompression = new System.Windows.Forms.Label();
            this.lblFiletype = new System.Windows.Forms.Label();
            this.cbFileType = new System.Windows.Forms.ComboBox();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnRemove = new System.Windows.Forms.Button();
            this.btnMoveDn = new System.Windows.Forms.Button();
            this.btnMoveUp = new System.Windows.Forms.Button();
            this.txtExpected = new System.Windows.Forms.NumericUpDown();
            this.btnScan = new System.Windows.Forms.Button();
            this.chkMultiple = new System.Windows.Forms.CheckBox();
            this.lblDots = new System.Windows.Forms.Label();
            this.rdoContrastManual = new System.Windows.Forms.RadioButton();
            this.rdoBrightnessAuto = new System.Windows.Forms.RadioButton();
            this.rdoBrightnessManual = new System.Windows.Forms.RadioButton();
            this.rdoContrastAuto = new System.Windows.Forms.RadioButton();
            this.trackContrast = new System.Windows.Forms.TrackBar();
            this.grpContrast = new System.Windows.Forms.GroupBox();
            this.lblContrastVal = new System.Windows.Forms.Label();
            this.grpBrightness = new System.Windows.Forms.GroupBox();
            this.lblBrightnessVal = new System.Windows.Forms.Label();
            this.trackBrightness = new System.Windows.Forms.TrackBar();
            this.cbDotsPerInch = new System.Windows.Forms.ComboBox();
            this.twainToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.btnInsert = new System.Windows.Forms.Button();
            this.cbxMarkList = new System.Windows.Forms.ComboBox();
            this.chkbDuplex = new System.Windows.Forms.CheckBox();
            this.chkEndorseBatchID = new System.Windows.Forms.CheckBox();
            this.cbColorMode = new System.Windows.Forms.ComboBox();
            this.btnSTOPScan = new System.Windows.Forms.Button();
            this.btnRotateRight = new System.Windows.Forms.Button();
            this.btnRotateLeft = new System.Windows.Forms.Button();
            this.listPageClass = new System.Windows.Forms.ComboBox();
            this.btnNextProb = new System.Windows.Forms.Button();
            this.listPageType = new System.Windows.Forms.ComboBox();
            this.listPageStatus = new System.Windows.Forms.ComboBox();
            this.textFixupMsg = new System.Windows.Forms.TextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.settingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveUnderBatchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveUserSettingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveAsStationSettingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.saveAsCustomSettingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadCustomSettingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.loadBatchSettingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadUserSettingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadStationSettingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.grpEndorser = new System.Windows.Forms.GroupBox();
            this.txtEndorserFormat = new System.Windows.Forms.TextBox();
            this.lblEndorserFormat = new System.Windows.Forms.Label();
            this.lblColor = new System.Windows.Forms.Label();
            this.btnFlip = new System.Windows.Forms.Button();
            this.btnSplit = new System.Windows.Forms.Button();
            this.btnJoin = new System.Windows.Forms.Button();
            this.lblClass = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblPageType = new System.Windows.Forms.Label();
            this.lblComment = new System.Windows.Forms.Label();
            this.btnOpen = new System.Windows.Forms.Button();
            this.grpScanner.SuspendLayout();
            this.grpStorage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtExpected)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackContrast)).BeginInit();
            this.grpContrast.SuspendLayout();
            this.grpBrightness.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBrightness)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.grpEndorser.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpScanner
            // 
            this.grpScanner.Controls.Add(this.btnConfigureScanner);
            this.grpScanner.Controls.Add(this.btnSelectScanner);
            this.grpScanner.Controls.Add(this.lblScannerName);
            this.grpScanner.Controls.Add(this.txtScanner);
            resources.ApplyResources(this.grpScanner, "grpScanner");
            this.grpScanner.Name = "grpScanner";
            this.grpScanner.TabStop = false;
            this.grpScanner.Layout += new System.Windows.Forms.LayoutEventHandler(this.grpScanner_Layout);
            // 
            // btnConfigureScanner
            // 
            resources.ApplyResources(this.btnConfigureScanner, "btnConfigureScanner");
            this.btnConfigureScanner.Name = "btnConfigureScanner";
            this.twainToolTip.SetToolTip(this.btnConfigureScanner, resources.GetString("btnConfigureScanner.ToolTip"));
            this.btnConfigureScanner.UseVisualStyleBackColor = true;
            this.btnConfigureScanner.Click += new System.EventHandler(this.btnConfigureScanner_Click);
            // 
            // btnSelectScanner
            // 
            resources.ApplyResources(this.btnSelectScanner, "btnSelectScanner");
            this.btnSelectScanner.Name = "btnSelectScanner";
            this.twainToolTip.SetToolTip(this.btnSelectScanner, resources.GetString("btnSelectScanner.ToolTip"));
            this.btnSelectScanner.UseVisualStyleBackColor = true;
            this.btnSelectScanner.Click += new System.EventHandler(this.btnSelectScanner_Click);
            // 
            // lblScannerName
            // 
            resources.ApplyResources(this.lblScannerName, "lblScannerName");
            this.lblScannerName.Name = "lblScannerName";
            // 
            // txtScanner
            // 
            this.txtScanner.BackColor = System.Drawing.SystemColors.Window;
            resources.ApplyResources(this.txtScanner, "txtScanner");
            this.txtScanner.Name = "txtScanner";
            this.twainToolTip.SetToolTip(this.txtScanner, resources.GetString("txtScanner.ToolTip"));
            // 
            // btnFinish
            // 
            resources.ApplyResources(this.btnFinish, "btnFinish");
            this.btnFinish.Name = "btnFinish";
            this.twainToolTip.SetToolTip(this.btnFinish, resources.GetString("btnFinish.ToolTip"));
            this.btnFinish.UseVisualStyleBackColor = true;
            this.btnFinish.Click += new System.EventHandler(this.btnFinish_Click);
            // 
            // btnRescan
            // 
            resources.ApplyResources(this.btnRescan, "btnRescan");
            this.btnRescan.Name = "btnRescan";
            this.twainToolTip.SetToolTip(this.btnRescan, resources.GetString("btnRescan.ToolTip"));
            this.btnRescan.UseVisualStyleBackColor = true;
            this.btnRescan.Click += new System.EventHandler(this.btnRescan_Click);
            // 
            // grpStorage
            // 
            this.grpStorage.Controls.Add(this.cbCompression);
            this.grpStorage.Controls.Add(this.lblCompression);
            this.grpStorage.Controls.Add(this.lblFiletype);
            this.grpStorage.Controls.Add(this.cbFileType);
            resources.ApplyResources(this.grpStorage, "grpStorage");
            this.grpStorage.Name = "grpStorage";
            this.grpStorage.TabStop = false;
            this.grpStorage.Layout += new System.Windows.Forms.LayoutEventHandler(this.grpStorage_Layout);
            // 
            // cbCompression
            // 
            this.cbCompression.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cbCompression.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cbCompression.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbCompression.FormattingEnabled = true;
            resources.ApplyResources(this.cbCompression, "cbCompression");
            this.cbCompression.Name = "cbCompression";
            this.cbCompression.SelectedIndexChanged += new System.EventHandler(this.cbCompression_SelectedIndexChanged);
            // 
            // lblCompression
            // 
            resources.ApplyResources(this.lblCompression, "lblCompression");
            this.lblCompression.Name = "lblCompression";
            // 
            // lblFiletype
            // 
            resources.ApplyResources(this.lblFiletype, "lblFiletype");
            this.lblFiletype.Name = "lblFiletype";
            // 
            // cbFileType
            // 
            this.cbFileType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cbFileType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cbFileType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbFileType.FormattingEnabled = true;
            resources.ApplyResources(this.cbFileType, "cbFileType");
            this.cbFileType.Name = "cbFileType";
            this.cbFileType.SelectedIndexChanged += new System.EventHandler(this.cbFileType_SelectedIndexChanged);
            // 
            // btnCancel
            // 
            resources.ApplyResources(this.btnCancel, "btnCancel");
            this.btnCancel.Name = "btnCancel";
            this.twainToolTip.SetToolTip(this.btnCancel, resources.GetString("btnCancel.ToolTip"));
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnRemove
            // 
            resources.ApplyResources(this.btnRemove, "btnRemove");
            this.btnRemove.Name = "btnRemove";
            this.twainToolTip.SetToolTip(this.btnRemove, resources.GetString("btnRemove.ToolTip"));
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // btnMoveDn
            // 
            resources.ApplyResources(this.btnMoveDn, "btnMoveDn");
            this.btnMoveDn.Name = "btnMoveDn";
            this.twainToolTip.SetToolTip(this.btnMoveDn, resources.GetString("btnMoveDn.ToolTip"));
            this.btnMoveDn.UseVisualStyleBackColor = true;
            this.btnMoveDn.Click += new System.EventHandler(this.btnMoveDn_Click);
            // 
            // btnMoveUp
            // 
            resources.ApplyResources(this.btnMoveUp, "btnMoveUp");
            this.btnMoveUp.Name = "btnMoveUp";
            this.twainToolTip.SetToolTip(this.btnMoveUp, resources.GetString("btnMoveUp.ToolTip"));
            this.btnMoveUp.UseVisualStyleBackColor = true;
            this.btnMoveUp.Click += new System.EventHandler(this.btnMoveUp_Click);
            // 
            // txtExpected
            // 
            resources.ApplyResources(this.txtExpected, "txtExpected");
            this.txtExpected.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.txtExpected.Name = "txtExpected";
            this.twainToolTip.SetToolTip(this.txtExpected, resources.GetString("txtExpected.ToolTip"));
            this.txtExpected.ValueChanged += new System.EventHandler(this.txtExpected_ValueChanged);
            // 
            // btnScan
            // 
            resources.ApplyResources(this.btnScan, "btnScan");
            this.btnScan.Name = "btnScan";
            this.twainToolTip.SetToolTip(this.btnScan, resources.GetString("btnScan.ToolTip"));
            this.btnScan.UseVisualStyleBackColor = true;
            this.btnScan.Click += new System.EventHandler(this.btnScan_Click);
            // 
            // chkMultiple
            // 
            resources.ApplyResources(this.chkMultiple, "chkMultiple");
            this.chkMultiple.Checked = true;
            this.chkMultiple.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkMultiple.Name = "chkMultiple";
            this.twainToolTip.SetToolTip(this.chkMultiple, resources.GetString("chkMultiple.ToolTip"));
            this.chkMultiple.UseVisualStyleBackColor = true;
            this.chkMultiple.CheckedChanged += new System.EventHandler(this.chkMultiple_CheckedChanged);
            // 
            // lblDots
            // 
            resources.ApplyResources(this.lblDots, "lblDots");
            this.lblDots.Name = "lblDots";
            // 
            // rdoContrastManual
            // 
            resources.ApplyResources(this.rdoContrastManual, "rdoContrastManual");
            this.rdoContrastManual.Name = "rdoContrastManual";
            this.rdoContrastManual.TabStop = true;
            this.twainToolTip.SetToolTip(this.rdoContrastManual, resources.GetString("rdoContrastManual.ToolTip"));
            this.rdoContrastManual.UseVisualStyleBackColor = true;
            this.rdoContrastManual.CheckedChanged += new System.EventHandler(this.rdoContrastManual_CheckedChanged);
            // 
            // rdoBrightnessAuto
            // 
            resources.ApplyResources(this.rdoBrightnessAuto, "rdoBrightnessAuto");
            this.rdoBrightnessAuto.Checked = true;
            this.rdoBrightnessAuto.Name = "rdoBrightnessAuto";
            this.rdoBrightnessAuto.TabStop = true;
            this.twainToolTip.SetToolTip(this.rdoBrightnessAuto, resources.GetString("rdoBrightnessAuto.ToolTip"));
            this.rdoBrightnessAuto.UseVisualStyleBackColor = true;
            this.rdoBrightnessAuto.CheckedChanged += new System.EventHandler(this.rdoBrightnessAuto_CheckedChanged);
            // 
            // rdoBrightnessManual
            // 
            resources.ApplyResources(this.rdoBrightnessManual, "rdoBrightnessManual");
            this.rdoBrightnessManual.Name = "rdoBrightnessManual";
            this.rdoBrightnessManual.TabStop = true;
            this.twainToolTip.SetToolTip(this.rdoBrightnessManual, resources.GetString("rdoBrightnessManual.ToolTip"));
            this.rdoBrightnessManual.UseVisualStyleBackColor = true;
            this.rdoBrightnessManual.CheckedChanged += new System.EventHandler(this.rdoBrightnessManual_CheckedChanged);
            // 
            // rdoContrastAuto
            // 
            resources.ApplyResources(this.rdoContrastAuto, "rdoContrastAuto");
            this.rdoContrastAuto.Checked = true;
            this.rdoContrastAuto.Name = "rdoContrastAuto";
            this.rdoContrastAuto.TabStop = true;
            this.twainToolTip.SetToolTip(this.rdoContrastAuto, resources.GetString("rdoContrastAuto.ToolTip"));
            this.rdoContrastAuto.UseVisualStyleBackColor = true;
            this.rdoContrastAuto.CheckedChanged += new System.EventHandler(this.rdoContrastAuto_CheckedChanged);
            // 
            // trackContrast
            // 
            resources.ApplyResources(this.trackContrast, "trackContrast");
            this.trackContrast.Maximum = 100;
            this.trackContrast.Name = "trackContrast";
            this.trackContrast.TickFrequency = 10;
            this.trackContrast.Value = 50;
            this.trackContrast.Scroll += new System.EventHandler(this.trackContrast_Scroll);
            // 
            // grpContrast
            // 
            this.grpContrast.Controls.Add(this.rdoContrastAuto);
            this.grpContrast.Controls.Add(this.rdoContrastManual);
            this.grpContrast.Controls.Add(this.trackContrast);
            this.grpContrast.Controls.Add(this.lblContrastVal);
            resources.ApplyResources(this.grpContrast, "grpContrast");
            this.grpContrast.Name = "grpContrast";
            this.grpContrast.TabStop = false;
            this.grpContrast.Layout += new System.Windows.Forms.LayoutEventHandler(this.grpContrast_Layout);
            // 
            // lblContrastVal
            // 
            resources.ApplyResources(this.lblContrastVal, "lblContrastVal");
            this.lblContrastVal.Name = "lblContrastVal";
            // 
            // grpBrightness
            // 
            this.grpBrightness.Controls.Add(this.rdoBrightnessAuto);
            this.grpBrightness.Controls.Add(this.rdoBrightnessManual);
            this.grpBrightness.Controls.Add(this.lblBrightnessVal);
            this.grpBrightness.Controls.Add(this.trackBrightness);
            resources.ApplyResources(this.grpBrightness, "grpBrightness");
            this.grpBrightness.Name = "grpBrightness";
            this.grpBrightness.TabStop = false;
            this.grpBrightness.Layout += new System.Windows.Forms.LayoutEventHandler(this.grpBrightness_Layout);
            // 
            // lblBrightnessVal
            // 
            resources.ApplyResources(this.lblBrightnessVal, "lblBrightnessVal");
            this.lblBrightnessVal.Name = "lblBrightnessVal";
            // 
            // trackBrightness
            // 
            resources.ApplyResources(this.trackBrightness, "trackBrightness");
            this.trackBrightness.Maximum = 100;
            this.trackBrightness.Name = "trackBrightness";
            this.trackBrightness.TickFrequency = 10;
            this.trackBrightness.Value = 50;
            this.trackBrightness.Scroll += new System.EventHandler(this.trackBrightness_Scroll);
            // 
            // cbDotsPerInch
            // 
            this.cbDotsPerInch.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cbDotsPerInch.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cbDotsPerInch.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cbDotsPerInch, "cbDotsPerInch");
            this.cbDotsPerInch.FormattingEnabled = true;
            this.cbDotsPerInch.Name = "cbDotsPerInch";
            this.twainToolTip.SetToolTip(this.cbDotsPerInch, resources.GetString("cbDotsPerInch.ToolTip"));
            this.cbDotsPerInch.SelectedIndexChanged += new System.EventHandler(this.cbDotsPerInch_SelectedIndexChanged);
            // 
            // btnInsert
            // 
            resources.ApplyResources(this.btnInsert, "btnInsert");
            this.btnInsert.Name = "btnInsert";
            this.twainToolTip.SetToolTip(this.btnInsert, resources.GetString("btnInsert.ToolTip"));
            this.btnInsert.UseVisualStyleBackColor = true;
            this.btnInsert.Click += new System.EventHandler(this.btnInsert_Click);
            // 
            // cbxMarkList
            // 
            resources.ApplyResources(this.cbxMarkList, "cbxMarkList");
            this.cbxMarkList.FormattingEnabled = true;
            this.cbxMarkList.Name = "cbxMarkList";
            this.twainToolTip.SetToolTip(this.cbxMarkList, resources.GetString("cbxMarkList.ToolTip"));
            this.cbxMarkList.SelectedIndexChanged += new System.EventHandler(this.cbxMarkList_SelectedIndexChanged);
            this.cbxMarkList.TextChanged += new System.EventHandler(this.cbxMarkList_TextChanged);
            this.cbxMarkList.LostFocus += new System.EventHandler(this.cbxMarkList_LostFocus);
            // 
            // chkbDuplex
            // 
            resources.ApplyResources(this.chkbDuplex, "chkbDuplex");
            this.chkbDuplex.Name = "chkbDuplex";
            this.twainToolTip.SetToolTip(this.chkbDuplex, resources.GetString("chkbDuplex.ToolTip"));
            this.chkbDuplex.UseVisualStyleBackColor = true;
            this.chkbDuplex.CheckedChanged += new System.EventHandler(this.chkbDuplex_CheckedChanged);
            // 
            // chkEndorseBatchID
            // 
            resources.ApplyResources(this.chkEndorseBatchID, "chkEndorseBatchID");
            this.chkEndorseBatchID.Name = "chkEndorseBatchID";
            this.twainToolTip.SetToolTip(this.chkEndorseBatchID, resources.GetString("chkEndorseBatchID.ToolTip"));
            this.chkEndorseBatchID.UseVisualStyleBackColor = true;
            this.chkEndorseBatchID.CheckedChanged += new System.EventHandler(this.chkEndorseBatchID_CheckedChanged);
            // 
            // cbColorMode
            // 
            this.cbColorMode.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cbColorMode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cbColorMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cbColorMode, "cbColorMode");
            this.cbColorMode.FormattingEnabled = true;
            this.cbColorMode.Name = "cbColorMode";
            this.twainToolTip.SetToolTip(this.cbColorMode, resources.GetString("cbColorMode.ToolTip"));
            this.cbColorMode.SelectedIndexChanged += new System.EventHandler(this.cbColorMode_SelectedIndexChanged);
            // 
            // btnSTOPScan
            // 
            resources.ApplyResources(this.btnSTOPScan, "btnSTOPScan");
            this.btnSTOPScan.Name = "btnSTOPScan";
            this.twainToolTip.SetToolTip(this.btnSTOPScan, resources.GetString("btnSTOPScan.ToolTip"));
            this.btnSTOPScan.UseVisualStyleBackColor = true;
            this.btnSTOPScan.Click += new System.EventHandler(this.btnSTOPScan_Click);
            // 
            // btnRotateRight
            // 
            this.btnRotateRight.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btnRotateRight.BackgroundImage = global::DotScanPanels.Properties.Resources.rotate_cw;
            resources.ApplyResources(this.btnRotateRight, "btnRotateRight");
            this.btnRotateRight.Name = "btnRotateRight";
            this.twainToolTip.SetToolTip(this.btnRotateRight, resources.GetString("btnRotateRight.ToolTip"));
            this.btnRotateRight.UseVisualStyleBackColor = false;
            this.btnRotateRight.Click += new System.EventHandler(this.btnRotateRight_Click);
            // 
            // btnRotateLeft
            // 
            this.btnRotateLeft.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btnRotateLeft.BackgroundImage = global::DotScanPanels.Properties.Resources.rotate_ccw;
            resources.ApplyResources(this.btnRotateLeft, "btnRotateLeft");
            this.btnRotateLeft.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnRotateLeft.Name = "btnRotateLeft";
            this.twainToolTip.SetToolTip(this.btnRotateLeft, resources.GetString("btnRotateLeft.ToolTip"));
            this.btnRotateLeft.UseVisualStyleBackColor = false;
            this.btnRotateLeft.Click += new System.EventHandler(this.btnRotateLeft_Click);
            // 
            // listPageClass
            // 
            this.listPageClass.AllowDrop = true;
            this.listPageClass.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.listPageClass.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.listPageClass.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.listPageClass, "listPageClass");
            this.listPageClass.FormattingEnabled = true;
            this.listPageClass.Name = "listPageClass";
            this.listPageClass.Sorted = true;
            this.twainToolTip.SetToolTip(this.listPageClass, resources.GetString("listPageClass.ToolTip"));
            this.listPageClass.SelectedIndexChanged += new System.EventHandler(this.listPageClass_SelectedIndexChanged);
            // 
            // btnNextProb
            // 
            resources.ApplyResources(this.btnNextProb, "btnNextProb");
            this.btnNextProb.Name = "btnNextProb";
            this.twainToolTip.SetToolTip(this.btnNextProb, resources.GetString("btnNextProb.ToolTip"));
            this.btnNextProb.UseVisualStyleBackColor = true;
            this.btnNextProb.Click += new System.EventHandler(this.btnNextProb_Click);
            // 
            // listPageType
            // 
            this.listPageType.AllowDrop = true;
            this.listPageType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.listPageType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.listPageType.CausesValidation = false;
            this.listPageType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.listPageType, "listPageType");
            this.listPageType.FormattingEnabled = true;
            this.listPageType.Name = "listPageType";
            this.listPageType.Sorted = true;
            this.twainToolTip.SetToolTip(this.listPageType, resources.GetString("listPageType.ToolTip"));
            this.listPageType.SelectedIndexChanged += new System.EventHandler(this.listPageType_SelectedIndexChanged);
            // 
            // listPageStatus
            // 
            this.listPageStatus.AllowDrop = true;
            this.listPageStatus.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.listPageStatus.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.listPageStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.listPageStatus, "listPageStatus");
            this.listPageStatus.FormattingEnabled = true;
            this.listPageStatus.Name = "listPageStatus";
            this.listPageStatus.Sorted = true;
            this.twainToolTip.SetToolTip(this.listPageStatus, resources.GetString("listPageStatus.ToolTip"));
            this.listPageStatus.SelectedIndexChanged += new System.EventHandler(this.listPageStatus_SelectedIndexChanged);
            // 
            // textFixupMsg
            // 
            resources.ApplyResources(this.textFixupMsg, "textFixupMsg");
            this.textFixupMsg.Name = "textFixupMsg";
            this.twainToolTip.SetToolTip(this.textFixupMsg, resources.GetString("textFixupMsg.ToolTip"));
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            resources.ApplyResources(this.menuStrip1, "menuStrip1");
            this.menuStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.settingsToolStripMenuItem});
            this.menuStrip1.Name = "menuStrip1";
            // 
            // settingsToolStripMenuItem
            // 
            this.settingsToolStripMenuItem.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.settingsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveUnderBatchToolStripMenuItem,
            this.saveUserSettingsToolStripMenuItem,
            this.saveAsStationSettingsToolStripMenuItem,
            this.toolStripSeparator1,
            this.saveAsCustomSettingsToolStripMenuItem,
            this.loadCustomSettingsToolStripMenuItem,
            this.toolStripSeparator2,
            this.loadBatchSettingsToolStripMenuItem,
            this.loadUserSettingsToolStripMenuItem,
            this.loadStationSettingsToolStripMenuItem});
            this.settingsToolStripMenuItem.Name = "settingsToolStripMenuItem";
            resources.ApplyResources(this.settingsToolStripMenuItem, "settingsToolStripMenuItem");
            // 
            // saveUnderBatchToolStripMenuItem
            // 
            this.saveUnderBatchToolStripMenuItem.Name = "saveUnderBatchToolStripMenuItem";
            resources.ApplyResources(this.saveUnderBatchToolStripMenuItem, "saveUnderBatchToolStripMenuItem");
            this.saveUnderBatchToolStripMenuItem.Click += new System.EventHandler(this.saveUnderBatchToolStripMenuItem_Click);
            // 
            // saveUserSettingsToolStripMenuItem
            // 
            this.saveUserSettingsToolStripMenuItem.Name = "saveUserSettingsToolStripMenuItem";
            resources.ApplyResources(this.saveUserSettingsToolStripMenuItem, "saveUserSettingsToolStripMenuItem");
            this.saveUserSettingsToolStripMenuItem.Click += new System.EventHandler(this.saveUserSettingsToolStripMenuItem_Click);
            // 
            // saveAsStationSettingsToolStripMenuItem
            // 
            this.saveAsStationSettingsToolStripMenuItem.Name = "saveAsStationSettingsToolStripMenuItem";
            resources.ApplyResources(this.saveAsStationSettingsToolStripMenuItem, "saveAsStationSettingsToolStripMenuItem");
            this.saveAsStationSettingsToolStripMenuItem.Click += new System.EventHandler(this.saveAsStationSettingsToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            resources.ApplyResources(this.toolStripSeparator1, "toolStripSeparator1");
            // 
            // saveAsCustomSettingsToolStripMenuItem
            // 
            this.saveAsCustomSettingsToolStripMenuItem.Name = "saveAsCustomSettingsToolStripMenuItem";
            resources.ApplyResources(this.saveAsCustomSettingsToolStripMenuItem, "saveAsCustomSettingsToolStripMenuItem");
            this.saveAsCustomSettingsToolStripMenuItem.Click += new System.EventHandler(this.saveAsCustomSettingsToolStripMenuItem_Click);
            // 
            // loadCustomSettingsToolStripMenuItem
            // 
            this.loadCustomSettingsToolStripMenuItem.Name = "loadCustomSettingsToolStripMenuItem";
            resources.ApplyResources(this.loadCustomSettingsToolStripMenuItem, "loadCustomSettingsToolStripMenuItem");
            this.loadCustomSettingsToolStripMenuItem.Click += new System.EventHandler(this.loadCustomSettingsToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            resources.ApplyResources(this.toolStripSeparator2, "toolStripSeparator2");
            // 
            // loadBatchSettingsToolStripMenuItem
            // 
            this.loadBatchSettingsToolStripMenuItem.Name = "loadBatchSettingsToolStripMenuItem";
            resources.ApplyResources(this.loadBatchSettingsToolStripMenuItem, "loadBatchSettingsToolStripMenuItem");
            this.loadBatchSettingsToolStripMenuItem.Click += new System.EventHandler(this.loadBatchSettingsToolStripMenuItem_Click);
            // 
            // loadUserSettingsToolStripMenuItem
            // 
            this.loadUserSettingsToolStripMenuItem.Name = "loadUserSettingsToolStripMenuItem";
            resources.ApplyResources(this.loadUserSettingsToolStripMenuItem, "loadUserSettingsToolStripMenuItem");
            this.loadUserSettingsToolStripMenuItem.Click += new System.EventHandler(this.loadUserSettingsToolStripMenuItem_Click);
            // 
            // loadStationSettingsToolStripMenuItem
            // 
            this.loadStationSettingsToolStripMenuItem.Name = "loadStationSettingsToolStripMenuItem";
            resources.ApplyResources(this.loadStationSettingsToolStripMenuItem, "loadStationSettingsToolStripMenuItem");
            this.loadStationSettingsToolStripMenuItem.Click += new System.EventHandler(this.loadStationSettingsToolStripMenuItem_Click);
            // 
            // grpEndorser
            // 
            this.grpEndorser.Controls.Add(this.txtEndorserFormat);
            this.grpEndorser.Controls.Add(this.lblEndorserFormat);
            this.grpEndorser.Controls.Add(this.chkEndorseBatchID);
            resources.ApplyResources(this.grpEndorser, "grpEndorser");
            this.grpEndorser.Name = "grpEndorser";
            this.grpEndorser.TabStop = false;
            this.grpEndorser.Enter += new System.EventHandler(this.grpEndorser_Enter);
            // 
            // txtEndorserFormat
            // 
            resources.ApplyResources(this.txtEndorserFormat, "txtEndorserFormat");
            this.txtEndorserFormat.Name = "txtEndorserFormat";
            this.txtEndorserFormat.TextChanged += new System.EventHandler(this.txtEndorserFormat_TextChanged);
            // 
            // lblEndorserFormat
            // 
            resources.ApplyResources(this.lblEndorserFormat, "lblEndorserFormat");
            this.lblEndorserFormat.Name = "lblEndorserFormat";
            this.lblEndorserFormat.Click += new System.EventHandler(this.lblEndorserID_Click);
            // 
            // lblColor
            // 
            resources.ApplyResources(this.lblColor, "lblColor");
            this.lblColor.Name = "lblColor";
            // 
            // btnFlip
            // 
            this.btnFlip.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btnFlip.BackgroundImage = global::DotScanPanels.Properties.Resources.rotate_180;
            resources.ApplyResources(this.btnFlip, "btnFlip");
            this.btnFlip.Name = "btnFlip";
            this.btnFlip.UseVisualStyleBackColor = false;
            this.btnFlip.Click += new System.EventHandler(this.btnFlip_Click);
            // 
            // btnSplit
            // 
            resources.ApplyResources(this.btnSplit, "btnSplit");
            this.btnSplit.Name = "btnSplit";
            this.btnSplit.UseVisualStyleBackColor = true;
            this.btnSplit.Click += new System.EventHandler(this.btnSplit_Click);
            // 
            // btnJoin
            // 
            resources.ApplyResources(this.btnJoin, "btnJoin");
            this.btnJoin.Name = "btnJoin";
            this.btnJoin.UseVisualStyleBackColor = true;
            this.btnJoin.Click += new System.EventHandler(this.btnJoin_Click);
            // 
            // lblClass
            // 
            resources.ApplyResources(this.lblClass, "lblClass");
            this.lblClass.Name = "lblClass";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // lblPageType
            // 
            resources.ApplyResources(this.lblPageType, "lblPageType");
            this.lblPageType.Name = "lblPageType";
            // 
            // lblComment
            // 
            resources.ApplyResources(this.lblComment, "lblComment");
            this.lblComment.Name = "lblComment";
            // 
            // btnOpen
            // 
            resources.ApplyResources(this.btnOpen, "btnOpen");
            this.btnOpen.Name = "btnOpen";
            this.btnOpen.UseVisualStyleBackColor = true;
            this.btnOpen.Click += new System.EventHandler(this.btnOpen_Click);
            // 
            // TWAINScan
            // 
            resources.ApplyResources(this, "$this");
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.Controls.Add(this.cbxMarkList);
            this.Controls.Add(this.btnOpen);
            this.Controls.Add(this.btnFlip);
            this.Controls.Add(this.btnRotateRight);
            this.Controls.Add(this.cbDotsPerInch);
            this.Controls.Add(this.btnRotateLeft);
            this.Controls.Add(this.lblDots);
            this.Controls.Add(this.btnSplit);
            this.Controls.Add(this.btnJoin);
            this.Controls.Add(this.lblClass);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblPageType);
            this.Controls.Add(this.listPageClass);
            this.Controls.Add(this.btnNextProb);
            this.Controls.Add(this.listPageType);
            this.Controls.Add(this.listPageStatus);
            this.Controls.Add(this.lblComment);
            this.Controls.Add(this.textFixupMsg);
            this.Controls.Add(this.btnSTOPScan);
            this.Controls.Add(this.lblColor);
            this.Controls.Add(this.cbColorMode);
            this.Controls.Add(this.grpEndorser);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.btnInsert);
            this.Controls.Add(this.chkbDuplex);
            this.Controls.Add(this.grpContrast);
            this.Controls.Add(this.grpBrightness);
            this.Controls.Add(this.grpScanner);
            this.Controls.Add(this.btnFinish);
            this.Controls.Add(this.btnRescan);
            this.Controls.Add(this.grpStorage);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnRemove);
            this.Controls.Add(this.btnMoveDn);
            this.Controls.Add(this.btnMoveUp);
            this.Controls.Add(this.txtExpected);
            this.Controls.Add(this.btnScan);
            this.Controls.Add(this.chkMultiple);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "TWAINScan";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.Load += new System.EventHandler(this.TWAINScan_Load);
            this.grpScanner.ResumeLayout(false);
            this.grpScanner.PerformLayout();
            this.grpStorage.ResumeLayout(false);
            this.grpStorage.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtExpected)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackContrast)).EndInit();
            this.grpContrast.ResumeLayout(false);
            this.grpContrast.PerformLayout();
            this.grpBrightness.ResumeLayout(false);
            this.grpBrightness.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBrightness)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.grpEndorser.ResumeLayout(false);
            this.grpEndorser.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grpScanner;
        private System.Windows.Forms.Button btnConfigureScanner;
        private System.Windows.Forms.Button btnSelectScanner;
        private System.Windows.Forms.Label lblScannerName;
        private System.Windows.Forms.TextBox txtScanner;
        private System.Windows.Forms.Button btnFinish;
        private System.Windows.Forms.Button btnRescan;
        private System.Windows.Forms.GroupBox grpStorage;
        private System.Windows.Forms.ComboBox cbCompression;
        private System.Windows.Forms.Label lblCompression;
        private System.Windows.Forms.Label lblFiletype;
        private System.Windows.Forms.ComboBox cbFileType;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.Button btnMoveDn;
        private System.Windows.Forms.Button btnMoveUp;
        private System.Windows.Forms.NumericUpDown txtExpected;
        private System.Windows.Forms.Button btnScan;
        private System.Windows.Forms.CheckBox chkMultiple;
        private System.Windows.Forms.Label lblDots;
        private System.Windows.Forms.RadioButton rdoContrastManual;
        private System.Windows.Forms.RadioButton rdoBrightnessAuto;
        private System.Windows.Forms.RadioButton rdoBrightnessManual;
        private System.Windows.Forms.RadioButton rdoContrastAuto;
        private System.Windows.Forms.TrackBar trackContrast;
        private System.Windows.Forms.GroupBox grpContrast;
        private System.Windows.Forms.Label lblContrastVal;
        private System.Windows.Forms.GroupBox grpBrightness;
        private System.Windows.Forms.TrackBar trackBrightness;
        private System.Windows.Forms.Label lblBrightnessVal;
        private System.Windows.Forms.ComboBox cbDotsPerInch;
        private System.Windows.Forms.ToolTip twainToolTip;
        private System.Windows.Forms.CheckBox chkbDuplex;
        private System.Windows.Forms.Button btnInsert;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem settingsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveUnderBatchToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveUserSettingsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveAsStationSettingsToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem saveAsCustomSettingsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadCustomSettingsToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem loadBatchSettingsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadUserSettingsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadStationSettingsToolStripMenuItem;
        private System.Windows.Forms.GroupBox grpEndorser;
        private System.Windows.Forms.Label lblEndorserFormat;
        private System.Windows.Forms.CheckBox chkEndorseBatchID;
        private System.Windows.Forms.ComboBox cbColorMode;
        private System.Windows.Forms.Label lblColor;
        private System.Windows.Forms.Button btnSTOPScan;
        private System.Windows.Forms.Button btnFlip;
        private System.Windows.Forms.Button btnRotateRight;
        private System.Windows.Forms.Button btnRotateLeft;
        private System.Windows.Forms.Button btnSplit;
        private System.Windows.Forms.Button btnJoin;
        private System.Windows.Forms.Label lblClass;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblPageType;
        private System.Windows.Forms.ComboBox listPageClass;
        private System.Windows.Forms.Button btnNextProb;
        private System.Windows.Forms.ComboBox listPageType;
        private System.Windows.Forms.ComboBox listPageStatus;
        private System.Windows.Forms.Label lblComment;
        private System.Windows.Forms.TextBox textFixupMsg;
        private System.Windows.Forms.Button btnOpen;
        private System.Windows.Forms.ComboBox cbxMarkList;
        private System.Windows.Forms.TextBox txtEndorserFormat;
    }
}
