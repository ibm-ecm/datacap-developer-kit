// Licensed Materials - Property of IBM
// 5725-C15
// � Copyright IBM Corp. 1994, 2012 All Rights Reserved
// 
// US Government Users Restricted Rights - Use, duplication or
// disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Runtime.InteropServices;
using System.Text;
using System.Xml;
using System.Windows.Forms;
using dcDTlib;

namespace DotScanPanels
{
    public partial class tempField : UserControl
    {
        // tempField class for displaying field edit box or combo dropdown box for data entry in DotScan StartBatch panel
        public tempField()
        {
            InitializeComponent();
            foreach (Control pCtrl in Controls)
                pCtrl.Visible = false;
        }

        public XmlNode xSet=null;
        public XmlNode xRun=null;
        public ToolStripLabel lblStatus=null;
        public dcDTlib.tmWeb pWeb=null;

        protected bool bOmr;
        protected string sDict;
        protected string sSel;
        protected string sLook;

		private string EscapeSQLClause(string sValue)
		{
			if (string.IsNullOrWhiteSpace(sValue)) return sValue;
			return sValue.Replace("'", "''");
		}

        public void Init()
        { 
            if (xSet==null || xRun==null)
                return;

            string sLbl=xRun.SelectSingleNode("V[@n='TYPE']").InnerText;
            XmlNode pLbl=xRun.SelectSingleNode("V[@n='label']");
            if (pLbl==null)
                pLbl=xSet.SelectSingleNode("V[@n='label']");
            if (pLbl!=null)
                sLbl=pLbl.InnerText;
            label1.Text=linkLabel1.Text=sLbl;

            sDict="";
            XmlNode pDict=xRun.SelectSingleNode("V[@n='DICT']");
            if (pDict==null)
                pDict=xSet.SelectSingleNode("V[@n='DICT']");
            if (pDict != null)
                sDict = pDict.InnerText;

            bOmr=false;
            XmlNode pOmr=xRun.SelectSingleNode("V[@n='RecogType']");
            if (pOmr==null)
                pOmr=xSet.SelectSingleNode("V[@n='RecogType']");
            if (pOmr != null && (pOmr.InnerText == "4" || pOmr.InnerText == "18"))
                bOmr = true;

            sLook="";
            XmlNode pLook=xRun.SelectSingleNode("V[@n='Lookup']");
            if (pLook==null)
                pLook=xSet.SelectSingleNode("V[@n='Lookup']");
            if (pLook!=null)
            {
                sLook=pLook.InnerText;
                linkLabel1.Visible=true;
            }
            else
                label1.Visible=true;


            string sSel="";
            XmlNode pSel=xRun.SelectSingleNode("V[@n='SELECT']");
            if (pSel==null)
                pSel=xSet.SelectSingleNode("V[@n='SELECT']");
            if (pSel!=null)
                sSel=pSel.InnerText;
            if (sSel != "" && pWeb!=null)
            {
                comboBox1.Visible = true;
                XmlNode xBlank = xSet.SelectSingleNode("V[@n='blank']");
                if (comboBox1.Items.Count > 0)
                    return;
                XmlDocument xDoc = new XmlDocument();
                try
                {
                    xDoc.LoadXml(pSel.InnerText);
                }
                catch (Exception ex)
                {
                    pWeb.WriteLog("SELECT syntax error " + pSel.InnerText); 
                    return;
                }
                string sDSN = xDoc.SelectSingleNode("SQL").Attributes["dsn"].Value;
                sDSN = pWeb.GetAppSetting(sDSN, 0, sDSN);

                string sSQL = xDoc.SelectSingleNode("SQL").InnerText;
                string sXml = pWeb.QueryDB(sDSN, sSQL);
                if (sXml != "")
                {
                    System.IO.StringReader pRead = new System.IO.StringReader(sXml);
                    DataSet pData = new DataSet();
                    pData.ReadXml(pRead);
                    DataTable data = (DataTable)pData.Tables["row"];
                    if (data == null)
                        return;
                    comboBox1.Items.Add("");
                    foreach (DataRow pRow in data.Rows)
                    {
                        string sText = Convert.ToString(pRow.ItemArray.GetValue(0));
                        if (sText != null && sText != "")
                            comboBox1.Items.Add(sText);
                    }

                }
            }
            else if (sDict != "" || bOmr)
            {
                comboBox1.Visible = true;
                XmlNode xBlank = xSet.SelectSingleNode("V[@n='blank']");
                XmlNodeList pWords = xSet.OwnerDocument.SelectNodes("S/DICT[@n='" + sDict + "']/W"); ;
                BindDict(((xBlank == null) ? "" : xBlank.InnerText), comboBox1, pWords, xSet.SelectNodes("F").Count);
            }
            else
                textBox1.Visible = true;

        }

        public void Loadz()
        {
            // Text
            string sText = GetAltText(xRun, 0);
            if (textBox1.Visible)
                textBox1.Text = sText;
            else
                comboBox1.SelectedIndex=comboBox1.FindStringExact(sText);
            string sStat = xRun.SelectSingleNode("V[@n='STATUS']").InnerText;
            // BackColor
            if (sStat != "0")
            {
                textBox1.BackColor = Color.LightPink;
                comboBox1.BackColor = Color.LightPink;
            }
            else
            {
                textBox1.BackColor = SystemColors.Window;
                comboBox1.BackColor = SystemColors.Window;
            }
        }

        public void Storz()
        {
            string sText = "";
            if (textBox1.Visible)
                sText = textBox1.Text;
            else if (comboBox1.SelectedIndex>-1)
                sText = comboBox1.Items[comboBox1.SelectedIndex].ToString();
            SetAltText(xRun, 0, sText);
        }

        private void BindDict(string sNoChoice, ComboBox pCtrl, XmlNodeList pWords, int nOMRCount)
        {
            if (pCtrl.Items.Count > 0)
                return;
            if (sNoChoice != null)
                pCtrl.Items.Add(sNoChoice);
            int nItems = 1;
            if (pWords.Count > 0)
            {
                foreach (XmlNode pWord in pWords)
                {
                    pCtrl.Items.Add(pWord.InnerText);
                    if (nItems++ == nOMRCount)
                        break;
                }
            }
            else
            {
                for (int i = 1; i < nOMRCount + 1; i++)
                    pCtrl.Items.Add("Choice " + i.ToString());
            }
        }

        public void SetAltText(XmlNode pNode, int nAlt, string sText)
        {

            XmlDocument xDoc = pNode.OwnerDocument;
            XmlNodeList pChars = pNode.SelectNodes("C");
            int i = 0;
            for (i = pChars.Count; i < sText.Length; i++)
            {
                XmlNode pChar = xDoc.CreateElement("C");
                XmlAttribute confAttr = xDoc.CreateAttribute("cn");
                confAttr.Value = "";
                pChar.Attributes.Append(confAttr);
                XmlAttribute coorAttr = xDoc.CreateAttribute("cr");
                coorAttr.Value = "0,0,0,0";
                pChar.Attributes.Append(coorAttr);
                pNode.AppendChild(pChar);
            }
            pChars = pNode.SelectNodes("C");
            i = 0;
            foreach (XmlNode pChar in pChars)
            {
                string sChar = "";
                string sConf = "";
                string sData = "";
                if (sText.Length > i)
                    sChar = Convert.ToString((int)sText[i]);
                string[] arData = null;
                arData = pChar.InnerText.Split(',');
                string[] arConf = null;
                arConf = pChar.Attributes["cn"].Value.Split(',');
                for (int j = 0; j < arData.Length; j++)
                {
                    if (j > 0)
                    {
                        sData += ",";
                        sConf += ",";
                    }
                    if (j != nAlt)
                    {
                        sData += arData[j];
                        sConf += arConf[j];
                    }
                    sData += sChar;
                    sConf += "10";
                }
                for (int j = arData.Length; j <= nAlt; j++)
                {
                    if (j > 0)
                    {
                        sData += ",";
                        sConf += "10";
                    }
                    if (j == nAlt)
                    {
                        sData += sChar;
                        sConf += "10";
                    }
                    else
                        sConf += "0";
                }
                pChar.InnerText = sData;
                pChar.Attributes["cn"].Value = sConf;
                if (sText.Length <= i)
                {
                    if (sData.Replace(",", "") == "")
                        pNode.RemoveChild(pChar);
                }
                i++;
            }
        }

        public string GetAltText(XmlNode pField, int nAlt)
        {
            string result = "";
            if (pField == null)
                return result;
            XmlNodeList pChars = pField.SelectNodes("C");
            foreach (XmlNode pChar in pChars)
            {
                string data = pChar.InnerText;
                string[] split = null;
                split = data.Split(',');
                if (split.Length > nAlt)
                {
                    if (split[nAlt].Length > 0)
                        result += Convert.ToChar(Convert.ToInt16(split[nAlt]));
                }
                else
                {
                    if (split[split.Length - 1].Length > 0)
                        result += Convert.ToChar(Convert.ToInt16(split[split.Length - 1]));
                }
            }
            return result;
        }

        private void textBox1_Enter(object sender, EventArgs e)
        {
            if (lblStatus != null && xRun != null)
            {
                lblStatus.Text = xRun.Attributes["id"].Value;
                XmlNode pMess = xRun.SelectSingleNode("V[@n='MESSAGE']");
                if (pMess != null && pMess.InnerText.Trim() != "")
                    lblStatus.Text += " : " + pMess.InnerText.Trim();
            }
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            if (lblStatus != null && xRun != null)
                lblStatus.Text = "";
        }

        private void comboBox1_Enter(object sender, EventArgs e)
        {
            if (lblStatus != null && xRun != null)
            {
                lblStatus.Text = xRun.Attributes["id"].Value;
                XmlNode pMess = xRun.SelectSingleNode("V[@n='MESSAGE']");
                if (pMess != null && pMess.InnerText.Trim() != "")
                    lblStatus.Text += " : " + pMess.InnerText.Trim();
            }
        }

        private void comboBox1_Leave(object sender, EventArgs e)
        {
            if (lblStatus != null && xRun != null)
                lblStatus.Text = "";
        }

        // Lookup:
        private void linkLabel1_Click(object sender, EventArgs e)
        {
            XmlNode xField = xRun;
            string sType = xField.SelectSingleNode("V[@n='TYPE']").InnerText;
            XmlNode xLabel = xField.SelectSingleNode("V[@n='Lookup']");
            if (xLabel == null)
                xLabel = xSet.OwnerDocument.SelectSingleNode("/S/F[@type='" + sType + "']/V[@n='Lookup']");
            if (xLabel == null)
                return;

            XmlDocument xDoc = new XmlDocument();
            try
            {
                xDoc.LoadXml(xLabel.InnerText);
            }
            catch (Exception ex)
            {
                pWeb.WriteLog("Lookup attribute syntax error " + xLabel.InnerText);
                return;
            }

            string sSQL = xDoc.SelectSingleNode("SQL").InnerText;
            int nPos = sSQL.IndexOf("@@");
            int nPosPrev = -1;
            startPan pForm = (Parent as startPan);
            if (pForm == null)
                return;
            while (nPos > -1 && nPos != nPosPrev)
            {
                nPosPrev = nPos;
                int nPos1 = sSQL.IndexOf("@@", nPos + 1);
                string sField = sSQL.Substring(nPos + 2, nPos1 - (nPos + 2));
                foreach (Control pCtrl in pForm.Controls)
                {
                    tempField pField = (pCtrl as tempField);
                    if (pField != null)
                    {
                        string sTag = (string)pField.Tag;
                        if (sTag == sField)
                        {
							if (pField.comboBox1.Items.Count == 0)
								sSQL = sSQL.Substring(0, nPos) + EscapeSQLClause(pField.textBox1.Text) + sSQL.Substring(nPos1 + 2);
							else
								sSQL = sSQL.Substring(0, nPos) + EscapeSQLClause(pField.comboBox1.Text) + sSQL.Substring(nPos1 + 2);
                            break;
                        }
                    }
                }
                nPos = sSQL.IndexOf("@@");
            }

            string sDSN = xDoc.SelectSingleNode("SQL").Attributes["dsn"].Value;
            sDSN = pForm.pWeb.GetAppSetting(sDSN, 0, sDSN);

            string sXml = pForm.pWeb.QueryDB(sDSN, sSQL);

            if (sXml == "")
            {
                MessageBox.Show(pForm.pWeb.lastError, Properties.Resources.programName, MessageBoxButtons.OK,
                                MessageBoxIcon.None, MessageBoxDefaultButton.Button1, GetMsgRTL());
                return;
            }

            dcDTlib.LookupForm lDlg = new dcDTlib.LookupForm(sXml);
            lDlg.Text = String.Format(Properties.Resources.msgLookupDataFor_Text, sType);


            if (lDlg.ShowDialog() != DialogResult.OK)
                return;
            string[] arRes = lDlg.sRes.Split('|');

            // Populate fields with results from SELECTED ROW.

            string flist = sType;
            if (xDoc.DocumentElement.Attributes["flist"] != null)
            {
                string fl = xDoc.DocumentElement.Attributes["flist"].Value;
                if (fl.StartsWith(","))
                    flist = flist + fl;
                else
                    flist = fl;
            }

            string[] arFields = flist.Split(',');

            int nIdx = 0;
            foreach (string s in arFields)
            {
                foreach (Control pCtrl in pForm.Controls)
                {
                    tempField pField = (pCtrl as tempField);
                    if (pField != null)
                    {
                        string sTag = (string)pField.Tag;
                        if (sTag == s)
                        {
                            pField.textBox1.Text=arRes[nIdx];
                            break;
                        }
                    }
                }
                nIdx++;
            }
        }

        // If the configured language is Right To Left, then set the message box options for right to left. BiDi
        public MessageBoxOptions GetMsgRTL()
        {
            MessageBoxOptions msgOptions = 0;
            if (System.Threading.Thread.CurrentThread.CurrentCulture.TextInfo.IsRightToLeft)
            {
                msgOptions = (MessageBoxOptions.RtlReading | MessageBoxOptions.RightAlign);
            }
            return msgOptions;
        }
    }
}
