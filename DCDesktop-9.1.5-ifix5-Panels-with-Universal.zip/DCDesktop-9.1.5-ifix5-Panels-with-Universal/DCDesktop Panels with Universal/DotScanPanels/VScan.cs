// Licensed Materials - Property of IBM
// 5725-C15
// � Copyright IBM Corp. 1994, 2018 All Rights Reserved
// 
// US Government Users Restricted Rights - Use, duplication or
// disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

//
// This is the manual VScan panel for DotScan, it allows the user to select one or more files to import into a batch, review, etc.
//

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Xml;
using System.Text;
using System.IO;
using System.Windows.Forms;
using dcDTlib;

namespace DotScanPanels
{
    public partial class VScan : dcDTlib.dotPanelBase, IMessageFilter
    {
        public VScan()
        {
            InitializeComponent();

            // Set the mirroring of the grid panel for locales that are right to left. (The panel RLT is set by the MainForm)
            lstImages.RightToLeft = (System.Threading.Thread.CurrentThread.CurrentCulture.TextInfo.IsRightToLeft) ? RightToLeft.Yes : RightToLeft.No;
            lstImages.RightToLeftLayout = System.Threading.Thread.CurrentThread.CurrentCulture.TextInfo.IsRightToLeft;
            textBox1.RightToLeft = RightToLeft.No; // This edit box always shows a file path.  File paths should always be LTR, even in BiDi mode.
        }

        string[] dlgFiles = null;

        //bool bf_update_inprogress = false;

        private void BatchForm_OnSelectionChange(Object src, EventArgs e)
        {
            //181472 : already handled in dotscan panel
            //if (BatchForm.AlreadySelectedFromBatch == true)
            //    return;
            //vk test if (bSelChange_InProgress)
            //vk test     return;
            //vk test bSelChange_InProgress = true;

            XmlNode xPage = (XmlNode)src;
            if (xPage.Name != "P")
                return;
            XmlNodeList xPages = dcTask.BatchXML.SelectNodes(".//P");
            int i = 0;
            for (i = 0; i < xPages.Count; i++)
            {
                if (xPage == xPages[i])
                    break;
            }
            if (lstImages.Items.Count > i)
                lstImages.Items[i].Selected = true;

            ImageForm.ImageSelect(xPage);
            if (ImageForm.AreThumbsEnabled())
                ImageForm.LoadThumbs(xPage.Attributes["id"].Value, false);
            //vk test bSelChange_InProgress = false;
        }

        private void BatchForm_OnTypeChange(Object src, EventArgs e)
        {
            XmlNode xPage = (XmlNode)src;
            if (xPage.Name != "P")
                return;
            XmlNodeList xPages = dcTask.BatchXML.SelectNodes(".//P");
            int i = 0;
            for (i = 0; i < xPages.Count; i++)
            {
                if (xPage == xPages[i])
                    break;
            }
            ImageForm.SetThumbText(xPage.SelectSingleNode("V[@n='TYPE']").InnerText, i);
        }

        private void BatchForm_OnDragDropCompleted(Object src, EventArgs e)
        {
            XmlNode xPage = (XmlNode)src;
            if (xPage.Name != "P")
                return;

            RearrangeListImages();
            ImageForm.LoadThumbs(xPage.Attributes["id"].Value, true);
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            string initialDir = string.Empty;
            string temp = LastFolderLocation();
            if (!temp.Equals(string.Empty))
                initialDir = Path.GetFullPath(temp);
            if(initialDir.Equals(string.Empty))
                initialDir = "c:\\datacap\\";

            OpenFileDialog oFD1 = new OpenFileDialog();

            //oFD1.InitialDirectory = "c:\\datacap\\";
            oFD1.InitialDirectory = initialDir;
            oFD1.Filter = "TIFF Files (*.tif)|*.tif|Image Files (*.jpg,*.tif,*.png)|*.jpg;*.tif;*.png|All Files(*.*)|*.*";
            oFD1.FilterIndex = 1;
            oFD1.Multiselect = true;

            oFD1.RestoreDirectory = true;
            if (oFD1.ShowDialog() == DialogResult.OK)
            {
                dlgFiles = oFD1.FileNames;
                textBox1.Text = Datacap.Global.DCBidi.FormatRTLFilePath(dlgFiles[0]); // Format any BiDi characters structured text
                if (dlgFiles.Length > 1)    // 1, to enable selecting a single file and reading in a sorted list. 0 to force selecting all files
                {
                    chkMultiple.Checked = true;
                    txtExpected.Value = dlgFiles.Length;
                    //Commented to fix defect 180777 - Batch tree viewer displays the images ingested through vscan in descending order 
                    /*string sTemp = dlgFiles[0];
                    for (int i = 0; i < dlgFiles.Length - 1; i++)
                        dlgFiles[i] = dlgFiles[i + 1];
                    dlgFiles[dlgFiles.Length - 1] = sTemp;*/
                }
                btnScan.Enabled = (textBox1.Text != "");
            }
        }


        // Moved to dotPanelBase.cs
        //private string FormatID(string sPre, int nIdx)
        //{
        //    string sNewID = nIdx.ToString();
        //    while (sNewID.Length < 6)
        //        sNewID = "0" + sNewID;
        //    sNewID = sPre + sNewID;
        //    return sNewID;
        //}


        private void btnScan_Click(object sender, EventArgs e)
        {
            if (lstImages.SelectedItems.Count == 1)
                lstImages.SelectedItems[0].Selected = false;
            int numpages = dcTask.BatchXML.SelectNodes(".//P").Count;
            int nExpected = (int)txtExpected.Value;
            if ((chkMultiple.Checked && nExpected > 0 && numpages >= nExpected) || (chkMultiple.Checked == false && numpages > 0))
            {
                MessageBox.Show(string.Format(Properties.Resources.msgExpectedNumberinBatch_Text), string.Format(Properties.Resources.titleNoScan_Title),
                                MessageBoxButtons.OK, MessageBoxIcon.None, MessageBoxDefaultButton.Button1, GetMsgRTL());
                return;
            }
            btnInsert_Click(null, EventArgs.Empty);
        }
        List<String[]> PropList;
        protected void CreateListOfPageProperties()
        {
            PropList = new List<String[]>();
            XmlNodeList xPages = dcTask.BatchXML.SelectNodes(".//P");
            foreach (XmlNode pPage in xPages)
            {
                String[] row = new String[4];
                row[0] = pPage.Attributes["id"].Value.ToString();
                string sNewPath = dcTask.BatchDir + "\\" + pPage.SelectSingleNode("V[@n='IMAGEFILE']").InnerText;
                try
                {
                    System.Drawing.Image pIm = System.Drawing.Image.FromFile(sNewPath);
                    if (pIm != null)
                    {
                        string sPixDepth = pIm.PixelFormat.ToString().Substring(6, pIm.PixelFormat.ToString().IndexOf("bpp") -3);
                        sPixDepth = sPixDepth.Replace("bpp", "");
                        string sDim = String.Format(Properties.Resources.fileDimensions, pIm.Width, pIm.Height, sPixDepth);
                        row[1] = Datacap.Global.DCBidi.LeftOrRightPhraseEmbed(sDim, false);  // Always display this in a LTR direction.  Ref Tomer.
                        FileInfo pIn = new FileInfo(sNewPath);
                        row[2] = String.Format(Properties.Resources.fileKilobytes, (pIn.Length / 1024).ToString());  /// (pIn.Length / 1024).ToString() + "K"
                        // Format the filename so BiDi characters display properly in the grid.
                        string sSrc = pPage.SelectSingleNode("V[@n='ScanSrcPath']").InnerText;
                        row[3] = Datacap.Global.DCBidi.FormatRTLFilePath(sSrc.Substring(sSrc.LastIndexOf('\\') + 1));
                        pIm.Dispose();
                        pIm = null;
                    }
                    else
                        return;
                }
                catch { }
                PropList.Add(row);
            }
        }
        protected void LoadExistingImages()
        {
            lstImages.Items.Clear();
            for (int i = 0; i < PropList.Count; i++)
            {
                ListViewItem lvi = new ListViewItem(PropList[i]);
                lstImages.Items.Add(lvi);
            }
            return;
        }

        protected string AddImage(string sSrc, int nIdx)
        {
            Application.DoEvents();
            if (dlgFiles == null)
                return "";
            XmlNode xParent = dcTask.BatchXML.DocumentElement;
            if (xParent.SelectSingleNode("D") != null)
                //xParent = xParent.SelectSingleNode("D");
                xParent = xParent.SelectSingleNode("D[last()]");

            string sNewID = FormatID("tt", ++nLastID);
            string sNewPath = dcTask.BatchDir + '\\' + sNewID + sSrc.Substring(sSrc.LastIndexOf('.'));
            while (File.Exists(sNewPath))
            {
                sNewID = FormatID("tt", ++nLastID);
                sNewPath = dcTask.BatchDir + '\\' + sNewID + sSrc.Substring(sSrc.LastIndexOf('.'));
            }
            File.Copy(sSrc, sNewPath);

            XmlElement xPage = dcTask.BatchXML.CreateElement("P");
            xPage.SetAttribute("id", FormatID("TM", nLastID));
            XmlElement xVar = dcTask.BatchXML.CreateElement("V");
            xVar.SetAttribute("n", "TYPE");
            xVar.InnerText = "Other";
            xPage.AppendChild(xVar);
            XmlElement xStat = dcTask.BatchXML.CreateElement("V");
            xStat.SetAttribute("n", "STATUS");
            xStat.InnerText = "49";
            xPage.AppendChild(xStat);

            XmlElement xImag = dcTask.BatchXML.CreateElement("V");
            xImag.SetAttribute("n", "IMAGEFILE");
            xImag.InnerText = sNewID + sSrc.Substring(sSrc.LastIndexOf('.'));
            xPage.AppendChild(xImag);

            XmlElement xSrc = dcTask.BatchXML.CreateElement("V");
            xSrc.SetAttribute("n", "ScanSrcPath");
            xSrc.InnerText = sSrc;
            xPage.AppendChild(xSrc);

            XmlElement xPageName = dcTask.BatchXML.CreateElement("V");
            xPageName.SetAttribute("n", "PageName");
            xPageName.InnerText = GetPageName(sSrc);
            xPage.AppendChild(xPageName);

            String[] row = new String[4];
            row[0] = FormatID("TM", nLastID);
            try
            {
                System.Drawing.Image pIm = System.Drawing.Image.FromFile(sNewPath);
                if (pIm != null)
                {
                    string sPixDepth = pIm.PixelFormat.ToString().Substring(6, pIm.PixelFormat.ToString().IndexOf("bpp") -3);
                    sPixDepth = sPixDepth.Replace("bpp", "");
                    string sDim = String.Format(Properties.Resources.fileDimensions, pIm.Width, pIm.Height, sPixDepth);
                    row[1] = Datacap.Global.DCBidi.LeftOrRightPhraseEmbed(sDim, false);  // Always display this in a LTR direction.  Ref Tomer.
                    FileInfo pIn = new FileInfo(sNewPath);
                    row[2] = String.Format(Properties.Resources.fileKilobytes, (pIn.Length / 1024).ToString());  /// (pIn.Length / 1024).ToString() + "K"
                    // Format the filename so BiDi characters display properly in the grid.
                    row[3] = Datacap.Global.DCBidi.FormatRTLFilePath(sSrc.Substring(sSrc.LastIndexOf('\\') + 1));
                    pIm.Dispose();
                    pIm = null;
                }
                else
                    return "";
            }
            catch {}

            ListViewItem lvi = new ListViewItem(row);
            XmlNode xRef=null;
            if (nIdx > -1)
            {
                xRef = xParent.SelectNodes("P")[nIdx];
                xParent.InsertBefore(xPage, xRef);
                lstImages.Items.Insert(nIdx, lvi);
                PropList.Insert(nIdx, row);
            }
            else
            {
                xParent.AppendChild(xPage);
                lstImages.Items.Add(lvi);
                PropList.Add(row);
            }
            BatchForm.DeselectTreeNodes();
            ImageForm.AddPage(xPage);
            BatchForm.AddPage(xPage);
            BatchForm.SelectTreeNode(xPage.Attributes["id"].Value);

            return xPage.Attributes["id"].Value;
        }

        private string GetPageName(string sSrc)
        {
            String pageName = sSrc;
            Int32 slashPos = sSrc.LastIndexOf("\\");
            if (slashPos >=0)
            {
                pageName = pageName.Substring(slashPos + 1);
            }
            Int32 dotPos = pageName.IndexOf(".");
            if (dotPos >= 0)
            {
                pageName = pageName.Substring(0, dotPos);
            }
            return pageName;
        }

        private void btnFinish_Click(object sender, EventArgs e)
        {
            //renumber pages / images (later)
            if (dcTask.BatchXML.SelectNodes(".//P").Count == 0)
            {
                if (MessageBox.Show(Properties.Resources.msgEmptyBatchCancel_Text, Properties.Resources.msgEmptyBatch_Title,
                                    MessageBoxButtons.YesNo,
                                    MessageBoxIcon.None, MessageBoxDefaultButton.Button1, GetMsgRTL()) == DialogResult.No)
                    return;
                Status = "canceled";
            }
            else
            {
                ReNumber();
                Status = "finished";
            }
            OnComplete(this, new TaskStatusEventArgs(Status));
        }

        public override bool StartBatch()
        {
            bool bRes = base.StartBatch();

            BatchForm.SelectionChange -= new System.EventHandler(BatchForm_OnSelectionChange);
            BatchForm.SelectionChange += new System.EventHandler(BatchForm_OnSelectionChange);

            BatchForm.TypeChange -= new System.EventHandler(BatchForm_OnTypeChange);
            BatchForm.TypeChange += new System.EventHandler(BatchForm_OnTypeChange);

            BatchForm.DragDropCompleted -= new System.EventHandler(BatchForm_OnDragDropCompleted);
            BatchForm.DragDropCompleted += new System.EventHandler(BatchForm_OnDragDropCompleted);

            ImageForm.MoveImage -= new System.EventHandler(ImageForm_OnMoveImage);
            ImageForm.MoveImage += new System.EventHandler(ImageForm_OnMoveImage);

            BatchForm.DeleteEventHandler -= new EventHandler(BatchForm_OnDeleteMenuClicked);
            BatchForm.DeleteEventHandler += new EventHandler(BatchForm_OnDeleteMenuClicked);

            ImageForm.RemoveClicked -= new dcDTlib.ImageForm.RemoveDelegate(ImageForm_RemoveClicked);
            ImageForm.RemoveClicked += new dcDTlib.ImageForm.RemoveDelegate(ImageForm_RemoveClicked);
            ImageForm.updateTreeEvent += new dcDTlib.ImageForm.updateTreeAfterDropDelegate(ImageForm_UpdateListAfterDragDrop);

            Application.AddMessageFilter(this); // to catch keystrokes

            lstImages_SelectedIndexChanged(null, EventArgs.Empty);

            btnScan.Enabled = (textBox1.Text != "");
            // if the batch has images, populate listbox
            bScanInProgress = false;
            lstImages.Items.Clear();
            CreateListOfPageProperties();
            LoadExistingImages();

            return bRes;

        }

        public override bool EndBatch(String Status)
        {
            if (bScanInProgress)
            {
                System.Threading.Thread.Sleep(1000);
                bScanInProgress = false;
            }
            // Clear stuff
            lstImages.Items.Clear();
            ImageForm.Clear();
            txtExpected.Value = 0;
//          chkMultiple.Checked = true;
//          textBox1.Text = "";
            dlgFiles = null;

            BatchForm.SelectionChange -= new System.EventHandler(BatchForm_OnSelectionChange);
            BatchForm.SelectionChange -= new System.EventHandler(BatchForm_OnSelectionChange);
            BatchForm.TypeChange -= new System.EventHandler(BatchForm_OnTypeChange);
            BatchForm.TypeChange -= new System.EventHandler(BatchForm_OnTypeChange);
            BatchForm.DragDropCompleted -= new System.EventHandler(BatchForm_OnDragDropCompleted);
            BatchForm.DragDropCompleted -= new System.EventHandler(BatchForm_OnDragDropCompleted);
            ImageForm.MoveImage -= new System.EventHandler(ImageForm_OnMoveImage);
            ImageForm.MoveImage -= new System.EventHandler(ImageForm_OnMoveImage);
            BatchForm.DeleteEventHandler -= new EventHandler(BatchForm_OnDeleteMenuClicked);
            BatchForm.DeleteEventHandler -= new EventHandler(BatchForm_OnDeleteMenuClicked);
            ImageForm.RemoveClicked -= new dcDTlib.ImageForm.RemoveDelegate(ImageForm_RemoveClicked);
            ImageForm.RemoveClicked -= new dcDTlib.ImageForm.RemoveDelegate(ImageForm_RemoveClicked);
            // 172362 : defect fix.
            // PreFilterMessage keeps getting called eventhough vscan page is closed.
            Application.RemoveMessageFilter(this);
            return base.EndBatch(Status);
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            textBox1.Text = Datacap.Global.DCBidi.FormatRTLFilePath(Datacap.Global.DCBidi.StripBiDiMarks(textBox1.Text));
            string pathNoBiDiMarks = Datacap.Global.DCBidi.StripBiDiMarks(textBox1.Text); // Remove any hidden BiDi formatting characters.
            pathNoBiDiMarks = pathNoBiDiMarks.Replace("\\\\", "\\");
            if (!File.Exists(@pathNoBiDiMarks))
                return;

            Application.UseWaitCursor = true;
            Cursor.Current = Cursors.WaitCursor;
            string sID = "";
            string onefileName = string.Empty;
            int nSel = lstImages.SelectedIndices.Count > 0 ? lstImages.SelectedIndices[0] : -1;
            btnCancel.Enabled = btnFinish.Enabled = false;
            bScanInProgress = true;
            int numpages = dcTask.BatchXML.SelectNodes(".//P").Count;
            int nExpected = (int)txtExpected.Value - numpages;
            if (dlgFiles != null && (dlgFiles.Length > 1 || (dlgFiles.Length == 0 && chkMultiple.Checked == false)))
            {
                // user selected multiple files, read those in only
                foreach (string s in dlgFiles)
                {
                    sID = AddImage(s, nSel);
                    if (sID!="" && nSel > -1)
                        nSel++;
                    nExpected--;
                    if (nExpected == 0)
                        break;
                }
            }
            else
            {
                dlgFiles = null;
                // user selected one file, try to read multiple if desired (in sort order!)
                pathNoBiDiMarks = Datacap.Global.DCBidi.StripBiDiMarks(textBox1.Text); // Remove any hidden BiDi formatting characters.
                pathNoBiDiMarks = pathNoBiDiMarks.Replace("\\\\", "\\");
                string extn = Path.GetExtension(@pathNoBiDiMarks);
                string sFolder = Path.GetDirectoryName(@pathNoBiDiMarks);
                try
                {
                    dlgFiles = Directory.GetFiles(sFolder, "*" + extn);
                    Array.Sort(dlgFiles);
                }
                catch (Exception ex)
                {
                    pWeb.aTM.WriteLogString(4, "btnInsert_Click: Exception " + ex.Message);
                }
                if (dlgFiles != null && dlgFiles.Length > 0)
                {
                    onefileName = dlgFiles[0];
                    bool bStarted = false;
                    nExpected = (int)txtExpected.Value;
                    if (chkMultiple.Checked == false)
                        nExpected = 1;
                    foreach (string s in dlgFiles)
                    {
                        if (0 == string.Compare(s, pathNoBiDiMarks, true))
                            bStarted = true;
                        if (!bStarted)
                            continue;
                        sID = AddImage(s, nSel);
                        if (sID == "")
                            continue;
                        if (nSel > -1)
                            nSel++;
                        nExpected--;
                        if (nExpected == 0)
                            break;
                    }
                }
            }
            btnCancel.Enabled = btnFinish.Enabled = true;
            bScanInProgress = false;
            // save the current folder 
            if (dlgFiles != null && dlgFiles.Length > 1)
                onefileName = dlgFiles[0];
            SaveLastFolderLocation(onefileName);
            Application.UseWaitCursor = false;
            Cursor.Current = Cursors.Default;
            BatchForm.LoadBatch(sID);
            ImageForm.LoadThumbs(sID, false);
        }

        private void chkMultiple_CheckedChanged(object sender, EventArgs e)
        {
            if (chkMultiple.Checked)
            {
                txtExpected.Enabled = true;
                txtExpected.Value = 0;
            }
            else
            {
                txtExpected.Enabled = false;
                txtExpected.Value = 1;
            }

        }

        private void btnMoveUp_Click(object sender, EventArgs e)
        {
            int nSel = lstImages.SelectedIndices.Count > 0 ? lstImages.SelectedIndices[0] : -1;
            MoveImage(nSel, nSel - 1);
        }

        private void btnMoveDn_Click(object sender, EventArgs e)
        {
            int nSel = lstImages.SelectedIndices.Count > 0 ? lstImages.SelectedIndices[0] : -1;
            MoveImage(nSel, nSel + 2);              // uses InsertBefore()
        }

        private void MoveImage(int nFrom, int nTo)
        {
            XmlNode xPage = dcTask.BatchXML.SelectNodes(".//P")[nFrom];
            XmlNode xParent = dcTask.BatchXML.DocumentElement;
            bool docNode = false;
            if (xParent.SelectSingleNode("D") != null)
            {
                xParent = xParent.SelectSingleNode("D");
                docNode = true;
            }
            int nCount = lstImages.Items.Count;
            XmlNode xRef = xParent.SelectNodes("P")[nTo];

            ListViewItem pItem = new ListViewItem(lstImages.Items[nFrom].Text, 0);
            int nsubs = lstImages.Items[nFrom].SubItems.Count;
            if (nsubs > 1)
            {
                for (int i = 1; i < nsubs; i++)
                {
                    pItem.SubItems.Add(lstImages.Items[nFrom].SubItems[i].Text);
                }
            }

            ImageForm.RemoveAt(nFrom);
            if (xRef != null)
                xParent.InsertBefore(xPage, xRef);
            else
                xParent.AppendChild(xPage);
            ImageForm.AddPage(xPage);
            ImageForm.SetThumbText(xPage.SelectSingleNode("V[@n='TYPE']").InnerText, nTo);

            if (nTo > nFrom)
            {
                lstImages.Items.RemoveAt(nFrom);
                lstImages.Items.Insert(--nTo, pItem);
            }
            else
            {
                lstImages.Items.RemoveAt(nFrom);
                lstImages.Items.Insert(nTo, pItem);
            }
            string[] row = PropList[nFrom];
            PropList.RemoveAt(nFrom);
            PropList.Insert(nTo, row);

            string sID = xParent.Attributes["id"].Value;
            if (docNode)
                sID = xParent.ParentNode.Attributes["id"].Value;
            BatchForm.LoadBatch(sID);       // sync batchview with the dco
            BatchForm.SelectTreeNode(xPage.Attributes["id"].Value);
        }

        private void BatchForm_OnDeleteMenuClicked(object sender, EventArgs e)
        {
            UpdateListImages(aSelectedPageIDs);
            return;
        }
        private void ImageForm_RemoveClicked()
        {
            XmlNodeList xPages = dcTask.BatchXML.SelectNodes(".//P");
            bool exist = false;
            List<string> sPIDs = new List<string>();
            foreach (string[] sa in PropList)
            {
                exist = false;
                string sID = sa[0];
                foreach(XmlNode pPage in xPages)
                {
                    if (sID.Equals(pPage.Attributes["id"].Value.ToString()))
                    {
                        exist = true;
                        break;
                    }
                }
                if (!exist)
                    sPIDs.Add(sID);
            }
            string[] aPIDs = sPIDs.ToArray();
            UpdateListImages(aPIDs);
        }
        private string ImageForm_UpdateListAfterDragDrop(string targetStr)
        {
            RearrangeListImages();
            return "";
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            string[] sIDs = GetSelectedPageIDs();
            RemoveSelectedImages();
            UpdateListImages(sIDs);
        }
        private void RearrangeListImages()
        {
            lstImages.Items.Clear();
            XmlNodeList xPages = dcTask.BatchXML.SelectNodes(".//P");
            List<string[]> lTemp = new List<string[]>();
            foreach(XmlNode pPage in xPages)
            {
                string pid = pPage.Attributes["id"].Value.ToString();
                string[] sa = PropList.Find(x => x[0].Contains(pid));
                lTemp.Add(sa);
            }
            PropList.Clear();
            foreach (string[] sa in lTemp)
                PropList.Add(sa);
            lTemp.Clear();
            lTemp = null;
            LoadExistingImages();
        }
        private void UpdateListImages(string[] sPageIDs)
        {
            if (sPageIDs == null || sPageIDs.Length == 0)
                return;
            foreach (string sID in sPageIDs)
            {
                string[] row = PropList.Find(x => x[0].Contains(sID));
                ListViewItem lvi = new ListViewItem(row);
                PropList.Remove(row);
            }
            LoadExistingImages();
        }

        bool bImageSel_InProgress = false;
        private void lstImages_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (bImageSel_InProgress)
                return;
            bImageSel_InProgress = true;

            int nSel = lstImages.SelectedIndices.Count > 0 ? lstImages.SelectedIndices[0] : -1;

            btnInsert.Enabled = (nSel > -1);
            btnMoveDn.Enabled = (nSel > -1 && nSel < lstImages.Items.Count - 1);
            btnMoveUp.Enabled = (nSel > -1 && nSel>0);
            btnRemove.Enabled = (nSel > -1);

            if (nSel > -1)
            {
                lstImages.EnsureVisible(nSel);
                XmlNode xPage = dcTask.BatchXML.SelectNodes(".//P")[nSel];
                BatchForm.SelectTreeNode(xPage.Attributes["id"].Value);
            }
            bImageSel_InProgress = false;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            int nCount = dcTask.BatchXML.SelectNodes(".//P").Count;
            if (nCount > 0)
                if (MessageBox.Show(string.Format(Properties.Resources.msgConfirmCancel_Text, nCount),
                                    Properties.Resources.msgConfirmCance_Title, MessageBoxButtons.YesNo,
                                    MessageBoxIcon.None, MessageBoxDefaultButton.Button1, GetMsgRTL()) != DialogResult.Yes)
                    return;
            Status = "canceled";
            OnComplete(this, new TaskStatusEventArgs(Status));
        }

        // Moved to dotPanelBase.cs
        //private void ReNumber()
        //{
        //    int nDocID=1;
        //    XmlNodeList xDox = dcTask.BatchXML.SelectNodes(".//D");
        //    foreach (XmlNode xDoc in xDox)
        //    {
        //        string sID=(nDocID++).ToString();
        //        while (sID.Length<2)
        //            sID="0" + sID;
        //        xDoc.Attributes["id"].Value = dcTask.BatchID + "." + sID;
        //    }

        //    int nIdx = 1;
        //    XmlNodeList xPages = dcTask.BatchXML.SelectNodes(".//P");
        //    foreach (XmlNode xPage in xPages)
        //    {
        //        string sNewID = FormatID("TM", nIdx++);
        //        xPage.Attributes["id"].Value = sNewID;
        //        string sPath=xPage.SelectSingleNode("V[@n='IMAGEFILE']").InnerText;
        //        string sNewPath=sNewID.ToLower() + sPath.Substring(sPath.LastIndexOf('.'));
        //        File.Move(dcTask.BatchDir + "\\" + sPath, dcTask.BatchDir + "\\" + sNewPath);
        //        xPage.SelectSingleNode("V[@n='IMAGEFILE']").InnerText = sNewPath;
        //    }
        //}

        private void ImageForm_OnMoveImage(Object src, EventArgs e)
        {
            int nFrom = ((Size)src).Width;
            int nTo = ((Size)src).Height;
            MoveImage(nFrom, nTo);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            btnScan.Enabled = true;
        }


        private void textBox1_Click(object sender, EventArgs e)
        {

        }

        // Reformat the field so it properly displays if there is BiDi text.
        private void textBox1_Leave(object sender, EventArgs e)
        {
            textBox1.Text = Datacap.Global.DCBidi.FormatRTLFilePath(Datacap.Global.DCBidi.StripBiDiMarks(textBox1.Text));

            // Moved from TextChanged to here because it really slows down typing in the edit box if File.Exists is not fast.
            string pathNoBiDiMarks = Datacap.Global.DCBidi.StripBiDiMarks(textBox1.Text); // Remove any hidden BiDi formatting characters.
            btnScan.Enabled = File.Exists(@pathNoBiDiMarks);
        }

        // When someone clicks to manually edit the path, remove any invisible BiDi formatting characters.
        private void textBox1_Enter(object sender, EventArgs e)
        {
            textBox1.Text = Datacap.Global.DCBidi.StripBiDiMarks(textBox1.Text);
        }

        public bool PreFilterMessage(ref Message m)
        {
            if (m.Msg == 256) // WM_KEYDOWN
            {
                // handle hotkeys to set pagetype, switch to batch tree view, etc
                // return true if this key has been handled, false if we want to pass it along

                if ((Control.ModifierKeys & (Keys.Control | Keys.Alt | Keys.Shift)) == 0)    // No ctrl/Alt/Shift held down
                {
                    switch ((int)m.WParam)
                    {
                        case (int)Keys.F6:
                            if (!bScanInProgress)
                                btnFinish_Click(null, null);
                            return true;
                        case (int)Keys.F5:
                            RefreshUI();
                            return true;
                        case (int)Keys.Left:       // Left Arrow
                            if (BatchForm.ContainsFocus)
                                return true;        // causes crash in batch view
                            break;
                        case (int)Keys.Right:       // Right Arrow
                            if (BatchForm.ContainsFocus)
                                return true;        // causes crash in batch view
                            break;
                        // Handled in Imageform
                        //case (int)Keys.Delete:       // Delete = Remove image
                        //   // if (btnRemove.Enabled)  // 172362 - when user clicks on delete button from batchview
                        //        btnRemove_Click(null, null);
                        //    return true;
                        case (int)Keys.Insert:       // Insert = Insert scanned images
                            if (btnInsert.Enabled)
                                btnInsert_Click(null, null);
                            return true;
                    }
                }

                const int VK_CONTROL = 0x11;        // control keycode


                if ((Control.ModifierKeys & (Keys.Control | Keys.Alt | Keys.Shift)) == Keys.Control)    // Ctrl only held down
                {
                    switch ((int)m.WParam)
                    {
                        case (int)Keys.Z:  // Ctrl-Z = Cancel batch
                            if (!bScanInProgress)
                                btnCancel_Click(null, null);
                            return true;
                        case (int)Keys.Q:  // Ctrl-Q = Hold batch
                            if (!bScanInProgress)
                            {
                                Status = "hold";
                                OnComplete(this, new TaskStatusEventArgs(Status));
                            }
                            return true;
                        case (int)Keys.B: // CTRL-B = focus on Batch Tree
                            BatchForm.SetBatchFocus();
                            return true;
                        case (int)Keys.D: // CTRL-D = Delete (Remove)
                            if (btnRemove.Enabled)
                                btnRemove_Click(null, null);
                            return true;
                        case (int)Keys.S:       // CTRL-S = focus on Scan Panel
                            this.Focus();
                            return true;
                        case (int)Keys.T:        // CTRL-T = toggle thumbnail view
                            ImageForm.ToggleThumbs();
                            return true;
                        case (int)Keys.Up:       // CTRL-UPARROW = Move Up
                            if (btnMoveUp.Enabled)
                                btnMoveUp_Click(null, null);
                            return true;
                        case (int)Keys.Down:       // CTRL-DOWNARROW = Move Down
                            if (btnMoveDn.Enabled)
                                btnMoveDn_Click(null, null);
                            return true;
                        //vk test case (int)VK_CONTROL:     // Control by itself
                        //vk test    return false;
                        default:
                            break;
                    }
                }

                //if ((int)m.LParam == 983041 && (int)m.WParam == 9 && (Control.ModifierKeys & Keys.Shift) != Keys.Shift)    // VK_TAB=9 LParam=0xF0001 (count=1,OEM scancode=F)
            }
            return false;
        }
    }
}
