namespace DotEditPanels
{
    partial class dotMaster
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtSetup = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.dlgFO = new System.Windows.Forms.OpenFileDialog();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.txtNewName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnCreate = new System.Windows.Forms.Button();
            this.cmbTypes = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnBrwsLayout = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtLayout = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // txtSetup
            // 
            this.txtSetup.Location = new System.Drawing.Point(87, 34);
            this.txtSetup.Name = "txtSetup";
            this.txtSetup.Size = new System.Drawing.Size(178, 20);
            this.txtSetup.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(20, 37);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "DCO Setup";
            // 
            // btnBrowse
            // 
            this.btnBrowse.Location = new System.Drawing.Point(271, 34);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(38, 23);
            this.btnBrowse.TabIndex = 7;
            this.btnBrowse.Text = "...";
            this.btnBrowse.UseVisualStyleBackColor = true;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // txtNewName
            // 
            this.txtNewName.Location = new System.Drawing.Point(87, 143);
            this.txtNewName.Name = "txtNewName";
            this.txtNewName.Size = new System.Drawing.Size(100, 20);
            this.txtNewName.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(20, 146);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "New name";
            // 
            // btnCreate
            // 
            this.btnCreate.Location = new System.Drawing.Point(234, 141);
            this.btnCreate.Name = "btnCreate";
            this.btnCreate.Size = new System.Drawing.Size(75, 23);
            this.btnCreate.TabIndex = 10;
            this.btnCreate.Text = "Create";
            this.btnCreate.UseVisualStyleBackColor = true;
            this.btnCreate.Click += new System.EventHandler(this.btnCreate_Click);
            // 
            // cmbTypes
            // 
            this.cmbTypes.FormattingEnabled = true;
            this.cmbTypes.Location = new System.Drawing.Point(87, 107);
            this.cmbTypes.Name = "cmbTypes";
            this.cmbTypes.Size = new System.Drawing.Size(121, 21);
            this.cmbTypes.TabIndex = 11;
            this.cmbTypes.SelectedIndexChanged += new System.EventHandler(this.cmbTypes_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(20, 110);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "Page Type";
            // 
            // btnBrwsLayout
            // 
            this.btnBrwsLayout.Location = new System.Drawing.Point(271, 70);
            this.btnBrwsLayout.Name = "btnBrwsLayout";
            this.btnBrwsLayout.Size = new System.Drawing.Size(38, 23);
            this.btnBrwsLayout.TabIndex = 15;
            this.btnBrwsLayout.Text = "...";
            this.btnBrwsLayout.UseVisualStyleBackColor = true;
            this.btnBrwsLayout.Click += new System.EventHandler(this.btnBrwsLayout_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 73);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 13);
            this.label1.TabIndex = 14;
            this.label1.Text = "Layout XML";
            // 
            // txtLayout
            // 
            this.txtLayout.Location = new System.Drawing.Point(87, 70);
            this.txtLayout.Name = "txtLayout";
            this.txtLayout.Size = new System.Drawing.Size(178, 20);
            this.txtLayout.TabIndex = 13;
            // 
            // dotMaster
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.btnBrwsLayout);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtLayout);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cmbTypes);
            this.Controls.Add(this.btnCreate);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtNewName);
            this.Controls.Add(this.btnBrowse);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtSetup);
            this.Name = "dotMaster";
            this.Size = new System.Drawing.Size(330, 204);
            
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtSetup;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.OpenFileDialog dlgFO;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.TextBox txtNewName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnCreate;
        private System.Windows.Forms.ComboBox cmbTypes;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnBrwsLayout;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtLayout;
    }
}
