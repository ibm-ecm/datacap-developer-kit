
namespace DotEditPanels
{
    partial class Main_Page
    {
        /// 
        /// Required designer variable.
        /// 
        private System.ComponentModel.IContainer components = null;

        /// 
        /// Clean up any resources being used.
        /// 
        /// true if managed resources should be disposed; otherwise, false.
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// 
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main_Page));
            this.lblVendor = new System.Windows.Forms.Label();
            this.lblVendor_Number = new System.Windows.Forms.Label();
            this.lblRemittance_Zip = new System.Windows.Forms.Label();
            this.lblInvoice_Number = new System.Windows.Forms.Label();
            this.lblInvoice_Date = new System.Windows.Forms.Label();
            this.lblPO_Number = new System.Windows.Forms.Label();
            this.lblTax = new System.Windows.Forms.Label();
            this.lblShipping = new System.Windows.Forms.Label();
            this.lblInvoice_Total = new System.Windows.Forms.Label();
            this.lblInvoice_Type = new System.Windows.Forms.Label();
            this.lbItemID = new System.Windows.Forms.Label();
            this.lbItemDesc = new System.Windows.Forms.Label();
            this.lbQty = new System.Windows.Forms.Label();
            this.lbPrice = new System.Windows.Forms.Label();
            this.lbLineTotal = new System.Windows.Forms.Label();
            this.panLineitem = new System.Windows.Forms.Panel();
            this.dcimItemID = new AxDCIMAGELib.AxDcimage();
            this.dcedItemID = new AxDCEDITLib.AxDcedit();
            this.dcimItemDesc = new AxDCIMAGELib.AxDcimage();
            this.dcedItemDesc = new AxDCEDITLib.AxDcedit();
            this.dcimQty = new AxDCIMAGELib.AxDcimage();
            this.dcedQty = new AxDCEDITLib.AxDcedit();
            this.dcimPrice = new AxDCIMAGELib.AxDcimage();
            this.dcedPrice = new AxDCEDITLib.AxDcedit();
            this.dcimLineTotal = new AxDCIMAGELib.AxDcimage();
            this.dcedLineTotal = new AxDCEDITLib.AxDcedit();
            this.btnInsBeforepbLineitem = new System.Windows.Forms.Button();
            this.btnInsAfterpbLineitem = new System.Windows.Forms.Button();
            this.btnDelpbLineitem = new System.Windows.Forms.Button();
            this.lblLineitem = new System.Windows.Forms.Label();
            this.dcedVendor = new AxDCEDITLib.AxDcedit();
            this.dcedVendor_Number = new AxDCEDITLib.AxDcedit();
            this.dcimRemittance_Zip = new AxDCIMAGELib.AxDcimage();
            this.dcedRemittance_Zip = new AxDCEDITLib.AxDcedit();
            this.dcimInvoice_Number = new AxDCIMAGELib.AxDcimage();
            this.dcedInvoice_Number = new AxDCEDITLib.AxDcedit();
            this.dcimInvoice_Date = new AxDCIMAGELib.AxDcimage();
            this.dcedInvoice_Date = new AxDCEDITLib.AxDcedit();
            this.dcimPO_Number = new AxDCIMAGELib.AxDcimage();
            this.dcedPO_Number = new AxDCEDITLib.AxDcedit();
            this.dcimTax = new AxDCIMAGELib.AxDcimage();
            this.dcedTax = new AxDCEDITLib.AxDcedit();
            this.dcimShipping = new AxDCIMAGELib.AxDcimage();
            this.dcedShipping = new AxDCEDITLib.AxDcedit();
            this.dcimInvoice_Total = new AxDCIMAGELib.AxDcimage();
            this.dcedInvoice_Total = new AxDCEDITLib.AxDcedit();
            this.dcedInvoice_Type = new AxDCEDITLib.AxDcedit();
            this.panLineitem.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dcimItemID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedItemID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimItemDesc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedItemDesc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimQty)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedQty)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimPrice)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedPrice)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimLineTotal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedLineTotal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedVendor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedVendor_Number)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimRemittance_Zip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedRemittance_Zip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimInvoice_Number)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedInvoice_Number)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimInvoice_Date)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedInvoice_Date)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimPO_Number)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedPO_Number)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimTax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedTax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimShipping)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedShipping)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimInvoice_Total)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedInvoice_Total)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedInvoice_Type)).BeginInit();
            this.SuspendLayout();
            // 
            // lblVendor
            // 
            this.lblVendor.AutoSize = true;
            this.lblVendor.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVendor.Location = new System.Drawing.Point(17, 37);
            this.lblVendor.Name = "lblVendor";
            this.lblVendor.Size = new System.Drawing.Size(65, 18);
            this.lblVendor.TabIndex = 0;
            this.lblVendor.Tag = "Vendor";
            this.lblVendor.Text = "Vendor";
            // 
            // lblVendor_Number
            // 
            this.lblVendor_Number.AutoSize = true;
            this.lblVendor_Number.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVendor_Number.Location = new System.Drawing.Point(19, 112);
            this.lblVendor_Number.Name = "lblVendor_Number";
            this.lblVendor_Number.Size = new System.Drawing.Size(138, 18);
            this.lblVendor_Number.TabIndex = 3;
            this.lblVendor_Number.Tag = "Vendor_Number";
            this.lblVendor_Number.Text = "Vendor_Number";
            // 
            // lblRemittance_Zip
            // 
            this.lblRemittance_Zip.AutoSize = true;
            this.lblRemittance_Zip.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRemittance_Zip.Location = new System.Drawing.Point(203, 91);
            this.lblRemittance_Zip.Name = "lblRemittance_Zip";
            this.lblRemittance_Zip.Size = new System.Drawing.Size(137, 18);
            this.lblRemittance_Zip.TabIndex = 6;
            this.lblRemittance_Zip.Tag = "Remittance_Zip";
            this.lblRemittance_Zip.Text = "Remittance_Zip";
            // 
            // lblInvoice_Number
            // 
            this.lblInvoice_Number.AutoSize = true;
            this.lblInvoice_Number.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInvoice_Number.Location = new System.Drawing.Point(17, 187);
            this.lblInvoice_Number.Name = "lblInvoice_Number";
            this.lblInvoice_Number.Size = new System.Drawing.Size(140, 18);
            this.lblInvoice_Number.TabIndex = 9;
            this.lblInvoice_Number.Tag = "Invoice_Number";
            this.lblInvoice_Number.Text = "Invoice_Number";
            // 
            // lblInvoice_Date
            // 
            this.lblInvoice_Date.AutoSize = true;
            this.lblInvoice_Date.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInvoice_Date.Location = new System.Drawing.Point(203, 187);
            this.lblInvoice_Date.Name = "lblInvoice_Date";
            this.lblInvoice_Date.Size = new System.Drawing.Size(116, 18);
            this.lblInvoice_Date.TabIndex = 12;
            this.lblInvoice_Date.Tag = "Invoice_Date";
            this.lblInvoice_Date.Text = "Invoice_Date";
            // 
            // lblPO_Number
            // 
            this.lblPO_Number.AutoSize = true;
            this.lblPO_Number.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPO_Number.Location = new System.Drawing.Point(389, 187);
            this.lblPO_Number.Name = "lblPO_Number";
            this.lblPO_Number.Size = new System.Drawing.Size(104, 18);
            this.lblPO_Number.TabIndex = 15;
            this.lblPO_Number.Tag = "PO_Number";
            this.lblPO_Number.Text = "PO_Number";
            // 
            // lblTax
            // 
            this.lblTax.AutoSize = true;
            this.lblTax.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTax.Location = new System.Drawing.Point(138, 283);
            this.lblTax.Name = "lblTax";
            this.lblTax.Size = new System.Drawing.Size(37, 18);
            this.lblTax.TabIndex = 18;
            this.lblTax.Tag = "Tax";
            this.lblTax.Text = "Tax";
            // 
            // lblShipping
            // 
            this.lblShipping.AutoSize = true;
            this.lblShipping.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblShipping.Location = new System.Drawing.Point(283, 283);
            this.lblShipping.Name = "lblShipping";
            this.lblShipping.Size = new System.Drawing.Size(78, 18);
            this.lblShipping.TabIndex = 21;
            this.lblShipping.Tag = "Shipping";
            this.lblShipping.Text = "Shipping";
            // 
            // lblInvoice_Total
            // 
            this.lblInvoice_Total.AutoSize = true;
            this.lblInvoice_Total.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInvoice_Total.Location = new System.Drawing.Point(428, 283);
            this.lblInvoice_Total.Name = "lblInvoice_Total";
            this.lblInvoice_Total.Size = new System.Drawing.Size(119, 18);
            this.lblInvoice_Total.TabIndex = 24;
            this.lblInvoice_Total.Tag = "Invoice_Total";
            this.lblInvoice_Total.Text = "Invoice_Total";
            // 
            // lblInvoice_Type
            // 
            this.lblInvoice_Type.AutoSize = true;
            this.lblInvoice_Type.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInvoice_Type.Location = new System.Drawing.Point(389, 112);
            this.lblInvoice_Type.Name = "lblInvoice_Type";
            this.lblInvoice_Type.Size = new System.Drawing.Size(116, 18);
            this.lblInvoice_Type.TabIndex = 27;
            this.lblInvoice_Type.Tag = "Invoice_Type";
            this.lblInvoice_Type.Text = "Invoice_Type";
            // 
            // lbItemID
            // 
            this.lbItemID.BackColor = System.Drawing.SystemColors.Desktop;
            this.lbItemID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbItemID.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbItemID.Location = new System.Drawing.Point(25, 413);
            this.lbItemID.Name = "lbItemID";
            this.lbItemID.Size = new System.Drawing.Size(89, 21);
            this.lbItemID.TabIndex = 33;
            this.lbItemID.Tag = "ItemID";
            this.lbItemID.Text = "ItemID";
            // 
            // lbItemDesc
            // 
            this.lbItemDesc.BackColor = System.Drawing.SystemColors.Desktop;
            this.lbItemDesc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbItemDesc.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbItemDesc.Location = new System.Drawing.Point(115, 413);
            this.lbItemDesc.Name = "lbItemDesc";
            this.lbItemDesc.Size = new System.Drawing.Size(201, 21);
            this.lbItemDesc.TabIndex = 34;
            this.lbItemDesc.Tag = "ItemDesc";
            this.lbItemDesc.Text = "ItemDesc";
            // 
            // lbQty
            // 
            this.lbQty.BackColor = System.Drawing.SystemColors.Desktop;
            this.lbQty.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbQty.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbQty.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lbQty.Location = new System.Drawing.Point(317, 413);
            this.lbQty.Name = "lbQty";
            this.lbQty.Size = new System.Drawing.Size(46, 21);
            this.lbQty.TabIndex = 35;
            this.lbQty.Tag = "Qty";
            this.lbQty.Text = "Qty";
            this.lbQty.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lbPrice
            // 
            this.lbPrice.BackColor = System.Drawing.SystemColors.Desktop;
            this.lbPrice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbPrice.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPrice.Location = new System.Drawing.Point(364, 413);
            this.lbPrice.Name = "lbPrice";
            this.lbPrice.Size = new System.Drawing.Size(79, 21);
            this.lbPrice.TabIndex = 36;
            this.lbPrice.Tag = "Price";
            this.lbPrice.Text = "Price";
            this.lbPrice.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lbLineTotal
            // 
            this.lbLineTotal.BackColor = System.Drawing.SystemColors.Desktop;
            this.lbLineTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbLineTotal.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbLineTotal.Location = new System.Drawing.Point(444, 413);
            this.lbLineTotal.Name = "lbLineTotal";
            this.lbLineTotal.Size = new System.Drawing.Size(104, 21);
            this.lbLineTotal.TabIndex = 37;
            this.lbLineTotal.Tag = "LineTotal";
            this.lbLineTotal.Text = "LineTotal";
            this.lbLineTotal.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // panLineitem
            // 
            this.panLineitem.AutoScroll = true;
            this.panLineitem.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panLineitem.Controls.Add(this.dcimItemID);
            this.panLineitem.Controls.Add(this.dcedItemID);
            this.panLineitem.Controls.Add(this.dcimItemDesc);
            this.panLineitem.Controls.Add(this.dcedItemDesc);
            this.panLineitem.Controls.Add(this.dcimQty);
            this.panLineitem.Controls.Add(this.dcedQty);
            this.panLineitem.Controls.Add(this.dcimPrice);
            this.panLineitem.Controls.Add(this.dcedPrice);
            this.panLineitem.Controls.Add(this.dcimLineTotal);
            this.panLineitem.Controls.Add(this.dcedLineTotal);
            this.panLineitem.Location = new System.Drawing.Point(22, 435);
            this.panLineitem.Name = "panLineitem";
            this.panLineitem.Size = new System.Drawing.Size(554, 208);
            this.panLineitem.TabIndex = 38;
            this.panLineitem.Tag = "Lineitem";
            // 
            // dcimItemID
            // 
            this.dcimItemID.Location = new System.Drawing.Point(0, 0);
            this.dcimItemID.Name = "dcimItemID";
            this.dcimItemID.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimItemID.OcxState")));
            this.dcimItemID.Size = new System.Drawing.Size(90, 27);
            this.dcimItemID.TabIndex = 0;
            this.dcimItemID.TabStop = false;
            this.dcimItemID.Tag = "ItemID";
            // 
            // dcedItemID
            // 
            this.dcedItemID.Location = new System.Drawing.Point(0, 26);
            this.dcedItemID.Name = "dcedItemID";
            this.dcedItemID.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedItemID.OcxState")));
            this.dcedItemID.Size = new System.Drawing.Size(90, 25);
            this.dcedItemID.TabIndex = 1;
            this.dcedItemID.Tag = "ItemID";
            // 
            // dcimItemDesc
            // 
            this.dcimItemDesc.Location = new System.Drawing.Point(90, 0);
            this.dcimItemDesc.Name = "dcimItemDesc";
            this.dcimItemDesc.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimItemDesc.OcxState")));
            this.dcimItemDesc.Size = new System.Drawing.Size(203, 27);
            this.dcimItemDesc.TabIndex = 2;
            this.dcimItemDesc.TabStop = false;
            this.dcimItemDesc.Tag = "ItemDesc";
            // 
            // dcedItemDesc
            // 
            this.dcedItemDesc.Location = new System.Drawing.Point(90, 26);
            this.dcedItemDesc.Name = "dcedItemDesc";
            this.dcedItemDesc.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedItemDesc.OcxState")));
            this.dcedItemDesc.Size = new System.Drawing.Size(203, 25);
            this.dcedItemDesc.TabIndex = 3;
            this.dcedItemDesc.Tag = "ItemDesc";
            // 
            // dcimQty
            // 
            this.dcimQty.Location = new System.Drawing.Point(293, 0);
            this.dcimQty.Name = "dcimQty";
            this.dcimQty.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimQty.OcxState")));
            this.dcimQty.Size = new System.Drawing.Size(47, 27);
            this.dcimQty.TabIndex = 4;
            this.dcimQty.TabStop = false;
            this.dcimQty.Tag = "Qty";
            // 
            // dcedQty
            // 
            this.dcedQty.Location = new System.Drawing.Point(293, 26);
            this.dcedQty.Name = "dcedQty";
            this.dcedQty.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedQty.OcxState")));
            this.dcedQty.Size = new System.Drawing.Size(47, 25);
            this.dcedQty.TabIndex = 5;
            this.dcedQty.Tag = "Qty";
            // 
            // dcimPrice
            // 
            this.dcimPrice.Location = new System.Drawing.Point(340, 0);
            this.dcimPrice.Name = "dcimPrice";
            this.dcimPrice.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimPrice.OcxState")));
            this.dcimPrice.Size = new System.Drawing.Size(80, 27);
            this.dcimPrice.TabIndex = 6;
            this.dcimPrice.TabStop = false;
            this.dcimPrice.Tag = "Price";
            // 
            // dcedPrice
            // 
            this.dcedPrice.Location = new System.Drawing.Point(340, 26);
            this.dcedPrice.Name = "dcedPrice";
            this.dcedPrice.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedPrice.OcxState")));
            this.dcedPrice.Size = new System.Drawing.Size(80, 25);
            this.dcedPrice.TabIndex = 7;
            this.dcedPrice.Tag = "Price";
            // 
            // dcimLineTotal
            // 
            this.dcimLineTotal.Location = new System.Drawing.Point(420, 0);
            this.dcimLineTotal.Name = "dcimLineTotal";
            this.dcimLineTotal.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimLineTotal.OcxState")));
            this.dcimLineTotal.Size = new System.Drawing.Size(105, 27);
            this.dcimLineTotal.TabIndex = 8;
            this.dcimLineTotal.TabStop = false;
            this.dcimLineTotal.Tag = "LineTotal";
            // 
            // dcedLineTotal
            // 
            this.dcedLineTotal.Location = new System.Drawing.Point(420, 26);
            this.dcedLineTotal.Name = "dcedLineTotal";
            this.dcedLineTotal.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedLineTotal.OcxState")));
            this.dcedLineTotal.Size = new System.Drawing.Size(105, 25);
            this.dcedLineTotal.TabIndex = 9;
            this.dcedLineTotal.Tag = "LineTotal";
            // 
            // btnInsBeforepbLineitem
            // 
            this.btnInsBeforepbLineitem.AutoSize = true;
            this.btnInsBeforepbLineitem.BackColor = System.Drawing.SystemColors.Control;
            this.btnInsBeforepbLineitem.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnInsBeforepbLineitem.Image = global::DotEditPanels.Properties.Resources._001_03;
            this.btnInsBeforepbLineitem.Location = new System.Drawing.Point(26, 377);
            this.btnInsBeforepbLineitem.Name = "btnInsBeforepbLineitem";
            this.btnInsBeforepbLineitem.Size = new System.Drawing.Size(39, 32);
            this.btnInsBeforepbLineitem.TabIndex = 39;
            this.btnInsBeforepbLineitem.Tag = "Lineitem";
            this.btnInsBeforepbLineitem.UseVisualStyleBackColor = false;
            // 
            // btnInsAfterpbLineitem
            // 
            this.btnInsAfterpbLineitem.AutoSize = true;
            this.btnInsAfterpbLineitem.BackColor = System.Drawing.SystemColors.Control;
            this.btnInsAfterpbLineitem.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnInsAfterpbLineitem.Image = global::DotEditPanels.Properties.Resources._001_01;
            this.btnInsAfterpbLineitem.Location = new System.Drawing.Point(74, 377);
            this.btnInsAfterpbLineitem.Name = "btnInsAfterpbLineitem";
            this.btnInsAfterpbLineitem.Size = new System.Drawing.Size(39, 32);
            this.btnInsAfterpbLineitem.TabIndex = 40;
            this.btnInsAfterpbLineitem.Tag = "Lineitem";
            this.btnInsAfterpbLineitem.UseVisualStyleBackColor = false;
            // 
            // btnDelpbLineitem
            // 
            this.btnDelpbLineitem.AutoSize = true;
            this.btnDelpbLineitem.BackColor = System.Drawing.SystemColors.Control;
            this.btnDelpbLineitem.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnDelpbLineitem.Image = global::DotEditPanels.Properties.Resources._001_02;
            this.btnDelpbLineitem.Location = new System.Drawing.Point(508, 378);
            this.btnDelpbLineitem.Name = "btnDelpbLineitem";
            this.btnDelpbLineitem.Size = new System.Drawing.Size(39, 30);
            this.btnDelpbLineitem.TabIndex = 41;
            this.btnDelpbLineitem.Tag = "Lineitem";
            this.btnDelpbLineitem.UseVisualStyleBackColor = false;
            // 
            // lblLineitem
            // 
            this.lblLineitem.AutoSize = true;
            this.lblLineitem.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLineitem.Location = new System.Drawing.Point(117, 389);
            this.lblLineitem.Name = "lblLineitem";
            this.lblLineitem.Size = new System.Drawing.Size(79, 18);
            this.lblLineitem.TabIndex = 42;
            this.lblLineitem.Text = "Lineitem";
            this.lblLineitem.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // dcedVendor
            // 
            this.dcedVendor.Location = new System.Drawing.Point(20, 58);
            this.dcedVendor.Name = "dcedVendor";
            this.dcedVendor.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedVendor.OcxState")));
            this.dcedVendor.Size = new System.Drawing.Size(527, 25);
            this.dcedVendor.TabIndex = 2;
            this.dcedVendor.Tag = "Vendor";
            // 
            // dcedVendor_Number
            // 
            this.dcedVendor_Number.Location = new System.Drawing.Point(20, 145);
            this.dcedVendor_Number.Name = "dcedVendor_Number";
            this.dcedVendor_Number.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedVendor_Number.OcxState")));
            this.dcedVendor_Number.Size = new System.Drawing.Size(155, 25);
            this.dcedVendor_Number.TabIndex = 5;
            this.dcedVendor_Number.Tag = "Vendor_Number";
            // 
            // dcimRemittance_Zip
            // 
            this.dcimRemittance_Zip.Location = new System.Drawing.Point(206, 112);
            this.dcimRemittance_Zip.Name = "dcimRemittance_Zip";
            this.dcimRemittance_Zip.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimRemittance_Zip.OcxState")));
            this.dcimRemittance_Zip.Size = new System.Drawing.Size(105, 27);
            this.dcimRemittance_Zip.TabIndex = 7;
            this.dcimRemittance_Zip.TabStop = false;
            this.dcimRemittance_Zip.Tag = "Remittance_Zip";
            // 
            // dcedRemittance_Zip
            // 
            this.dcedRemittance_Zip.Location = new System.Drawing.Point(206, 145);
            this.dcedRemittance_Zip.Name = "dcedRemittance_Zip";
            this.dcedRemittance_Zip.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedRemittance_Zip.OcxState")));
            this.dcedRemittance_Zip.Size = new System.Drawing.Size(155, 25);
            this.dcedRemittance_Zip.TabIndex = 8;
            this.dcedRemittance_Zip.Tag = "Remittance_Zip";
            // 
            // dcimInvoice_Number
            // 
            this.dcimInvoice_Number.Location = new System.Drawing.Point(20, 208);
            this.dcimInvoice_Number.Name = "dcimInvoice_Number";
            this.dcimInvoice_Number.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimInvoice_Number.OcxState")));
            this.dcimInvoice_Number.Size = new System.Drawing.Size(155, 27);
            this.dcimInvoice_Number.TabIndex = 10;
            this.dcimInvoice_Number.TabStop = false;
            this.dcimInvoice_Number.Tag = "Invoice_Number";
            // 
            // dcedInvoice_Number
            // 
            this.dcedInvoice_Number.Location = new System.Drawing.Point(20, 241);
            this.dcedInvoice_Number.Name = "dcedInvoice_Number";
            this.dcedInvoice_Number.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedInvoice_Number.OcxState")));
            this.dcedInvoice_Number.Size = new System.Drawing.Size(155, 25);
            this.dcedInvoice_Number.TabIndex = 11;
            this.dcedInvoice_Number.Tag = "Invoice_Number";
            // 
            // dcimInvoice_Date
            // 
            this.dcimInvoice_Date.Location = new System.Drawing.Point(206, 208);
            this.dcimInvoice_Date.Name = "dcimInvoice_Date";
            this.dcimInvoice_Date.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimInvoice_Date.OcxState")));
            this.dcimInvoice_Date.Size = new System.Drawing.Size(155, 27);
            this.dcimInvoice_Date.TabIndex = 13;
            this.dcimInvoice_Date.TabStop = false;
            this.dcimInvoice_Date.Tag = "Invoice_Date";
            // 
            // dcedInvoice_Date
            // 
            this.dcedInvoice_Date.Location = new System.Drawing.Point(206, 241);
            this.dcedInvoice_Date.Name = "dcedInvoice_Date";
            this.dcedInvoice_Date.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedInvoice_Date.OcxState")));
            this.dcedInvoice_Date.Size = new System.Drawing.Size(155, 25);
            this.dcedInvoice_Date.TabIndex = 14;
            this.dcedInvoice_Date.Tag = "Invoice_Date";
            // 
            // dcimPO_Number
            // 
            this.dcimPO_Number.Location = new System.Drawing.Point(392, 208);
            this.dcimPO_Number.Name = "dcimPO_Number";
            this.dcimPO_Number.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimPO_Number.OcxState")));
            this.dcimPO_Number.Size = new System.Drawing.Size(155, 27);
            this.dcimPO_Number.TabIndex = 16;
            this.dcimPO_Number.TabStop = false;
            this.dcimPO_Number.Tag = "PO_Number";
            // 
            // dcedPO_Number
            // 
            this.dcedPO_Number.Location = new System.Drawing.Point(392, 241);
            this.dcedPO_Number.Name = "dcedPO_Number";
            this.dcedPO_Number.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedPO_Number.OcxState")));
            this.dcedPO_Number.Size = new System.Drawing.Size(155, 25);
            this.dcedPO_Number.TabIndex = 17;
            this.dcedPO_Number.Tag = "PO_Number";
            // 
            // dcimTax
            // 
            this.dcimTax.Location = new System.Drawing.Point(20, 304);
            this.dcimTax.Name = "dcimTax";
            this.dcimTax.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimTax.OcxState")));
            this.dcimTax.Size = new System.Drawing.Size(155, 27);
            this.dcimTax.TabIndex = 19;
            this.dcimTax.TabStop = false;
            this.dcimTax.Tag = "Tax";
            // 
            // dcedTax
            // 
            this.dcedTax.Location = new System.Drawing.Point(20, 337);
            this.dcedTax.Name = "dcedTax";
            this.dcedTax.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedTax.OcxState")));
            this.dcedTax.Size = new System.Drawing.Size(155, 25);
            this.dcedTax.TabIndex = 20;
            this.dcedTax.Tag = "Tax";
            // 
            // dcimShipping
            // 
            this.dcimShipping.Location = new System.Drawing.Point(206, 304);
            this.dcimShipping.Name = "dcimShipping";
            this.dcimShipping.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimShipping.OcxState")));
            this.dcimShipping.Size = new System.Drawing.Size(155, 27);
            this.dcimShipping.TabIndex = 22;
            this.dcimShipping.TabStop = false;
            this.dcimShipping.Tag = "Shipping";
            // 
            // dcedShipping
            // 
            this.dcedShipping.Location = new System.Drawing.Point(206, 337);
            this.dcedShipping.Name = "dcedShipping";
            this.dcedShipping.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedShipping.OcxState")));
            this.dcedShipping.Size = new System.Drawing.Size(155, 25);
            this.dcedShipping.TabIndex = 23;
            this.dcedShipping.Tag = "Shipping";
            // 
            // dcimInvoice_Total
            // 
            this.dcimInvoice_Total.Location = new System.Drawing.Point(392, 304);
            this.dcimInvoice_Total.Name = "dcimInvoice_Total";
            this.dcimInvoice_Total.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimInvoice_Total.OcxState")));
            this.dcimInvoice_Total.Size = new System.Drawing.Size(155, 27);
            this.dcimInvoice_Total.TabIndex = 25;
            this.dcimInvoice_Total.TabStop = false;
            this.dcimInvoice_Total.Tag = "Invoice_Total";
            // 
            // dcedInvoice_Total
            // 
            this.dcedInvoice_Total.Location = new System.Drawing.Point(392, 337);
            this.dcedInvoice_Total.Name = "dcedInvoice_Total";
            this.dcedInvoice_Total.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedInvoice_Total.OcxState")));
            this.dcedInvoice_Total.Size = new System.Drawing.Size(155, 25);
            this.dcedInvoice_Total.TabIndex = 26;
            this.dcedInvoice_Total.Tag = "Invoice_Total";
            // 
            // dcedInvoice_Type
            // 
            this.dcedInvoice_Type.Location = new System.Drawing.Point(392, 145);
            this.dcedInvoice_Type.Name = "dcedInvoice_Type";
            this.dcedInvoice_Type.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedInvoice_Type.OcxState")));
            this.dcedInvoice_Type.Size = new System.Drawing.Size(155, 25);
            this.dcedInvoice_Type.TabIndex = 29;
            this.dcedInvoice_Type.Tag = "Invoice_Type";
            // 
            // Main_Page
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.Controls.Add(this.lblLineitem);
            this.Controls.Add(this.lblVendor);
            this.Controls.Add(this.dcedVendor);
            this.Controls.Add(this.lblVendor_Number);
            this.Controls.Add(this.dcedVendor_Number);
            this.Controls.Add(this.lblRemittance_Zip);
            this.Controls.Add(this.dcimRemittance_Zip);
            this.Controls.Add(this.dcedRemittance_Zip);
            this.Controls.Add(this.lblInvoice_Number);
            this.Controls.Add(this.dcimInvoice_Number);
            this.Controls.Add(this.dcedInvoice_Number);
            this.Controls.Add(this.lblInvoice_Date);
            this.Controls.Add(this.dcimInvoice_Date);
            this.Controls.Add(this.dcedInvoice_Date);
            this.Controls.Add(this.lblPO_Number);
            this.Controls.Add(this.dcimPO_Number);
            this.Controls.Add(this.dcedPO_Number);
            this.Controls.Add(this.lblTax);
            this.Controls.Add(this.dcimTax);
            this.Controls.Add(this.dcedTax);
            this.Controls.Add(this.lblShipping);
            this.Controls.Add(this.dcimShipping);
            this.Controls.Add(this.dcedShipping);
            this.Controls.Add(this.lblInvoice_Total);
            this.Controls.Add(this.dcimInvoice_Total);
            this.Controls.Add(this.dcedInvoice_Total);
            this.Controls.Add(this.lblInvoice_Type);
            this.Controls.Add(this.dcedInvoice_Type);
            this.Controls.Add(this.lbItemID);
            this.Controls.Add(this.lbItemDesc);
            this.Controls.Add(this.lbQty);
            this.Controls.Add(this.lbPrice);
            this.Controls.Add(this.lbLineTotal);
            this.Controls.Add(this.panLineitem);
            this.Controls.Add(this.btnDelpbLineitem);
            this.Controls.Add(this.btnInsAfterpbLineitem);
            this.Controls.Add(this.btnInsBeforepbLineitem);
            this.Name = "Main_Page";
            this.Size = new System.Drawing.Size(592, 682);
            this.panLineitem.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dcimItemID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedItemID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimItemDesc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedItemDesc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimQty)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedQty)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimPrice)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedPrice)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimLineTotal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedLineTotal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedVendor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedVendor_Number)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimRemittance_Zip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedRemittance_Zip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimInvoice_Number)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedInvoice_Number)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimInvoice_Date)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedInvoice_Date)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimPO_Number)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedPO_Number)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimTax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedTax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimShipping)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedShipping)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimInvoice_Total)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedInvoice_Total)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedInvoice_Type)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblVendor;
                                private AxDCEDITLib.AxDcedit dcedVendor;
        private System.Windows.Forms.Label lblVendor_Number;
                                private AxDCEDITLib.AxDcedit dcedVendor_Number;
                                private System.Windows.Forms.Label lblRemittance_Zip;
                                private AxDCIMAGELib.AxDcimage dcimRemittance_Zip;
                                private AxDCEDITLib.AxDcedit dcedRemittance_Zip;
                                private System.Windows.Forms.Label lblInvoice_Number;
                                private AxDCIMAGELib.AxDcimage dcimInvoice_Number;
                                private AxDCEDITLib.AxDcedit dcedInvoice_Number;
                                private System.Windows.Forms.Label lblInvoice_Date;
                                private AxDCIMAGELib.AxDcimage dcimInvoice_Date;
                                private AxDCEDITLib.AxDcedit dcedInvoice_Date;
                                private System.Windows.Forms.Label lblPO_Number;
                                private AxDCIMAGELib.AxDcimage dcimPO_Number;
                                private AxDCEDITLib.AxDcedit dcedPO_Number;
                                private System.Windows.Forms.Label lblTax;
                                private AxDCIMAGELib.AxDcimage dcimTax;
                                private AxDCEDITLib.AxDcedit dcedTax;
                                private System.Windows.Forms.Label lblShipping;
                                private AxDCIMAGELib.AxDcimage dcimShipping;
                                private AxDCEDITLib.AxDcedit dcedShipping;
                                private System.Windows.Forms.Label lblInvoice_Total;
                                private AxDCIMAGELib.AxDcimage dcimInvoice_Total;
                                private AxDCEDITLib.AxDcedit dcedInvoice_Total;
        private System.Windows.Forms.Label lblInvoice_Type;
        private AxDCEDITLib.AxDcedit dcedInvoice_Type;
                                private System.Windows.Forms.Label lbItemID;
                                private System.Windows.Forms.Label lbItemDesc;
                                private System.Windows.Forms.Label lbQty;
                                private System.Windows.Forms.Label lbPrice;
                                private System.Windows.Forms.Label lbLineTotal;
                              private System.Windows.Forms.Panel panLineitem;
                                private System.Windows.Forms.Button btnInsBeforepbLineitem;
        private System.Windows.Forms.Button btnInsAfterpbLineitem;
        private System.Windows.Forms.Button btnDelpbLineitem;
                                private AxDCIMAGELib.AxDcimage dcimItemID;
                                private AxDCEDITLib.AxDcedit dcedItemID;
                                private AxDCIMAGELib.AxDcimage dcimItemDesc;
                                private AxDCEDITLib.AxDcedit dcedItemDesc;
                                private AxDCIMAGELib.AxDcimage dcimQty;
                                private AxDCEDITLib.AxDcedit dcedQty;
                                private AxDCIMAGELib.AxDcimage dcimPrice;
                                private AxDCEDITLib.AxDcedit dcedPrice;
                                private AxDCIMAGELib.AxDcimage dcimLineTotal;
                                private AxDCEDITLib.AxDcedit dcedLineTotal;
        private System.Windows.Forms.Label lblLineitem;
                        
    }
}
                