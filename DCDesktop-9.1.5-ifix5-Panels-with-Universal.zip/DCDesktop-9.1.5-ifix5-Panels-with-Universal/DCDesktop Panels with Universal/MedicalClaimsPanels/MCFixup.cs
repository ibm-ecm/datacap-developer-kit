﻿// Licensed Materials - Property of IBM
// 5725-C15
// © Copyright IBM Corp. 1994, 2013 All Rights Reserved
// 
// US Government Users Restricted Rights - Use, duplication or
// disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using System.IO;
using dcDTlib;

namespace MedicalClaimsPanels
{
    public partial class MCFixup : dcDTlib.dotPanelBase, IMessageFilter
    {
        static System.Windows.Forms.Timer myTimer = new System.Windows.Forms.Timer();

        string[] dcfiletypes = { "Tiff", "Bmp", "Jpeg", "Png", "Jp2" };
        private string sBarcodeSepValue = "";
        private bool bClassUpdateInProgress = false;
        static string sRescanIDs = "";
        static string sRescanPageType = "Other";
        private bool bScanInProgress = false;

        // batch variables from startbatch / runtime DCO (bit currently used)
        public int nED = 0;
        public int nEP = 0;
        public int nAD = 0;
        public int nAP = 0;

        public MCFixup()
        {
            InitializeComponent();
            try
            {
                //dcScan = new ScanISIS();
                //dcScan.scannerstate = new ScanState(this.GetScanState);
            }
            catch (Exception ex)
            {
                string sMeg = ex.Message;
            }
        }

        private void GetScanState(int st)
        {

            if (bScanInProgress == false)
            {
                // when done, update the selection-dependent buttons like join, split, insert, etc
                XmlNode xPage;
                string sSelectedID = GetFirstSelectedPageID();
                xPage = xNodeByID(sSelectedID);
                if (xPage != null)
                    UpdateEnabledPositionDependent(xPage);

                Application.UseWaitCursor = false;
                Cursor.Current = Cursors.Default;
            }
            else
            {
                Application.UseWaitCursor = true;
                Cursor.Current = Cursors.WaitCursor;
            }
        }

        public override bool StartBatch()
        {
            bool bRes = base.StartBatch();
            string taskoperator = dcTask.Operator;

            BatchForm.SelectionChange -= new System.EventHandler(BatchForm_OnSelectionChange);
            BatchForm.SelectionChange += new System.EventHandler(BatchForm_OnSelectionChange);

            BatchForm.TypeChange -= new System.EventHandler(BatchForm_OnTypeChange);
            BatchForm.TypeChange += new System.EventHandler(BatchForm_OnTypeChange);

            ImageForm.MoveImage -= new System.EventHandler(ImageForm_OnMoveImage);
            ImageForm.MoveImage += new System.EventHandler(ImageForm_OnMoveImage);

            Application.AddMessageFilter(this); // to catch keystrokes

            myTimer.Tick += new EventHandler(TimerEventProcessor);  // to handle timer callbacks for multi-file replace

            if (dcTask.sFPDSN != null)
            {
                bClassUpdateInProgress = true;
                bRes = LoadFingerprintDB(dcTask.sFPDSN, listPageClass);  // generate list of pagetypes, doctypes, HostIDs
                bClassUpdateInProgress = false;
            }

            init_statuses();                                    // initialize fixup globals, controls, settings, markers
            init_fixup_controls();                              // enable/show or disable/hide fixup related controls based on sCheckStructure flag
            populate_fixup_status(listPageStatus);
            populate_fixup_types(listPageType);

            XmlNode xBatch = dcTask.BatchXML.SelectSingleNode("B"); //??
            XmlNode xN = xBatch.SelectSingleNode("V[@n='ED']"); //??

            XmlNode xParent = dcTask.BatchXML.DocumentElement;
            XmlNode xLastPage = null;

            // start task with first page in batch selected
            if (xParent.SelectSingleNode("D") != null)
                xParent = xParent.SelectSingleNode("D[1]");
            xLastPage = xParent.SelectSingleNode("P[1]");

            try
            {
                if (xLastPage != null && xLastPage.Name == "P")
                {
                    BatchForm.SelectTreeNode(xLastPage.Attributes["id"].Value); // select the last page in batch 
                }
            }
            catch (Exception ex)
            {
                dcTask.WriteLog("Error loading batch or image view: " + ex.Message);
            }

            // INITIALIZE SCANNING

            sBarcodeSepValue = dcTask.GetTaskSettingString("BCSepValue");
            try
            {
                string sUseBatchSettings = dcTask.GetTaskSettingString("UseBatchSettings");
                if (sUseBatchSettings != "1")
                {
                    // for use case where different scanner will pick up batch on hold
                    // we don't want to use previous batch settings
                    // so we delete them so dcscanisis won't load them
                    try
                    {
                        File.Delete(Path.Combine(dcTask.BatchDir, "scanisis.xml"));
                    }
                    catch { }
                }
                string sScannerSettingsFile = dcTask.GetTaskSettingString("ScannerSettingsFile");


            }
            catch (Exception ex)
            {
                dcTask.WriteLog("Scanner initialization exception " + ex.Message);
            }

            ImageForm.savedThumbStateToggle = "";
            if (ImageForm.AreThumbsEnabled())
                ImageForm.LoadThumbs(GetFirstSelectedPageID(), true);

            if (bCheckStructure) // go to first problem
            {
                textFixupMsg.Text = "";
                FindNextProblem(true, ref textFixupMsg);
            }
            return bRes;
        }

        public override bool EndBatch(String Status)
        {
            Application.RemoveMessageFilter(this);
            myTimer.Tick -= TimerEventProcessor;

            BatchForm.SelectionChange -= new System.EventHandler(BatchForm_OnSelectionChange);
            BatchForm.SelectionChange -= new System.EventHandler(BatchForm_OnSelectionChange);
            BatchForm.TypeChange -= new System.EventHandler(BatchForm_OnTypeChange);
            BatchForm.TypeChange -= new System.EventHandler(BatchForm_OnTypeChange);
            ImageForm.MoveImage -= new System.EventHandler(ImageForm_OnMoveImage);
            ImageForm.MoveImage -= new System.EventHandler(ImageForm_OnMoveImage);

            ImageForm.Clear();
            anchor_deinit();
            return base.EndBatch(Status);
        }

        // Batch tree view selection was changed - update UI for newly selected page, doc, or batch node
        private void BatchForm_OnSelectionChange(Object src, EventArgs e)
        {
            bool bSelectedTypeChanged = false;  // do we need to repopulate "Type" dropdown?
            if (bSelChange_InProgress)
                return;
            textFixupMsg.Text = "";

            bSelChange_InProgress = true;

            // FIXUP
            XmlNode pPage = (XmlNode)src;
            if (pPage.Name != "P" && pPage.Name != "D")
            {
                btnSplit.Enabled = false;
                btnJoin.Enabled = false;
                listPageType.Enabled = false;
                listPageStatus.Enabled = false;
                listPageClass.Enabled = false;
                bSelChange_InProgress = false;
                return;
            }

            listPageType.Enabled = true;
            listPageStatus.Enabled = true;
            listPageClass.Enabled = true;

            dcTask.WriteLog("SelChange: " + pPage.Attributes["id"].Value);
            dcTask.WriteLog("Old type: " + sSelectedDCOType + ", New type: " + pPage.Name);

            bSelectedTypeChanged = (sSelectedDCOType != pPage.Name);
            sSelectedDCOType = pPage.Name;  // P or D selected
            sSelectedIDs = pPage.Attributes["id"].Value;
            if (bSelectedTypeChanged)
            {
                populate_fixup_types(listPageType);
                populate_fixup_status(listPageStatus);
            }

            // 'comments'
            if (bCheckStructure)
            {
                XmlNode pNode = pPage.SelectSingleNode("V[@n='comments']");
                if (pNode != null)
                    textFixupMsg.Text = pNode.InnerText;
                else
                    textFixupMsg.Text = "";
            }

            if (pPage.Name == "P")
            {
                ImageForm.ImageSelect(pPage);
                if (ImageForm.AreThumbsEnabled())
                    ImageForm.LoadThumbs(pPage.Attributes["id"].Value, false);

                // display page type, page status
                // display FP class / hostname of this image
                int nSel;
                string sTemp;

                sTemp = pPage.SelectSingleNode("V[@n='TYPE']").InnerText;
                nSel = listPageType.FindStringExact(sTemp);
                bSuppressPageTypeChange = true;
                listPageType.SelectedIndex = nSel;
                bSuppressPageTypeChange = false;

                sTemp = pPage.SelectSingleNode("V[@n='STATUS']").InnerText;
                update_status_control((int)Convert.ToInt16(sTemp), listPageStatus);

                // update page class if needed
                XmlNode pFPNode = pPage.SelectSingleNode("V[@n='TemplateID']");
                if (pFPNode != null)
                {
                    string sFPID = pFPNode.InnerText;
                    UpdatePageClass(pPage, sFPID);
                }
                else
                    UpdatePageClass(pPage, "");
            }
            else if (pPage.Name == "D")
            {
                // display doc type and status
                string sTemp = pPage.SelectSingleNode("V[@n='TYPE']").InnerText;
                int nSel = listPageType.FindStringExact(sTemp);
                bSuppressPageTypeChange = true;
                listPageType.SelectedIndex = nSel;
                bSuppressPageTypeChange = false;

                sTemp = pPage.SelectSingleNode("V[@n='STATUS']").InnerText;
                update_status_control((int)Convert.ToInt16(sTemp), listPageStatus);
                UpdatePageClass(pPage, "");
                // select first page in doc
            }

            BatchForm.ExpandAll();

            bSuppressPageTypeChange = false;

            XmlNode xPage = (XmlNode)src;

            UpdateEnabledPositionDependent(xPage);  // update the selection dependent buttons


            // if thumbnails enabled, and selected document is not currently displayed, display in thumbnails
            string sDocID = "";
            if (xPage.Name == "D") sDocID = xPage.Attributes["id"].Value;
            else if (xPage.Name == "P")
            {
                XmlNode xParent = xPage.ParentNode;
                if (xParent.Name == "D") sDocID = xParent.Attributes["id"].Value;
            }
            if (ImageForm.AreThumbsEnabled())
                ImageForm.LoadThumbs(pPage.Attributes["id"].Value, false);

            // done
            bSelChange_InProgress = false;
            return;
        }

        // update enabled status of Split, Join, MoveUp, MoveDn, and Insert
        void UpdateEnabledPositionDependent(XmlNode xPage)
        {
            if (xPage.Name != "P")
            {
                // if document selected, and not first, enable Join
                btnSplit.Enabled = false;
                btnMoveUp.Enabled = (xDocPrev(xPage) != null);
                btnJoin.Enabled = (xDocPrev(xPage) != null) && bJoinEnabled;
                btnMoveDn.Enabled = (xDocNext(xPage) != null);
                btnRemove.Enabled = false;  // if we allow deleting docs: (dcTask.BatchXML.SelectNodes(".//D").Count > 1);

            }
            else
            {
                int i;
                // Page selected, enable/disable controls as needed
                XmlNodeList xPages = dcTask.BatchXML.SelectNodes(".//P");
                for (i = 0; i < xPages.Count; i++)
                {
                    if (xPage == xPages[i])
                        break;
                }
                btnMoveDn.Enabled = (i > -1 && i < (xPages.Count - 1));   // should be same as xPage.NextSibling?
                btnMoveUp.Enabled = (i > -1 && i > 0);
                btnRemove.Enabled = (xPages.Count > 1 && i > -1);

                XmlNode xPrev;
                for (xPrev = xPage.PreviousSibling; xPrev != null && xPrev.Name != "P" && xPrev.Name != "D"; xPrev = xPrev.PreviousSibling) ;
                btnSplit.Enabled = (i > 0 && xPrev != null && xPrev.Name == "P") && bSplitEnabled;
                XmlNode xParent = xPage.ParentNode;
                if (xParent == null || !IsDocNode(xParent) || xParent.PreviousSibling == null || xParent.PreviousSibling.Name != "D")
                    btnJoin.Enabled = false;
                else
                    btnJoin.Enabled = bJoinEnabled;
            }
        }

        public bool UpdatePageClass(XmlNode pPage, string sFPID)    // update FP class (hostname) given a selected FingerprintID
        {
            if (!bShowFPClass || listPageClass.Items.Count <= 0)
                return false;

            string sTemp = "";
            string sPageType = "";

            if (sPageClasses != null) for (int i = 0; i < sPageClasses.Length; i++)
                {
                    if (sPageClasses[i].spc_FPtemplateID != null)
                    {
                        for (int j = 0; j < sPageClasses[i].spc_FPtemplateID.Length; j++)
                        {
                            if (sPageClasses[i].spc_FPtemplateID[j].ToString() == sFPID)
                            {
                                sTemp = sPageClasses[i].spc_hostName;
                                sPageType = sPageClasses[i].spc_FPtemplateID[0];

                                bClassUpdateInProgress = true;
                                int nSel = listPageClass.FindStringExact(sTemp);
                                listPageClass.SelectedIndex = nSel >= 0 ? nSel : 0;     // 0 is the null class
                                bClassUpdateInProgress = false;

                                //nSel = listPageType.FindStringExact(sPageType);
                                //bSuppressPageTypeChange = true;
                                //listPageType.SelectedIndex = nSel >= 0 ? nSel : 0;
                                //bSuppressPageTypeChange = false;

                                return true;
                            }
                        }
                    }
                }
            listPageClass.SelectedIndex = 0;
            return true;
        }

        private void BatchForm_OnTypeChange(Object src, EventArgs e)
        {
            // THIS IS NOT USED
            XmlNode xPage = (XmlNode)src;
            if (xPage.Name != "P")
                return;
            XmlNodeList xPages = dcTask.BatchXML.SelectNodes(".//P");
            int i = 0;
            for (i = 0; i < xPages.Count; i++)
            {
                if (xPage == xPages[i])
                    break;
            }
            ImageForm.SetThumbText(xPage.SelectSingleNode("V[@n='TYPE']").InnerText, i);
        }


        public void init_fixup_controls()
        {
            btnNextProb.Visible = btnNextProb.Enabled = bCheckStructure;
            textFixupMsg.Visible = bCheckStructure; // WAS also setting enabled, now always disabled
            lblComment.Visible = lblComment.Enabled = bCheckStructure;

            listPageClass.Visible = listPageClass.Enabled = bShowFPClass;
            lblClass.Visible = lblClass.Enabled = bShowFPClass;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            int nCount = dcTask.BatchXML.SelectNodes(".//P").Count;
            if (nCount > 0)
                if (MessageBox.Show(string.Format(MedicalClaimsPanels.Properties.Resources.msgConfirmCancel_Text, nCount), MedicalClaimsPanels.Properties.Resources.msgConfirmCancel_Title, MessageBoxButtons.YesNo) != DialogResult.Yes)
                    return;
            Status = "canceled";
            OnComplete(this, new TaskStatusEventArgs(Status));

        }

        private void btnMoveUp_Click(object sender, EventArgs e)
        {
            MoveUp();
        }

        private void btnMoveDn_Click(object sender, EventArgs e)
        {
            MoveDown();
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            string[] sIDs = GetSelectedPageIDs();
            bool approved = false;
            XmlNode xSelNode = null;       // go to first page after (or before if none after) deletion

            foreach (string sID in sIDs)
            {
                if (sID != "")
                {
                    // delete a single page
                    XmlNode xPage = dcTask.BatchXML.SelectSingleNode(".//*[@id='" + sID + "']"); //  XML node in runtime DCO
                    if (IsPageNode(xPage))
                    {
                        // disallow deleting last page in batch
                        if (dcTask.BatchXML.SelectNodes(".//P").Count <= 1)
                            return;

                        string sFullPath = dcTask.BatchDir + '\\' + xPage.SelectSingleNode("V[@n='IMAGEFILE']").InnerText;  // may or may not have IMAGEILE var?
                        string sPath = sFullPath.Substring(sFullPath.LastIndexOf('\\') + 1);

                        xSelNode = xPageNext(xPage);        // next page in this doc for selection after deleted

                        if (xSelNode == null)
                            xSelNode = xPagePrev(xPage);    // else prev page in this doc

                        if (xSelNode == null)
                        {
                            // this is the last page in this doc - select first page in next doc, or last page in prior doc
                            xSelNode = xDocNext(xPage.ParentNode);
                            if (xSelNode != null)
                                xSelNode = xFirstPageInDoc(xSelNode);
                            else
                            {
                                xSelNode = xDocPrev(xPage.ParentNode);
                                if (xSelNode != null) xSelNode = xLastPageInDoc(xSelNode);
                            }
                        }

                        // Ask the operator to confirm page delete (only for the first page in a group delete)
                        // We SHOULD ask about deleting the doc if it is the last page in the doc!
                        if (approved || MessageBox.Show(string.Format(MedicalClaimsPanels.Properties.Resources.msgAreYouRemoveImage_Text, sPath), MedicalClaimsPanels.Properties.Resources.msgRemoveImage_Title, MessageBoxButtons.OKCancel) == DialogResult.OK)
                        {
                            approved = true;

                            //Update Single/Multi doc type here
                            //count number of claims in doc
                            int pNumClaims = CountClaims(xPage.ParentNode);

                            //update the doc type: Multi or Single 
                            UpdateMCDocType(pNumClaims - 1, xPage.ParentNode);

                            BatchForm.RemovePageID(sID);        // this also removes the parent document, if this is the last page in the doc

                            xPage = null;
                            File.Delete(sFullPath);             // delete image file - should be optional, the other option to mark deleted
                            Delete_Page_AuxFiles(sFullPath, true);
                        }
                        else
                            break;

                    }
                    else if (IsDocNode(xPage))
                    {
                        // disallow deleting last doc
                        if (dcTask.BatchXML.SelectNodes(".//D").Count <= 1)
                            return;
                        // TODO: we don't support deleting docs yet
                    }
                }
            }

        }

        bool insertMode = false;
        XmlNode xRefNode = null;


        // drag and drop?
        private void ImageForm_OnMoveImage(Object src, EventArgs e)
        {
            int nFrom = ((Size)src).Width;
            int nTo = ((Size)src).Height;
            MoveImage(nFrom, nTo);
        }

     


        // Finish clicked 
        // validate batch
        // must have at least one page
        // if structure invalid, put on hold
        private void btnFinish_Click(object sender, EventArgs e)
        {
            FinishClick(textFixupMsg);
        }

        // Delete page or doc
        private void btn_Delete_Click(object sender, EventArgs e)
        {
            RemoveSelectedImages();
        }

        private void btnNextProb_Click(object sender, EventArgs e)
        {
            // clear the Comment field
            textFixupMsg.Text = "";
            FindNextProblem(true, ref textFixupMsg);
        }

        private void btnHold_Click(object sender, EventArgs e)
        {
            Status = "hold";
            OnComplete(this, new TaskStatusEventArgs(Status));
        }

        private bool CheckCount()
        {
            bool bIsValid = true;
            string msg = "";

            if (bCheckCount != true)
                return bIsValid;

            //Retrieve Actual Count
            int nDocs = dcTask.BatchXML.DocumentElement.SelectNodes("D").Count;
            int nPages = dcTask.BatchXML.DocumentElement.SelectNodes("P").Count;

            //Compare to adjusted Count
            if (nAD > 0)
            {
                if (nDocs != nAD)
                {
                    msg = "Doc count: " + nDocs + " does not match adjusted: " + nAD;
                }
            }
            else if (nED > 0)
            {
                if (nDocs != nED)
                {
                    msg = "Doc count: " + nDocs + " does not match expected: " + nED;
                }
            }

            if (nAP > 0)
            {
                if (nPages != nAP)
                {
                    if (msg != "")
                    {
                        msg = msg + "\n" + "Page count: " + nPages + " does not match adjusted: " + nAP;
                    }
                    else
                    {
                        msg = "Page count " + nPages + " does not match adjusted " + nAP;
                    }
                }
            }
            else
            {
                if (nEP > 0)
                {
                    if (nPages != nEP)
                    {
                        if (msg != "")
                        {
                            msg = msg + "\n" + "Page count: " + nPages + " does not match expected: " + nEP;
                        }
                        else
                        {
                            msg = "Page count " + nPages + " does not match expected " + nEP;
                        }
                    }
                }
            }

            if (msg == "")
                return bIsValid;
            bIsValid = false;
            /*
	msg = msg & vbCrlf & vbCrlf & "*** Set adjusted counts to actual? ***"
	
	retn = CInt(blockMsgBox(msg, 1, "Reset Count")) ' buttons: OK (reset) or Cancel (don't reset)
	
	If retn = 1 Then	' user clicked OK
		Pilot.ExpectedDocs = nD ' set in Engine DB tmbatch table
		Pilot.ExpectedPages = nP

		DCO.Variable("AD") = nD
		DCO.Variable("AP") = nP
'		Pilot.SaveData(DCO) ' saves data from controls to memory
'		DCO.Write(Pilot.DCOFile) would write out to batch, not needed
		' DCO is automatically written at end of batch		
		WriteLog("Override, setting Adjusted Docs/Pages = Expected Docs/Pages")
		WriteLog("Adjusted Docs set to: " & nD)
		WriteLog("Adjusted Pages set to: " & nP)
		CheckCount = True
	End If
             * */

            return bIsValid;
        }


        private void listPageStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            // update page or doc status in Batch runtime XML
            string sID = BatchForm.GetSelID();
            int nSel = CountSelected();
            if (nSel != 1)
                return;
            XmlNode pNode = dcTask.BatchXML.SelectSingleNode(".//*[@id='" + sID + "']");
            if (pNode == null) return;
            string sStatus = listPageStatus.Text;
            int nStatus = LookupIntStatus(sStatus);
            if (nStatus > -1)
            {
                XmlNode pStatusNode = pNode.SelectSingleNode("V[@n='STATUS']");
                if (pStatusNode != null)
                    pStatusNode.InnerText = nStatus.ToString();
            }
        }

        // User updated page class via combo
        private void listPageClass_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (bClassUpdateInProgress)
                return;

            string sID = sSelectedIDs;  // last selected node ID from batch tree - page or doc
            if (sID == "")
                return;

            XmlNode xPage = dcTask.BatchXML.SelectSingleNode(".//*[@id='" + sID + "']"); //  XML node in runtime DCO
            if (xPage == null || xPage.Name != "P")
            {
                bClassUpdateInProgress = true;
                listPageClass.SelectedIndex = 0;    // clear it
                bClassUpdateInProgress = false;
                return;
            }
            string sNewClass = listPageClass.Text;

            if (sNewClass == "")
            {
                XmlNode xTemplateVar = xPage.SelectSingleNode("V[@n='TemplateID']");
                if (xTemplateVar == null)
                    return;
                xPage.RemoveChild(xTemplateVar);
            }
            else
            {
                // given new page type
                // find (first) matching fingerprint ID and set TemplateID variable in XML along with page type
                // sPageClasses pPageClass;
                ReplacePageClass(xPage, sNewClass);
            }
        }

        // user changed class selection - now update the page FPID and page type as well as updating the page type displayed
        public bool ReplacePageClass(XmlNode xPage, string sNewClass)
        {
            // find any/all FPs that match this page class
            string sFPID = First_FPID_from_FPClass(sNewClass);
            // then update the FP (TemplateID) with a matching one
            if (sFPID == "")
                return false;     // this should not be possible
            XmlNode xTemplateVar = xPage.SelectSingleNode("V[@n='TemplateID']");
            if (xTemplateVar == null)
            {
                XmlElement xVar = (XmlElement)dcTask.BatchXML.CreateElement("V");
                xVar.SetAttribute("n", "TemplateID");
                xVar.InnerText = sFPID;
                xPage.AppendChild(xVar);
            }
            else
                xTemplateVar.InnerText = sFPID;

            // might need to find pagetype for this FP and set if different?? not done in ifixup.
            return true;
        }

        private void listPageType_SelectionChangeCommitted(object sender, EventArgs e)  // page/doc type dropdown new selection BY the USER
        {
            // only works for combo box not list box
        }

        private bool bSuppressPageTypeChange = false;
        private void listPageType_SelectedIndexChanged(object sender, EventArgs e)  // page/doc type dropdown new selection
        {
            if (bSuppressPageTypeChange)
            {
                bSuppressPageTypeChange = false;
                return;
            }

            // update page or doc type in Batch runtime XML
            string sID = BatchForm.GetSelID();

            XmlNode pNode = dcTask.BatchXML.SelectSingleNode(".//*[@id='" + sID + "']");
            if (pNode == null)
                return;
            string sNewType = listPageType.Text;
            XmlNode xTmp = pNode.SelectSingleNode("V[@n='TYPE']");
            string sOldType = "";
            if (xTmp != null)
                sOldType = xTmp.InnerText;
            dcTask.WriteLog("Type change? ID=" + sID + " old=" + sOldType + " new=" + sNewType);
            if (sOldType == sNewType)
                return;
            
            pNode.SelectSingleNode("V[@n='TYPE']").InnerText = sNewType;    // update type in batch XML

            //and add formtype version
            if (sNewType == "PClaim")
            {
                if (MessageBox.Show("Make this page a 02/12 form Version?", "Select Form Version", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    SetVariable(pNode, "FormVersion", "02/12"); // @P.FormVersion = 02/12
                    SetVariable(pNode, "TemplateID", "1059"); // @P.TemplateID = 1059
                    SetVariable(pNode, "OverlayFileName", "1500_0212.tif"); // @P.OverlayFileName = 1500_0212t.tif
                }
                else
                {
                    SetVariable(pNode, "FormVersion", "08/05");
                    SetVariable(pNode, "TemplateID", "1052");
                    SetVariable(pNode, "OverlayFileName", "CMSt.tif");
                }
            }
            else if (sNewType == "IClaim")
            {
                SetVariable(pNode, "TemplateID", "1055");
                SetVariable(pNode, "OverlayFileName", "ub04t.tif");
            }

            if (pNode.SelectSingleNode("V[@n='DATAFILE']") != null)
                pNode.RemoveChild(pNode.SelectSingleNode("V[@n='DATAFILE']"));  // remove data if pagetype changed

            if (pNode.Name == "P")
            {
                string sFname = ImageFilePath(pNode);
                Delete_Page_AuxFiles(sFname, false);
            }
            // must either reload batch tree or update the tree node as in cmbType_SelectedIndexChanged()
            BatchForm.LoadBatch(sID);
        }

        private int LookupIntStatus(string sStatus)
        {
            if (sSelectedDCOType == "P")
            {
                foreach (tStatus pStatus in sPageStatuses)
                {
                    if (pStatus.sStatus == sStatus)
                        return (pStatus.nStatus);
                }
            }
            else
            {
                foreach (tStatus pStatus in sDocStatuses)
                {
                    if (pStatus.sStatus == sStatus)
                        return (pStatus.nStatus);
                }
            }
            return (-1);
        }

        private void btnRotateLeft_Click(object sender, EventArgs e)
        {
            Rotate_Selected(270);
        }


        private void btnRotateRight_Click(object sender, EventArgs e)
        {
            Rotate_Selected(90);
        }

        private void btnFlip_Click(object sender, EventArgs e)
        {
            Rotate_Selected(180);
        }

        private void btnJoin_Click(object sender, EventArgs e)
        {
            //Copy of JoinHere() logic from DotScanPanelBase
            string sID = GetFirstSelectedPageID();
            XmlNode xCurr = xNodeByID(sID);

            if (xCurr == null)
                return;

            if (IsDocNode(xCurr))
            {
                for (xCurr = xCurr.FirstChild; xCurr != null && xCurr.Name != "P" && xCurr.Name != "D"; xCurr = xCurr.NextSibling) ;
            }

            if (xCurr == null || !IsPageNode(xCurr))
                return;

            XmlNode xDoc = xCurr.ParentNode;
            if (xDoc == null || !IsDocNode(xDoc))
                return;

            XmlNode xPrevDoc = xDocPrev(xDoc); // get previous document in the batch - skip over any other siblings
            if (xPrevDoc == null)
                return;

            //count number of claims in both documents
            int pNumClaims = CountClaims(xPrevDoc);
            int xNumClaims = CountClaims(xDoc);

            //get DocType of target document
            string DocType = xPrevDoc.SelectSingleNode("./V[@n='TYPE']").InnerText;
            bool bIsMulti = DocType.Contains("Multi");

            UpdateMCDocType(pNumClaims + xNumClaims, xPrevDoc);

            // go through all pages or other nodes in the current doc, move each page into previous doc, delete all non-pages (vars, fields)
            xCurr = xDoc.FirstChild;
            XmlNode xNext = xCurr;
            while (xNext != null)
            {
                XmlNode xNNext = xNext.NextSibling;
                // Move Pages to xPrevDoc
                if (xNext.Name == "P")
                {
                    //Add logic to change new pages to type Attachment if target doc is not 'Multi' here
                    //Add logic to check Page types in Target doc and set Multi or Single
                    xPrevDoc.AppendChild(xNext);
                }
                else
                    xDoc.RemoveChild(xNext);  // delete any variables, or non-pages, in the doc

                xNext = xNNext;
            }
            dcTask.BatchXML.DocumentElement.RemoveChild(xDoc); // now remove this doc
            BatchForm.LoadBatch(sID);
            ImageForm.LoadThumbs(sID, true);

        }

        private int CountClaims(XmlNode xmlDoc)
        {
            int Count = 0;
            XmlNodeList nClaims = null;

            nClaims = xmlDoc.SelectNodes("./P/V[@n='TYPE' and text()='PClaim']");
            if (nClaims != null)
                Count = Count + nClaims.Count;

            nClaims = xmlDoc.SelectNodes("./P/V[@n='TYPE' and text()='IClaim']");
            if (nClaims != null)
                Count = Count + nClaims.Count;

            return Count;
        }

        private void UpdateMCDocType(int nClaims, XmlNode xDoc)
        {
            //set multipage doc
            if (nClaims > 1)
            {
                //multipage if more than one claim in final doc
                if (dcTask.JobName.Contains("PROF"))
                    xDoc.SelectSingleNode("./V[@n='TYPE']").InnerText = "Prof Multi";
                else
                    xDoc.SelectSingleNode("./V[@n='TYPE']").InnerText = "Inst Multi";
            }
            else
            {
                //single page claim document
                if (dcTask.JobName.Contains("PROF"))
                    xDoc.SelectSingleNode("./V[@n='TYPE']").InnerText = "Prof Single";
                else
                    xDoc.SelectSingleNode("./V[@n='TYPE']").InnerText = "Inst Single";
            }

            string sID = xDoc.SelectSingleNode("@id").Value;
            RestoreNodeStatus(sID); 
            
        }


        public void RestoreNodeStatus(string sID)
        {
            //string[] arDOF = dcTask. SetupXML.sDOF.Split(',');

            XmlNode pNode = dcTask.BatchXML.SelectSingleNode(".//*[@id='" + sID + "']");
            if (pNode == null)
                return;
            pNode.SelectSingleNode("V[@n='STATUS']").InnerText = @"2"; // arDOF[2];

        }

        private void btnSplit_Click(object sender, EventArgs e)
        {
            XmlNode xNode;  // the page selected - split right before this
            XmlNode xNext;  // temp

            // if this is not the first page in a document, make it a new doc
            string sID = GetFirstSelectedPageID();
            xNode = xNodeByID(sID);

            if (xNode == null || !IsPageNode(xNode))
                return;

            XmlNode xParent = xNode.ParentNode;
            if (xParent == null)
            {
                dcTask.WriteLog("Cannot split page - no parent node!");
                return;     // every page has a parent - at least the batch node
            }

            // create new doc element
            XmlElement xNewDoc = (XmlElement)dcTask.BatchXML.CreateElement("D");
            xNewDoc.SetAttribute("id", "new");  // we will create the actual DocID later by renumbering all docs
            XmlElement xVar = (XmlElement)dcTask.BatchXML.CreateElement("V");
            xVar.SetAttribute("n", "TYPE");
            
            // assign doctype - if setup doc exists containing selected pagetype, use that doctype (first one), otherwise use the first doctype
            XmlNode xNDoc = dcTask.SetupXML.SelectSingleNode("/S/D[P[@type='" + xNode.SelectSingleNode("V[@n='TYPE']").InnerText + "']]");
            if (xNDoc == null)
                xNDoc = dcTask.SetupXML.SelectSingleNode("/S/D");
            xVar.InnerText = (xNDoc == null) ? "" : xNDoc.Attributes["type"].Value; // set doctype
            xNewDoc.AppendChild(xVar);
            // assign doc status
            xVar = (XmlElement)dcTask.BatchXML.CreateElement("V");
            xVar.SetAttribute("n", "STATUS");
            xVar.InnerText = "0";
            xNewDoc.AppendChild(xVar);

            XmlNode xFirstPage = xParent.SelectSingleNode(".//P");
            // if there are no docs in the batch yet, and we're not splitting from first page, create root doc
            if (xParent.Name == "B" && xFirstPage != xNode)
            {
                // create doc before first page because tree view doesn't support mixed docs/naked
                XmlNode xRootDoc = xNewDoc.Clone();
                xRootDoc = (XmlElement)xParent.InsertBefore(xRootDoc, xFirstPage);      // if parent is the Batch node, insert doc before page
                // copy children prior to selected node into root doc
                xNext = xFirstPage;
                while (xNext != null && xNext != xNode)
                {
                    XmlNode xNNext = xNext.NextSibling;
                    xRootDoc.AppendChild(xNext);
                    dcTask.WriteLog("Add child to root" + xNext.InnerXml);
                    xNext = xNNext;
                }
                xParent = xRootDoc;
            }
            
            // insert the new doc into the batch
            xNewDoc = (XmlElement)dcTask.BatchXML.DocumentElement.InsertAfter(xNewDoc, xParent);   // insert this doc right after the previous doc

            // now move childresn from previous doc into this doc as needed
            xNext = xNode;
            while (xNext != null)
            {
                XmlNode xNNext = xNext.NextSibling;
                xNewDoc.AppendChild(xNext);
                dcTask.WriteLog("Add child " + xNext.InnerXml);
                xNext = xNNext;
            }

            XmlNodeList xDocs = dcTask.BatchXML.SelectNodes(".//D");
            int nIdx = 0;
            foreach (XmlNode xDoc in xDocs)
            {
                nIdx++;
                string sNewID = nIdx.ToString();
                while (sNewID.Length < 2)
                    sNewID = "0" + sNewID;
                sNewID = dcTask.BatchID + "." + sNewID; 
                xDoc.Attributes["id"].Value = sNewID;
            }

            //update mclaims doc type
            int nClaims = CountClaims(xNewDoc);
            UpdateMCDocType(nClaims, xNewDoc);
            nClaims = CountClaims(xParent);
            UpdateMCDocType(nClaims, xParent);


            BatchForm.LoadBatch(sID);
            // BatchForm.ExpandAll();
            ImageForm.LoadThumbs(sID, true);

        }



        private void btnOpen_Click(object sender, EventArgs e)
        {
            ImportFile();  // call base class
        }

        const bool FASTENOUGH = true;
        const bool FASTENOUGH2 = false;

        //private void ProcessNewImageFile(XmlElement xPage, int insertPos, string[] listitems)
        private void ProcessNewImageFile(XmlElement xPage, int insertPos)
        {
            dcTask.WriteLog("ProcessNewImage " + xPage.Attributes["id"].Value);



            XmlNode xParent = null;
            if (insertMode)
            {
                // insert page where selection
                if (IsDocNode(xRefNode))
                {
                    // add to end of previous document
                    xParent = xDocPrev(xRefNode);
                    if (xParent == null)
                        return;
                    xParent.AppendChild(xPage);
                }
                else
                {
                    xParent = xRefNode.ParentNode;
                    xParent.InsertBefore(xPage, xRefNode);
                }

                BatchForm.AddPage(xPage);   // insert page into tree view, etc

                string sID;
                sID = xParent.Attributes["id"].Value;
                if (FASTENOUGH)
                    ImageForm.AddPage(xPage);       // display page in image view and add to thumbnails if enabled

                //                if (FASTENOUGH2)  // TODO: this line is needed to work around page added to end of tree view above
                //                    BatchForm.LoadBatch(sID);       // without this, the batchview will not be in sync with the dco
            }
            else
            {
                xParent = dcTask.BatchXML.DocumentElement;
                // not insert to mid batch - append to end of batch
                if (xParent.SelectSingleNode("D") != null)
                    xParent = xParent.SelectSingleNode("D[last()]");
                xParent.AppendChild(xPage);

                if (FASTENOUGH)
                    ImageForm.AddPage(xPage);
                if (FASTENOUGH)
                    BatchForm.AddPage(xPage);
            }
            dcTask.WriteLog("Scan IMAGEFILE " + xPage.SelectSingleNode("V[@n='IMAGEFILE']").InnerText);

            BatchForm.SelectTreeNode(xPage.Attributes["id"].Value);
            if (!sBarcodeSepValue.Equals(""))   // if barcode separator value provided in task settings
                StartNewDoc(xPage, xParent);    // compare with scanner read barcode and create new document if needed
        }


        // This is the method to run when the timer is raised.
        private void TimerEventProcessor(Object myObject, EventArgs myEventArgs)
        {
            myTimer.Stop();

            if (bScanInProgress)
            {
                myTimer.Enabled = true;
                return;
            }

            for (int iComma = sRescanIDs.IndexOf(","); iComma > -1; iComma = sRescanIDs.IndexOf(","))
            {
                //  more selected images to rescan (multiple rescan)
                sRescanIDs = sRescanIDs.Substring(iComma + 1);
                int iNextComma = sRescanIDs.IndexOf(",");
                string sID = (iNextComma > -1) ? sRescanIDs.Substring(0, iNextComma) : sRescanIDs;
                XmlNode xNextRescanPage = xNodeByID(sID);
                if (xNextRescanPage == null || !IsPageNode(xNextRescanPage))
                    continue;
                Cursor.Current = Cursors.Default;
                return;
            }
        }

        private bool StartNewDoc(XmlNode xPage, XmlNode xParent)
        {
            XmlNode xnum = xPage.SelectSingleNode("V[@n='NumBarcodes']");
            int num = 0;
            if (xnum == null)
                return false;
            else
                num = Convert.ToInt16(xnum.InnerText);

            XmlNode xbc = null;
            if (num == 0)
                return false;
            else
            {
                for (int i = 0; i < num; i++)
                {
                    xbc = xPage.SelectSingleNode("V[@n='GetBarcode" + i + "']");
                    if (xbc.InnerText.Equals(sBarcodeSepValue, StringComparison.CurrentCultureIgnoreCase))
                    {
                        XmlElement xNewDoc = (XmlElement)dcTask.BatchXML.CreateElement("D");
                        xNewDoc.SetAttribute("id", "new");
                        XmlElement xTmp = dcTask.BatchXML.CreateElement("V");
                        xTmp.SetAttribute("n", "TYPE");
                        xTmp.InnerText = "";
                        xNewDoc.AppendChild(xTmp);
                        xTmp = dcTask.BatchXML.CreateElement("V");
                        xTmp.SetAttribute("n", "STATUS");
                        xTmp.InnerText = "0";
                        xNewDoc.AppendChild(xTmp);
                        xNewDoc = (XmlElement)dcTask.BatchXML.DocumentElement.InsertAfter(xNewDoc, xParent);
                        xNewDoc.AppendChild(xPage);

                        XmlNodeList xDocs = dcTask.BatchXML.SelectNodes(".//D");
                        int nId = 0;
                        foreach (XmlNode xDoc in xDocs)
                        {
                            nId++;
                            string sNewID = nId.ToString();
                            while (sNewID.Length < 2)
                                sNewID = "0" + sNewID;
                            sNewID = dcTask.BatchID + "." + sNewID;
                            xDoc.Attributes["id"].Value = sNewID;
                        }
                        BatchForm.LoadBatch(xPage.Attributes["id"].Value);

                        return true;
                    }
                }
                return false;
            }
        }

        public string sMarkID = "";
        bool bInReview = false;

        private void MarkPageReview(string asComment)
        {
            // user hit hotkey - either display dropdown list; or update batch XML with new comment and disable dropdown list
            if (bCheckStructure == false)
                return;
            if (bInReview)
            {
                // update the comment in the fixup message and batch XML
                string sComment = cbxMarkList.Text;
                textFixupMsg.Visible = true;
                textFixupMsg.Text = sComment;
                cbxMarkList.Enabled = false;
                cbxMarkList.Visible = false;
                BatchForm.FlagNodeComment(sComment, GetFirstSelectedPageID());   // set the comment variable in the batch XML
                bInReview = false;
                BatchForm.SetBatchFocus();  // for OCC issue 80
                return;
            }
            bInReview = true;
            string sID = GetFirstSelectedPageID();
            XmlNode xNode = xNodeByID(sID);
            if (xNode == null || !IsPageNode(xNode))
                return;

            // DPS[0] is "mark for review" status by convention
            BatchForm.FlagNodeStatus(0, sID);   // flag page for review
            string sStatus = xNode.SelectSingleNode("V[@n='STATUS']").InnerText; // get numeric value DPS[0] that was just set
            update_status_control(Convert.ToInt32(sStatus), listPageStatus);  // update page status dropdown value

            if (pPageMarker.Length < 1)
                return;

            sMarkID = sID;
            // display dropdown list of possible comments
            // textFixupMsg.Enabled = false;
            textFixupMsg.Visible = false;
            cbxMarkList.Enabled = true;
            cbxMarkList.Visible = true;
            // get string to mark by displaying dropdown list
            cbxMarkList.Items.Clear();
            cbxMarkList.Text = "";
            foreach (tStatus sMarker in pPageMarker)
            {
                cbxMarkList.Items.Add(sMarker.sStatus);
                if (sMarker.sStatus == asComment)
                    cbxMarkList.SelectedText = asComment;
            }
            cbxMarkList.Select();
            cbxMarkList.Focus();
        }

        private void cbxMarkList_SelectedIndexChanged(object sender, EventArgs e)
        {
        }
        private void cbxMarkList_LostFocus(object sender, EventArgs e)
        {
            // dcTask.WriteLog("Comment lost focus");
        }
        private void cbxMarkList_TextChanged(object sender, EventArgs e)
        {
            // dcTask.WriteLog("Comment text changed");
        }

        private void settingsToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        public bool PreFilterMessage(ref Message m)
        {
            if (m.Msg == 256) // WM_KEYDOWN
            {
                // handle hotkeys to set pagetype, switch to batch tree view, etc
                // return true if this key has been handled, false if we want to pass it along

                if ((Control.ModifierKeys & (Keys.Control | Keys.Alt | Keys.Shift)) == 0)    // No ctrl/Alt/Shift held down
                {
                    switch ((int)m.WParam)
                    {
                        case (int)Keys.F6:
                            btnFinish_Click(null, null);
                            return true;
                        case (int)Keys.F5:
                            RefreshUI();
                            return true;
                        case (int)Keys.Left:       // Left Arrow
                            if (BatchForm.ContainsFocus)
                                return true;        // causes crash in batch view
                            break;
                        case (int)Keys.Right:       // Right Arrow
                            if (BatchForm.ContainsFocus)
                                return true;        // causes crash in batch view
                            break;
                        case (int)Keys.Delete:       // Delete = Remove image
                            if (btnRemove.Enabled)
                                btnRemove_Click(null, null);
                            return true;

                    }
                }

                const int VK_CONTROL = 0x11;        // control keycode


                if ((Control.ModifierKeys & (Keys.Control | Keys.Alt | Keys.Shift)) == Keys.Control)    // Ctrl only held down
                {
                    switch ((int)m.WParam)
                    {
                        case (int)Keys.Z:  // Ctrl-Z = Cancel batch
                            btnCancel_Click(null, null);
                            return true;
                        case (int)Keys.Q:  // Ctrl-Q = Hold batch
                            Status = "hold";
                            OnComplete(this, new TaskStatusEventArgs(Status));
                            return true;
                        case (int)Keys.B: // CTRL-B = focus on Batch Tree
                            BatchForm.SetBatchFocus();
                            return true;
                        case (int)Keys.D: // CTRL-D = Delete (Remove)
                            if (btnRemove.Enabled)
                                btnRemove_Click(null, null);
                            return true;
                        case (int)Keys.F: // CTRL-F = Flip - rotate 180
                            if (btnFlip.Enabled)
                                btnFlip_Click(null, null);
                            return true;
                        case (int)Keys.L: // CTRL-L = rotate Left (90 CCW)
                            if (btnRotateLeft.Enabled)
                                btnRotateLeft_Click(null, null);
                            return true;
                        case (int)Keys.R: // CTRL-R = rotate Right (90 CW)
                            if (btnRotateRight.Enabled)
                                btnRotateRight_Click(null, null);
                            return true;
                        case (int)Keys.S:       // CTRL-S = focus on Scan Panel
                            this.Focus();
                            return true;
                        case (int)Keys.T:        // CTRL-T = toggle thumbnail view
                            ImageForm.ToggleThumbs();
                            return true;
                        case (int)Keys.F8:       // CTRL-F8 = pop up page type
                            listPageType.Focus();
                            listPageType.DroppedDown = true;
                            return true;
                        case (int)Keys.F9:       // CTRL-F9 = mark page for review, with optional comment
                            MarkPageReview("");
                            return true;
                        case (int)Keys.Up:       // CTRL-UPARROW = Move Up
                            if (btnMoveUp.Enabled)
                                btnMoveUp_Click(null, null);
                            return true;
                        case (int)Keys.Down:       // CTRL-DOWNARROW = Move Down
                            if (btnMoveDn.Enabled)
                                btnMoveDn_Click(null, null);
                            return true;
                        case (int)VK_CONTROL:     // Control by itself
                            return false;
                        default:

                            tStatus[] sStatuses = (sSelectedDCOType == "D" ? sDocStatuses : sPageStatuses);
                            if (sStatuses != null) foreach (tStatus pStatus in sStatuses)
                                {
                                    if ((int)pStatus.cShortcut == (int)m.WParam)
                                    {
                                        int nSel = listPageStatus.FindStringExact(pStatus.sStatus);
                                        if (nSel >= 0)
                                        {
                                            listPageStatus.SelectedIndex = nSel;
                                            return true;
                                        }
                                    }
                                }
                            if (pPageMarker != null) foreach (tStatus pStatus in pPageMarker)
                                {
                                    if ((int)pStatus.cShortcut == (int)m.WParam)
                                        MarkPageReview(pStatus.sStatus);
                                }
                            break;
                    }
                }

                //if ((int)m.LParam == 983041 && (int)m.WParam == 9 && (Control.ModifierKeys & Keys.Shift) != Keys.Shift)    // VK_TAB=9 LParam=0xF0001 (count=1,OEM scancode=F)
            }
            return false;
        }



        public void WriteISISLogMsg(string caller, int lvl, string msgfmt = "", string[] fmtArgs = null)
        {
            string outmsg = msgfmt;
            if (fmtArgs != null)
                outmsg = string.Format(msgfmt, fmtArgs);

            if (lvl >= 7)
                dcTask.WriteLog(caller + ":Verbose: " + outmsg);
            else if (lvl <= 3)
                dcTask.WriteLog(caller + ":Error: " + outmsg);
            else
                dcTask.WriteLog(caller + ":Info: " + outmsg);
        }

        private void btnMakeClaim_Click(object sender, EventArgs e)
        {
            //multipage renaming
            string[] sIDs = GetSelectedPageIDs();
            int pgCount = sIDs.Length;
            string xParentID = "";
            bool approved = false;
            bool version = false;  //only ever true if Jobname contains PROF - for form version msgbox
            
            foreach (string sID in sIDs)
            {
                if (sID != "")
                {
                    // delete a single page
                    XmlNode xPage = dcTask.BatchXML.SelectSingleNode(".//*[@id='" + sID + "']"); //  XML node in runtime DCO
                    if (IsPageNode(xPage))
                    {
                        XmlNode xParent = xPage.ParentNode;
                        if (xParent == null)
                        {
                            dcTask.WriteLog("Cannot re-identify page '" + sID + "' - no parent node!");
                            return;
                        }

                        XmlNode xTmp = xPage.SelectSingleNode("V[@n='TYPE']");
                        string sOldType = "";
                        
                        if (xTmp != null)
                            sOldType = xTmp.InnerText;  
                        
                        //proceed with the renaming
                        string sNewType = "";

                        if (dcTask.JobName.Contains("INST"))
                            sNewType = "IClaim";
                        else if (dcTask.JobName.Contains("PROF"))
                        {
                            sNewType = "PClaim";
                            if (xParentID != xParent.SelectSingleNode("@id").Value) //toggles prompt for PClaim version msgbox
                            {
                                version = false;  //When parent is a new document 
                                xParentID = xParent.SelectSingleNode("@id").Value;
                            }
                        }

                        if (sOldType == sNewType || sNewType == "")
                        {
                            dcTask.WriteLog("Can not re-identify page '" + sID + "'. New Type is same as current Type, or Jobname is does not contain PROF or INST.");
                            return;
                        }

                        if (approved || MessageBox.Show(string.Format(MedicalClaimsPanels.Properties.Resources.msgConfirmTypeChange_Text, sNewType), MedicalClaimsPanels.Properties.Resources.msgConfirmTypeChange_Title, MessageBoxButtons.OKCancel) == DialogResult.OK)
                        {   
                            approved = true;

                            dcTask.WriteLog("Type change: ID=" + sID + " old=" + sOldType + " new=" + sNewType);
                            
                            xPage.SelectSingleNode("V[@n='TYPE']").InnerText = sNewType;    // update type in batch XML

                            //update status 
                            XmlNode pStatusNode = xPage.SelectSingleNode("V[@n='STATUS']");
                            if (pStatusNode != null)
                                pStatusNode.InnerText = "55";
                            
                            //and add formtype version
                            if (sNewType == "PClaim")
                            {
                                if (version || MessageBox.Show("Make this page a 02/12 form Version?", "Select Form Version", MessageBoxButtons.YesNo) == DialogResult.Yes)
                                {
                                    version = true;
                                    SetVariable(xPage, "FormVersion", "02/12"); // @P.FormVersion = 02/12
                                    SetVariable(xPage, "TemplateID", "1059"); // @P.TemplateID = 1059
                                    SetVariable(xPage, "OverlayFileName", "1500_0212.tif"); // @P.OverlayFileName = 1500_0212t.tif
                                }
                                else
                                {
                                    SetVariable(xPage, "FormVersion", "08/05");
                                    SetVariable(xPage, "TemplateID", "1052");
                                    SetVariable(xPage, "OverlayFileName", "CMSt.tif");
                                }
                            }
                            else
                            {
                                SetVariable(xPage, "TemplateID", "1055");
                                SetVariable(xPage, "OverlayFileName", "ub04t.tif");
                            }

                            if (xPage.SelectSingleNode("V[@n='DATAFILE']") != null)
                                 xPage.RemoveChild(xPage.SelectSingleNode("V[@n='DATAFILE']"));  // remove data if pagetype changed

                            if (xPage.Name == "P")
                            {
                                string sFname = ImageFilePath(xPage);
                                Delete_Page_AuxFiles(sFname, false);
                            }

                            //update doc type
                            int nClaims = CountClaims(xParent);
                            UpdateMCDocType(nClaims, xParent);

                            // must reload batch tree 
                            BatchForm.LoadBatch(sID);
                        }
                    }

                }

            }
                     
        }

        public void SetVariable(XmlNode pNode, string sVarName, string sValue)
        {
            XmlNode pVar = pNode.SelectSingleNode("V[@n='" + sVarName + "']");
            if (pVar != null)
            {
                pVar.InnerText = sValue;
                return;
            }
             
            //if not found
            XmlElement xVar = dcTask.BatchXML.CreateElement("V");
            xVar.SetAttribute("n", sVarName);
            xVar.InnerText = sValue;
            pNode.AppendChild(xVar);
            
        }

        private void btnMakeAttachment_Click(object sender, EventArgs e)
        {
            //multipage renaming
            string[] sIDs = GetSelectedPageIDs();
            int pgCount = sIDs.Length;
            bool approved = false;
           
            foreach (string sID in sIDs)
            {
                if (sID != "")
                {
                    // delete a single page
                    XmlNode xPage = dcTask.BatchXML.SelectSingleNode(".//*[@id='" + sID + "']"); //  XML node in runtime DCO
                    if (IsPageNode(xPage))
                    {
                        XmlNode xParent = xPage.ParentNode;
                        if (xParent == null)
                        {
                            dcTask.WriteLog("Cannot re-identify page '" + sID + "' - no parent node!");
                            return;
                        }

                        XmlNode xTmp = xPage.SelectSingleNode("V[@n='TYPE']");
                        string sOldType = "";

                        if (xTmp != null)
                            sOldType = xTmp.InnerText;

                        //proceed with the renaming
                        string sNewType = "Attachment";

                        if (sOldType == sNewType || sNewType == "")
                        {
                            dcTask.WriteLog("Can not re-identify page '" + sID + "'. New Type is same as current Type, or Jobname is does not contain PROF or INST.");
                            return;
                        }

                        if (approved || MessageBox.Show(string.Format(MedicalClaimsPanels.Properties.Resources.msgConfirmTypeChange_Text, sNewType), MedicalClaimsPanels.Properties.Resources.msgConfirmTypeChange_Title, MessageBoxButtons.OKCancel) == DialogResult.OK)
                        {
                            approved = true;

                            dcTask.WriteLog("Type change: ID=" + sID + " old=" + sOldType + " new=" + sNewType);

                            xPage.SelectSingleNode("V[@n='TYPE']").InnerText = sNewType;    // update type in batch XML

                            //update status 
                            XmlNode pStatusNode = xPage.SelectSingleNode("V[@n='STATUS']");
                            if (pStatusNode != null)
                                pStatusNode.InnerText = "74";

                            if (xPage.SelectSingleNode("V[@n='DATAFILE']") != null)
                                xPage.RemoveChild(xPage.SelectSingleNode("V[@n='DATAFILE']"));  // remove data if pagetype changed

                            if (xPage.Name == "P")
                            {
                                string sFname = ImageFilePath(xPage);
                                Delete_Page_AuxFiles(sFname, false);
                            }

                            //update doc type
                            int nClaims = CountClaims(xParent);
                            UpdateMCDocType(nClaims, xParent);

                            // must reload batch tree 
                            BatchForm.LoadBatch(sID);
                        }
                    }

                }

            }
        }
           

    }
}
