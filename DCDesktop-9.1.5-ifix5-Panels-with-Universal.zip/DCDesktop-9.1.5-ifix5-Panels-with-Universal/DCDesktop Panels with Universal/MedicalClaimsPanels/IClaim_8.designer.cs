
namespace MedicalClaimsPanels
{
    partial class IClaim_8
    {
        /// 
        /// Required designer variable.
        /// 
        private System.ComponentModel.IContainer components = null;

        /// 
        /// Clean up any resources being used.
        /// 
        /// true if managed resources should be disposed; otherwise, false.
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// 
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(IClaim_8));
            this.dcim1fcynmad = new AxDCIMAGELib.AxDcimage();
            this.lbl1provnam = new System.Windows.Forms.Label();
            this.dced1provnam = new AxDCEDITLib.AxDcedit();
            this.dced1provadd = new AxDCEDITLib.AxDcedit();
            this.dced1provcit = new AxDCEDITLib.AxDcedit();
            this.dced1provsta = new AxDCEDITLib.AxDcedit();
            this.lbl3apctlnm = new System.Windows.Forms.Label();
            this.dcim3apctlnm = new AxDCIMAGELib.AxDcimage();
            this.dced3apctlnm = new AxDCEDITLib.AxDcedit();
            this.lbl3bmdrcnm = new System.Windows.Forms.Label();
            this.dcim3bmdrcnm = new AxDCIMAGELib.AxDcimage();
            this.dced3bmdrcnm = new AxDCEDITLib.AxDcedit();
            this.lbl4typbill = new System.Windows.Forms.Label();
            this.dcim4typbill = new AxDCIMAGELib.AxDcimage();
            this.dced4typbill = new AxDCEDITLib.AxDcedit();
            this.lbl5fedtxnm = new System.Windows.Forms.Label();
            this.dcim5fedtxnm = new AxDCIMAGELib.AxDcimage();
            this.dced5fedtxnm = new AxDCEDITLib.AxDcedit();
            this.lbl6scpfrom = new System.Windows.Forms.Label();
            this.dcim6scpfrom = new AxDCIMAGELib.AxDcimage();
            this.dced6scpfrom = new AxDCEDITLib.AxDcedit();
            this.dcim6scpthru = new AxDCIMAGELib.AxDcimage();
            this.dced6scpthru = new AxDCEDITLib.AxDcedit();
            this.lbl8ptnmid = new System.Windows.Forms.Label();
            this.dcim8ptnmid = new AxDCIMAGELib.AxDcimage();
            this.dced8ptnmid = new AxDCEDITLib.AxDcedit();
            this.lbl8ptnm = new System.Windows.Forms.Label();
            this.dcim8ptnm = new AxDCIMAGELib.AxDcimage();
            this.dced8plname = new AxDCEDITLib.AxDcedit();
            this.dced8pfname = new AxDCEDITLib.AxDcedit();
            this.dced8pminit = new AxDCEDITLib.AxDcedit();
            this.dcim9paddstr = new AxDCIMAGELib.AxDcimage();
            this.dced9paddstr = new AxDCEDITLib.AxDcedit();
            this.dcim9paddcty = new AxDCIMAGELib.AxDcimage();
            this.dced9paddcty = new AxDCEDITLib.AxDcedit();
            this.dcim9paddsta = new AxDCIMAGELib.AxDcimage();
            this.dced9paddsta = new AxDCEDITLib.AxDcedit();
            this.dcim9paddzip = new AxDCIMAGELib.AxDcimage();
            this.dced9paddzip = new AxDCEDITLib.AxDcedit();
            this.dcim9paddccd = new AxDCIMAGELib.AxDcimage();
            this.dced9paddccd = new AxDCEDITLib.AxDcedit();
            this.lbl10pbdate = new System.Windows.Forms.Label();
            this.dcim10pbdate = new AxDCIMAGELib.AxDcimage();
            this.dced10pbdate = new AxDCEDITLib.AxDcedit();
            this.lbl11psex = new System.Windows.Forms.Label();
            this.dcim11psex = new AxDCIMAGELib.AxDcimage();
            this.dced11psex = new AxDCEDITLib.AxDcedit();
            this.lbl12admdte = new System.Windows.Forms.Label();
            this.dcim12admdte = new AxDCIMAGELib.AxDcimage();
            this.dced12admdte = new AxDCEDITLib.AxDcedit();
            this.lbl13admhr = new System.Windows.Forms.Label();
            this.dcim13admhr = new AxDCIMAGELib.AxDcimage();
            this.dced13admhr = new AxDCEDITLib.AxDcedit();
            this.lbl14admtyp = new System.Windows.Forms.Label();
            this.dcim14admtyp = new AxDCIMAGELib.AxDcimage();
            this.dced14admtyp = new AxDCEDITLib.AxDcedit();
            this.lbl16dhr = new System.Windows.Forms.Label();
            this.dcim16dhr = new AxDCIMAGELib.AxDcimage();
            this.dced16dhr = new AxDCEDITLib.AxDcedit();
            this.lbl17stat = new System.Windows.Forms.Label();
            this.dcim17stat = new AxDCIMAGELib.AxDcimage();
            this.dced17stat = new AxDCEDITLib.AxDcedit();
            this.lbl31aocrcd = new System.Windows.Forms.Label();
            this.dcim31aocrcd = new AxDCIMAGELib.AxDcimage();
            this.dced31aocrcd = new AxDCEDITLib.AxDcedit();
            this.dcim31aocrdt = new AxDCIMAGELib.AxDcimage();
            this.dced31aocrdt = new AxDCEDITLib.AxDcedit();
            this.dcim31bocrcd = new AxDCIMAGELib.AxDcimage();
            this.dced31bocrcd = new AxDCEDITLib.AxDcedit();
            this.dcim31bocrdt = new AxDCIMAGELib.AxDcimage();
            this.dced31bocrdt = new AxDCEDITLib.AxDcedit();
            this.lbl32aocrcd = new System.Windows.Forms.Label();
            this.dcim32aocrcd = new AxDCIMAGELib.AxDcimage();
            this.dced32aocrcd = new AxDCEDITLib.AxDcedit();
            this.dcim32aocrdt = new AxDCIMAGELib.AxDcimage();
            this.dced32aocrdt = new AxDCEDITLib.AxDcedit();
            this.dcim32bocrcd = new AxDCIMAGELib.AxDcimage();
            this.dced32bocrcd = new AxDCEDITLib.AxDcedit();
            this.dcim32bocrdt = new AxDCIMAGELib.AxDcimage();
            this.dced32bocrdt = new AxDCEDITLib.AxDcedit();
            this.lbl36aospcd = new System.Windows.Forms.Label();
            this.dcim36aospcd = new AxDCIMAGELib.AxDcimage();
            this.dced36aospcd = new AxDCEDITLib.AxDcedit();
            this.dcim36aospfr = new AxDCIMAGELib.AxDcimage();
            this.dced36aospfr = new AxDCEDITLib.AxDcedit();
            this.dcim36aospth = new AxDCIMAGELib.AxDcimage();
            this.dced36aospth = new AxDCEDITLib.AxDcedit();
            this.dcim36bospcd = new AxDCIMAGELib.AxDcimage();
            this.dced36bospcd = new AxDCEDITLib.AxDcedit();
            this.dcim36bospfr = new AxDCIMAGELib.AxDcimage();
            this.dced36bospfr = new AxDCEDITLib.AxDcedit();
            this.dcim36bospth = new AxDCIMAGELib.AxDcimage();
            this.dced36bospth = new AxDCEDITLib.AxDcedit();
            this.lbl39avlcd = new System.Windows.Forms.Label();
            this.dcim39avlcd = new AxDCIMAGELib.AxDcimage();
            this.dced39avlcd = new AxDCEDITLib.AxDcedit();
            this.dcim39avlamt = new AxDCIMAGELib.AxDcimage();
            this.dced39avlamt = new AxDCEDITLib.AxDcedit();
            this.dcim39bvlcd = new AxDCIMAGELib.AxDcimage();
            this.dced39bvlcd = new AxDCEDITLib.AxDcedit();
            this.dcim39bvlamt = new AxDCIMAGELib.AxDcimage();
            this.dced39bvlamt = new AxDCEDITLib.AxDcedit();
            this.dcim39cvlcd = new AxDCIMAGELib.AxDcimage();
            this.dced39cvlcd = new AxDCEDITLib.AxDcedit();
            this.dcim39cvlamt = new AxDCIMAGELib.AxDcimage();
            this.dced39cvlamt = new AxDCEDITLib.AxDcedit();
            this.dcim39dvlcd = new AxDCIMAGELib.AxDcimage();
            this.dced39dvlcd = new AxDCEDITLib.AxDcedit();
            this.dcim39dvlamt = new AxDCIMAGELib.AxDcimage();
            this.dced39dvlamt = new AxDCEDITLib.AxDcedit();
            this.lbl40avlcd = new System.Windows.Forms.Label();
            this.dcim40avlcd = new AxDCIMAGELib.AxDcimage();
            this.dced40avlcd = new AxDCEDITLib.AxDcedit();
            this.dcim40avlamt = new AxDCIMAGELib.AxDcimage();
            this.dced40avlamt = new AxDCEDITLib.AxDcedit();
            this.dcim40bvlcd = new AxDCIMAGELib.AxDcimage();
            this.dced40bvlcd = new AxDCEDITLib.AxDcedit();
            this.dcim40bvlamt = new AxDCIMAGELib.AxDcimage();
            this.dced40bvlamt = new AxDCEDITLib.AxDcedit();
            this.dcim40cvlcd = new AxDCIMAGELib.AxDcimage();
            this.dced40cvlcd = new AxDCEDITLib.AxDcedit();
            this.dcim40cvlamt = new AxDCIMAGELib.AxDcimage();
            this.dced40cvlamt = new AxDCEDITLib.AxDcedit();
            this.dcim40dvlcd = new AxDCIMAGELib.AxDcimage();
            this.dced40dvlcd = new AxDCEDITLib.AxDcedit();
            this.dcim40dvlamt = new AxDCIMAGELib.AxDcimage();
            this.dced40dvlamt = new AxDCEDITLib.AxDcedit();
            this.dcim41avlcd = new AxDCIMAGELib.AxDcimage();
            this.dced41avlcd = new AxDCEDITLib.AxDcedit();
            this.dcim41avlamt = new AxDCIMAGELib.AxDcimage();
            this.dced41avlamt = new AxDCEDITLib.AxDcedit();
            this.lbl41bvlcd = new System.Windows.Forms.Label();
            this.dcim41bvlcd = new AxDCIMAGELib.AxDcimage();
            this.dced41bvlcd = new AxDCEDITLib.AxDcedit();
            this.dcim41bvlamt = new AxDCIMAGELib.AxDcimage();
            this.dced41bvlamt = new AxDCEDITLib.AxDcedit();
            this.dcim41cvlcd = new AxDCIMAGELib.AxDcimage();
            this.dced41cvlcd = new AxDCEDITLib.AxDcedit();
            this.dcim41cvlamt = new AxDCIMAGELib.AxDcimage();
            this.dced41cvlamt = new AxDCEDITLib.AxDcedit();
            this.dcim41dvlcd = new AxDCIMAGELib.AxDcimage();
            this.dced41dvlcd = new AxDCEDITLib.AxDcedit();
            this.dcim41dvlamt = new AxDCIMAGELib.AxDcimage();
            this.dced41dvlamt = new AxDCEDITLib.AxDcedit();
            this.lbl1fcynmad = new System.Windows.Forms.Label();
            this.lbl1provadd = new System.Windows.Forms.Label();
            this.lbl1provcit = new System.Windows.Forms.Label();
            this.lbl1provsta = new System.Windows.Forms.Label();
            this.dced1provzip = new AxDCEDITLib.AxDcedit();
            this.lbl1provzip = new System.Windows.Forms.Label();
            this.lbl8plname = new System.Windows.Forms.Label();
            this.lbl8pfname = new System.Windows.Forms.Label();
            this.lbl8pminit = new System.Windows.Forms.Label();
            this.lbl9paddstr = new System.Windows.Forms.Label();
            this.lbl9paddcty = new System.Windows.Forms.Label();
            this.lbl9paddsta = new System.Windows.Forms.Label();
            this.lbl9paddzip = new System.Windows.Forms.Label();
            this.lbl9paddccd = new System.Windows.Forms.Label();
            this.picbx1 = new System.Windows.Forms.PictureBox();
            this.picbx8 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnDelpbLINEITEM = new System.Windows.Forms.Button();
            this.btnInsAfterpbLINEITEM = new System.Windows.Forms.Button();
            this.btnInsBeforepbLINEITEM = new System.Windows.Forms.Button();
            this.dcim50apayer = new AxDCIMAGELib.AxDcimage();
            this.dced50apayer = new AxDCEDITLib.AxDcedit();
            this.dcim50bpayer = new AxDCIMAGELib.AxDcimage();
            this.dced50bpayer = new AxDCEDITLib.AxDcedit();
            this.lbl50cpayer = new System.Windows.Forms.Label();
            this.dcim50cpayer = new AxDCIMAGELib.AxDcimage();
            this.dced50cpayer = new AxDCEDITLib.AxDcedit();
            this.dcim51aprvno = new AxDCIMAGELib.AxDcimage();
            this.dced51aprvno = new AxDCEDITLib.AxDcedit();
            this.dcim51bprvno = new AxDCIMAGELib.AxDcimage();
            this.dced51bprvno = new AxDCEDITLib.AxDcedit();
            this.lbl51cprvno = new System.Windows.Forms.Label();
            this.dcim51cprvno = new AxDCIMAGELib.AxDcimage();
            this.dced51cprvno = new AxDCEDITLib.AxDcedit();
            this.lbl56npi = new System.Windows.Forms.Label();
            this.dcim56npi = new AxDCIMAGELib.AxDcimage();
            this.dced56npi = new AxDCEDITLib.AxDcedit();
            this.dcim58ainsnm = new AxDCIMAGELib.AxDcimage();
            this.lbl58alname = new System.Windows.Forms.Label();
            this.dced58alname = new AxDCEDITLib.AxDcedit();
            this.lbl58afname = new System.Windows.Forms.Label();
            this.dced58afname = new AxDCEDITLib.AxDcedit();
            this.lbl58aminit = new System.Windows.Forms.Label();
            this.dced58aminit = new AxDCEDITLib.AxDcedit();
            this.lbl58binsnm = new System.Windows.Forms.Label();
            this.dcim58binsnm = new AxDCIMAGELib.AxDcimage();
            this.lbl58blname = new System.Windows.Forms.Label();
            this.dced58blname = new AxDCEDITLib.AxDcedit();
            this.lbl58bfname = new System.Windows.Forms.Label();
            this.dced58bfname = new AxDCEDITLib.AxDcedit();
            this.lbl58bminit = new System.Windows.Forms.Label();
            this.dced58bminit = new AxDCEDITLib.AxDcedit();
            this.dcim58cinsnm = new AxDCIMAGELib.AxDcimage();
            this.lbl58clname = new System.Windows.Forms.Label();
            this.dced58clname = new AxDCEDITLib.AxDcedit();
            this.dced58cfname = new AxDCEDITLib.AxDcedit();
            this.dced58cminit = new AxDCEDITLib.AxDcedit();
            this.dcim60acshi = new AxDCIMAGELib.AxDcimage();
            this.dced60acshi = new AxDCEDITLib.AxDcedit();
            this.dcim60bcshi = new AxDCIMAGELib.AxDcimage();
            this.dced60bcshi = new AxDCEDITLib.AxDcedit();
            this.lbl60ccshi = new System.Windows.Forms.Label();
            this.dcim60ccshi = new AxDCIMAGELib.AxDcimage();
            this.dced60ccshi = new AxDCEDITLib.AxDcedit();
            this.dcim66dxverq = new AxDCIMAGELib.AxDcimage();
            this.dced66dxverq = new AxDCEDITLib.AxDcedit();
            this.lbl67prdgcd = new System.Windows.Forms.Label();
            this.dcim67prdgcd = new AxDCIMAGELib.AxDcimage();
            this.dced67prdgcd = new AxDCEDITLib.AxDcedit();
            this.lbl67aothdg = new System.Windows.Forms.Label();
            this.dcim67aothdg = new AxDCIMAGELib.AxDcimage();
            this.dced67aothdg = new AxDCEDITLib.AxDcedit();
            this.lbl67bothdg = new System.Windows.Forms.Label();
            this.dcim67bothdg = new AxDCIMAGELib.AxDcimage();
            this.dced67bothdg = new AxDCEDITLib.AxDcedit();
            this.lbl67cothdg = new System.Windows.Forms.Label();
            this.dcim67cothdg = new AxDCIMAGELib.AxDcimage();
            this.dced67cothdg = new AxDCEDITLib.AxDcedit();
            this.lbl67dothdg = new System.Windows.Forms.Label();
            this.dcim67dothdg = new AxDCIMAGELib.AxDcimage();
            this.dced67dothdg = new AxDCEDITLib.AxDcedit();
            this.lbl67eothdg = new System.Windows.Forms.Label();
            this.dcim67eothdg = new AxDCIMAGELib.AxDcimage();
            this.dced67eothdg = new AxDCEDITLib.AxDcedit();
            this.lbl67fothdg = new System.Windows.Forms.Label();
            this.dcim67fothdg = new AxDCIMAGELib.AxDcimage();
            this.dced67fothdg = new AxDCEDITLib.AxDcedit();
            this.lbl67gothdg = new System.Windows.Forms.Label();
            this.dcim67gothdg = new AxDCIMAGELib.AxDcimage();
            this.dced67gothdg = new AxDCEDITLib.AxDcedit();
            this.lbl67hothdg = new System.Windows.Forms.Label();
            this.dcim67hothdg = new AxDCIMAGELib.AxDcimage();
            this.dced67hothdg = new AxDCEDITLib.AxDcedit();
            this.lbl67iothdg = new System.Windows.Forms.Label();
            this.dcim67iothdg = new AxDCIMAGELib.AxDcimage();
            this.dced67iothdg = new AxDCEDITLib.AxDcedit();
            this.lbl67jothdg = new System.Windows.Forms.Label();
            this.dcim67jothdg = new AxDCIMAGELib.AxDcimage();
            this.dced67jothdg = new AxDCEDITLib.AxDcedit();
            this.lbl67kothdg = new System.Windows.Forms.Label();
            this.dcim67kothdg = new AxDCIMAGELib.AxDcimage();
            this.dced67kothdg = new AxDCEDITLib.AxDcedit();
            this.lbl67lothdg = new System.Windows.Forms.Label();
            this.dcim67lothdg = new AxDCIMAGELib.AxDcimage();
            this.dced67lothdg = new AxDCEDITLib.AxDcedit();
            this.lbl67mothdg = new System.Windows.Forms.Label();
            this.dcim67mothdg = new AxDCIMAGELib.AxDcimage();
            this.dced67mothdg = new AxDCEDITLib.AxDcedit();
            this.lbl67nothdg = new System.Windows.Forms.Label();
            this.dcim67nothdg = new AxDCIMAGELib.AxDcimage();
            this.dced67nothdg = new AxDCEDITLib.AxDcedit();
            this.lbl67oothdg = new System.Windows.Forms.Label();
            this.dcim67oothdg = new AxDCIMAGELib.AxDcimage();
            this.dced67oothdg = new AxDCEDITLib.AxDcedit();
            this.lbl67pothdg = new System.Windows.Forms.Label();
            this.dcim67pothdg = new AxDCIMAGELib.AxDcimage();
            this.dced67pothdg = new AxDCEDITLib.AxDcedit();
            this.lbl67qothdg = new System.Windows.Forms.Label();
            this.dcim67qothdg = new AxDCIMAGELib.AxDcimage();
            this.dced67qothdg = new AxDCEDITLib.AxDcedit();
            this.dcim69amdgcd = new AxDCIMAGELib.AxDcimage();
            this.dced69amdgcd = new AxDCEDITLib.AxDcedit();
            this.dcim70arfvcd = new AxDCIMAGELib.AxDcimage();
            this.dced70arfvcd = new AxDCEDITLib.AxDcedit();
            this.dcim70brfvcd = new AxDCIMAGELib.AxDcimage();
            this.dced70brfvcd = new AxDCEDITLib.AxDcedit();
            this.dcim70crfvcd = new AxDCIMAGELib.AxDcimage();
            this.dced70crfvcd = new AxDCEDITLib.AxDcedit();
            this.dcim71ppscd = new AxDCIMAGELib.AxDcimage();
            this.dced71ppscd = new AxDCEDITLib.AxDcedit();
            this.lbl72aecicd = new System.Windows.Forms.Label();
            this.dcim72aecicd = new AxDCIMAGELib.AxDcimage();
            this.dced72aecicd = new AxDCEDITLib.AxDcedit();
            this.lbl23TotChgs = new System.Windows.Forms.Label();
            this.dcim23TotChgs = new AxDCIMAGELib.AxDcimage();
            this.dced23TotChgs = new AxDCEDITLib.AxDcedit();
            this.panLINEITEM = new System.Windows.Forms.Panel();
            this.dcimNDCType = new AxDCIMAGELib.AxDcimage();
            this.dcedNDCType = new AxDCEDITLib.AxDcedit();
            this.dcimNDCQty = new AxDCIMAGELib.AxDcimage();
            this.dcedNDCQty = new AxDCEDITLib.AxDcedit();
            this.dcimRevCode = new AxDCIMAGELib.AxDcimage();
            this.dcedRevCode = new AxDCEDITLib.AxDcedit();
            this.dcimDescription = new AxDCIMAGELib.AxDcimage();
            this.dcedDescription = new AxDCEDITLib.AxDcedit();
            this.dcimHCPCS = new AxDCIMAGELib.AxDcimage();
            this.dcedHCPCS = new AxDCEDITLib.AxDcedit();
            this.dcimServiceDate = new AxDCIMAGELib.AxDcimage();
            this.dcedServiceDate = new AxDCEDITLib.AxDcedit();
            this.dcimUnits = new AxDCIMAGELib.AxDcimage();
            this.dcedUnits = new AxDCEDITLib.AxDcedit();
            this.dcimCharges = new AxDCIMAGELib.AxDcimage();
            this.dcedCharges = new AxDCEDITLib.AxDcedit();
            this.dcimNonCovered = new AxDCIMAGELib.AxDcimage();
            this.dcedNonCovered = new AxDCEDITLib.AxDcedit();
            this.dcimNDC = new AxDCIMAGELib.AxDcimage();
            this.dcedNDC = new AxDCEDITLib.AxDcedit();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.lbl74prprcd = new System.Windows.Forms.Label();
            this.dcim74prprcd = new AxDCIMAGELib.AxDcimage();
            this.dced74prprcd = new AxDCEDITLib.AxDcedit();
            this.dcim74prprdt = new AxDCIMAGELib.AxDcimage();
            this.dced74prprdt = new AxDCEDITLib.AxDcedit();
            this.lbl74aoprcd = new System.Windows.Forms.Label();
            this.dcim74aoprcd = new AxDCIMAGELib.AxDcimage();
            this.dced74aoprcd = new AxDCEDITLib.AxDcedit();
            this.dcim74aoprdt = new AxDCIMAGELib.AxDcimage();
            this.dced74aoprdt = new AxDCEDITLib.AxDcedit();
            this.dcim74boprcd = new AxDCIMAGELib.AxDcimage();
            this.dced74boprcd = new AxDCEDITLib.AxDcedit();
            this.lbl74boprdt = new System.Windows.Forms.Label();
            this.dcim74boprdt = new AxDCIMAGELib.AxDcimage();
            this.dced74boprdt = new AxDCEDITLib.AxDcedit();
            this.lbl74coprcd = new System.Windows.Forms.Label();
            this.dcim74coprcd = new AxDCIMAGELib.AxDcimage();
            this.dced74coprcd = new AxDCEDITLib.AxDcedit();
            this.dcim74coprdt = new AxDCIMAGELib.AxDcimage();
            this.dced74coprdt = new AxDCEDITLib.AxDcedit();
            this.lbl74doprcd = new System.Windows.Forms.Label();
            this.dcim74doprcd = new AxDCIMAGELib.AxDcimage();
            this.dced74doprcd = new AxDCEDITLib.AxDcedit();
            this.dcim74doprdt = new AxDCIMAGELib.AxDcimage();
            this.dced74doprdt = new AxDCEDITLib.AxDcedit();
            this.lbl74eoprcd = new System.Windows.Forms.Label();
            this.dcim74eoprcd = new AxDCIMAGELib.AxDcimage();
            this.dced74eoprcd = new AxDCEDITLib.AxDcedit();
            this.lbl74eoprdt = new System.Windows.Forms.Label();
            this.dcim74eoprdt = new AxDCIMAGELib.AxDcimage();
            this.dced74eoprdt = new AxDCEDITLib.AxDcedit();
            this.lbl76apnpi = new System.Windows.Forms.Label();
            this.dcim76apnpi = new AxDCIMAGELib.AxDcimage();
            this.dced76apnpi = new AxDCEDITLib.AxDcedit();
            this.lbl76apqual = new System.Windows.Forms.Label();
            this.dcim76apqual = new AxDCIMAGELib.AxDcimage();
            this.dced76apqual = new AxDCEDITLib.AxDcedit();
            this.lbl76apid = new System.Windows.Forms.Label();
            this.dcim76apid = new AxDCIMAGELib.AxDcimage();
            this.dced76apid = new AxDCEDITLib.AxDcedit();
            this.lbl76aplnm = new System.Windows.Forms.Label();
            this.dcim76aplnm = new AxDCIMAGELib.AxDcimage();
            this.dced76aplnm = new AxDCEDITLib.AxDcedit();
            this.lbl76apfnm = new System.Windows.Forms.Label();
            this.dcim76apfnm = new AxDCIMAGELib.AxDcimage();
            this.dced76apfnm = new AxDCEDITLib.AxDcedit();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.dcim33aocrcd = new AxDCIMAGELib.AxDcimage();
            this.dced33aocrcd = new AxDCEDITLib.AxDcedit();
            this.dcim33aocrdt = new AxDCIMAGELib.AxDcimage();
            this.dced33aocrdt = new AxDCEDITLib.AxDcedit();
            this.dcim33bocrcd = new AxDCIMAGELib.AxDcimage();
            this.dced33bocrcd = new AxDCEDITLib.AxDcedit();
            this.dcim33bocrdt = new AxDCIMAGELib.AxDcimage();
            this.dced33bocrdt = new AxDCEDITLib.AxDcedit();
            this.label17 = new System.Windows.Forms.Label();
            this.dcim34aocrcd = new AxDCIMAGELib.AxDcimage();
            this.dced34aocrcd = new AxDCEDITLib.AxDcedit();
            this.dcim34aocrdt = new AxDCIMAGELib.AxDcimage();
            this.dced34aocrdt = new AxDCEDITLib.AxDcedit();
            this.dcim34bocrcd = new AxDCIMAGELib.AxDcimage();
            this.dced34bocrcd = new AxDCEDITLib.AxDcedit();
            this.dcim34bocrdt = new AxDCIMAGELib.AxDcimage();
            this.dced34bocrdt = new AxDCEDITLib.AxDcedit();
            this.label18 = new System.Windows.Forms.Label();
            this.dcim35aospcd = new AxDCIMAGELib.AxDcimage();
            this.dced35aospcd = new AxDCEDITLib.AxDcedit();
            this.dcim35aospfr = new AxDCIMAGELib.AxDcimage();
            this.dced35aospfr = new AxDCEDITLib.AxDcedit();
            this.dcim35aospth = new AxDCIMAGELib.AxDcimage();
            this.dced35aospth = new AxDCEDITLib.AxDcedit();
            this.dcim35bospcd = new AxDCIMAGELib.AxDcimage();
            this.dced35bospcd = new AxDCEDITLib.AxDcedit();
            this.dcim35bospfr = new AxDCIMAGELib.AxDcimage();
            this.dced35bospfr = new AxDCEDITLib.AxDcedit();
            this.dcim35bospth = new AxDCIMAGELib.AxDcimage();
            this.dced35bospth = new AxDCEDITLib.AxDcedit();
            this.dcim2payto = new AxDCIMAGELib.AxDcimage();
            this.label19 = new System.Windows.Forms.Label();
            this.dced2paytnm = new AxDCEDITLib.AxDcedit();
            this.dced2paytadd = new AxDCEDITLib.AxDcedit();
            this.dced2paytcty = new AxDCEDITLib.AxDcedit();
            this.dced2paytst = new AxDCEDITLib.AxDcedit();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.dced2paytzip = new AxDCEDITLib.AxDcedit();
            this.label24 = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.label25 = new System.Windows.Forms.Label();
            this.dcim18concd = new AxDCIMAGELib.AxDcimage();
            this.dced18concd = new AxDCEDITLib.AxDcedit();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.axDcimage1 = new AxDCIMAGELib.AxDcimage();
            this.axDcedit1 = new AxDCEDITLib.AxDcedit();
            this.label28 = new System.Windows.Forms.Label();
            this.dcim20concd = new AxDCIMAGELib.AxDcimage();
            this.dced20concd = new AxDCEDITLib.AxDcedit();
            this.label26 = new System.Windows.Forms.Label();
            this.dcim19concd = new AxDCIMAGELib.AxDcimage();
            this.dced19concd = new AxDCEDITLib.AxDcedit();
            this.label29 = new System.Windows.Forms.Label();
            this.dcim21concd = new AxDCIMAGELib.AxDcimage();
            this.dced21concd = new AxDCEDITLib.AxDcedit();
            this.label30 = new System.Windows.Forms.Label();
            this.dcim23concd = new AxDCIMAGELib.AxDcimage();
            this.dced23concd = new AxDCEDITLib.AxDcedit();
            this.label31 = new System.Windows.Forms.Label();
            this.dcim24concd = new AxDCIMAGELib.AxDcimage();
            this.dced24concd = new AxDCEDITLib.AxDcedit();
            this.label32 = new System.Windows.Forms.Label();
            this.dcim25concd = new AxDCIMAGELib.AxDcimage();
            this.dced25concd = new AxDCEDITLib.AxDcedit();
            this.label33 = new System.Windows.Forms.Label();
            this.dcim26concd = new AxDCIMAGELib.AxDcimage();
            this.dced26concd = new AxDCEDITLib.AxDcedit();
            this.label34 = new System.Windows.Forms.Label();
            this.dcim22concd = new AxDCIMAGELib.AxDcimage();
            this.dced22concd = new AxDCEDITLib.AxDcedit();
            this.label35 = new System.Windows.Forms.Label();
            this.dcim27concd = new AxDCIMAGELib.AxDcimage();
            this.dced27concd = new AxDCEDITLib.AxDcedit();
            this.label27 = new System.Windows.Forms.Label();
            this.dcim28concd = new AxDCIMAGELib.AxDcimage();
            this.dced28concd = new AxDCEDITLib.AxDcedit();
            this.dced2paytid = new AxDCEDITLib.AxDcedit();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.label38 = new System.Windows.Forms.Label();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.dced67POA = new AxDCEDITLib.AxDcedit();
            this.dcim67bPOA = new AxDCIMAGELib.AxDcimage();
            this.dced67bPOA = new AxDCEDITLib.AxDcedit();
            this.dcim67dPOA = new AxDCIMAGELib.AxDcimage();
            this.dced67dPOA = new AxDCEDITLib.AxDcedit();
            this.dcim67ePOA = new AxDCIMAGELib.AxDcimage();
            this.dced67ePOA = new AxDCEDITLib.AxDcedit();
            this.dcim67fPOA = new AxDCIMAGELib.AxDcimage();
            this.dced67fPOA = new AxDCEDITLib.AxDcedit();
            this.axDcimage6 = new AxDCIMAGELib.AxDcimage();
            this.axDcedit8 = new AxDCEDITLib.AxDcedit();
            this.dcim67hPOA = new AxDCIMAGELib.AxDcimage();
            this.dced67hPOA = new AxDCEDITLib.AxDcedit();
            this.dcim67gPOA = new AxDCIMAGELib.AxDcimage();
            this.dced67gPOA = new AxDCEDITLib.AxDcedit();
            this.dcim67cPOA = new AxDCIMAGELib.AxDcimage();
            this.dced67cPOA = new AxDCEDITLib.AxDcedit();
            this.axDcimage10 = new AxDCIMAGELib.AxDcimage();
            this.axDcedit12 = new AxDCEDITLib.AxDcedit();
            this.axDcimage11 = new AxDCIMAGELib.AxDcimage();
            this.axDcedit13 = new AxDCEDITLib.AxDcedit();
            this.axDcimage12 = new AxDCIMAGELib.AxDcimage();
            this.axDcedit14 = new AxDCEDITLib.AxDcedit();
            this.axDcimage13 = new AxDCIMAGELib.AxDcimage();
            this.axDcedit15 = new AxDCEDITLib.AxDcedit();
            this.axDcimage14 = new AxDCIMAGELib.AxDcimage();
            this.axDcedit16 = new AxDCEDITLib.AxDcedit();
            this.axDcimage15 = new AxDCIMAGELib.AxDcimage();
            this.axDcedit17 = new AxDCEDITLib.AxDcedit();
            this.axDcimage16 = new AxDCIMAGELib.AxDcimage();
            this.axDcedit18 = new AxDCEDITLib.AxDcedit();
            this.dced67aPOA = new AxDCEDITLib.AxDcedit();
            this.dcim67aPOA = new AxDCIMAGELib.AxDcimage();
            this.dcim67POA = new AxDCIMAGELib.AxDcimage();
            this.axDcimage2 = new AxDCIMAGELib.AxDcimage();
            this.axDcedit2 = new AxDCEDITLib.AxDcedit();
            this.label46 = new System.Windows.Forms.Label();
            this.dcim72becicd = new AxDCIMAGELib.AxDcimage();
            this.dced72becicd = new AxDCEDITLib.AxDcedit();
            this.dcim72aPOA = new AxDCIMAGELib.AxDcimage();
            this.dced72aPOA = new AxDCEDITLib.AxDcedit();
            this.dcim72bPOA = new AxDCIMAGELib.AxDcimage();
            this.dced72bPOA = new AxDCEDITLib.AxDcedit();
            this.dcim72cPOA = new AxDCIMAGELib.AxDcimage();
            this.dced72cPOA = new AxDCEDITLib.AxDcedit();
            this.label47 = new System.Windows.Forms.Label();
            this.dcim72cecicd = new AxDCIMAGELib.AxDcimage();
            this.dced72cecicd = new AxDCEDITLib.AxDcedit();
            this.dcim55aetamt = new AxDCIMAGELib.AxDcimage();
            this.dced55aetamt = new AxDCEDITLib.AxDcedit();
            this.dcim55betamt = new AxDCIMAGELib.AxDcimage();
            this.dced55betamt = new AxDCEDITLib.AxDcedit();
            this.label48 = new System.Windows.Forms.Label();
            this.dcim55cetamt = new AxDCIMAGELib.AxDcimage();
            this.dced55cetamt = new AxDCEDITLib.AxDcedit();
            this.dcim54aprpay = new AxDCIMAGELib.AxDcimage();
            this.dced54aprpay = new AxDCEDITLib.AxDcedit();
            this.dcim54bprpay = new AxDCIMAGELib.AxDcimage();
            this.dced54bprpay = new AxDCEDITLib.AxDcedit();
            this.label49 = new System.Windows.Forms.Label();
            this.dcim54cprpay = new AxDCIMAGELib.AxDcimage();
            this.dced54cprpay = new AxDCEDITLib.AxDcedit();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.dcim77opnpi = new AxDCIMAGELib.AxDcimage();
            this.dced77opnpi = new AxDCEDITLib.AxDcedit();
            this.label55 = new System.Windows.Forms.Label();
            this.dcim77opqual = new AxDCIMAGELib.AxDcimage();
            this.dced77opqual = new AxDCEDITLib.AxDcedit();
            this.label56 = new System.Windows.Forms.Label();
            this.dcim77opid = new AxDCIMAGELib.AxDcimage();
            this.dced77opid = new AxDCEDITLib.AxDcedit();
            this.label57 = new System.Windows.Forms.Label();
            this.dcim77oplnm = new AxDCIMAGELib.AxDcimage();
            this.dced77oplnm = new AxDCEDITLib.AxDcedit();
            this.label58 = new System.Windows.Forms.Label();
            this.dcim77opfnm = new AxDCIMAGELib.AxDcimage();
            this.dced77opfnm = new AxDCEDITLib.AxDcedit();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.dcimotnpi = new AxDCIMAGELib.AxDcimage();
            this.dced78otnpi = new AxDCEDITLib.AxDcedit();
            this.label61 = new System.Windows.Forms.Label();
            this.dcim78otql2 = new AxDCIMAGELib.AxDcimage();
            this.dcedotql2 = new AxDCEDITLib.AxDcedit();
            this.label62 = new System.Windows.Forms.Label();
            this.dcim78otid = new AxDCIMAGELib.AxDcimage();
            this.dced78otid = new AxDCEDITLib.AxDcedit();
            this.label63 = new System.Windows.Forms.Label();
            this.dcimotlnm = new AxDCIMAGELib.AxDcimage();
            this.dced78otlnm = new AxDCEDITLib.AxDcedit();
            this.label64 = new System.Windows.Forms.Label();
            this.dcim78otfnm = new AxDCIMAGELib.AxDcimage();
            this.dced78otfnm = new AxDCEDITLib.AxDcedit();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.label65 = new System.Windows.Forms.Label();
            this.dcim78otql1 = new AxDCIMAGELib.AxDcimage();
            this.dced78otql1 = new AxDCEDITLib.AxDcedit();
            this.label66 = new System.Windows.Forms.Label();
            this.dcim79otql1 = new AxDCIMAGELib.AxDcimage();
            this.dced79otql1 = new AxDCEDITLib.AxDcedit();
            this.label67 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.dcim79otnpi = new AxDCIMAGELib.AxDcimage();
            this.dced79otnpi = new AxDCEDITLib.AxDcedit();
            this.label69 = new System.Windows.Forms.Label();
            this.dcim79otql2 = new AxDCIMAGELib.AxDcimage();
            this.dced79otql2 = new AxDCEDITLib.AxDcedit();
            this.label70 = new System.Windows.Forms.Label();
            this.dcim79otid = new AxDCIMAGELib.AxDcimage();
            this.dced79otid = new AxDCEDITLib.AxDcedit();
            this.label71 = new System.Windows.Forms.Label();
            this.dcim79otlnm = new AxDCIMAGELib.AxDcimage();
            this.dced79otlnm = new AxDCEDITLib.AxDcedit();
            this.label72 = new System.Windows.Forms.Label();
            this.dcim79otfnm = new AxDCIMAGELib.AxDcimage();
            this.dced79otfnm = new AxDCEDITLib.AxDcedit();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.label73 = new System.Windows.Forms.Label();
            this.dcim57copidt = new AxDCIMAGELib.AxDcimage();
            this.dced57copidt = new AxDCEDITLib.AxDcedit();
            this.label74 = new System.Windows.Forms.Label();
            this.dcim57aopidp = new AxDCIMAGELib.AxDcimage();
            this.dced57aopidp = new AxDCEDITLib.AxDcedit();
            this.label75 = new System.Windows.Forms.Label();
            this.dcim57bopids = new AxDCIMAGELib.AxDcimage();
            this.dced57bopids = new AxDCEDITLib.AxDcedit();
            this.dcim80aremrk = new AxDCIMAGELib.AxDcimage();
            this.dced80aremrk = new AxDCEDITLib.AxDcedit();
            this.dcim80bremrk = new AxDCIMAGELib.AxDcimage();
            this.dced80bremrk = new AxDCEDITLib.AxDcedit();
            this.dcim80cremrk = new AxDCIMAGELib.AxDcimage();
            this.dced80cremrk = new AxDCEDITLib.AxDcedit();
            this.dcim80dremrk = new AxDCIMAGELib.AxDcimage();
            this.dced80dremrk = new AxDCEDITLib.AxDcedit();
            this.label76 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dcim1fcynmad)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced1provnam)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced1provadd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced1provcit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced1provsta)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim3apctlnm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced3apctlnm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim3bmdrcnm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced3bmdrcnm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim4typbill)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced4typbill)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim5fedtxnm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced5fedtxnm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim6scpfrom)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced6scpfrom)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim6scpthru)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced6scpthru)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim8ptnmid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced8ptnmid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim8ptnm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced8plname)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced8pfname)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced8pminit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim9paddstr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced9paddstr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim9paddcty)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced9paddcty)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim9paddsta)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced9paddsta)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim9paddzip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced9paddzip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim9paddccd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced9paddccd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim10pbdate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced10pbdate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim11psex)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced11psex)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim12admdte)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced12admdte)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim13admhr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced13admhr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim14admtyp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced14admtyp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim16dhr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced16dhr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim17stat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced17stat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim31aocrcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced31aocrcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim31aocrdt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced31aocrdt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim31bocrcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced31bocrcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim31bocrdt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced31bocrdt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim32aocrcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced32aocrcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim32aocrdt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced32aocrdt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim32bocrcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced32bocrcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim32bocrdt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced32bocrdt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim36aospcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced36aospcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim36aospfr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced36aospfr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim36aospth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced36aospth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim36bospcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced36bospcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim36bospfr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced36bospfr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim36bospth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced36bospth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim39avlcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced39avlcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim39avlamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced39avlamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim39bvlcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced39bvlcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim39bvlamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced39bvlamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim39cvlcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced39cvlcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim39cvlamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced39cvlamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim39dvlcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced39dvlcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim39dvlamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced39dvlamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim40avlcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced40avlcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim40avlamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced40avlamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim40bvlcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced40bvlcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim40bvlamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced40bvlamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim40cvlcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced40cvlcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim40cvlamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced40cvlamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim40dvlcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced40dvlcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim40dvlamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced40dvlamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim41avlcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced41avlcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim41avlamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced41avlamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim41bvlcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced41bvlcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim41bvlamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced41bvlamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim41cvlcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced41cvlcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim41cvlamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced41cvlamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim41dvlcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced41dvlcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim41dvlamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced41dvlamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced1provzip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim50apayer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced50apayer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim50bpayer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced50bpayer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim50cpayer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced50cpayer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim51aprvno)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced51aprvno)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim51bprvno)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced51bprvno)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim51cprvno)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced51cprvno)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim56npi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced56npi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim58ainsnm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced58alname)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced58afname)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced58aminit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim58binsnm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced58blname)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced58bfname)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced58bminit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim58cinsnm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced58clname)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced58cfname)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced58cminit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim60acshi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced60acshi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim60bcshi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced60bcshi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim60ccshi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced60ccshi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim66dxverq)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced66dxverq)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67prdgcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67prdgcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67aothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67aothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67bothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67bothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67cothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67cothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67dothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67dothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67eothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67eothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67fothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67fothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67gothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67gothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67hothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67hothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67iothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67iothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67jothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67jothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67kothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67kothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67lothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67lothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67mothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67mothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67nothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67nothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67oothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67oothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67pothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67pothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67qothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67qothdg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim69amdgcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced69amdgcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim70arfvcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced70arfvcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim70brfvcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced70brfvcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim70crfvcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced70crfvcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim71ppscd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced71ppscd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim72aecicd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced72aecicd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim23TotChgs)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced23TotChgs)).BeginInit();
            this.panLINEITEM.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dcimNDCType)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedNDCType)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimNDCQty)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedNDCQty)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimRevCode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedRevCode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimDescription)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedDescription)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimHCPCS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedHCPCS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimServiceDate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedServiceDate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimUnits)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedUnits)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimCharges)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedCharges)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimNonCovered)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedNonCovered)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimNDC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedNDC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim74prprcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced74prprcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim74prprdt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced74prprdt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim74aoprcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced74aoprcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim74aoprdt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced74aoprdt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim74boprcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced74boprcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim74boprdt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced74boprdt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim74coprcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced74coprcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim74coprdt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced74coprdt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim74doprcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced74doprcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim74doprdt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced74doprdt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim74eoprcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced74eoprcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim74eoprdt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced74eoprdt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim76apnpi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced76apnpi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim76apqual)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced76apqual)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim76apid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced76apid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim76aplnm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced76aplnm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim76apfnm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced76apfnm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim33aocrcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced33aocrcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim33aocrdt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced33aocrdt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim33bocrcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced33bocrcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim33bocrdt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced33bocrdt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim34aocrcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced34aocrcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim34aocrdt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced34aocrdt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim34bocrcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced34bocrcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim34bocrdt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced34bocrdt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim35aospcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced35aospcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim35aospfr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced35aospfr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim35aospth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced35aospth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim35bospcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced35bospcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim35bospfr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced35bospfr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim35bospth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced35bospth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim2payto)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced2paytnm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced2paytadd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced2paytcty)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced2paytst)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced2paytzip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim18concd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced18concd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axDcimage1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axDcedit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim20concd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced20concd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim19concd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced19concd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim21concd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced21concd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim23concd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced23concd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim24concd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced24concd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim25concd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced25concd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim26concd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced26concd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim22concd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced22concd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim27concd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced27concd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim28concd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced28concd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced2paytid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67POA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67bPOA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67bPOA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67dPOA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67dPOA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67ePOA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67ePOA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67fPOA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67fPOA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axDcimage6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axDcedit8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67hPOA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67hPOA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67gPOA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67gPOA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67cPOA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67cPOA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axDcimage10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axDcedit12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axDcimage11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axDcedit13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axDcimage12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axDcedit14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axDcimage13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axDcedit15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axDcimage14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axDcedit16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axDcimage15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axDcedit17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axDcimage16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axDcedit18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67aPOA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67aPOA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67POA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axDcimage2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axDcedit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim72becicd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced72becicd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim72aPOA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced72aPOA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim72bPOA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced72bPOA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim72cPOA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced72cPOA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim72cecicd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced72cecicd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim55aetamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced55aetamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim55betamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced55betamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim55cetamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced55cetamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim54aprpay)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced54aprpay)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim54bprpay)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced54bprpay)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim54cprpay)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced54cprpay)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim77opnpi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced77opnpi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim77opqual)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced77opqual)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim77opid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced77opid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim77oplnm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced77oplnm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim77opfnm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced77opfnm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimotnpi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced78otnpi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim78otql2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedotql2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim78otid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced78otid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimotlnm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced78otlnm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim78otfnm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced78otfnm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim78otql1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced78otql1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim79otql1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced79otql1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim79otnpi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced79otnpi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim79otql2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced79otql2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim79otid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced79otid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim79otlnm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced79otlnm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim79otfnm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced79otfnm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim57copidt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced57copidt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim57aopidp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced57aopidp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim57bopids)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced57bopids)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim80aremrk)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced80aremrk)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim80bremrk)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced80bremrk)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim80cremrk)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced80cremrk)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim80dremrk)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced80dremrk)).BeginInit();
            this.SuspendLayout();
            // 
            // dcim1fcynmad
            // 
            this.dcim1fcynmad.Location = new System.Drawing.Point(34, 30);
            this.dcim1fcynmad.Name = "dcim1fcynmad";
            this.dcim1fcynmad.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim1fcynmad.OcxState")));
            this.dcim1fcynmad.Size = new System.Drawing.Size(270, 72);
            this.dcim1fcynmad.TabIndex = 1;
            this.dcim1fcynmad.TabStop = false;
            this.dcim1fcynmad.Tag = "1fcynmad";
            // 
            // lbl1provnam
            // 
            this.lbl1provnam.AutoSize = true;
            this.lbl1provnam.BackColor = System.Drawing.Color.Lavender;
            this.lbl1provnam.Location = new System.Drawing.Point(33, 16);
            this.lbl1provnam.Name = "lbl1provnam";
            this.lbl1provnam.Size = new System.Drawing.Size(89, 13);
            this.lbl1provnam.TabIndex = 714;
            this.lbl1provnam.Tag = "1provnam";
            this.lbl1provnam.Text = "1 Facility Address";
            // 
            // dced1provnam
            // 
            this.dced1provnam.Location = new System.Drawing.Point(34, 118);
            this.dced1provnam.Name = "dced1provnam";
            this.dced1provnam.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced1provnam.OcxState")));
            this.dced1provnam.Size = new System.Drawing.Size(270, 18);
            this.dced1provnam.TabIndex = 2;
            this.dced1provnam.Tag = "1provnam";
            // 
            // dced1provadd
            // 
            this.dced1provadd.Location = new System.Drawing.Point(34, 154);
            this.dced1provadd.Name = "dced1provadd";
            this.dced1provadd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced1provadd.OcxState")));
            this.dced1provadd.Size = new System.Drawing.Size(270, 18);
            this.dced1provadd.TabIndex = 3;
            this.dced1provadd.Tag = "1provadd";
            // 
            // dced1provcit
            // 
            this.dced1provcit.Location = new System.Drawing.Point(34, 190);
            this.dced1provcit.Name = "dced1provcit";
            this.dced1provcit.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced1provcit.OcxState")));
            this.dced1provcit.Size = new System.Drawing.Size(270, 18);
            this.dced1provcit.TabIndex = 4;
            this.dced1provcit.Tag = "1provcit";
            // 
            // dced1provsta
            // 
            this.dced1provsta.Location = new System.Drawing.Point(34, 224);
            this.dced1provsta.Name = "dced1provsta";
            this.dced1provsta.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced1provsta.OcxState")));
            this.dced1provsta.Size = new System.Drawing.Size(176, 18);
            this.dced1provsta.TabIndex = 5;
            this.dced1provsta.Tag = "1provsta";
            // 
            // lbl3apctlnm
            // 
            this.lbl3apctlnm.AutoSize = true;
            this.lbl3apctlnm.Location = new System.Drawing.Point(612, 11);
            this.lbl3apctlnm.Name = "lbl3apctlnm";
            this.lbl3apctlnm.Size = new System.Drawing.Size(83, 13);
            this.lbl3apctlnm.TabIndex = 724;
            this.lbl3apctlnm.Tag = "3apctlnm";
            this.lbl3apctlnm.Text = "3a Patient Ctrl #";
            // 
            // dcim3apctlnm
            // 
            this.dcim3apctlnm.Location = new System.Drawing.Point(613, 24);
            this.dcim3apctlnm.Name = "dcim3apctlnm";
            this.dcim3apctlnm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim3apctlnm.OcxState")));
            this.dcim3apctlnm.Size = new System.Drawing.Size(202, 18);
            this.dcim3apctlnm.TabIndex = 725;
            this.dcim3apctlnm.TabStop = false;
            this.dcim3apctlnm.Tag = "3apctlnm";
            // 
            // dced3apctlnm
            // 
            this.dced3apctlnm.Location = new System.Drawing.Point(613, 43);
            this.dced3apctlnm.Name = "dced3apctlnm";
            this.dced3apctlnm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced3apctlnm.OcxState")));
            this.dced3apctlnm.Size = new System.Drawing.Size(202, 18);
            this.dced3apctlnm.TabIndex = 14;
            this.dced3apctlnm.Tag = "3apctlnm";
            // 
            // lbl3bmdrcnm
            // 
            this.lbl3bmdrcnm.AutoSize = true;
            this.lbl3bmdrcnm.Location = new System.Drawing.Point(612, 63);
            this.lbl3bmdrcnm.Name = "lbl3bmdrcnm";
            this.lbl3bmdrcnm.Size = new System.Drawing.Size(94, 13);
            this.lbl3bmdrcnm.TabIndex = 727;
            this.lbl3bmdrcnm.Tag = "3bmdrcnm";
            this.lbl3bmdrcnm.Text = "3b Med. Record #";
            // 
            // dcim3bmdrcnm
            // 
            this.dcim3bmdrcnm.Location = new System.Drawing.Point(613, 76);
            this.dcim3bmdrcnm.Name = "dcim3bmdrcnm";
            this.dcim3bmdrcnm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim3bmdrcnm.OcxState")));
            this.dcim3bmdrcnm.Size = new System.Drawing.Size(219, 18);
            this.dcim3bmdrcnm.TabIndex = 728;
            this.dcim3bmdrcnm.TabStop = false;
            this.dcim3bmdrcnm.Tag = "3bmdrcnm";
            // 
            // dced3bmdrcnm
            // 
            this.dced3bmdrcnm.Location = new System.Drawing.Point(613, 95);
            this.dced3bmdrcnm.Name = "dced3bmdrcnm";
            this.dced3bmdrcnm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced3bmdrcnm.OcxState")));
            this.dced3bmdrcnm.Size = new System.Drawing.Size(219, 18);
            this.dced3bmdrcnm.TabIndex = 15;
            this.dced3bmdrcnm.Tag = "3bmdrcnm";
            // 
            // lbl4typbill
            // 
            this.lbl4typbill.AutoSize = true;
            this.lbl4typbill.Location = new System.Drawing.Point(823, 11);
            this.lbl4typbill.Name = "lbl4typbill";
            this.lbl4typbill.Size = new System.Drawing.Size(56, 13);
            this.lbl4typbill.TabIndex = 730;
            this.lbl4typbill.Tag = "4typbill";
            this.lbl4typbill.Text = "4 Bill Type";
            // 
            // dcim4typbill
            // 
            this.dcim4typbill.Location = new System.Drawing.Point(827, 24);
            this.dcim4typbill.Name = "dcim4typbill";
            this.dcim4typbill.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim4typbill.OcxState")));
            this.dcim4typbill.Size = new System.Drawing.Size(50, 18);
            this.dcim4typbill.TabIndex = 731;
            this.dcim4typbill.TabStop = false;
            this.dcim4typbill.Tag = "4typbill";
            // 
            // dced4typbill
            // 
            this.dced4typbill.Location = new System.Drawing.Point(827, 43);
            this.dced4typbill.Name = "dced4typbill";
            this.dced4typbill.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced4typbill.OcxState")));
            this.dced4typbill.Size = new System.Drawing.Size(50, 18);
            this.dced4typbill.TabIndex = 16;
            this.dced4typbill.Tag = "4typbill";
            // 
            // lbl5fedtxnm
            // 
            this.lbl5fedtxnm.AutoSize = true;
            this.lbl5fedtxnm.Location = new System.Drawing.Point(890, 11);
            this.lbl5fedtxnm.Name = "lbl5fedtxnm";
            this.lbl5fedtxnm.Size = new System.Drawing.Size(78, 13);
            this.lbl5fedtxnm.TabIndex = 733;
            this.lbl5fedtxnm.Tag = "5fedtxnm";
            this.lbl5fedtxnm.Text = "5 Fed. Tax No.";
            // 
            // dcim5fedtxnm
            // 
            this.dcim5fedtxnm.Location = new System.Drawing.Point(888, 24);
            this.dcim5fedtxnm.Name = "dcim5fedtxnm";
            this.dcim5fedtxnm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim5fedtxnm.OcxState")));
            this.dcim5fedtxnm.Size = new System.Drawing.Size(109, 18);
            this.dcim5fedtxnm.TabIndex = 734;
            this.dcim5fedtxnm.TabStop = false;
            this.dcim5fedtxnm.Tag = "5fedtxnm";
            // 
            // dced5fedtxnm
            // 
            this.dced5fedtxnm.Location = new System.Drawing.Point(888, 43);
            this.dced5fedtxnm.Name = "dced5fedtxnm";
            this.dced5fedtxnm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced5fedtxnm.OcxState")));
            this.dced5fedtxnm.Size = new System.Drawing.Size(109, 18);
            this.dced5fedtxnm.TabIndex = 17;
            this.dced5fedtxnm.Tag = "5fedtxnm";
            // 
            // lbl6scpfrom
            // 
            this.lbl6scpfrom.AutoSize = true;
            this.lbl6scpfrom.Location = new System.Drawing.Point(850, 63);
            this.lbl6scpfrom.Name = "lbl6scpfrom";
            this.lbl6scpfrom.Size = new System.Drawing.Size(141, 13);
            this.lbl6scpfrom.TabIndex = 736;
            this.lbl6scpfrom.Tag = "6scpfrom";
            this.lbl6scpfrom.Text = "6 Stmt Period From/Through";
            // 
            // dcim6scpfrom
            // 
            this.dcim6scpfrom.Location = new System.Drawing.Point(851, 76);
            this.dcim6scpfrom.Name = "dcim6scpfrom";
            this.dcim6scpfrom.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim6scpfrom.OcxState")));
            this.dcim6scpfrom.Size = new System.Drawing.Size(73, 18);
            this.dcim6scpfrom.TabIndex = 737;
            this.dcim6scpfrom.TabStop = false;
            this.dcim6scpfrom.Tag = "6scpfrom";
            // 
            // dced6scpfrom
            // 
            this.dced6scpfrom.Location = new System.Drawing.Point(851, 95);
            this.dced6scpfrom.Name = "dced6scpfrom";
            this.dced6scpfrom.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced6scpfrom.OcxState")));
            this.dced6scpfrom.Size = new System.Drawing.Size(73, 18);
            this.dced6scpfrom.TabIndex = 18;
            this.dced6scpfrom.Tag = "6scpfrom";
            // 
            // dcim6scpthru
            // 
            this.dcim6scpthru.Location = new System.Drawing.Point(924, 76);
            this.dcim6scpthru.Name = "dcim6scpthru";
            this.dcim6scpthru.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim6scpthru.OcxState")));
            this.dcim6scpthru.Size = new System.Drawing.Size(73, 18);
            this.dcim6scpthru.TabIndex = 739;
            this.dcim6scpthru.TabStop = false;
            this.dcim6scpthru.Tag = "6scpthru";
            // 
            // dced6scpthru
            // 
            this.dced6scpthru.Location = new System.Drawing.Point(924, 95);
            this.dced6scpthru.Name = "dced6scpthru";
            this.dced6scpthru.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced6scpthru.OcxState")));
            this.dced6scpthru.Size = new System.Drawing.Size(73, 18);
            this.dced6scpthru.TabIndex = 19;
            this.dced6scpthru.Tag = "6scpthru";
            // 
            // lbl8ptnmid
            // 
            this.lbl8ptnmid.AutoSize = true;
            this.lbl8ptnmid.Location = new System.Drawing.Point(29, 257);
            this.lbl8ptnmid.Name = "lbl8ptnmid";
            this.lbl8ptnmid.Size = new System.Drawing.Size(69, 13);
            this.lbl8ptnmid.TabIndex = 741;
            this.lbl8ptnmid.Tag = "8ptnmid";
            this.lbl8ptnmid.Text = "8a Patient ID";
            // 
            // dcim8ptnmid
            // 
            this.dcim8ptnmid.Location = new System.Drawing.Point(28, 270);
            this.dcim8ptnmid.Name = "dcim8ptnmid";
            this.dcim8ptnmid.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim8ptnmid.OcxState")));
            this.dcim8ptnmid.Size = new System.Drawing.Size(122, 18);
            this.dcim8ptnmid.TabIndex = 742;
            this.dcim8ptnmid.TabStop = false;
            this.dcim8ptnmid.Tag = "8ptnmid";
            // 
            // dced8ptnmid
            // 
            this.dced8ptnmid.Location = new System.Drawing.Point(28, 289);
            this.dced8ptnmid.Name = "dced8ptnmid";
            this.dced8ptnmid.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced8ptnmid.OcxState")));
            this.dced8ptnmid.Size = new System.Drawing.Size(122, 18);
            this.dced8ptnmid.TabIndex = 23;
            this.dced8ptnmid.Tag = "8ptnmid";
            // 
            // lbl8ptnm
            // 
            this.lbl8ptnm.AutoSize = true;
            this.lbl8ptnm.BackColor = System.Drawing.Color.Lavender;
            this.lbl8ptnm.Location = new System.Drawing.Point(621, 122);
            this.lbl8ptnm.Name = "lbl8ptnm";
            this.lbl8ptnm.Size = new System.Drawing.Size(80, 13);
            this.lbl8ptnm.TabIndex = 744;
            this.lbl8ptnm.Tag = "8ptnm";
            this.lbl8ptnm.Text = "8 Patient Name";
            // 
            // dcim8ptnm
            // 
            this.dcim8ptnm.Location = new System.Drawing.Point(623, 135);
            this.dcim8ptnm.Name = "dcim8ptnm";
            this.dcim8ptnm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim8ptnm.OcxState")));
            this.dcim8ptnm.Size = new System.Drawing.Size(366, 18);
            this.dcim8ptnm.TabIndex = 745;
            this.dcim8ptnm.TabStop = false;
            this.dcim8ptnm.Tag = "8ptnm";
            // 
            // dced8plname
            // 
            this.dced8plname.Location = new System.Drawing.Point(623, 166);
            this.dced8plname.Name = "dced8plname";
            this.dced8plname.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced8plname.OcxState")));
            this.dced8plname.Size = new System.Drawing.Size(187, 18);
            this.dced8plname.TabIndex = 20;
            this.dced8plname.Tag = "8plname";
            // 
            // dced8pfname
            // 
            this.dced8pfname.Location = new System.Drawing.Point(816, 166);
            this.dced8pfname.Name = "dced8pfname";
            this.dced8pfname.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced8pfname.OcxState")));
            this.dced8pfname.Size = new System.Drawing.Size(141, 18);
            this.dced8pfname.TabIndex = 21;
            this.dced8pfname.Tag = "8pfname";
            // 
            // dced8pminit
            // 
            this.dced8pminit.Location = new System.Drawing.Point(963, 166);
            this.dced8pminit.Name = "dced8pminit";
            this.dced8pminit.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced8pminit.OcxState")));
            this.dced8pminit.Size = new System.Drawing.Size(26, 18);
            this.dced8pminit.TabIndex = 22;
            this.dced8pminit.Tag = "8pminit";
            // 
            // dcim9paddstr
            // 
            this.dcim9paddstr.Location = new System.Drawing.Point(621, 212);
            this.dcim9paddstr.Name = "dcim9paddstr";
            this.dcim9paddstr.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim9paddstr.OcxState")));
            this.dcim9paddstr.Size = new System.Drawing.Size(263, 18);
            this.dcim9paddstr.TabIndex = 753;
            this.dcim9paddstr.TabStop = false;
            this.dcim9paddstr.Tag = "9paddstr";
            // 
            // dced9paddstr
            // 
            this.dced9paddstr.Location = new System.Drawing.Point(621, 231);
            this.dced9paddstr.Name = "dced9paddstr";
            this.dced9paddstr.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced9paddstr.OcxState")));
            this.dced9paddstr.Size = new System.Drawing.Size(263, 18);
            this.dced9paddstr.TabIndex = 26;
            this.dced9paddstr.Tag = "9paddstr";
            // 
            // dcim9paddcty
            // 
            this.dcim9paddcty.Location = new System.Drawing.Point(621, 264);
            this.dcim9paddcty.Name = "dcim9paddcty";
            this.dcim9paddcty.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim9paddcty.OcxState")));
            this.dcim9paddcty.Size = new System.Drawing.Size(211, 18);
            this.dcim9paddcty.TabIndex = 756;
            this.dcim9paddcty.TabStop = false;
            this.dcim9paddcty.Tag = "9paddcty";
            // 
            // dced9paddcty
            // 
            this.dced9paddcty.Location = new System.Drawing.Point(621, 283);
            this.dced9paddcty.Name = "dced9paddcty";
            this.dced9paddcty.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced9paddcty.OcxState")));
            this.dced9paddcty.Size = new System.Drawing.Size(211, 18);
            this.dced9paddcty.TabIndex = 27;
            this.dced9paddcty.Tag = "9paddcty";
            // 
            // dcim9paddsta
            // 
            this.dcim9paddsta.Location = new System.Drawing.Point(836, 264);
            this.dcim9paddsta.Name = "dcim9paddsta";
            this.dcim9paddsta.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim9paddsta.OcxState")));
            this.dcim9paddsta.Size = new System.Drawing.Size(48, 18);
            this.dcim9paddsta.TabIndex = 759;
            this.dcim9paddsta.TabStop = false;
            this.dcim9paddsta.Tag = "9paddsta";
            // 
            // dced9paddsta
            // 
            this.dced9paddsta.Location = new System.Drawing.Point(836, 283);
            this.dced9paddsta.Name = "dced9paddsta";
            this.dced9paddsta.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced9paddsta.OcxState")));
            this.dced9paddsta.Size = new System.Drawing.Size(48, 18);
            this.dced9paddsta.TabIndex = 28;
            this.dced9paddsta.Tag = "9paddsta";
            // 
            // dcim9paddzip
            // 
            this.dcim9paddzip.Location = new System.Drawing.Point(888, 264);
            this.dcim9paddzip.Name = "dcim9paddzip";
            this.dcim9paddzip.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim9paddzip.OcxState")));
            this.dcim9paddzip.Size = new System.Drawing.Size(103, 18);
            this.dcim9paddzip.TabIndex = 762;
            this.dcim9paddzip.TabStop = false;
            this.dcim9paddzip.Tag = "9paddzip";
            // 
            // dced9paddzip
            // 
            this.dced9paddzip.Location = new System.Drawing.Point(888, 283);
            this.dced9paddzip.Name = "dced9paddzip";
            this.dced9paddzip.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced9paddzip.OcxState")));
            this.dced9paddzip.Size = new System.Drawing.Size(103, 18);
            this.dced9paddzip.TabIndex = 29;
            this.dced9paddzip.Tag = "9paddzip";
            // 
            // dcim9paddccd
            // 
            this.dcim9paddccd.Location = new System.Drawing.Point(941, 212);
            this.dcim9paddccd.Name = "dcim9paddccd";
            this.dcim9paddccd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim9paddccd.OcxState")));
            this.dcim9paddccd.Size = new System.Drawing.Size(50, 18);
            this.dcim9paddccd.TabIndex = 765;
            this.dcim9paddccd.TabStop = false;
            this.dcim9paddccd.Tag = "9paddccd";
            // 
            // dced9paddccd
            // 
            this.dced9paddccd.Location = new System.Drawing.Point(941, 231);
            this.dced9paddccd.Name = "dced9paddccd";
            this.dced9paddccd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced9paddccd.OcxState")));
            this.dced9paddccd.Size = new System.Drawing.Size(50, 18);
            this.dced9paddccd.TabIndex = 30;
            this.dced9paddccd.Tag = "9paddccd";
            // 
            // lbl10pbdate
            // 
            this.lbl10pbdate.AutoSize = true;
            this.lbl10pbdate.Location = new System.Drawing.Point(153, 257);
            this.lbl10pbdate.Name = "lbl10pbdate";
            this.lbl10pbdate.Size = new System.Drawing.Size(64, 13);
            this.lbl10pbdate.TabIndex = 767;
            this.lbl10pbdate.Tag = "10pbdate";
            this.lbl10pbdate.Text = "10 Birthdate";
            // 
            // dcim10pbdate
            // 
            this.dcim10pbdate.Location = new System.Drawing.Point(156, 270);
            this.dcim10pbdate.Name = "dcim10pbdate";
            this.dcim10pbdate.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim10pbdate.OcxState")));
            this.dcim10pbdate.Size = new System.Drawing.Size(73, 18);
            this.dcim10pbdate.TabIndex = 768;
            this.dcim10pbdate.TabStop = false;
            this.dcim10pbdate.Tag = "10pbdate";
            // 
            // dced10pbdate
            // 
            this.dced10pbdate.Location = new System.Drawing.Point(156, 289);
            this.dced10pbdate.Name = "dced10pbdate";
            this.dced10pbdate.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced10pbdate.OcxState")));
            this.dced10pbdate.Size = new System.Drawing.Size(73, 18);
            this.dced10pbdate.TabIndex = 24;
            this.dced10pbdate.Tag = "10pbdate";
            // 
            // lbl11psex
            // 
            this.lbl11psex.AutoSize = true;
            this.lbl11psex.Location = new System.Drawing.Point(233, 257);
            this.lbl11psex.Name = "lbl11psex";
            this.lbl11psex.Size = new System.Drawing.Size(40, 13);
            this.lbl11psex.TabIndex = 770;
            this.lbl11psex.Tag = "11psex";
            this.lbl11psex.Text = "11 Sex";
            // 
            // dcim11psex
            // 
            this.dcim11psex.Location = new System.Drawing.Point(236, 270);
            this.dcim11psex.Name = "dcim11psex";
            this.dcim11psex.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim11psex.OcxState")));
            this.dcim11psex.Size = new System.Drawing.Size(44, 18);
            this.dcim11psex.TabIndex = 771;
            this.dcim11psex.TabStop = false;
            this.dcim11psex.Tag = "11psex";
            // 
            // dced11psex
            // 
            this.dced11psex.Location = new System.Drawing.Point(236, 289);
            this.dced11psex.Name = "dced11psex";
            this.dced11psex.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced11psex.OcxState")));
            this.dced11psex.Size = new System.Drawing.Size(44, 18);
            this.dced11psex.TabIndex = 25;
            this.dced11psex.Tag = "11psex";
            // 
            // lbl12admdte
            // 
            this.lbl12admdte.AutoSize = true;
            this.lbl12admdte.BackColor = System.Drawing.Color.Lavender;
            this.lbl12admdte.Location = new System.Drawing.Point(84, 321);
            this.lbl12admdte.Name = "lbl12admdte";
            this.lbl12admdte.Size = new System.Drawing.Size(45, 13);
            this.lbl12admdte.TabIndex = 773;
            this.lbl12admdte.Tag = "12admdte";
            this.lbl12admdte.Text = "12 Date";
            // 
            // dcim12admdte
            // 
            this.dcim12admdte.Location = new System.Drawing.Point(87, 334);
            this.dcim12admdte.Name = "dcim12admdte";
            this.dcim12admdte.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim12admdte.OcxState")));
            this.dcim12admdte.Size = new System.Drawing.Size(73, 18);
            this.dcim12admdte.TabIndex = 774;
            this.dcim12admdte.TabStop = false;
            this.dcim12admdte.Tag = "12admdte";
            // 
            // dced12admdte
            // 
            this.dced12admdte.Location = new System.Drawing.Point(87, 353);
            this.dced12admdte.Name = "dced12admdte";
            this.dced12admdte.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced12admdte.OcxState")));
            this.dced12admdte.Size = new System.Drawing.Size(73, 18);
            this.dced12admdte.TabIndex = 31;
            this.dced12admdte.Tag = "12admdte";
            // 
            // lbl13admhr
            // 
            this.lbl13admhr.AutoSize = true;
            this.lbl13admhr.BackColor = System.Drawing.Color.Lavender;
            this.lbl13admhr.Location = new System.Drawing.Point(208, 321);
            this.lbl13admhr.Name = "lbl13admhr";
            this.lbl13admhr.Size = new System.Drawing.Size(50, 13);
            this.lbl13admhr.TabIndex = 779;
            this.lbl13admhr.Tag = "13admhr";
            this.lbl13admhr.Text = "14 TYPE";
            // 
            // dcim13admhr
            // 
            this.dcim13admhr.Location = new System.Drawing.Point(164, 334);
            this.dcim13admhr.Name = "dcim13admhr";
            this.dcim13admhr.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim13admhr.OcxState")));
            this.dcim13admhr.Size = new System.Drawing.Size(44, 18);
            this.dcim13admhr.TabIndex = 777;
            this.dcim13admhr.TabStop = false;
            this.dcim13admhr.Tag = "13admhr";
            // 
            // dced13admhr
            // 
            this.dced13admhr.Location = new System.Drawing.Point(164, 353);
            this.dced13admhr.Name = "dced13admhr";
            this.dced13admhr.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced13admhr.OcxState")));
            this.dced13admhr.Size = new System.Drawing.Size(44, 18);
            this.dced13admhr.TabIndex = 32;
            this.dced13admhr.Tag = "13admhr";
            // 
            // lbl14admtyp
            // 
            this.lbl14admtyp.AutoSize = true;
            this.lbl14admtyp.BackColor = System.Drawing.Color.Lavender;
            this.lbl14admtyp.Location = new System.Drawing.Point(161, 321);
            this.lbl14admtyp.Name = "lbl14admtyp";
            this.lbl14admtyp.Size = new System.Drawing.Size(38, 13);
            this.lbl14admtyp.TabIndex = 776;
            this.lbl14admtyp.Tag = "14admtyp";
            this.lbl14admtyp.Text = "13 HR";
            // 
            // dcim14admtyp
            // 
            this.dcim14admtyp.Location = new System.Drawing.Point(212, 334);
            this.dcim14admtyp.Name = "dcim14admtyp";
            this.dcim14admtyp.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim14admtyp.OcxState")));
            this.dcim14admtyp.Size = new System.Drawing.Size(44, 18);
            this.dcim14admtyp.TabIndex = 780;
            this.dcim14admtyp.TabStop = false;
            this.dcim14admtyp.Tag = "14admtyp";
            // 
            // dced14admtyp
            // 
            this.dced14admtyp.Location = new System.Drawing.Point(212, 353);
            this.dced14admtyp.Name = "dced14admtyp";
            this.dced14admtyp.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced14admtyp.OcxState")));
            this.dced14admtyp.Size = new System.Drawing.Size(44, 18);
            this.dced14admtyp.TabIndex = 33;
            this.dced14admtyp.Tag = "14admtyp";
            // 
            // lbl16dhr
            // 
            this.lbl16dhr.AutoSize = true;
            this.lbl16dhr.BackColor = System.Drawing.Color.Lavender;
            this.lbl16dhr.Location = new System.Drawing.Point(258, 321);
            this.lbl16dhr.Name = "lbl16dhr";
            this.lbl16dhr.Size = new System.Drawing.Size(46, 13);
            this.lbl16dhr.TabIndex = 782;
            this.lbl16dhr.Tag = "16dhr";
            this.lbl16dhr.Text = "16 DHR";
            // 
            // dcim16dhr
            // 
            this.dcim16dhr.Location = new System.Drawing.Point(261, 334);
            this.dcim16dhr.Name = "dcim16dhr";
            this.dcim16dhr.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim16dhr.OcxState")));
            this.dcim16dhr.Size = new System.Drawing.Size(44, 18);
            this.dcim16dhr.TabIndex = 783;
            this.dcim16dhr.TabStop = false;
            this.dcim16dhr.Tag = "16dhr";
            // 
            // dced16dhr
            // 
            this.dced16dhr.Location = new System.Drawing.Point(261, 353);
            this.dced16dhr.Name = "dced16dhr";
            this.dced16dhr.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced16dhr.OcxState")));
            this.dced16dhr.Size = new System.Drawing.Size(44, 18);
            this.dced16dhr.TabIndex = 34;
            this.dced16dhr.Tag = "16dhr";
            // 
            // lbl17stat
            // 
            this.lbl17stat.AutoSize = true;
            this.lbl17stat.BackColor = System.Drawing.Color.Lavender;
            this.lbl17stat.Location = new System.Drawing.Point(307, 321);
            this.lbl17stat.Name = "lbl17stat";
            this.lbl17stat.Size = new System.Drawing.Size(50, 13);
            this.lbl17stat.TabIndex = 785;
            this.lbl17stat.Tag = "17stat";
            this.lbl17stat.Text = "17 STAT";
            // 
            // dcim17stat
            // 
            this.dcim17stat.Location = new System.Drawing.Point(310, 334);
            this.dcim17stat.Name = "dcim17stat";
            this.dcim17stat.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim17stat.OcxState")));
            this.dcim17stat.Size = new System.Drawing.Size(44, 18);
            this.dcim17stat.TabIndex = 786;
            this.dcim17stat.TabStop = false;
            this.dcim17stat.Tag = "17stat";
            // 
            // dced17stat
            // 
            this.dced17stat.Location = new System.Drawing.Point(310, 353);
            this.dced17stat.Name = "dced17stat";
            this.dced17stat.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced17stat.OcxState")));
            this.dced17stat.Size = new System.Drawing.Size(44, 18);
            this.dced17stat.TabIndex = 35;
            this.dced17stat.Tag = "17stat";
            // 
            // lbl31aocrcd
            // 
            this.lbl31aocrcd.AutoSize = true;
            this.lbl31aocrcd.Location = new System.Drawing.Point(25, 379);
            this.lbl31aocrcd.Name = "lbl31aocrcd";
            this.lbl31aocrcd.Size = new System.Drawing.Size(134, 13);
            this.lbl31aocrcd.TabIndex = 788;
            this.lbl31aocrcd.Tag = "31aocrcd";
            this.lbl31aocrcd.Text = "31 Occurrence Code/Date";
            // 
            // dcim31aocrcd
            // 
            this.dcim31aocrcd.Location = new System.Drawing.Point(28, 394);
            this.dcim31aocrcd.Name = "dcim31aocrcd";
            this.dcim31aocrcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim31aocrcd.OcxState")));
            this.dcim31aocrcd.Size = new System.Drawing.Size(47, 18);
            this.dcim31aocrcd.TabIndex = 789;
            this.dcim31aocrcd.TabStop = false;
            this.dcim31aocrcd.Tag = "31aocrcd";
            // 
            // dced31aocrcd
            // 
            this.dced31aocrcd.Location = new System.Drawing.Point(28, 413);
            this.dced31aocrcd.Name = "dced31aocrcd";
            this.dced31aocrcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced31aocrcd.OcxState")));
            this.dced31aocrcd.Size = new System.Drawing.Size(47, 18);
            this.dced31aocrcd.TabIndex = 47;
            this.dced31aocrcd.Tag = "31aocrcd";
            // 
            // dcim31aocrdt
            // 
            this.dcim31aocrdt.Location = new System.Drawing.Point(78, 394);
            this.dcim31aocrdt.Name = "dcim31aocrdt";
            this.dcim31aocrdt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim31aocrdt.OcxState")));
            this.dcim31aocrdt.Size = new System.Drawing.Size(79, 18);
            this.dcim31aocrdt.TabIndex = 791;
            this.dcim31aocrdt.TabStop = false;
            this.dcim31aocrdt.Tag = "31aocrdt";
            // 
            // dced31aocrdt
            // 
            this.dced31aocrdt.Location = new System.Drawing.Point(78, 413);
            this.dced31aocrdt.Name = "dced31aocrdt";
            this.dced31aocrdt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced31aocrdt.OcxState")));
            this.dced31aocrdt.Size = new System.Drawing.Size(79, 18);
            this.dced31aocrdt.TabIndex = 48;
            this.dced31aocrdt.Tag = "31aocrdt";
            // 
            // dcim31bocrcd
            // 
            this.dcim31bocrcd.Location = new System.Drawing.Point(28, 436);
            this.dcim31bocrcd.Name = "dcim31bocrcd";
            this.dcim31bocrcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim31bocrcd.OcxState")));
            this.dcim31bocrcd.Size = new System.Drawing.Size(47, 18);
            this.dcim31bocrcd.TabIndex = 793;
            this.dcim31bocrcd.TabStop = false;
            this.dcim31bocrcd.Tag = "31bocrcd";
            // 
            // dced31bocrcd
            // 
            this.dced31bocrcd.Location = new System.Drawing.Point(28, 455);
            this.dced31bocrcd.Name = "dced31bocrcd";
            this.dced31bocrcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced31bocrcd.OcxState")));
            this.dced31bocrcd.Size = new System.Drawing.Size(47, 18);
            this.dced31bocrcd.TabIndex = 49;
            this.dced31bocrcd.Tag = "31bocrcd";
            // 
            // dcim31bocrdt
            // 
            this.dcim31bocrdt.Location = new System.Drawing.Point(78, 436);
            this.dcim31bocrdt.Name = "dcim31bocrdt";
            this.dcim31bocrdt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim31bocrdt.OcxState")));
            this.dcim31bocrdt.Size = new System.Drawing.Size(79, 18);
            this.dcim31bocrdt.TabIndex = 795;
            this.dcim31bocrdt.TabStop = false;
            this.dcim31bocrdt.Tag = "31bocrdt";
            // 
            // dced31bocrdt
            // 
            this.dced31bocrdt.Location = new System.Drawing.Point(78, 455);
            this.dced31bocrdt.Name = "dced31bocrdt";
            this.dced31bocrdt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced31bocrdt.OcxState")));
            this.dced31bocrdt.Size = new System.Drawing.Size(79, 18);
            this.dced31bocrdt.TabIndex = 50;
            this.dced31bocrdt.Tag = "31bocrdt";
            // 
            // lbl32aocrcd
            // 
            this.lbl32aocrcd.AutoSize = true;
            this.lbl32aocrcd.Location = new System.Drawing.Point(168, 379);
            this.lbl32aocrcd.Name = "lbl32aocrcd";
            this.lbl32aocrcd.Size = new System.Drawing.Size(132, 13);
            this.lbl32aocrcd.TabIndex = 797;
            this.lbl32aocrcd.Tag = "32aocrcd";
            this.lbl32aocrcd.Text = "32 Occurrence Code:Date";
            // 
            // dcim32aocrcd
            // 
            this.dcim32aocrcd.Location = new System.Drawing.Point(170, 394);
            this.dcim32aocrcd.Name = "dcim32aocrcd";
            this.dcim32aocrcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim32aocrcd.OcxState")));
            this.dcim32aocrcd.Size = new System.Drawing.Size(53, 18);
            this.dcim32aocrcd.TabIndex = 798;
            this.dcim32aocrcd.TabStop = false;
            this.dcim32aocrcd.Tag = "32aocrcd";
            // 
            // dced32aocrcd
            // 
            this.dced32aocrcd.Location = new System.Drawing.Point(170, 413);
            this.dced32aocrcd.Name = "dced32aocrcd";
            this.dced32aocrcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced32aocrcd.OcxState")));
            this.dced32aocrcd.Size = new System.Drawing.Size(53, 18);
            this.dced32aocrcd.TabIndex = 51;
            this.dced32aocrcd.Tag = "32aocrcd";
            // 
            // dcim32aocrdt
            // 
            this.dcim32aocrdt.Location = new System.Drawing.Point(226, 394);
            this.dcim32aocrdt.Name = "dcim32aocrdt";
            this.dcim32aocrdt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim32aocrdt.OcxState")));
            this.dcim32aocrdt.Size = new System.Drawing.Size(79, 18);
            this.dcim32aocrdt.TabIndex = 800;
            this.dcim32aocrdt.TabStop = false;
            this.dcim32aocrdt.Tag = "32aocrdt";
            // 
            // dced32aocrdt
            // 
            this.dced32aocrdt.Location = new System.Drawing.Point(226, 413);
            this.dced32aocrdt.Name = "dced32aocrdt";
            this.dced32aocrdt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced32aocrdt.OcxState")));
            this.dced32aocrdt.Size = new System.Drawing.Size(79, 18);
            this.dced32aocrdt.TabIndex = 52;
            this.dced32aocrdt.Tag = "32aocrdt";
            // 
            // dcim32bocrcd
            // 
            this.dcim32bocrcd.Location = new System.Drawing.Point(170, 436);
            this.dcim32bocrcd.Name = "dcim32bocrcd";
            this.dcim32bocrcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim32bocrcd.OcxState")));
            this.dcim32bocrcd.Size = new System.Drawing.Size(53, 18);
            this.dcim32bocrcd.TabIndex = 802;
            this.dcim32bocrcd.TabStop = false;
            this.dcim32bocrcd.Tag = "32bocrcd";
            // 
            // dced32bocrcd
            // 
            this.dced32bocrcd.Location = new System.Drawing.Point(170, 455);
            this.dced32bocrcd.Name = "dced32bocrcd";
            this.dced32bocrcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced32bocrcd.OcxState")));
            this.dced32bocrcd.Size = new System.Drawing.Size(53, 18);
            this.dced32bocrcd.TabIndex = 53;
            this.dced32bocrcd.Tag = "32bocrcd";
            // 
            // dcim32bocrdt
            // 
            this.dcim32bocrdt.Location = new System.Drawing.Point(226, 436);
            this.dcim32bocrdt.Name = "dcim32bocrdt";
            this.dcim32bocrdt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim32bocrdt.OcxState")));
            this.dcim32bocrdt.Size = new System.Drawing.Size(79, 18);
            this.dcim32bocrdt.TabIndex = 804;
            this.dcim32bocrdt.TabStop = false;
            this.dcim32bocrdt.Tag = "32bocrdt";
            // 
            // dced32bocrdt
            // 
            this.dced32bocrdt.Location = new System.Drawing.Point(226, 455);
            this.dced32bocrdt.Name = "dced32bocrdt";
            this.dced32bocrdt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced32bocrdt.OcxState")));
            this.dced32bocrdt.Size = new System.Drawing.Size(79, 18);
            this.dced32bocrdt.TabIndex = 54;
            this.dced32bocrdt.Tag = "32bocrdt";
            // 
            // lbl36aospcd
            // 
            this.lbl36aospcd.AutoSize = true;
            this.lbl36aospcd.BackColor = System.Drawing.Color.Lavender;
            this.lbl36aospcd.Location = new System.Drawing.Point(326, 479);
            this.lbl36aospcd.Name = "lbl36aospcd";
            this.lbl36aospcd.Size = new System.Drawing.Size(208, 13);
            this.lbl36aospcd.TabIndex = 806;
            this.lbl36aospcd.Tag = "36aospcd";
            this.lbl36aospcd.Text = "36 Occurrence Span. Code:From/Through";
            // 
            // dcim36aospcd
            // 
            this.dcim36aospcd.Location = new System.Drawing.Point(328, 492);
            this.dcim36aospcd.Name = "dcim36aospcd";
            this.dcim36aospcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim36aospcd.OcxState")));
            this.dcim36aospcd.Size = new System.Drawing.Size(92, 18);
            this.dcim36aospcd.TabIndex = 807;
            this.dcim36aospcd.TabStop = false;
            this.dcim36aospcd.Tag = "36aospcd";
            // 
            // dced36aospcd
            // 
            this.dced36aospcd.Location = new System.Drawing.Point(328, 511);
            this.dced36aospcd.Name = "dced36aospcd";
            this.dced36aospcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced36aospcd.OcxState")));
            this.dced36aospcd.Size = new System.Drawing.Size(92, 18);
            this.dced36aospcd.TabIndex = 69;
            this.dced36aospcd.Tag = "36aospcd";
            // 
            // dcim36aospfr
            // 
            this.dcim36aospfr.Location = new System.Drawing.Point(424, 492);
            this.dcim36aospfr.Name = "dcim36aospfr";
            this.dcim36aospfr.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim36aospfr.OcxState")));
            this.dcim36aospfr.Size = new System.Drawing.Size(81, 18);
            this.dcim36aospfr.TabIndex = 809;
            this.dcim36aospfr.TabStop = false;
            this.dcim36aospfr.Tag = "36aospfr";
            // 
            // dced36aospfr
            // 
            this.dced36aospfr.Location = new System.Drawing.Point(424, 511);
            this.dced36aospfr.Name = "dced36aospfr";
            this.dced36aospfr.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced36aospfr.OcxState")));
            this.dced36aospfr.Size = new System.Drawing.Size(81, 18);
            this.dced36aospfr.TabIndex = 70;
            this.dced36aospfr.Tag = "36aospfr";
            // 
            // dcim36aospth
            // 
            this.dcim36aospth.Location = new System.Drawing.Point(505, 492);
            this.dcim36aospth.Name = "dcim36aospth";
            this.dcim36aospth.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim36aospth.OcxState")));
            this.dcim36aospth.Size = new System.Drawing.Size(78, 18);
            this.dcim36aospth.TabIndex = 811;
            this.dcim36aospth.TabStop = false;
            this.dcim36aospth.Tag = "36aospth";
            // 
            // dced36aospth
            // 
            this.dced36aospth.Location = new System.Drawing.Point(505, 511);
            this.dced36aospth.Name = "dced36aospth";
            this.dced36aospth.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced36aospth.OcxState")));
            this.dced36aospth.Size = new System.Drawing.Size(78, 18);
            this.dced36aospth.TabIndex = 71;
            this.dced36aospth.Tag = "36aospth";
            // 
            // dcim36bospcd
            // 
            this.dcim36bospcd.Location = new System.Drawing.Point(328, 535);
            this.dcim36bospcd.Name = "dcim36bospcd";
            this.dcim36bospcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim36bospcd.OcxState")));
            this.dcim36bospcd.Size = new System.Drawing.Size(92, 18);
            this.dcim36bospcd.TabIndex = 813;
            this.dcim36bospcd.TabStop = false;
            this.dcim36bospcd.Tag = "36bospcd";
            // 
            // dced36bospcd
            // 
            this.dced36bospcd.Location = new System.Drawing.Point(328, 554);
            this.dced36bospcd.Name = "dced36bospcd";
            this.dced36bospcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced36bospcd.OcxState")));
            this.dced36bospcd.Size = new System.Drawing.Size(92, 18);
            this.dced36bospcd.TabIndex = 72;
            this.dced36bospcd.Tag = "36bospcd";
            // 
            // dcim36bospfr
            // 
            this.dcim36bospfr.Location = new System.Drawing.Point(424, 535);
            this.dcim36bospfr.Name = "dcim36bospfr";
            this.dcim36bospfr.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim36bospfr.OcxState")));
            this.dcim36bospfr.Size = new System.Drawing.Size(81, 18);
            this.dcim36bospfr.TabIndex = 815;
            this.dcim36bospfr.TabStop = false;
            this.dcim36bospfr.Tag = "36bospfr";
            // 
            // dced36bospfr
            // 
            this.dced36bospfr.Location = new System.Drawing.Point(424, 554);
            this.dced36bospfr.Name = "dced36bospfr";
            this.dced36bospfr.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced36bospfr.OcxState")));
            this.dced36bospfr.Size = new System.Drawing.Size(81, 18);
            this.dced36bospfr.TabIndex = 73;
            this.dced36bospfr.Tag = "36bospfr";
            // 
            // dcim36bospth
            // 
            this.dcim36bospth.Location = new System.Drawing.Point(505, 535);
            this.dcim36bospth.Name = "dcim36bospth";
            this.dcim36bospth.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim36bospth.OcxState")));
            this.dcim36bospth.Size = new System.Drawing.Size(78, 18);
            this.dcim36bospth.TabIndex = 817;
            this.dcim36bospth.TabStop = false;
            this.dcim36bospth.Tag = "36bospth";
            // 
            // dced36bospth
            // 
            this.dced36bospth.Location = new System.Drawing.Point(505, 554);
            this.dced36bospth.Name = "dced36bospth";
            this.dced36bospth.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced36bospth.OcxState")));
            this.dced36bospth.Size = new System.Drawing.Size(78, 18);
            this.dced36bospth.TabIndex = 74;
            this.dced36bospth.Tag = "36bospth";
            // 
            // lbl39avlcd
            // 
            this.lbl39avlcd.AutoSize = true;
            this.lbl39avlcd.Location = new System.Drawing.Point(623, 380);
            this.lbl39avlcd.Name = "lbl39avlcd";
            this.lbl39avlcd.Size = new System.Drawing.Size(119, 13);
            this.lbl39avlcd.TabIndex = 819;
            this.lbl39avlcd.Tag = "39avlcd";
            this.lbl39avlcd.Text = "39 Value Code, Amount";
            // 
            // dcim39avlcd
            // 
            this.dcim39avlcd.Location = new System.Drawing.Point(624, 393);
            this.dcim39avlcd.Name = "dcim39avlcd";
            this.dcim39avlcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim39avlcd.OcxState")));
            this.dcim39avlcd.Size = new System.Drawing.Size(36, 18);
            this.dcim39avlcd.TabIndex = 820;
            this.dcim39avlcd.TabStop = false;
            this.dcim39avlcd.Tag = "39avlcd";
            // 
            // dced39avlcd
            // 
            this.dced39avlcd.Location = new System.Drawing.Point(624, 412);
            this.dced39avlcd.Name = "dced39avlcd";
            this.dced39avlcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced39avlcd.OcxState")));
            this.dced39avlcd.Size = new System.Drawing.Size(36, 18);
            this.dced39avlcd.TabIndex = 75;
            this.dced39avlcd.Tag = "39avlcd";
            // 
            // dcim39avlamt
            // 
            this.dcim39avlamt.Location = new System.Drawing.Point(664, 393);
            this.dcim39avlamt.Name = "dcim39avlamt";
            this.dcim39avlamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim39avlamt.OcxState")));
            this.dcim39avlamt.Size = new System.Drawing.Size(78, 18);
            this.dcim39avlamt.TabIndex = 822;
            this.dcim39avlamt.TabStop = false;
            this.dcim39avlamt.Tag = "39avlamt";
            // 
            // dced39avlamt
            // 
            this.dced39avlamt.Location = new System.Drawing.Point(664, 412);
            this.dced39avlamt.Name = "dced39avlamt";
            this.dced39avlamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced39avlamt.OcxState")));
            this.dced39avlamt.Size = new System.Drawing.Size(78, 18);
            this.dced39avlamt.TabIndex = 76;
            this.dced39avlamt.Tag = "39avlamt";
            // 
            // dcim39bvlcd
            // 
            this.dcim39bvlcd.Location = new System.Drawing.Point(624, 435);
            this.dcim39bvlcd.Name = "dcim39bvlcd";
            this.dcim39bvlcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim39bvlcd.OcxState")));
            this.dcim39bvlcd.Size = new System.Drawing.Size(36, 18);
            this.dcim39bvlcd.TabIndex = 824;
            this.dcim39bvlcd.TabStop = false;
            this.dcim39bvlcd.Tag = "39bvlcd";
            // 
            // dced39bvlcd
            // 
            this.dced39bvlcd.Location = new System.Drawing.Point(624, 454);
            this.dced39bvlcd.Name = "dced39bvlcd";
            this.dced39bvlcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced39bvlcd.OcxState")));
            this.dced39bvlcd.Size = new System.Drawing.Size(36, 18);
            this.dced39bvlcd.TabIndex = 77;
            this.dced39bvlcd.Tag = "39bvlcd";
            // 
            // dcim39bvlamt
            // 
            this.dcim39bvlamt.Location = new System.Drawing.Point(664, 435);
            this.dcim39bvlamt.Name = "dcim39bvlamt";
            this.dcim39bvlamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim39bvlamt.OcxState")));
            this.dcim39bvlamt.Size = new System.Drawing.Size(78, 18);
            this.dcim39bvlamt.TabIndex = 826;
            this.dcim39bvlamt.TabStop = false;
            this.dcim39bvlamt.Tag = "39bvlamt";
            // 
            // dced39bvlamt
            // 
            this.dced39bvlamt.Location = new System.Drawing.Point(664, 454);
            this.dced39bvlamt.Name = "dced39bvlamt";
            this.dced39bvlamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced39bvlamt.OcxState")));
            this.dced39bvlamt.Size = new System.Drawing.Size(78, 18);
            this.dced39bvlamt.TabIndex = 78;
            this.dced39bvlamt.Tag = "39bvlamt";
            // 
            // dcim39cvlcd
            // 
            this.dcim39cvlcd.Location = new System.Drawing.Point(624, 478);
            this.dcim39cvlcd.Name = "dcim39cvlcd";
            this.dcim39cvlcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim39cvlcd.OcxState")));
            this.dcim39cvlcd.Size = new System.Drawing.Size(36, 18);
            this.dcim39cvlcd.TabIndex = 828;
            this.dcim39cvlcd.TabStop = false;
            this.dcim39cvlcd.Tag = "39cvlcd";
            // 
            // dced39cvlcd
            // 
            this.dced39cvlcd.Location = new System.Drawing.Point(624, 497);
            this.dced39cvlcd.Name = "dced39cvlcd";
            this.dced39cvlcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced39cvlcd.OcxState")));
            this.dced39cvlcd.Size = new System.Drawing.Size(36, 18);
            this.dced39cvlcd.TabIndex = 79;
            this.dced39cvlcd.Tag = "39cvlcd";
            // 
            // dcim39cvlamt
            // 
            this.dcim39cvlamt.Location = new System.Drawing.Point(664, 478);
            this.dcim39cvlamt.Name = "dcim39cvlamt";
            this.dcim39cvlamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim39cvlamt.OcxState")));
            this.dcim39cvlamt.Size = new System.Drawing.Size(78, 18);
            this.dcim39cvlamt.TabIndex = 830;
            this.dcim39cvlamt.TabStop = false;
            this.dcim39cvlamt.Tag = "39cvlamt";
            // 
            // dced39cvlamt
            // 
            this.dced39cvlamt.Location = new System.Drawing.Point(664, 497);
            this.dced39cvlamt.Name = "dced39cvlamt";
            this.dced39cvlamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced39cvlamt.OcxState")));
            this.dced39cvlamt.Size = new System.Drawing.Size(78, 18);
            this.dced39cvlamt.TabIndex = 80;
            this.dced39cvlamt.Tag = "39cvlamt";
            // 
            // dcim39dvlcd
            // 
            this.dcim39dvlcd.Location = new System.Drawing.Point(624, 521);
            this.dcim39dvlcd.Name = "dcim39dvlcd";
            this.dcim39dvlcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim39dvlcd.OcxState")));
            this.dcim39dvlcd.Size = new System.Drawing.Size(36, 18);
            this.dcim39dvlcd.TabIndex = 832;
            this.dcim39dvlcd.TabStop = false;
            this.dcim39dvlcd.Tag = "39dvlcd";
            // 
            // dced39dvlcd
            // 
            this.dced39dvlcd.Location = new System.Drawing.Point(624, 540);
            this.dced39dvlcd.Name = "dced39dvlcd";
            this.dced39dvlcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced39dvlcd.OcxState")));
            this.dced39dvlcd.Size = new System.Drawing.Size(36, 18);
            this.dced39dvlcd.TabIndex = 81;
            this.dced39dvlcd.Tag = "39dvlcd";
            // 
            // dcim39dvlamt
            // 
            this.dcim39dvlamt.Location = new System.Drawing.Point(664, 521);
            this.dcim39dvlamt.Name = "dcim39dvlamt";
            this.dcim39dvlamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim39dvlamt.OcxState")));
            this.dcim39dvlamt.Size = new System.Drawing.Size(78, 18);
            this.dcim39dvlamt.TabIndex = 834;
            this.dcim39dvlamt.TabStop = false;
            this.dcim39dvlamt.Tag = "39dvlamt";
            // 
            // dced39dvlamt
            // 
            this.dced39dvlamt.Location = new System.Drawing.Point(664, 540);
            this.dced39dvlamt.Name = "dced39dvlamt";
            this.dced39dvlamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced39dvlamt.OcxState")));
            this.dced39dvlamt.Size = new System.Drawing.Size(78, 18);
            this.dced39dvlamt.TabIndex = 82;
            this.dced39dvlamt.Tag = "39dvlamt";
            // 
            // lbl40avlcd
            // 
            this.lbl40avlcd.AutoSize = true;
            this.lbl40avlcd.Location = new System.Drawing.Point(752, 380);
            this.lbl40avlcd.Name = "lbl40avlcd";
            this.lbl40avlcd.Size = new System.Drawing.Size(119, 13);
            this.lbl40avlcd.TabIndex = 836;
            this.lbl40avlcd.Tag = "40avlcd";
            this.lbl40avlcd.Text = "40 Value Code, Amount";
            // 
            // dcim40avlcd
            // 
            this.dcim40avlcd.Location = new System.Drawing.Point(753, 393);
            this.dcim40avlcd.Name = "dcim40avlcd";
            this.dcim40avlcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim40avlcd.OcxState")));
            this.dcim40avlcd.Size = new System.Drawing.Size(36, 18);
            this.dcim40avlcd.TabIndex = 837;
            this.dcim40avlcd.TabStop = false;
            this.dcim40avlcd.Tag = "40avlcd";
            // 
            // dced40avlcd
            // 
            this.dced40avlcd.Location = new System.Drawing.Point(753, 412);
            this.dced40avlcd.Name = "dced40avlcd";
            this.dced40avlcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced40avlcd.OcxState")));
            this.dced40avlcd.Size = new System.Drawing.Size(36, 18);
            this.dced40avlcd.TabIndex = 83;
            this.dced40avlcd.Tag = "40avlcd";
            // 
            // dcim40avlamt
            // 
            this.dcim40avlamt.Location = new System.Drawing.Point(793, 393);
            this.dcim40avlamt.Name = "dcim40avlamt";
            this.dcim40avlamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim40avlamt.OcxState")));
            this.dcim40avlamt.Size = new System.Drawing.Size(78, 18);
            this.dcim40avlamt.TabIndex = 839;
            this.dcim40avlamt.TabStop = false;
            this.dcim40avlamt.Tag = "40avlamt";
            // 
            // dced40avlamt
            // 
            this.dced40avlamt.Location = new System.Drawing.Point(793, 412);
            this.dced40avlamt.Name = "dced40avlamt";
            this.dced40avlamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced40avlamt.OcxState")));
            this.dced40avlamt.Size = new System.Drawing.Size(78, 18);
            this.dced40avlamt.TabIndex = 84;
            this.dced40avlamt.Tag = "40avlamt";
            // 
            // dcim40bvlcd
            // 
            this.dcim40bvlcd.Location = new System.Drawing.Point(753, 435);
            this.dcim40bvlcd.Name = "dcim40bvlcd";
            this.dcim40bvlcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim40bvlcd.OcxState")));
            this.dcim40bvlcd.Size = new System.Drawing.Size(36, 18);
            this.dcim40bvlcd.TabIndex = 841;
            this.dcim40bvlcd.TabStop = false;
            this.dcim40bvlcd.Tag = "40bvlcd";
            // 
            // dced40bvlcd
            // 
            this.dced40bvlcd.Location = new System.Drawing.Point(753, 454);
            this.dced40bvlcd.Name = "dced40bvlcd";
            this.dced40bvlcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced40bvlcd.OcxState")));
            this.dced40bvlcd.Size = new System.Drawing.Size(36, 18);
            this.dced40bvlcd.TabIndex = 85;
            this.dced40bvlcd.Tag = "40bvlcd";
            // 
            // dcim40bvlamt
            // 
            this.dcim40bvlamt.Location = new System.Drawing.Point(793, 435);
            this.dcim40bvlamt.Name = "dcim40bvlamt";
            this.dcim40bvlamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim40bvlamt.OcxState")));
            this.dcim40bvlamt.Size = new System.Drawing.Size(78, 18);
            this.dcim40bvlamt.TabIndex = 843;
            this.dcim40bvlamt.TabStop = false;
            this.dcim40bvlamt.Tag = "40bvlamt";
            // 
            // dced40bvlamt
            // 
            this.dced40bvlamt.Location = new System.Drawing.Point(793, 454);
            this.dced40bvlamt.Name = "dced40bvlamt";
            this.dced40bvlamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced40bvlamt.OcxState")));
            this.dced40bvlamt.Size = new System.Drawing.Size(78, 18);
            this.dced40bvlamt.TabIndex = 86;
            this.dced40bvlamt.Tag = "40bvlamt";
            // 
            // dcim40cvlcd
            // 
            this.dcim40cvlcd.Location = new System.Drawing.Point(753, 478);
            this.dcim40cvlcd.Name = "dcim40cvlcd";
            this.dcim40cvlcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim40cvlcd.OcxState")));
            this.dcim40cvlcd.Size = new System.Drawing.Size(36, 18);
            this.dcim40cvlcd.TabIndex = 845;
            this.dcim40cvlcd.TabStop = false;
            this.dcim40cvlcd.Tag = "40cvlcd";
            // 
            // dced40cvlcd
            // 
            this.dced40cvlcd.Location = new System.Drawing.Point(753, 497);
            this.dced40cvlcd.Name = "dced40cvlcd";
            this.dced40cvlcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced40cvlcd.OcxState")));
            this.dced40cvlcd.Size = new System.Drawing.Size(36, 18);
            this.dced40cvlcd.TabIndex = 87;
            this.dced40cvlcd.Tag = "40cvlcd";
            // 
            // dcim40cvlamt
            // 
            this.dcim40cvlamt.Location = new System.Drawing.Point(793, 478);
            this.dcim40cvlamt.Name = "dcim40cvlamt";
            this.dcim40cvlamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim40cvlamt.OcxState")));
            this.dcim40cvlamt.Size = new System.Drawing.Size(78, 18);
            this.dcim40cvlamt.TabIndex = 847;
            this.dcim40cvlamt.TabStop = false;
            this.dcim40cvlamt.Tag = "40cvlamt";
            // 
            // dced40cvlamt
            // 
            this.dced40cvlamt.Location = new System.Drawing.Point(793, 497);
            this.dced40cvlamt.Name = "dced40cvlamt";
            this.dced40cvlamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced40cvlamt.OcxState")));
            this.dced40cvlamt.Size = new System.Drawing.Size(78, 18);
            this.dced40cvlamt.TabIndex = 88;
            this.dced40cvlamt.Tag = "40cvlamt";
            // 
            // dcim40dvlcd
            // 
            this.dcim40dvlcd.Location = new System.Drawing.Point(753, 521);
            this.dcim40dvlcd.Name = "dcim40dvlcd";
            this.dcim40dvlcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim40dvlcd.OcxState")));
            this.dcim40dvlcd.Size = new System.Drawing.Size(36, 18);
            this.dcim40dvlcd.TabIndex = 849;
            this.dcim40dvlcd.TabStop = false;
            this.dcim40dvlcd.Tag = "40dvlcd";
            // 
            // dced40dvlcd
            // 
            this.dced40dvlcd.Location = new System.Drawing.Point(753, 540);
            this.dced40dvlcd.Name = "dced40dvlcd";
            this.dced40dvlcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced40dvlcd.OcxState")));
            this.dced40dvlcd.Size = new System.Drawing.Size(36, 18);
            this.dced40dvlcd.TabIndex = 89;
            this.dced40dvlcd.Tag = "40dvlcd";
            // 
            // dcim40dvlamt
            // 
            this.dcim40dvlamt.Location = new System.Drawing.Point(793, 521);
            this.dcim40dvlamt.Name = "dcim40dvlamt";
            this.dcim40dvlamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim40dvlamt.OcxState")));
            this.dcim40dvlamt.Size = new System.Drawing.Size(78, 18);
            this.dcim40dvlamt.TabIndex = 851;
            this.dcim40dvlamt.TabStop = false;
            this.dcim40dvlamt.Tag = "40dvlamt";
            // 
            // dced40dvlamt
            // 
            this.dced40dvlamt.Location = new System.Drawing.Point(793, 540);
            this.dced40dvlamt.Name = "dced40dvlamt";
            this.dced40dvlamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced40dvlamt.OcxState")));
            this.dced40dvlamt.Size = new System.Drawing.Size(78, 18);
            this.dced40dvlamt.TabIndex = 90;
            this.dced40dvlamt.Tag = "40dvlamt";
            // 
            // dcim41avlcd
            // 
            this.dcim41avlcd.Location = new System.Drawing.Point(881, 393);
            this.dcim41avlcd.Name = "dcim41avlcd";
            this.dcim41avlcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim41avlcd.OcxState")));
            this.dcim41avlcd.Size = new System.Drawing.Size(36, 18);
            this.dcim41avlcd.TabIndex = 853;
            this.dcim41avlcd.TabStop = false;
            this.dcim41avlcd.Tag = "41avlcd";
            // 
            // dced41avlcd
            // 
            this.dced41avlcd.Location = new System.Drawing.Point(881, 412);
            this.dced41avlcd.Name = "dced41avlcd";
            this.dced41avlcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced41avlcd.OcxState")));
            this.dced41avlcd.Size = new System.Drawing.Size(36, 18);
            this.dced41avlcd.TabIndex = 91;
            this.dced41avlcd.Tag = "41avlcd";
            // 
            // dcim41avlamt
            // 
            this.dcim41avlamt.Location = new System.Drawing.Point(921, 393);
            this.dcim41avlamt.Name = "dcim41avlamt";
            this.dcim41avlamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim41avlamt.OcxState")));
            this.dcim41avlamt.Size = new System.Drawing.Size(78, 18);
            this.dcim41avlamt.TabIndex = 855;
            this.dcim41avlamt.TabStop = false;
            this.dcim41avlamt.Tag = "41avlamt";
            // 
            // dced41avlamt
            // 
            this.dced41avlamt.Location = new System.Drawing.Point(921, 412);
            this.dced41avlamt.Name = "dced41avlamt";
            this.dced41avlamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced41avlamt.OcxState")));
            this.dced41avlamt.Size = new System.Drawing.Size(78, 18);
            this.dced41avlamt.TabIndex = 92;
            this.dced41avlamt.Tag = "41avlamt";
            // 
            // lbl41bvlcd
            // 
            this.lbl41bvlcd.AutoSize = true;
            this.lbl41bvlcd.Location = new System.Drawing.Point(880, 380);
            this.lbl41bvlcd.Name = "lbl41bvlcd";
            this.lbl41bvlcd.Size = new System.Drawing.Size(119, 13);
            this.lbl41bvlcd.TabIndex = 857;
            this.lbl41bvlcd.Tag = "41bvlcd";
            this.lbl41bvlcd.Text = "41 Value Code, Amount";
            // 
            // dcim41bvlcd
            // 
            this.dcim41bvlcd.Location = new System.Drawing.Point(881, 435);
            this.dcim41bvlcd.Name = "dcim41bvlcd";
            this.dcim41bvlcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim41bvlcd.OcxState")));
            this.dcim41bvlcd.Size = new System.Drawing.Size(36, 18);
            this.dcim41bvlcd.TabIndex = 858;
            this.dcim41bvlcd.TabStop = false;
            this.dcim41bvlcd.Tag = "41bvlcd";
            // 
            // dced41bvlcd
            // 
            this.dced41bvlcd.Location = new System.Drawing.Point(881, 454);
            this.dced41bvlcd.Name = "dced41bvlcd";
            this.dced41bvlcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced41bvlcd.OcxState")));
            this.dced41bvlcd.Size = new System.Drawing.Size(36, 18);
            this.dced41bvlcd.TabIndex = 93;
            this.dced41bvlcd.Tag = "41bvlcd";
            // 
            // dcim41bvlamt
            // 
            this.dcim41bvlamt.Location = new System.Drawing.Point(921, 435);
            this.dcim41bvlamt.Name = "dcim41bvlamt";
            this.dcim41bvlamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim41bvlamt.OcxState")));
            this.dcim41bvlamt.Size = new System.Drawing.Size(78, 18);
            this.dcim41bvlamt.TabIndex = 860;
            this.dcim41bvlamt.TabStop = false;
            this.dcim41bvlamt.Tag = "41bvlamt";
            // 
            // dced41bvlamt
            // 
            this.dced41bvlamt.Location = new System.Drawing.Point(921, 454);
            this.dced41bvlamt.Name = "dced41bvlamt";
            this.dced41bvlamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced41bvlamt.OcxState")));
            this.dced41bvlamt.Size = new System.Drawing.Size(78, 18);
            this.dced41bvlamt.TabIndex = 94;
            this.dced41bvlamt.Tag = "41bvlamt";
            // 
            // dcim41cvlcd
            // 
            this.dcim41cvlcd.Location = new System.Drawing.Point(881, 478);
            this.dcim41cvlcd.Name = "dcim41cvlcd";
            this.dcim41cvlcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim41cvlcd.OcxState")));
            this.dcim41cvlcd.Size = new System.Drawing.Size(36, 18);
            this.dcim41cvlcd.TabIndex = 862;
            this.dcim41cvlcd.TabStop = false;
            this.dcim41cvlcd.Tag = "41cvlcd";
            // 
            // dced41cvlcd
            // 
            this.dced41cvlcd.Location = new System.Drawing.Point(881, 497);
            this.dced41cvlcd.Name = "dced41cvlcd";
            this.dced41cvlcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced41cvlcd.OcxState")));
            this.dced41cvlcd.Size = new System.Drawing.Size(36, 18);
            this.dced41cvlcd.TabIndex = 95;
            this.dced41cvlcd.Tag = "41cvlcd";
            // 
            // dcim41cvlamt
            // 
            this.dcim41cvlamt.Location = new System.Drawing.Point(921, 478);
            this.dcim41cvlamt.Name = "dcim41cvlamt";
            this.dcim41cvlamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim41cvlamt.OcxState")));
            this.dcim41cvlamt.Size = new System.Drawing.Size(78, 18);
            this.dcim41cvlamt.TabIndex = 864;
            this.dcim41cvlamt.TabStop = false;
            this.dcim41cvlamt.Tag = "41cvlamt";
            // 
            // dced41cvlamt
            // 
            this.dced41cvlamt.Location = new System.Drawing.Point(921, 497);
            this.dced41cvlamt.Name = "dced41cvlamt";
            this.dced41cvlamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced41cvlamt.OcxState")));
            this.dced41cvlamt.Size = new System.Drawing.Size(78, 18);
            this.dced41cvlamt.TabIndex = 96;
            this.dced41cvlamt.Tag = "41cvlamt";
            // 
            // dcim41dvlcd
            // 
            this.dcim41dvlcd.Location = new System.Drawing.Point(881, 521);
            this.dcim41dvlcd.Name = "dcim41dvlcd";
            this.dcim41dvlcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim41dvlcd.OcxState")));
            this.dcim41dvlcd.Size = new System.Drawing.Size(36, 18);
            this.dcim41dvlcd.TabIndex = 866;
            this.dcim41dvlcd.TabStop = false;
            this.dcim41dvlcd.Tag = "41dvlcd";
            // 
            // dced41dvlcd
            // 
            this.dced41dvlcd.Location = new System.Drawing.Point(881, 540);
            this.dced41dvlcd.Name = "dced41dvlcd";
            this.dced41dvlcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced41dvlcd.OcxState")));
            this.dced41dvlcd.Size = new System.Drawing.Size(36, 18);
            this.dced41dvlcd.TabIndex = 97;
            this.dced41dvlcd.Tag = "41dvlcd";
            // 
            // dcim41dvlamt
            // 
            this.dcim41dvlamt.Location = new System.Drawing.Point(921, 521);
            this.dcim41dvlamt.Name = "dcim41dvlamt";
            this.dcim41dvlamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim41dvlamt.OcxState")));
            this.dcim41dvlamt.Size = new System.Drawing.Size(78, 18);
            this.dcim41dvlamt.TabIndex = 868;
            this.dcim41dvlamt.TabStop = false;
            this.dcim41dvlamt.Tag = "41dvlamt";
            // 
            // dced41dvlamt
            // 
            this.dced41dvlamt.Location = new System.Drawing.Point(921, 540);
            this.dced41dvlamt.Name = "dced41dvlamt";
            this.dced41dvlamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced41dvlamt.OcxState")));
            this.dced41dvlamt.Size = new System.Drawing.Size(78, 18);
            this.dced41dvlamt.TabIndex = 98;
            this.dced41dvlamt.Tag = "41dvlamt";
            // 
            // lbl1fcynmad
            // 
            this.lbl1fcynmad.AutoSize = true;
            this.lbl1fcynmad.BackColor = System.Drawing.Color.Lavender;
            this.lbl1fcynmad.Location = new System.Drawing.Point(34, 105);
            this.lbl1fcynmad.Name = "lbl1fcynmad";
            this.lbl1fcynmad.Size = new System.Drawing.Size(75, 13);
            this.lbl1fcynmad.TabIndex = 712;
            this.lbl1fcynmad.Tag = "1fcynmad";
            this.lbl1fcynmad.Text = "Provider name";
            // 
            // lbl1provadd
            // 
            this.lbl1provadd.AutoSize = true;
            this.lbl1provadd.BackColor = System.Drawing.Color.Lavender;
            this.lbl1provadd.Location = new System.Drawing.Point(34, 141);
            this.lbl1provadd.Name = "lbl1provadd";
            this.lbl1provadd.Size = new System.Drawing.Size(45, 13);
            this.lbl1provadd.TabIndex = 716;
            this.lbl1provadd.Tag = "1provadd";
            this.lbl1provadd.Text = "Address";
            // 
            // lbl1provcit
            // 
            this.lbl1provcit.AutoSize = true;
            this.lbl1provcit.BackColor = System.Drawing.Color.Lavender;
            this.lbl1provcit.Location = new System.Drawing.Point(34, 177);
            this.lbl1provcit.Name = "lbl1provcit";
            this.lbl1provcit.Size = new System.Drawing.Size(24, 13);
            this.lbl1provcit.TabIndex = 718;
            this.lbl1provcit.Tag = "1provcit";
            this.lbl1provcit.Text = "City";
            // 
            // lbl1provsta
            // 
            this.lbl1provsta.AutoSize = true;
            this.lbl1provsta.BackColor = System.Drawing.Color.Lavender;
            this.lbl1provsta.Location = new System.Drawing.Point(34, 211);
            this.lbl1provsta.Name = "lbl1provsta";
            this.lbl1provsta.Size = new System.Drawing.Size(32, 13);
            this.lbl1provsta.TabIndex = 720;
            this.lbl1provsta.Tag = "1provsta";
            this.lbl1provsta.Text = "State";
            // 
            // dced1provzip
            // 
            this.dced1provzip.Location = new System.Drawing.Point(218, 224);
            this.dced1provzip.Name = "dced1provzip";
            this.dced1provzip.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced1provzip.OcxState")));
            this.dced1provzip.Size = new System.Drawing.Size(86, 18);
            this.dced1provzip.TabIndex = 6;
            this.dced1provzip.Tag = "1provzip";
            // 
            // lbl1provzip
            // 
            this.lbl1provzip.AutoSize = true;
            this.lbl1provzip.BackColor = System.Drawing.Color.Lavender;
            this.lbl1provzip.Location = new System.Drawing.Point(216, 211);
            this.lbl1provzip.Name = "lbl1provzip";
            this.lbl1provzip.Size = new System.Drawing.Size(22, 13);
            this.lbl1provzip.TabIndex = 722;
            this.lbl1provzip.Tag = "1provzip";
            this.lbl1provzip.Text = "Zip";
            // 
            // lbl8plname
            // 
            this.lbl8plname.AutoSize = true;
            this.lbl8plname.BackColor = System.Drawing.Color.Lavender;
            this.lbl8plname.Location = new System.Drawing.Point(623, 154);
            this.lbl8plname.Name = "lbl8plname";
            this.lbl8plname.Size = new System.Drawing.Size(56, 13);
            this.lbl8plname.TabIndex = 746;
            this.lbl8plname.Tag = "8plname";
            this.lbl8plname.Text = "Last name";
            // 
            // lbl8pfname
            // 
            this.lbl8pfname.AutoSize = true;
            this.lbl8pfname.BackColor = System.Drawing.Color.Lavender;
            this.lbl8pfname.Location = new System.Drawing.Point(818, 153);
            this.lbl8pfname.Name = "lbl8pfname";
            this.lbl8pfname.Size = new System.Drawing.Size(55, 13);
            this.lbl8pfname.TabIndex = 748;
            this.lbl8pfname.Tag = "8pfname";
            this.lbl8pfname.Text = "First name";
            // 
            // lbl8pminit
            // 
            this.lbl8pminit.AutoSize = true;
            this.lbl8pminit.BackColor = System.Drawing.Color.Lavender;
            this.lbl8pminit.Location = new System.Drawing.Point(966, 153);
            this.lbl8pminit.Name = "lbl8pminit";
            this.lbl8pminit.Size = new System.Drawing.Size(19, 13);
            this.lbl8pminit.TabIndex = 750;
            this.lbl8pminit.Tag = "8pminit";
            this.lbl8pminit.Text = "MI";
            // 
            // lbl9paddstr
            // 
            this.lbl9paddstr.AutoSize = true;
            this.lbl9paddstr.BackColor = System.Drawing.Color.Lavender;
            this.lbl9paddstr.Location = new System.Drawing.Point(621, 200);
            this.lbl9paddstr.Name = "lbl9paddstr";
            this.lbl9paddstr.Size = new System.Drawing.Size(90, 13);
            this.lbl9paddstr.TabIndex = 752;
            this.lbl9paddstr.Tag = "9paddstr";
            this.lbl9paddstr.Text = "9 Patient Address";
            // 
            // lbl9paddcty
            // 
            this.lbl9paddcty.AutoSize = true;
            this.lbl9paddcty.BackColor = System.Drawing.Color.Lavender;
            this.lbl9paddcty.Location = new System.Drawing.Point(619, 251);
            this.lbl9paddcty.Name = "lbl9paddcty";
            this.lbl9paddcty.Size = new System.Drawing.Size(24, 13);
            this.lbl9paddcty.TabIndex = 755;
            this.lbl9paddcty.Tag = "9paddcty";
            this.lbl9paddcty.Text = "City";
            // 
            // lbl9paddsta
            // 
            this.lbl9paddsta.AutoSize = true;
            this.lbl9paddsta.BackColor = System.Drawing.Color.Lavender;
            this.lbl9paddsta.Location = new System.Drawing.Point(836, 251);
            this.lbl9paddsta.Name = "lbl9paddsta";
            this.lbl9paddsta.Size = new System.Drawing.Size(32, 13);
            this.lbl9paddsta.TabIndex = 758;
            this.lbl9paddsta.Tag = "9paddsta";
            this.lbl9paddsta.Text = "State";
            // 
            // lbl9paddzip
            // 
            this.lbl9paddzip.AutoSize = true;
            this.lbl9paddzip.BackColor = System.Drawing.Color.Lavender;
            this.lbl9paddzip.Location = new System.Drawing.Point(886, 251);
            this.lbl9paddzip.Name = "lbl9paddzip";
            this.lbl9paddzip.Size = new System.Drawing.Size(22, 13);
            this.lbl9paddzip.TabIndex = 761;
            this.lbl9paddzip.Tag = "9paddzip";
            this.lbl9paddzip.Text = "Zip";
            // 
            // lbl9paddccd
            // 
            this.lbl9paddccd.AutoSize = true;
            this.lbl9paddccd.BackColor = System.Drawing.Color.Lavender;
            this.lbl9paddccd.Location = new System.Drawing.Point(940, 200);
            this.lbl9paddccd.Name = "lbl9paddccd";
            this.lbl9paddccd.Size = new System.Drawing.Size(29, 13);
            this.lbl9paddccd.TabIndex = 764;
            this.lbl9paddccd.Tag = "9paddccd";
            this.lbl9paddccd.Text = "CCD";
            // 
            // picbx1
            // 
            this.picbx1.BackColor = System.Drawing.Color.Lavender;
            this.picbx1.Location = new System.Drawing.Point(28, 11);
            this.picbx1.Name = "picbx1";
            this.picbx1.Size = new System.Drawing.Size(285, 241);
            this.picbx1.TabIndex = 870;
            this.picbx1.TabStop = false;
            // 
            // picbx8
            // 
            this.picbx8.BackColor = System.Drawing.Color.Lavender;
            this.picbx8.Location = new System.Drawing.Point(613, 118);
            this.picbx8.Name = "picbx8";
            this.picbx8.Size = new System.Drawing.Size(383, 73);
            this.picbx8.TabIndex = 871;
            this.picbx8.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Lavender;
            this.pictureBox1.Location = new System.Drawing.Point(614, 197);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(383, 110);
            this.pictureBox1.TabIndex = 872;
            this.pictureBox1.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Lavender;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(16, 1085);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(16, 15);
            this.label4.TabIndex = 1005;
            this.label4.Text = "C";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Lavender;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(15, 1040);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(16, 15);
            this.label3.TabIndex = 1004;
            this.label3.Text = "B";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Lavender;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(16, 1000);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(15, 15);
            this.label2.TabIndex = 1003;
            this.label2.Text = "A";
            // 
            // btnDelpbLINEITEM
            // 
            this.btnDelpbLINEITEM.Location = new System.Drawing.Point(184, 919);
            this.btnDelpbLINEITEM.Name = "btnDelpbLINEITEM";
            this.btnDelpbLINEITEM.Size = new System.Drawing.Size(74, 26);
            this.btnDelpbLINEITEM.TabIndex = 102;
            this.btnDelpbLINEITEM.Tag = "LINEITEM";
            this.btnDelpbLINEITEM.Text = "Delete";
            this.btnDelpbLINEITEM.UseVisualStyleBackColor = true;
            // 
            // btnInsAfterpbLINEITEM
            // 
            this.btnInsAfterpbLINEITEM.Location = new System.Drawing.Point(106, 919);
            this.btnInsAfterpbLINEITEM.Name = "btnInsAfterpbLINEITEM";
            this.btnInsAfterpbLINEITEM.Size = new System.Drawing.Size(76, 26);
            this.btnInsAfterpbLINEITEM.TabIndex = 101;
            this.btnInsAfterpbLINEITEM.Tag = "LINEITEM";
            this.btnInsAfterpbLINEITEM.Text = "Append";
            this.btnInsAfterpbLINEITEM.UseVisualStyleBackColor = true;
            // 
            // btnInsBeforepbLINEITEM
            // 
            this.btnInsBeforepbLINEITEM.Location = new System.Drawing.Point(23, 919);
            this.btnInsBeforepbLINEITEM.Name = "btnInsBeforepbLINEITEM";
            this.btnInsBeforepbLINEITEM.Size = new System.Drawing.Size(77, 26);
            this.btnInsBeforepbLINEITEM.TabIndex = 100;
            this.btnInsBeforepbLINEITEM.Tag = "LINEITEM";
            this.btnInsBeforepbLINEITEM.Text = "Insert";
            this.btnInsBeforepbLINEITEM.UseVisualStyleBackColor = true;
            // 
            // dcim50apayer
            // 
            this.dcim50apayer.Location = new System.Drawing.Point(32, 988);
            this.dcim50apayer.Name = "dcim50apayer";
            this.dcim50apayer.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim50apayer.OcxState")));
            this.dcim50apayer.Size = new System.Drawing.Size(156, 18);
            this.dcim50apayer.TabIndex = 884;
            this.dcim50apayer.TabStop = false;
            this.dcim50apayer.Tag = "50apayer";
            // 
            // dced50apayer
            // 
            this.dced50apayer.Location = new System.Drawing.Point(32, 1007);
            this.dced50apayer.Name = "dced50apayer";
            this.dced50apayer.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced50apayer.OcxState")));
            this.dced50apayer.Size = new System.Drawing.Size(156, 18);
            this.dced50apayer.TabIndex = 105;
            this.dced50apayer.Tag = "50apayer";
            // 
            // dcim50bpayer
            // 
            this.dcim50bpayer.Location = new System.Drawing.Point(32, 1032);
            this.dcim50bpayer.Name = "dcim50bpayer";
            this.dcim50bpayer.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim50bpayer.OcxState")));
            this.dcim50bpayer.Size = new System.Drawing.Size(156, 18);
            this.dcim50bpayer.TabIndex = 895;
            this.dcim50bpayer.TabStop = false;
            this.dcim50bpayer.Tag = "50bpayer";
            // 
            // dced50bpayer
            // 
            this.dced50bpayer.Location = new System.Drawing.Point(32, 1051);
            this.dced50bpayer.Name = "dced50bpayer";
            this.dced50bpayer.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced50bpayer.OcxState")));
            this.dced50bpayer.Size = new System.Drawing.Size(156, 18);
            this.dced50bpayer.TabIndex = 109;
            this.dced50bpayer.Tag = "50bpayer";
            // 
            // lbl50cpayer
            // 
            this.lbl50cpayer.AutoSize = true;
            this.lbl50cpayer.BackColor = System.Drawing.Color.Lavender;
            this.lbl50cpayer.Location = new System.Drawing.Point(31, 975);
            this.lbl50cpayer.Name = "lbl50cpayer";
            this.lbl50cpayer.Size = new System.Drawing.Size(83, 13);
            this.lbl50cpayer.TabIndex = 883;
            this.lbl50cpayer.Tag = "50cpayer";
            this.lbl50cpayer.Text = "50  Payer Name";
            // 
            // dcim50cpayer
            // 
            this.dcim50cpayer.Location = new System.Drawing.Point(32, 1077);
            this.dcim50cpayer.Name = "dcim50cpayer";
            this.dcim50cpayer.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim50cpayer.OcxState")));
            this.dcim50cpayer.Size = new System.Drawing.Size(156, 18);
            this.dcim50cpayer.TabIndex = 905;
            this.dcim50cpayer.TabStop = false;
            this.dcim50cpayer.Tag = "50cpayer";
            // 
            // dced50cpayer
            // 
            this.dced50cpayer.Location = new System.Drawing.Point(32, 1096);
            this.dced50cpayer.Name = "dced50cpayer";
            this.dced50cpayer.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced50cpayer.OcxState")));
            this.dced50cpayer.Size = new System.Drawing.Size(156, 18);
            this.dced50cpayer.TabIndex = 113;
            this.dced50cpayer.Tag = "50cpayer";
            // 
            // dcim51aprvno
            // 
            this.dcim51aprvno.Location = new System.Drawing.Point(201, 988);
            this.dcim51aprvno.Name = "dcim51aprvno";
            this.dcim51aprvno.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim51aprvno.OcxState")));
            this.dcim51aprvno.Size = new System.Drawing.Size(162, 18);
            this.dcim51aprvno.TabIndex = 887;
            this.dcim51aprvno.TabStop = false;
            this.dcim51aprvno.Tag = "51aprvno";
            // 
            // dced51aprvno
            // 
            this.dced51aprvno.Location = new System.Drawing.Point(201, 1007);
            this.dced51aprvno.Name = "dced51aprvno";
            this.dced51aprvno.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced51aprvno.OcxState")));
            this.dced51aprvno.Size = new System.Drawing.Size(162, 18);
            this.dced51aprvno.TabIndex = 106;
            this.dced51aprvno.Tag = "51aprvno";
            // 
            // dcim51bprvno
            // 
            this.dcim51bprvno.Location = new System.Drawing.Point(201, 1032);
            this.dcim51bprvno.Name = "dcim51bprvno";
            this.dcim51bprvno.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim51bprvno.OcxState")));
            this.dcim51bprvno.Size = new System.Drawing.Size(162, 18);
            this.dcim51bprvno.TabIndex = 897;
            this.dcim51bprvno.TabStop = false;
            this.dcim51bprvno.Tag = "51bprvno";
            // 
            // dced51bprvno
            // 
            this.dced51bprvno.Location = new System.Drawing.Point(201, 1051);
            this.dced51bprvno.Name = "dced51bprvno";
            this.dced51bprvno.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced51bprvno.OcxState")));
            this.dced51bprvno.Size = new System.Drawing.Size(162, 18);
            this.dced51bprvno.TabIndex = 110;
            this.dced51bprvno.Tag = "51bprvno";
            // 
            // lbl51cprvno
            // 
            this.lbl51cprvno.AutoSize = true;
            this.lbl51cprvno.BackColor = System.Drawing.Color.Lavender;
            this.lbl51cprvno.Location = new System.Drawing.Point(200, 975);
            this.lbl51cprvno.Name = "lbl51cprvno";
            this.lbl51cprvno.Size = new System.Drawing.Size(118, 13);
            this.lbl51cprvno.TabIndex = 886;
            this.lbl51cprvno.Tag = "51cprvno";
            this.lbl51cprvno.Text = "51  Provider ID Number";
            // 
            // dcim51cprvno
            // 
            this.dcim51cprvno.Location = new System.Drawing.Point(201, 1077);
            this.dcim51cprvno.Name = "dcim51cprvno";
            this.dcim51cprvno.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim51cprvno.OcxState")));
            this.dcim51cprvno.Size = new System.Drawing.Size(162, 18);
            this.dcim51cprvno.TabIndex = 907;
            this.dcim51cprvno.TabStop = false;
            this.dcim51cprvno.Tag = "51cprvno";
            // 
            // dced51cprvno
            // 
            this.dced51cprvno.Location = new System.Drawing.Point(201, 1096);
            this.dced51cprvno.Name = "dced51cprvno";
            this.dced51cprvno.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced51cprvno.OcxState")));
            this.dced51cprvno.Size = new System.Drawing.Size(162, 18);
            this.dced51cprvno.TabIndex = 114;
            this.dced51cprvno.Tag = "51cprvno";
            // 
            // lbl56npi
            // 
            this.lbl56npi.AutoSize = true;
            this.lbl56npi.Location = new System.Drawing.Point(859, 924);
            this.lbl56npi.Name = "lbl56npi";
            this.lbl56npi.Size = new System.Drawing.Size(40, 13);
            this.lbl56npi.TabIndex = 880;
            this.lbl56npi.Tag = "56npi";
            this.lbl56npi.Text = "56 NPI";
            // 
            // dcim56npi
            // 
            this.dcim56npi.Location = new System.Drawing.Point(900, 924);
            this.dcim56npi.Name = "dcim56npi";
            this.dcim56npi.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim56npi.OcxState")));
            this.dcim56npi.Size = new System.Drawing.Size(96, 18);
            this.dcim56npi.TabIndex = 881;
            this.dcim56npi.TabStop = false;
            this.dcim56npi.Tag = "56npi";
            // 
            // dced56npi
            // 
            this.dced56npi.Location = new System.Drawing.Point(900, 943);
            this.dced56npi.Name = "dced56npi";
            this.dced56npi.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced56npi.OcxState")));
            this.dced56npi.Size = new System.Drawing.Size(96, 18);
            this.dced56npi.TabIndex = 104;
            this.dced56npi.Tag = "56npi";
            // 
            // dcim58ainsnm
            // 
            this.dcim58ainsnm.Location = new System.Drawing.Point(627, 988);
            this.dcim58ainsnm.Name = "dcim58ainsnm";
            this.dcim58ainsnm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim58ainsnm.OcxState")));
            this.dcim58ainsnm.Size = new System.Drawing.Size(233, 18);
            this.dcim58ainsnm.TabIndex = 889;
            this.dcim58ainsnm.TabStop = false;
            this.dcim58ainsnm.Tag = "58ainsnm";
            // 
            // lbl58alname
            // 
            this.lbl58alname.AutoSize = true;
            this.lbl58alname.BackColor = System.Drawing.Color.Lavender;
            this.lbl58alname.Location = new System.Drawing.Point(21, 1188);
            this.lbl58alname.Name = "lbl58alname";
            this.lbl58alname.Size = new System.Drawing.Size(22, 26);
            this.lbl58alname.TabIndex = 915;
            this.lbl58alname.Tag = "58alname";
            this.lbl58alname.Text = "66\r\nDX";
            // 
            // dced58alname
            // 
            this.dced58alname.Location = new System.Drawing.Point(627, 1007);
            this.dced58alname.Name = "dced58alname";
            this.dced58alname.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced58alname.OcxState")));
            this.dced58alname.Size = new System.Drawing.Size(105, 18);
            this.dced58alname.TabIndex = 117;
            this.dced58alname.Tag = "58alname";
            // 
            // lbl58afname
            // 
            this.lbl58afname.AutoSize = true;
            this.lbl58afname.BackColor = System.Drawing.Color.Lavender;
            this.lbl58afname.Location = new System.Drawing.Point(50, 1255);
            this.lbl58afname.Name = "lbl58afname";
            this.lbl58afname.Size = new System.Drawing.Size(65, 13);
            this.lbl58afname.TabIndex = 916;
            this.lbl58afname.Tag = "58afname";
            this.lbl58afname.Text = "69 Admitting";
            // 
            // dced58afname
            // 
            this.dced58afname.Location = new System.Drawing.Point(733, 1007);
            this.dced58afname.Name = "dced58afname";
            this.dced58afname.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced58afname.OcxState")));
            this.dced58afname.Size = new System.Drawing.Size(95, 18);
            this.dced58afname.TabIndex = 118;
            this.dced58afname.Tag = "58afname";
            // 
            // lbl58aminit
            // 
            this.lbl58aminit.AutoSize = true;
            this.lbl58aminit.BackColor = System.Drawing.Color.Lavender;
            this.lbl58aminit.Location = new System.Drawing.Point(174, 1255);
            this.lbl58aminit.Name = "lbl58aminit";
            this.lbl58aminit.Size = new System.Drawing.Size(65, 13);
            this.lbl58aminit.TabIndex = 917;
            this.lbl58aminit.Tag = "58aminit";
            this.lbl58aminit.Text = "70a Reason";
            // 
            // dced58aminit
            // 
            this.dced58aminit.Location = new System.Drawing.Point(829, 1007);
            this.dced58aminit.Name = "dced58aminit";
            this.dced58aminit.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced58aminit.OcxState")));
            this.dced58aminit.Size = new System.Drawing.Size(31, 18);
            this.dced58aminit.TabIndex = 119;
            this.dced58aminit.Tag = "58aminit";
            // 
            // lbl58binsnm
            // 
            this.lbl58binsnm.AutoSize = true;
            this.lbl58binsnm.BackColor = System.Drawing.Color.Lavender;
            this.lbl58binsnm.Location = new System.Drawing.Point(624, 975);
            this.lbl58binsnm.Name = "lbl58binsnm";
            this.lbl58binsnm.Size = new System.Drawing.Size(198, 13);
            this.lbl58binsnm.TabIndex = 918;
            this.lbl58binsnm.Tag = "58binsnm";
            this.lbl58binsnm.Text = "58  Insured\'s Last Name, First Name , MI";
            // 
            // dcim58binsnm
            // 
            this.dcim58binsnm.Location = new System.Drawing.Point(627, 1034);
            this.dcim58binsnm.Name = "dcim58binsnm";
            this.dcim58binsnm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim58binsnm.OcxState")));
            this.dcim58binsnm.Size = new System.Drawing.Size(233, 18);
            this.dcim58binsnm.TabIndex = 899;
            this.dcim58binsnm.TabStop = false;
            this.dcim58binsnm.Tag = "58binsnm";
            // 
            // lbl58blname
            // 
            this.lbl58blname.AutoSize = true;
            this.lbl58blname.BackColor = System.Drawing.Color.Lavender;
            this.lbl58blname.Location = new System.Drawing.Point(250, 1255);
            this.lbl58blname.Name = "lbl58blname";
            this.lbl58blname.Size = new System.Drawing.Size(66, 13);
            this.lbl58blname.TabIndex = 919;
            this.lbl58blname.Tag = "58blname";
            this.lbl58blname.Text = "70B Reason";
            // 
            // dced58blname
            // 
            this.dced58blname.Location = new System.Drawing.Point(627, 1053);
            this.dced58blname.Name = "dced58blname";
            this.dced58blname.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced58blname.OcxState")));
            this.dced58blname.Size = new System.Drawing.Size(105, 18);
            this.dced58blname.TabIndex = 121;
            this.dced58blname.Tag = "58blname";
            // 
            // lbl58bfname
            // 
            this.lbl58bfname.AutoSize = true;
            this.lbl58bfname.BackColor = System.Drawing.Color.Lavender;
            this.lbl58bfname.Location = new System.Drawing.Point(325, 1255);
            this.lbl58bfname.Name = "lbl58bfname";
            this.lbl58bfname.Size = new System.Drawing.Size(66, 13);
            this.lbl58bfname.TabIndex = 920;
            this.lbl58bfname.Tag = "58bfname";
            this.lbl58bfname.Text = "70C Reason";
            // 
            // dced58bfname
            // 
            this.dced58bfname.Location = new System.Drawing.Point(733, 1053);
            this.dced58bfname.Name = "dced58bfname";
            this.dced58bfname.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced58bfname.OcxState")));
            this.dced58bfname.Size = new System.Drawing.Size(95, 18);
            this.dced58bfname.TabIndex = 122;
            this.dced58bfname.Tag = "58bfname";
            // 
            // lbl58bminit
            // 
            this.lbl58bminit.AutoSize = true;
            this.lbl58bminit.BackColor = System.Drawing.Color.Lavender;
            this.lbl58bminit.Location = new System.Drawing.Point(428, 1255);
            this.lbl58bminit.Name = "lbl58bminit";
            this.lbl58bminit.Size = new System.Drawing.Size(72, 13);
            this.lbl58bminit.TabIndex = 921;
            this.lbl58bminit.Tag = "58bminit";
            this.lbl58bminit.Text = "71 PPS/DRG";
            // 
            // dced58bminit
            // 
            this.dced58bminit.Location = new System.Drawing.Point(829, 1053);
            this.dced58bminit.Name = "dced58bminit";
            this.dced58bminit.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced58bminit.OcxState")));
            this.dced58bminit.Size = new System.Drawing.Size(31, 18);
            this.dced58bminit.TabIndex = 123;
            this.dced58bminit.Tag = "58bminit";
            // 
            // dcim58cinsnm
            // 
            this.dcim58cinsnm.Location = new System.Drawing.Point(627, 1079);
            this.dcim58cinsnm.Name = "dcim58cinsnm";
            this.dcim58cinsnm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim58cinsnm.OcxState")));
            this.dcim58cinsnm.Size = new System.Drawing.Size(233, 18);
            this.dcim58cinsnm.TabIndex = 909;
            this.dcim58cinsnm.TabStop = false;
            this.dcim58cinsnm.Tag = "58cinsnm";
            // 
            // lbl58clname
            // 
            this.lbl58clname.AutoSize = true;
            this.lbl58clname.BackColor = System.Drawing.Color.Lavender;
            this.lbl58clname.Location = new System.Drawing.Point(596, 1255);
            this.lbl58clname.Name = "lbl58clname";
            this.lbl58clname.Size = new System.Drawing.Size(74, 13);
            this.lbl58clname.TabIndex = 922;
            this.lbl58clname.Tag = "58clname";
            this.lbl58clname.Text = "72a EDI Code";
            // 
            // dced58clname
            // 
            this.dced58clname.Location = new System.Drawing.Point(627, 1098);
            this.dced58clname.Name = "dced58clname";
            this.dced58clname.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced58clname.OcxState")));
            this.dced58clname.Size = new System.Drawing.Size(105, 18);
            this.dced58clname.TabIndex = 125;
            this.dced58clname.Tag = "58clname";
            // 
            // dced58cfname
            // 
            this.dced58cfname.Location = new System.Drawing.Point(733, 1098);
            this.dced58cfname.Name = "dced58cfname";
            this.dced58cfname.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced58cfname.OcxState")));
            this.dced58cfname.Size = new System.Drawing.Size(95, 18);
            this.dced58cfname.TabIndex = 126;
            this.dced58cfname.Tag = "58cfname";
            // 
            // dced58cminit
            // 
            this.dced58cminit.Location = new System.Drawing.Point(829, 1098);
            this.dced58cminit.Name = "dced58cminit";
            this.dced58cminit.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced58cminit.OcxState")));
            this.dced58cminit.Size = new System.Drawing.Size(31, 18);
            this.dced58cminit.TabIndex = 127;
            this.dced58cminit.Tag = "58cminit";
            // 
            // dcim60acshi
            // 
            this.dcim60acshi.Location = new System.Drawing.Point(874, 988);
            this.dcim60acshi.Name = "dcim60acshi";
            this.dcim60acshi.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim60acshi.OcxState")));
            this.dcim60acshi.Size = new System.Drawing.Size(122, 18);
            this.dcim60acshi.TabIndex = 893;
            this.dcim60acshi.TabStop = false;
            this.dcim60acshi.Tag = "60acshi";
            // 
            // dced60acshi
            // 
            this.dced60acshi.Location = new System.Drawing.Point(874, 1007);
            this.dced60acshi.Name = "dced60acshi";
            this.dced60acshi.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced60acshi.OcxState")));
            this.dced60acshi.Size = new System.Drawing.Size(122, 18);
            this.dced60acshi.TabIndex = 120;
            this.dced60acshi.Tag = "60acshi";
            // 
            // dcim60bcshi
            // 
            this.dcim60bcshi.Location = new System.Drawing.Point(874, 1032);
            this.dcim60bcshi.Name = "dcim60bcshi";
            this.dcim60bcshi.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim60bcshi.OcxState")));
            this.dcim60bcshi.Size = new System.Drawing.Size(122, 18);
            this.dcim60bcshi.TabIndex = 903;
            this.dcim60bcshi.TabStop = false;
            this.dcim60bcshi.Tag = "60bcshi";
            // 
            // dced60bcshi
            // 
            this.dced60bcshi.Location = new System.Drawing.Point(874, 1051);
            this.dced60bcshi.Name = "dced60bcshi";
            this.dced60bcshi.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced60bcshi.OcxState")));
            this.dced60bcshi.Size = new System.Drawing.Size(122, 18);
            this.dced60bcshi.TabIndex = 124;
            this.dced60bcshi.Tag = "60bcshi";
            // 
            // lbl60ccshi
            // 
            this.lbl60ccshi.AutoSize = true;
            this.lbl60ccshi.BackColor = System.Drawing.Color.Lavender;
            this.lbl60ccshi.Location = new System.Drawing.Point(872, 975);
            this.lbl60ccshi.Name = "lbl60ccshi";
            this.lbl60ccshi.Size = new System.Drawing.Size(115, 13);
            this.lbl60ccshi.TabIndex = 923;
            this.lbl60ccshi.Tag = "60ccshi";
            this.lbl60ccshi.Text = "60 Insured\'s Unique ID";
            // 
            // dcim60ccshi
            // 
            this.dcim60ccshi.Location = new System.Drawing.Point(874, 1079);
            this.dcim60ccshi.Name = "dcim60ccshi";
            this.dcim60ccshi.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim60ccshi.OcxState")));
            this.dcim60ccshi.Size = new System.Drawing.Size(122, 18);
            this.dcim60ccshi.TabIndex = 913;
            this.dcim60ccshi.TabStop = false;
            this.dcim60ccshi.Tag = "60ccshi";
            // 
            // dced60ccshi
            // 
            this.dced60ccshi.Location = new System.Drawing.Point(874, 1098);
            this.dced60ccshi.Name = "dced60ccshi";
            this.dced60ccshi.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced60ccshi.OcxState")));
            this.dced60ccshi.Size = new System.Drawing.Size(122, 18);
            this.dced60ccshi.TabIndex = 128;
            this.dced60ccshi.Tag = "60ccshi";
            // 
            // dcim66dxverq
            // 
            this.dcim66dxverq.Location = new System.Drawing.Point(23, 1214);
            this.dcim66dxverq.Name = "dcim66dxverq";
            this.dcim66dxverq.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim66dxverq.OcxState")));
            this.dcim66dxverq.Size = new System.Drawing.Size(20, 18);
            this.dcim66dxverq.TabIndex = 924;
            this.dcim66dxverq.TabStop = false;
            this.dcim66dxverq.Tag = "66dxverq";
            // 
            // dced66dxverq
            // 
            this.dced66dxverq.Location = new System.Drawing.Point(23, 1233);
            this.dced66dxverq.Name = "dced66dxverq";
            this.dced66dxverq.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced66dxverq.OcxState")));
            this.dced66dxverq.Size = new System.Drawing.Size(20, 18);
            this.dced66dxverq.TabIndex = 129;
            this.dced66dxverq.Tag = "66dxverq";
            // 
            // lbl67prdgcd
            // 
            this.lbl67prdgcd.AutoSize = true;
            this.lbl67prdgcd.BackColor = System.Drawing.Color.Lavender;
            this.lbl67prdgcd.Location = new System.Drawing.Point(52, 1147);
            this.lbl67prdgcd.Name = "lbl67prdgcd";
            this.lbl67prdgcd.Size = new System.Drawing.Size(62, 13);
            this.lbl67prdgcd.TabIndex = 926;
            this.lbl67prdgcd.Tag = "67prdgcd";
            this.lbl67prdgcd.Text = "67 Principle";
            // 
            // dcim67prdgcd
            // 
            this.dcim67prdgcd.Location = new System.Drawing.Point(49, 1160);
            this.dcim67prdgcd.Name = "dcim67prdgcd";
            this.dcim67prdgcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim67prdgcd.OcxState")));
            this.dcim67prdgcd.Size = new System.Drawing.Size(69, 18);
            this.dcim67prdgcd.TabIndex = 927;
            this.dcim67prdgcd.TabStop = false;
            this.dcim67prdgcd.Tag = "67prdgcd";
            // 
            // dced67prdgcd
            // 
            this.dced67prdgcd.Location = new System.Drawing.Point(49, 1179);
            this.dced67prdgcd.Name = "dced67prdgcd";
            this.dced67prdgcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced67prdgcd.OcxState")));
            this.dced67prdgcd.Size = new System.Drawing.Size(69, 18);
            this.dced67prdgcd.TabIndex = 130;
            this.dced67prdgcd.Tag = "67prdgcd";
            // 
            // lbl67aothdg
            // 
            this.lbl67aothdg.AutoSize = true;
            this.lbl67aothdg.BackColor = System.Drawing.Color.Lavender;
            this.lbl67aothdg.Location = new System.Drawing.Point(143, 1147);
            this.lbl67aothdg.Name = "lbl67aothdg";
            this.lbl67aothdg.Size = new System.Drawing.Size(28, 13);
            this.lbl67aothdg.TabIndex = 929;
            this.lbl67aothdg.Tag = "67aothdg";
            this.lbl67aothdg.Text = "67 a";
            // 
            // dcim67aothdg
            // 
            this.dcim67aothdg.Location = new System.Drawing.Point(140, 1160);
            this.dcim67aothdg.Name = "dcim67aothdg";
            this.dcim67aothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim67aothdg.OcxState")));
            this.dcim67aothdg.Size = new System.Drawing.Size(69, 18);
            this.dcim67aothdg.TabIndex = 930;
            this.dcim67aothdg.TabStop = false;
            this.dcim67aothdg.Tag = "67aothdg";
            // 
            // dced67aothdg
            // 
            this.dced67aothdg.Location = new System.Drawing.Point(140, 1179);
            this.dced67aothdg.Name = "dced67aothdg";
            this.dced67aothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced67aothdg.OcxState")));
            this.dced67aothdg.Size = new System.Drawing.Size(69, 18);
            this.dced67aothdg.TabIndex = 132;
            this.dced67aothdg.Tag = "67aothdg";
            // 
            // lbl67bothdg
            // 
            this.lbl67bothdg.AutoSize = true;
            this.lbl67bothdg.BackColor = System.Drawing.Color.Lavender;
            this.lbl67bothdg.Location = new System.Drawing.Point(234, 1147);
            this.lbl67bothdg.Name = "lbl67bothdg";
            this.lbl67bothdg.Size = new System.Drawing.Size(28, 13);
            this.lbl67bothdg.TabIndex = 932;
            this.lbl67bothdg.Tag = "67bothdg";
            this.lbl67bothdg.Text = "67 b";
            // 
            // dcim67bothdg
            // 
            this.dcim67bothdg.Location = new System.Drawing.Point(231, 1160);
            this.dcim67bothdg.Name = "dcim67bothdg";
            this.dcim67bothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim67bothdg.OcxState")));
            this.dcim67bothdg.Size = new System.Drawing.Size(69, 18);
            this.dcim67bothdg.TabIndex = 933;
            this.dcim67bothdg.TabStop = false;
            this.dcim67bothdg.Tag = "67bothdg";
            // 
            // dced67bothdg
            // 
            this.dced67bothdg.Location = new System.Drawing.Point(231, 1179);
            this.dced67bothdg.Name = "dced67bothdg";
            this.dced67bothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced67bothdg.OcxState")));
            this.dced67bothdg.Size = new System.Drawing.Size(69, 18);
            this.dced67bothdg.TabIndex = 134;
            this.dced67bothdg.Tag = "67bothdg";
            // 
            // lbl67cothdg
            // 
            this.lbl67cothdg.AutoSize = true;
            this.lbl67cothdg.BackColor = System.Drawing.Color.Lavender;
            this.lbl67cothdg.Location = new System.Drawing.Point(325, 1147);
            this.lbl67cothdg.Name = "lbl67cothdg";
            this.lbl67cothdg.Size = new System.Drawing.Size(28, 13);
            this.lbl67cothdg.TabIndex = 935;
            this.lbl67cothdg.Tag = "67cothdg";
            this.lbl67cothdg.Text = "67 c";
            // 
            // dcim67cothdg
            // 
            this.dcim67cothdg.Location = new System.Drawing.Point(322, 1160);
            this.dcim67cothdg.Name = "dcim67cothdg";
            this.dcim67cothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim67cothdg.OcxState")));
            this.dcim67cothdg.Size = new System.Drawing.Size(69, 18);
            this.dcim67cothdg.TabIndex = 936;
            this.dcim67cothdg.TabStop = false;
            this.dcim67cothdg.Tag = "67cothdg";
            // 
            // dced67cothdg
            // 
            this.dced67cothdg.Location = new System.Drawing.Point(322, 1179);
            this.dced67cothdg.Name = "dced67cothdg";
            this.dced67cothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced67cothdg.OcxState")));
            this.dced67cothdg.Size = new System.Drawing.Size(69, 18);
            this.dced67cothdg.TabIndex = 136;
            this.dced67cothdg.Tag = "67cothdg";
            // 
            // lbl67dothdg
            // 
            this.lbl67dothdg.AutoSize = true;
            this.lbl67dothdg.BackColor = System.Drawing.Color.Lavender;
            this.lbl67dothdg.Location = new System.Drawing.Point(414, 1147);
            this.lbl67dothdg.Name = "lbl67dothdg";
            this.lbl67dothdg.Size = new System.Drawing.Size(28, 13);
            this.lbl67dothdg.TabIndex = 938;
            this.lbl67dothdg.Tag = "67dothdg";
            this.lbl67dothdg.Text = "67 d";
            // 
            // dcim67dothdg
            // 
            this.dcim67dothdg.Location = new System.Drawing.Point(413, 1160);
            this.dcim67dothdg.Name = "dcim67dothdg";
            this.dcim67dothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim67dothdg.OcxState")));
            this.dcim67dothdg.Size = new System.Drawing.Size(69, 18);
            this.dcim67dothdg.TabIndex = 939;
            this.dcim67dothdg.TabStop = false;
            this.dcim67dothdg.Tag = "67dothdg";
            // 
            // dced67dothdg
            // 
            this.dced67dothdg.Location = new System.Drawing.Point(413, 1179);
            this.dced67dothdg.Name = "dced67dothdg";
            this.dced67dothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced67dothdg.OcxState")));
            this.dced67dothdg.Size = new System.Drawing.Size(69, 18);
            this.dced67dothdg.TabIndex = 138;
            this.dced67dothdg.Tag = "67dothdg";
            // 
            // lbl67eothdg
            // 
            this.lbl67eothdg.AutoSize = true;
            this.lbl67eothdg.BackColor = System.Drawing.Color.Lavender;
            this.lbl67eothdg.Location = new System.Drawing.Point(508, 1147);
            this.lbl67eothdg.Name = "lbl67eothdg";
            this.lbl67eothdg.Size = new System.Drawing.Size(28, 13);
            this.lbl67eothdg.TabIndex = 941;
            this.lbl67eothdg.Tag = "67eothdg";
            this.lbl67eothdg.Text = "67 e";
            // 
            // dcim67eothdg
            // 
            this.dcim67eothdg.Location = new System.Drawing.Point(505, 1160);
            this.dcim67eothdg.Name = "dcim67eothdg";
            this.dcim67eothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim67eothdg.OcxState")));
            this.dcim67eothdg.Size = new System.Drawing.Size(69, 18);
            this.dcim67eothdg.TabIndex = 942;
            this.dcim67eothdg.TabStop = false;
            this.dcim67eothdg.Tag = "67eothdg";
            // 
            // dced67eothdg
            // 
            this.dced67eothdg.Location = new System.Drawing.Point(505, 1179);
            this.dced67eothdg.Name = "dced67eothdg";
            this.dced67eothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced67eothdg.OcxState")));
            this.dced67eothdg.Size = new System.Drawing.Size(69, 18);
            this.dced67eothdg.TabIndex = 140;
            this.dced67eothdg.Tag = "67eothdg";
            // 
            // lbl67fothdg
            // 
            this.lbl67fothdg.AutoSize = true;
            this.lbl67fothdg.BackColor = System.Drawing.Color.Lavender;
            this.lbl67fothdg.Location = new System.Drawing.Point(598, 1147);
            this.lbl67fothdg.Name = "lbl67fothdg";
            this.lbl67fothdg.Size = new System.Drawing.Size(25, 13);
            this.lbl67fothdg.TabIndex = 944;
            this.lbl67fothdg.Tag = "67fothdg";
            this.lbl67fothdg.Text = "67 f";
            // 
            // dcim67fothdg
            // 
            this.dcim67fothdg.Location = new System.Drawing.Point(596, 1160);
            this.dcim67fothdg.Name = "dcim67fothdg";
            this.dcim67fothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim67fothdg.OcxState")));
            this.dcim67fothdg.Size = new System.Drawing.Size(69, 18);
            this.dcim67fothdg.TabIndex = 945;
            this.dcim67fothdg.TabStop = false;
            this.dcim67fothdg.Tag = "67fothdg";
            // 
            // dced67fothdg
            // 
            this.dced67fothdg.Location = new System.Drawing.Point(596, 1179);
            this.dced67fothdg.Name = "dced67fothdg";
            this.dced67fothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced67fothdg.OcxState")));
            this.dced67fothdg.Size = new System.Drawing.Size(69, 18);
            this.dced67fothdg.TabIndex = 142;
            this.dced67fothdg.Tag = "67fothdg";
            // 
            // lbl67gothdg
            // 
            this.lbl67gothdg.AutoSize = true;
            this.lbl67gothdg.BackColor = System.Drawing.Color.Lavender;
            this.lbl67gothdg.Location = new System.Drawing.Point(689, 1147);
            this.lbl67gothdg.Name = "lbl67gothdg";
            this.lbl67gothdg.Size = new System.Drawing.Size(28, 13);
            this.lbl67gothdg.TabIndex = 947;
            this.lbl67gothdg.Tag = "67gothdg";
            this.lbl67gothdg.Text = "67 g";
            // 
            // dcim67gothdg
            // 
            this.dcim67gothdg.Location = new System.Drawing.Point(687, 1160);
            this.dcim67gothdg.Name = "dcim67gothdg";
            this.dcim67gothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim67gothdg.OcxState")));
            this.dcim67gothdg.Size = new System.Drawing.Size(69, 18);
            this.dcim67gothdg.TabIndex = 948;
            this.dcim67gothdg.TabStop = false;
            this.dcim67gothdg.Tag = "67gothdg";
            // 
            // dced67gothdg
            // 
            this.dced67gothdg.Location = new System.Drawing.Point(687, 1179);
            this.dced67gothdg.Name = "dced67gothdg";
            this.dced67gothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced67gothdg.OcxState")));
            this.dced67gothdg.Size = new System.Drawing.Size(69, 18);
            this.dced67gothdg.TabIndex = 144;
            this.dced67gothdg.Tag = "67gothdg";
            // 
            // lbl67hothdg
            // 
            this.lbl67hothdg.AutoSize = true;
            this.lbl67hothdg.BackColor = System.Drawing.Color.Lavender;
            this.lbl67hothdg.Location = new System.Drawing.Point(780, 1147);
            this.lbl67hothdg.Name = "lbl67hothdg";
            this.lbl67hothdg.Size = new System.Drawing.Size(28, 13);
            this.lbl67hothdg.TabIndex = 950;
            this.lbl67hothdg.Tag = "67hothdg";
            this.lbl67hothdg.Text = "67 h";
            // 
            // dcim67hothdg
            // 
            this.dcim67hothdg.Location = new System.Drawing.Point(778, 1160);
            this.dcim67hothdg.Name = "dcim67hothdg";
            this.dcim67hothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim67hothdg.OcxState")));
            this.dcim67hothdg.Size = new System.Drawing.Size(69, 18);
            this.dcim67hothdg.TabIndex = 951;
            this.dcim67hothdg.TabStop = false;
            this.dcim67hothdg.Tag = "67hothdg";
            // 
            // dced67hothdg
            // 
            this.dced67hothdg.Location = new System.Drawing.Point(778, 1179);
            this.dced67hothdg.Name = "dced67hothdg";
            this.dced67hothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced67hothdg.OcxState")));
            this.dced67hothdg.Size = new System.Drawing.Size(69, 18);
            this.dced67hothdg.TabIndex = 146;
            this.dced67hothdg.Tag = "67hothdg";
            // 
            // lbl67iothdg
            // 
            this.lbl67iothdg.AutoSize = true;
            this.lbl67iothdg.BackColor = System.Drawing.Color.Lavender;
            this.lbl67iothdg.Location = new System.Drawing.Point(63, 1201);
            this.lbl67iothdg.Name = "lbl67iothdg";
            this.lbl67iothdg.Size = new System.Drawing.Size(24, 13);
            this.lbl67iothdg.TabIndex = 953;
            this.lbl67iothdg.Tag = "67iothdg";
            this.lbl67iothdg.Text = "67 i";
            // 
            // dcim67iothdg
            // 
            this.dcim67iothdg.Location = new System.Drawing.Point(49, 1214);
            this.dcim67iothdg.Name = "dcim67iothdg";
            this.dcim67iothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim67iothdg.OcxState")));
            this.dcim67iothdg.Size = new System.Drawing.Size(69, 18);
            this.dcim67iothdg.TabIndex = 954;
            this.dcim67iothdg.TabStop = false;
            this.dcim67iothdg.Tag = "67iothdg";
            // 
            // dced67iothdg
            // 
            this.dced67iothdg.Location = new System.Drawing.Point(49, 1233);
            this.dced67iothdg.Name = "dced67iothdg";
            this.dced67iothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced67iothdg.OcxState")));
            this.dced67iothdg.Size = new System.Drawing.Size(69, 18);
            this.dced67iothdg.TabIndex = 148;
            this.dced67iothdg.Tag = "67iothdg";
            // 
            // lbl67jothdg
            // 
            this.lbl67jothdg.AutoSize = true;
            this.lbl67jothdg.BackColor = System.Drawing.Color.Lavender;
            this.lbl67jothdg.Location = new System.Drawing.Point(143, 1201);
            this.lbl67jothdg.Name = "lbl67jothdg";
            this.lbl67jothdg.Size = new System.Drawing.Size(24, 13);
            this.lbl67jothdg.TabIndex = 956;
            this.lbl67jothdg.Tag = "67jothdg";
            this.lbl67jothdg.Text = "67 j";
            // 
            // dcim67jothdg
            // 
            this.dcim67jothdg.Location = new System.Drawing.Point(140, 1214);
            this.dcim67jothdg.Name = "dcim67jothdg";
            this.dcim67jothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim67jothdg.OcxState")));
            this.dcim67jothdg.Size = new System.Drawing.Size(69, 18);
            this.dcim67jothdg.TabIndex = 957;
            this.dcim67jothdg.TabStop = false;
            this.dcim67jothdg.Tag = "67jothdg";
            // 
            // dced67jothdg
            // 
            this.dced67jothdg.Location = new System.Drawing.Point(140, 1233);
            this.dced67jothdg.Name = "dced67jothdg";
            this.dced67jothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced67jothdg.OcxState")));
            this.dced67jothdg.Size = new System.Drawing.Size(69, 18);
            this.dced67jothdg.TabIndex = 150;
            this.dced67jothdg.Tag = "67jothdg";
            // 
            // lbl67kothdg
            // 
            this.lbl67kothdg.AutoSize = true;
            this.lbl67kothdg.BackColor = System.Drawing.Color.Lavender;
            this.lbl67kothdg.Location = new System.Drawing.Point(233, 1201);
            this.lbl67kothdg.Name = "lbl67kothdg";
            this.lbl67kothdg.Size = new System.Drawing.Size(28, 13);
            this.lbl67kothdg.TabIndex = 959;
            this.lbl67kothdg.Tag = "67kothdg";
            this.lbl67kothdg.Text = "67 k";
            // 
            // dcim67kothdg
            // 
            this.dcim67kothdg.Location = new System.Drawing.Point(231, 1214);
            this.dcim67kothdg.Name = "dcim67kothdg";
            this.dcim67kothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim67kothdg.OcxState")));
            this.dcim67kothdg.Size = new System.Drawing.Size(69, 18);
            this.dcim67kothdg.TabIndex = 960;
            this.dcim67kothdg.TabStop = false;
            this.dcim67kothdg.Tag = "67kothdg";
            // 
            // dced67kothdg
            // 
            this.dced67kothdg.Location = new System.Drawing.Point(231, 1233);
            this.dced67kothdg.Name = "dced67kothdg";
            this.dced67kothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced67kothdg.OcxState")));
            this.dced67kothdg.Size = new System.Drawing.Size(69, 18);
            this.dced67kothdg.TabIndex = 152;
            this.dced67kothdg.Tag = "67kothdg";
            // 
            // lbl67lothdg
            // 
            this.lbl67lothdg.AutoSize = true;
            this.lbl67lothdg.BackColor = System.Drawing.Color.Lavender;
            this.lbl67lothdg.Location = new System.Drawing.Point(324, 1201);
            this.lbl67lothdg.Name = "lbl67lothdg";
            this.lbl67lothdg.Size = new System.Drawing.Size(24, 13);
            this.lbl67lothdg.TabIndex = 962;
            this.lbl67lothdg.Tag = "67lothdg";
            this.lbl67lothdg.Text = "67 l";
            // 
            // dcim67lothdg
            // 
            this.dcim67lothdg.Location = new System.Drawing.Point(322, 1214);
            this.dcim67lothdg.Name = "dcim67lothdg";
            this.dcim67lothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim67lothdg.OcxState")));
            this.dcim67lothdg.Size = new System.Drawing.Size(69, 18);
            this.dcim67lothdg.TabIndex = 963;
            this.dcim67lothdg.TabStop = false;
            this.dcim67lothdg.Tag = "67lothdg";
            // 
            // dced67lothdg
            // 
            this.dced67lothdg.Location = new System.Drawing.Point(322, 1233);
            this.dced67lothdg.Name = "dced67lothdg";
            this.dced67lothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced67lothdg.OcxState")));
            this.dced67lothdg.Size = new System.Drawing.Size(69, 18);
            this.dced67lothdg.TabIndex = 154;
            this.dced67lothdg.Tag = "67lothdg";
            // 
            // lbl67mothdg
            // 
            this.lbl67mothdg.AutoSize = true;
            this.lbl67mothdg.BackColor = System.Drawing.Color.Lavender;
            this.lbl67mothdg.Location = new System.Drawing.Point(416, 1201);
            this.lbl67mothdg.Name = "lbl67mothdg";
            this.lbl67mothdg.Size = new System.Drawing.Size(30, 13);
            this.lbl67mothdg.TabIndex = 965;
            this.lbl67mothdg.Tag = "67mothdg";
            this.lbl67mothdg.Text = "67 m";
            // 
            // dcim67mothdg
            // 
            this.dcim67mothdg.Location = new System.Drawing.Point(413, 1214);
            this.dcim67mothdg.Name = "dcim67mothdg";
            this.dcim67mothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim67mothdg.OcxState")));
            this.dcim67mothdg.Size = new System.Drawing.Size(69, 18);
            this.dcim67mothdg.TabIndex = 966;
            this.dcim67mothdg.TabStop = false;
            this.dcim67mothdg.Tag = "67mothdg";
            // 
            // dced67mothdg
            // 
            this.dced67mothdg.Location = new System.Drawing.Point(413, 1233);
            this.dced67mothdg.Name = "dced67mothdg";
            this.dced67mothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced67mothdg.OcxState")));
            this.dced67mothdg.Size = new System.Drawing.Size(69, 18);
            this.dced67mothdg.TabIndex = 156;
            this.dced67mothdg.Tag = "67mothdg";
            // 
            // lbl67nothdg
            // 
            this.lbl67nothdg.AutoSize = true;
            this.lbl67nothdg.BackColor = System.Drawing.Color.Lavender;
            this.lbl67nothdg.Location = new System.Drawing.Point(507, 1201);
            this.lbl67nothdg.Name = "lbl67nothdg";
            this.lbl67nothdg.Size = new System.Drawing.Size(28, 13);
            this.lbl67nothdg.TabIndex = 968;
            this.lbl67nothdg.Tag = "67nothdg";
            this.lbl67nothdg.Text = "67 n";
            // 
            // dcim67nothdg
            // 
            this.dcim67nothdg.Location = new System.Drawing.Point(505, 1214);
            this.dcim67nothdg.Name = "dcim67nothdg";
            this.dcim67nothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim67nothdg.OcxState")));
            this.dcim67nothdg.Size = new System.Drawing.Size(69, 18);
            this.dcim67nothdg.TabIndex = 969;
            this.dcim67nothdg.TabStop = false;
            this.dcim67nothdg.Tag = "67nothdg";
            // 
            // dced67nothdg
            // 
            this.dced67nothdg.Location = new System.Drawing.Point(505, 1233);
            this.dced67nothdg.Name = "dced67nothdg";
            this.dced67nothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced67nothdg.OcxState")));
            this.dced67nothdg.Size = new System.Drawing.Size(69, 18);
            this.dced67nothdg.TabIndex = 158;
            this.dced67nothdg.Tag = "67nothdg";
            // 
            // lbl67oothdg
            // 
            this.lbl67oothdg.AutoSize = true;
            this.lbl67oothdg.BackColor = System.Drawing.Color.Lavender;
            this.lbl67oothdg.Location = new System.Drawing.Point(598, 1201);
            this.lbl67oothdg.Name = "lbl67oothdg";
            this.lbl67oothdg.Size = new System.Drawing.Size(28, 13);
            this.lbl67oothdg.TabIndex = 971;
            this.lbl67oothdg.Tag = "67oothdg";
            this.lbl67oothdg.Text = "67 o";
            // 
            // dcim67oothdg
            // 
            this.dcim67oothdg.Location = new System.Drawing.Point(596, 1214);
            this.dcim67oothdg.Name = "dcim67oothdg";
            this.dcim67oothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim67oothdg.OcxState")));
            this.dcim67oothdg.Size = new System.Drawing.Size(69, 18);
            this.dcim67oothdg.TabIndex = 972;
            this.dcim67oothdg.TabStop = false;
            this.dcim67oothdg.Tag = "67oothdg";
            // 
            // dced67oothdg
            // 
            this.dced67oothdg.Location = new System.Drawing.Point(596, 1233);
            this.dced67oothdg.Name = "dced67oothdg";
            this.dced67oothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced67oothdg.OcxState")));
            this.dced67oothdg.Size = new System.Drawing.Size(69, 18);
            this.dced67oothdg.TabIndex = 160;
            this.dced67oothdg.Tag = "67oothdg";
            // 
            // lbl67pothdg
            // 
            this.lbl67pothdg.AutoSize = true;
            this.lbl67pothdg.BackColor = System.Drawing.Color.Lavender;
            this.lbl67pothdg.Location = new System.Drawing.Point(690, 1201);
            this.lbl67pothdg.Name = "lbl67pothdg";
            this.lbl67pothdg.Size = new System.Drawing.Size(28, 13);
            this.lbl67pothdg.TabIndex = 974;
            this.lbl67pothdg.Tag = "67pothdg";
            this.lbl67pothdg.Text = "67 p";
            // 
            // dcim67pothdg
            // 
            this.dcim67pothdg.Location = new System.Drawing.Point(687, 1214);
            this.dcim67pothdg.Name = "dcim67pothdg";
            this.dcim67pothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim67pothdg.OcxState")));
            this.dcim67pothdg.Size = new System.Drawing.Size(69, 18);
            this.dcim67pothdg.TabIndex = 975;
            this.dcim67pothdg.TabStop = false;
            this.dcim67pothdg.Tag = "67pothdg";
            // 
            // dced67pothdg
            // 
            this.dced67pothdg.Location = new System.Drawing.Point(687, 1233);
            this.dced67pothdg.Name = "dced67pothdg";
            this.dced67pothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced67pothdg.OcxState")));
            this.dced67pothdg.Size = new System.Drawing.Size(69, 18);
            this.dced67pothdg.TabIndex = 161;
            this.dced67pothdg.Tag = "67pothdg";
            // 
            // lbl67qothdg
            // 
            this.lbl67qothdg.AutoSize = true;
            this.lbl67qothdg.BackColor = System.Drawing.Color.Lavender;
            this.lbl67qothdg.Location = new System.Drawing.Point(780, 1201);
            this.lbl67qothdg.Name = "lbl67qothdg";
            this.lbl67qothdg.Size = new System.Drawing.Size(28, 13);
            this.lbl67qothdg.TabIndex = 977;
            this.lbl67qothdg.Tag = "67qothdg";
            this.lbl67qothdg.Text = "67 q";
            // 
            // dcim67qothdg
            // 
            this.dcim67qothdg.Location = new System.Drawing.Point(778, 1214);
            this.dcim67qothdg.Name = "dcim67qothdg";
            this.dcim67qothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim67qothdg.OcxState")));
            this.dcim67qothdg.Size = new System.Drawing.Size(69, 18);
            this.dcim67qothdg.TabIndex = 978;
            this.dcim67qothdg.TabStop = false;
            this.dcim67qothdg.Tag = "67qothdg";
            // 
            // dced67qothdg
            // 
            this.dced67qothdg.Location = new System.Drawing.Point(778, 1233);
            this.dced67qothdg.Name = "dced67qothdg";
            this.dced67qothdg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced67qothdg.OcxState")));
            this.dced67qothdg.Size = new System.Drawing.Size(69, 18);
            this.dced67qothdg.TabIndex = 163;
            this.dced67qothdg.Tag = "67qothdg";
            // 
            // dcim69amdgcd
            // 
            this.dcim69amdgcd.Location = new System.Drawing.Point(49, 1268);
            this.dcim69amdgcd.Name = "dcim69amdgcd";
            this.dcim69amdgcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim69amdgcd.OcxState")));
            this.dcim69amdgcd.Size = new System.Drawing.Size(69, 18);
            this.dcim69amdgcd.TabIndex = 980;
            this.dcim69amdgcd.TabStop = false;
            this.dcim69amdgcd.Tag = "69amdgcd";
            // 
            // dced69amdgcd
            // 
            this.dced69amdgcd.Location = new System.Drawing.Point(49, 1287);
            this.dced69amdgcd.Name = "dced69amdgcd";
            this.dced69amdgcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced69amdgcd.OcxState")));
            this.dced69amdgcd.Size = new System.Drawing.Size(69, 18);
            this.dced69amdgcd.TabIndex = 165;
            this.dced69amdgcd.Tag = "69amdgcd";
            // 
            // dcim70arfvcd
            // 
            this.dcim70arfvcd.Location = new System.Drawing.Point(172, 1268);
            this.dcim70arfvcd.Name = "dcim70arfvcd";
            this.dcim70arfvcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim70arfvcd.OcxState")));
            this.dcim70arfvcd.Size = new System.Drawing.Size(69, 18);
            this.dcim70arfvcd.TabIndex = 982;
            this.dcim70arfvcd.TabStop = false;
            this.dcim70arfvcd.Tag = "70arfvcd";
            // 
            // dced70arfvcd
            // 
            this.dced70arfvcd.Location = new System.Drawing.Point(172, 1287);
            this.dced70arfvcd.Name = "dced70arfvcd";
            this.dced70arfvcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced70arfvcd.OcxState")));
            this.dced70arfvcd.Size = new System.Drawing.Size(69, 18);
            this.dced70arfvcd.TabIndex = 166;
            this.dced70arfvcd.Tag = "70arfvcd";
            // 
            // dcim70brfvcd
            // 
            this.dcim70brfvcd.Location = new System.Drawing.Point(247, 1268);
            this.dcim70brfvcd.Name = "dcim70brfvcd";
            this.dcim70brfvcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim70brfvcd.OcxState")));
            this.dcim70brfvcd.Size = new System.Drawing.Size(69, 18);
            this.dcim70brfvcd.TabIndex = 984;
            this.dcim70brfvcd.TabStop = false;
            this.dcim70brfvcd.Tag = "70brfvcd";
            // 
            // dced70brfvcd
            // 
            this.dced70brfvcd.Location = new System.Drawing.Point(247, 1287);
            this.dced70brfvcd.Name = "dced70brfvcd";
            this.dced70brfvcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced70brfvcd.OcxState")));
            this.dced70brfvcd.Size = new System.Drawing.Size(69, 18);
            this.dced70brfvcd.TabIndex = 167;
            this.dced70brfvcd.Tag = "70brfvcd";
            // 
            // dcim70crfvcd
            // 
            this.dcim70crfvcd.Location = new System.Drawing.Point(322, 1268);
            this.dcim70crfvcd.Name = "dcim70crfvcd";
            this.dcim70crfvcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim70crfvcd.OcxState")));
            this.dcim70crfvcd.Size = new System.Drawing.Size(69, 18);
            this.dcim70crfvcd.TabIndex = 986;
            this.dcim70crfvcd.TabStop = false;
            this.dcim70crfvcd.Tag = "70crfvcd";
            // 
            // dced70crfvcd
            // 
            this.dced70crfvcd.Location = new System.Drawing.Point(322, 1287);
            this.dced70crfvcd.Name = "dced70crfvcd";
            this.dced70crfvcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced70crfvcd.OcxState")));
            this.dced70crfvcd.Size = new System.Drawing.Size(69, 18);
            this.dced70crfvcd.TabIndex = 168;
            this.dced70crfvcd.Tag = "70crfvcd";
            // 
            // dcim71ppscd
            // 
            this.dcim71ppscd.Location = new System.Drawing.Point(430, 1268);
            this.dcim71ppscd.Name = "dcim71ppscd";
            this.dcim71ppscd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim71ppscd.OcxState")));
            this.dcim71ppscd.Size = new System.Drawing.Size(69, 18);
            this.dcim71ppscd.TabIndex = 988;
            this.dcim71ppscd.TabStop = false;
            this.dcim71ppscd.Tag = "71ppscd";
            // 
            // dced71ppscd
            // 
            this.dced71ppscd.Location = new System.Drawing.Point(430, 1287);
            this.dced71ppscd.Name = "dced71ppscd";
            this.dced71ppscd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced71ppscd.OcxState")));
            this.dced71ppscd.Size = new System.Drawing.Size(69, 18);
            this.dced71ppscd.TabIndex = 169;
            this.dced71ppscd.Tag = "71ppscd";
            // 
            // lbl72aecicd
            // 
            this.lbl72aecicd.AutoSize = true;
            this.lbl72aecicd.BackColor = System.Drawing.Color.Lavender;
            this.lbl72aecicd.Location = new System.Drawing.Point(17, 1133);
            this.lbl72aecicd.Name = "lbl72aecicd";
            this.lbl72aecicd.Size = new System.Drawing.Size(81, 13);
            this.lbl72aecicd.TabIndex = 990;
            this.lbl72aecicd.Tag = "72aecicd";
            this.lbl72aecicd.Text = "Diagnosis Code";
            // 
            // dcim72aecicd
            // 
            this.dcim72aecicd.Location = new System.Drawing.Point(596, 1268);
            this.dcim72aecicd.Name = "dcim72aecicd";
            this.dcim72aecicd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim72aecicd.OcxState")));
            this.dcim72aecicd.Size = new System.Drawing.Size(69, 18);
            this.dcim72aecicd.TabIndex = 991;
            this.dcim72aecicd.TabStop = false;
            this.dcim72aecicd.Tag = "72aecicd";
            // 
            // dced72aecicd
            // 
            this.dced72aecicd.Location = new System.Drawing.Point(596, 1287);
            this.dced72aecicd.Name = "dced72aecicd";
            this.dced72aecicd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced72aecicd.OcxState")));
            this.dced72aecicd.Size = new System.Drawing.Size(69, 18);
            this.dced72aecicd.TabIndex = 170;
            this.dced72aecicd.Tag = "72aecicd";
            // 
            // lbl23TotChgs
            // 
            this.lbl23TotChgs.AutoSize = true;
            this.lbl23TotChgs.BackColor = System.Drawing.Color.Transparent;
            this.lbl23TotChgs.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl23TotChgs.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl23TotChgs.ForeColor = System.Drawing.Color.Black;
            this.lbl23TotChgs.Location = new System.Drawing.Point(413, 926);
            this.lbl23TotChgs.Name = "lbl23TotChgs";
            this.lbl23TotChgs.Size = new System.Drawing.Size(86, 13);
            this.lbl23TotChgs.TabIndex = 877;
            this.lbl23TotChgs.Tag = "23TotChgs";
            this.lbl23TotChgs.Text = "Total Charges";
            // 
            // dcim23TotChgs
            // 
            this.dcim23TotChgs.Location = new System.Drawing.Point(505, 924);
            this.dcim23TotChgs.Name = "dcim23TotChgs";
            this.dcim23TotChgs.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim23TotChgs.OcxState")));
            this.dcim23TotChgs.Size = new System.Drawing.Size(113, 18);
            this.dcim23TotChgs.TabIndex = 878;
            this.dcim23TotChgs.TabStop = false;
            this.dcim23TotChgs.Tag = "23TotChgs";
            // 
            // dced23TotChgs
            // 
            this.dced23TotChgs.Location = new System.Drawing.Point(505, 943);
            this.dced23TotChgs.Name = "dced23TotChgs";
            this.dced23TotChgs.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced23TotChgs.OcxState")));
            this.dced23TotChgs.Size = new System.Drawing.Size(113, 18);
            this.dced23TotChgs.TabIndex = 103;
            this.dced23TotChgs.Tag = "23TotChgs";
            // 
            // panLINEITEM
            // 
            this.panLINEITEM.AutoScroll = true;
            this.panLINEITEM.BackColor = System.Drawing.Color.Beige;
            this.panLINEITEM.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panLINEITEM.Controls.Add(this.dcimNDCType);
            this.panLINEITEM.Controls.Add(this.dcedNDCType);
            this.panLINEITEM.Controls.Add(this.dcimNDCQty);
            this.panLINEITEM.Controls.Add(this.dcedNDCQty);
            this.panLINEITEM.Controls.Add(this.dcimRevCode);
            this.panLINEITEM.Controls.Add(this.dcedRevCode);
            this.panLINEITEM.Controls.Add(this.dcimDescription);
            this.panLINEITEM.Controls.Add(this.dcedDescription);
            this.panLINEITEM.Controls.Add(this.dcimHCPCS);
            this.panLINEITEM.Controls.Add(this.dcedHCPCS);
            this.panLINEITEM.Controls.Add(this.dcimServiceDate);
            this.panLINEITEM.Controls.Add(this.dcedServiceDate);
            this.panLINEITEM.Controls.Add(this.dcimUnits);
            this.panLINEITEM.Controls.Add(this.dcedUnits);
            this.panLINEITEM.Controls.Add(this.dcimCharges);
            this.panLINEITEM.Controls.Add(this.dcedCharges);
            this.panLINEITEM.Controls.Add(this.dcimNonCovered);
            this.panLINEITEM.Controls.Add(this.dcedNonCovered);
            this.panLINEITEM.Controls.Add(this.dcimNDC);
            this.panLINEITEM.Controls.Add(this.dcedNDC);
            this.panLINEITEM.Location = new System.Drawing.Point(22, 607);
            this.panLINEITEM.Name = "panLINEITEM";
            this.panLINEITEM.Size = new System.Drawing.Size(999, 311);
            this.panLINEITEM.TabIndex = 99;
            this.panLINEITEM.Tag = "LINEITEM";
            // 
            // dcimNDCType
            // 
            this.dcimNDCType.Location = new System.Drawing.Point(807, 2);
            this.dcimNDCType.Name = "dcimNDCType";
            this.dcimNDCType.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimNDCType.OcxState")));
            this.dcimNDCType.Size = new System.Drawing.Size(68, 18);
            this.dcimNDCType.TabIndex = 16;
            this.dcimNDCType.TabStop = false;
            this.dcimNDCType.Tag = "NDCType";
            // 
            // dcedNDCType
            // 
            this.dcedNDCType.Location = new System.Drawing.Point(807, 19);
            this.dcedNDCType.Name = "dcedNDCType";
            this.dcedNDCType.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedNDCType.OcxState")));
            this.dcedNDCType.Size = new System.Drawing.Size(68, 18);
            this.dcedNDCType.TabIndex = 17;
            this.dcedNDCType.Tag = "NDCType";
            // 
            // dcimNDCQty
            // 
            this.dcimNDCQty.Location = new System.Drawing.Point(875, 2);
            this.dcimNDCQty.Name = "dcimNDCQty";
            this.dcimNDCQty.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimNDCQty.OcxState")));
            this.dcimNDCQty.Size = new System.Drawing.Size(103, 18);
            this.dcimNDCQty.TabIndex = 18;
            this.dcimNDCQty.TabStop = false;
            this.dcimNDCQty.Tag = "NDCQty";
            // 
            // dcedNDCQty
            // 
            this.dcedNDCQty.Location = new System.Drawing.Point(875, 19);
            this.dcedNDCQty.Name = "dcedNDCQty";
            this.dcedNDCQty.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedNDCQty.OcxState")));
            this.dcedNDCQty.Size = new System.Drawing.Size(103, 18);
            this.dcedNDCQty.TabIndex = 19;
            this.dcedNDCQty.Tag = "NDCQty";
            // 
            // dcimRevCode
            // 
            this.dcimRevCode.Location = new System.Drawing.Point(0, 2);
            this.dcimRevCode.Name = "dcimRevCode";
            this.dcimRevCode.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimRevCode.OcxState")));
            this.dcimRevCode.Size = new System.Drawing.Size(45, 18);
            this.dcimRevCode.TabIndex = 0;
            this.dcimRevCode.TabStop = false;
            this.dcimRevCode.Tag = "RevCode";
            // 
            // dcedRevCode
            // 
            this.dcedRevCode.Location = new System.Drawing.Point(0, 19);
            this.dcedRevCode.Name = "dcedRevCode";
            this.dcedRevCode.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedRevCode.OcxState")));
            this.dcedRevCode.Size = new System.Drawing.Size(45, 18);
            this.dcedRevCode.TabIndex = 1;
            this.dcedRevCode.Tag = "RevCode";
            // 
            // dcimDescription
            // 
            this.dcimDescription.Location = new System.Drawing.Point(159, 2);
            this.dcimDescription.Name = "dcimDescription";
            this.dcimDescription.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimDescription.OcxState")));
            this.dcimDescription.Size = new System.Drawing.Size(196, 18);
            this.dcimDescription.TabIndex = 4;
            this.dcimDescription.TabStop = false;
            this.dcimDescription.Tag = "Description";
            // 
            // dcedDescription
            // 
            this.dcedDescription.Location = new System.Drawing.Point(159, 19);
            this.dcedDescription.Name = "dcedDescription";
            this.dcedDescription.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedDescription.OcxState")));
            this.dcedDescription.Size = new System.Drawing.Size(196, 18);
            this.dcedDescription.TabIndex = 5;
            this.dcedDescription.Tag = "Description";
            // 
            // dcimHCPCS
            // 
            this.dcimHCPCS.Location = new System.Drawing.Point(45, 2);
            this.dcimHCPCS.Name = "dcimHCPCS";
            this.dcimHCPCS.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimHCPCS.OcxState")));
            this.dcimHCPCS.Size = new System.Drawing.Size(114, 18);
            this.dcimHCPCS.TabIndex = 2;
            this.dcimHCPCS.TabStop = false;
            this.dcimHCPCS.Tag = "HCPCS";
            // 
            // dcedHCPCS
            // 
            this.dcedHCPCS.Location = new System.Drawing.Point(45, 19);
            this.dcedHCPCS.Name = "dcedHCPCS";
            this.dcedHCPCS.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedHCPCS.OcxState")));
            this.dcedHCPCS.Size = new System.Drawing.Size(114, 18);
            this.dcedHCPCS.TabIndex = 3;
            this.dcedHCPCS.Tag = "HCPCS";
            // 
            // dcimServiceDate
            // 
            this.dcimServiceDate.Location = new System.Drawing.Point(355, 2);
            this.dcimServiceDate.Name = "dcimServiceDate";
            this.dcimServiceDate.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimServiceDate.OcxState")));
            this.dcimServiceDate.Size = new System.Drawing.Size(93, 18);
            this.dcimServiceDate.TabIndex = 6;
            this.dcimServiceDate.TabStop = false;
            this.dcimServiceDate.Tag = "ServiceDate";
            // 
            // dcedServiceDate
            // 
            this.dcedServiceDate.Location = new System.Drawing.Point(355, 19);
            this.dcedServiceDate.Name = "dcedServiceDate";
            this.dcedServiceDate.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedServiceDate.OcxState")));
            this.dcedServiceDate.Size = new System.Drawing.Size(93, 18);
            this.dcedServiceDate.TabIndex = 7;
            this.dcedServiceDate.Tag = "ServiceDate";
            // 
            // dcimUnits
            // 
            this.dcimUnits.Location = new System.Drawing.Point(448, 2);
            this.dcimUnits.Name = "dcimUnits";
            this.dcimUnits.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimUnits.OcxState")));
            this.dcimUnits.Size = new System.Drawing.Size(63, 18);
            this.dcimUnits.TabIndex = 8;
            this.dcimUnits.TabStop = false;
            this.dcimUnits.Tag = "Units";
            // 
            // dcedUnits
            // 
            this.dcedUnits.Location = new System.Drawing.Point(448, 19);
            this.dcedUnits.Name = "dcedUnits";
            this.dcedUnits.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedUnits.OcxState")));
            this.dcedUnits.Size = new System.Drawing.Size(63, 18);
            this.dcedUnits.TabIndex = 9;
            this.dcedUnits.Tag = "Units";
            // 
            // dcimCharges
            // 
            this.dcimCharges.Location = new System.Drawing.Point(511, 2);
            this.dcimCharges.Name = "dcimCharges";
            this.dcimCharges.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimCharges.OcxState")));
            this.dcimCharges.Size = new System.Drawing.Size(88, 18);
            this.dcimCharges.TabIndex = 10;
            this.dcimCharges.TabStop = false;
            this.dcimCharges.Tag = "Charges";
            // 
            // dcedCharges
            // 
            this.dcedCharges.Location = new System.Drawing.Point(511, 19);
            this.dcedCharges.Name = "dcedCharges";
            this.dcedCharges.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedCharges.OcxState")));
            this.dcedCharges.Size = new System.Drawing.Size(88, 18);
            this.dcedCharges.TabIndex = 11;
            this.dcedCharges.Tag = "Charges";
            // 
            // dcimNonCovered
            // 
            this.dcimNonCovered.Location = new System.Drawing.Point(599, 2);
            this.dcimNonCovered.Name = "dcimNonCovered";
            this.dcimNonCovered.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimNonCovered.OcxState")));
            this.dcimNonCovered.Size = new System.Drawing.Size(87, 18);
            this.dcimNonCovered.TabIndex = 12;
            this.dcimNonCovered.TabStop = false;
            this.dcimNonCovered.Tag = "NonCovered";
            // 
            // dcedNonCovered
            // 
            this.dcedNonCovered.Location = new System.Drawing.Point(599, 19);
            this.dcedNonCovered.Name = "dcedNonCovered";
            this.dcedNonCovered.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedNonCovered.OcxState")));
            this.dcedNonCovered.Size = new System.Drawing.Size(87, 18);
            this.dcedNonCovered.TabIndex = 13;
            this.dcedNonCovered.Tag = "NonCovered";
            // 
            // dcimNDC
            // 
            this.dcimNDC.Location = new System.Drawing.Point(704, 2);
            this.dcimNDC.Name = "dcimNDC";
            this.dcimNDC.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimNDC.OcxState")));
            this.dcimNDC.Size = new System.Drawing.Size(103, 18);
            this.dcimNDC.TabIndex = 14;
            this.dcimNDC.TabStop = false;
            this.dcimNDC.Tag = "NDC";
            // 
            // dcedNDC
            // 
            this.dcedNDC.Location = new System.Drawing.Point(704, 19);
            this.dcedNDC.Name = "dcedNDC";
            this.dcedNDC.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedNDC.OcxState")));
            this.dcedNDC.Size = new System.Drawing.Size(103, 18);
            this.dcedNDC.TabIndex = 15;
            this.dcedNDC.Tag = "NDC";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Lavender;
            this.pictureBox2.Location = new System.Drawing.Point(14, 1130);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(857, 184);
            this.pictureBox2.TabIndex = 1001;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Lavender;
            this.pictureBox3.Location = new System.Drawing.Point(14, 970);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(585, 154);
            this.pictureBox3.TabIndex = 1002;
            this.pictureBox3.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Lavender;
            this.label5.Location = new System.Drawing.Point(468, 1325);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(115, 13);
            this.label5.TabIndex = 1053;
            this.label5.Text = "76 Attending Physician";
            // 
            // lbl74prprcd
            // 
            this.lbl74prprcd.AutoSize = true;
            this.lbl74prprcd.BackColor = System.Drawing.Color.Lavender;
            this.lbl74prprcd.Location = new System.Drawing.Point(19, 1338);
            this.lbl74prprcd.Name = "lbl74prprcd";
            this.lbl74prprcd.Size = new System.Drawing.Size(131, 13);
            this.lbl74prprcd.TabIndex = 1006;
            this.lbl74prprcd.Tag = "74prprcd";
            this.lbl74prprcd.Text = "Prin. Proc. Code and Date";
            // 
            // dcim74prprcd
            // 
            this.dcim74prprcd.Location = new System.Drawing.Point(21, 1351);
            this.dcim74prprcd.Name = "dcim74prprcd";
            this.dcim74prprcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim74prprcd.OcxState")));
            this.dcim74prprcd.Size = new System.Drawing.Size(69, 18);
            this.dcim74prprcd.TabIndex = 1007;
            this.dcim74prprcd.TabStop = false;
            this.dcim74prprcd.Tag = "74prprcd";
            // 
            // dced74prprcd
            // 
            this.dced74prprcd.Location = new System.Drawing.Point(21, 1370);
            this.dced74prprcd.Name = "dced74prprcd";
            this.dced74prprcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced74prprcd.OcxState")));
            this.dced74prprcd.Size = new System.Drawing.Size(69, 18);
            this.dced74prprcd.TabIndex = 179;
            this.dced74prprcd.Tag = "74prprcd";
            // 
            // dcim74prprdt
            // 
            this.dcim74prprdt.Location = new System.Drawing.Point(91, 1351);
            this.dcim74prprdt.Name = "dcim74prprdt";
            this.dcim74prprdt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim74prprdt.OcxState")));
            this.dcim74prprdt.Size = new System.Drawing.Size(66, 18);
            this.dcim74prprdt.TabIndex = 1009;
            this.dcim74prprdt.TabStop = false;
            this.dcim74prprdt.Tag = "74prprdt";
            // 
            // dced74prprdt
            // 
            this.dced74prprdt.Location = new System.Drawing.Point(91, 1370);
            this.dced74prprdt.Name = "dced74prprdt";
            this.dced74prprdt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced74prprdt.OcxState")));
            this.dced74prprdt.Size = new System.Drawing.Size(66, 18);
            this.dced74prprdt.TabIndex = 180;
            this.dced74prprdt.Tag = "74prprdt";
            // 
            // lbl74aoprcd
            // 
            this.lbl74aoprcd.AutoSize = true;
            this.lbl74aoprcd.BackColor = System.Drawing.Color.Lavender;
            this.lbl74aoprcd.Location = new System.Drawing.Point(166, 1338);
            this.lbl74aoprcd.Name = "lbl74aoprcd";
            this.lbl74aoprcd.Size = new System.Drawing.Size(13, 13);
            this.lbl74aoprcd.TabIndex = 1011;
            this.lbl74aoprcd.Tag = "74aoprcd";
            this.lbl74aoprcd.Text = "a";
            // 
            // dcim74aoprcd
            // 
            this.dcim74aoprcd.Location = new System.Drawing.Point(164, 1351);
            this.dcim74aoprcd.Name = "dcim74aoprcd";
            this.dcim74aoprcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim74aoprcd.OcxState")));
            this.dcim74aoprcd.Size = new System.Drawing.Size(69, 18);
            this.dcim74aoprcd.TabIndex = 1012;
            this.dcim74aoprcd.TabStop = false;
            this.dcim74aoprcd.Tag = "74aoprcd";
            // 
            // dced74aoprcd
            // 
            this.dced74aoprcd.Location = new System.Drawing.Point(164, 1370);
            this.dced74aoprcd.Name = "dced74aoprcd";
            this.dced74aoprcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced74aoprcd.OcxState")));
            this.dced74aoprcd.Size = new System.Drawing.Size(69, 18);
            this.dced74aoprcd.TabIndex = 181;
            this.dced74aoprcd.Tag = "74aoprcd";
            // 
            // dcim74aoprdt
            // 
            this.dcim74aoprdt.Location = new System.Drawing.Point(234, 1351);
            this.dcim74aoprdt.Name = "dcim74aoprdt";
            this.dcim74aoprdt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim74aoprdt.OcxState")));
            this.dcim74aoprdt.Size = new System.Drawing.Size(66, 18);
            this.dcim74aoprdt.TabIndex = 1014;
            this.dcim74aoprdt.TabStop = false;
            this.dcim74aoprdt.Tag = "74aoprdt";
            // 
            // dced74aoprdt
            // 
            this.dced74aoprdt.Location = new System.Drawing.Point(234, 1370);
            this.dced74aoprdt.Name = "dced74aoprdt";
            this.dced74aoprdt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced74aoprdt.OcxState")));
            this.dced74aoprdt.Size = new System.Drawing.Size(66, 18);
            this.dced74aoprdt.TabIndex = 182;
            this.dced74aoprdt.Tag = "74aoprdt";
            // 
            // dcim74boprcd
            // 
            this.dcim74boprcd.Location = new System.Drawing.Point(307, 1351);
            this.dcim74boprcd.Name = "dcim74boprcd";
            this.dcim74boprcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim74boprcd.OcxState")));
            this.dcim74boprcd.Size = new System.Drawing.Size(69, 18);
            this.dcim74boprcd.TabIndex = 1016;
            this.dcim74boprcd.TabStop = false;
            this.dcim74boprcd.Tag = "74boprcd";
            // 
            // dced74boprcd
            // 
            this.dced74boprcd.Location = new System.Drawing.Point(307, 1370);
            this.dced74boprcd.Name = "dced74boprcd";
            this.dced74boprcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced74boprcd.OcxState")));
            this.dced74boprcd.Size = new System.Drawing.Size(69, 18);
            this.dced74boprcd.TabIndex = 183;
            this.dced74boprcd.Tag = "74boprcd";
            // 
            // lbl74boprdt
            // 
            this.lbl74boprdt.AutoSize = true;
            this.lbl74boprdt.BackColor = System.Drawing.Color.Lavender;
            this.lbl74boprdt.Location = new System.Drawing.Point(310, 1338);
            this.lbl74boprdt.Name = "lbl74boprdt";
            this.lbl74boprdt.Size = new System.Drawing.Size(13, 13);
            this.lbl74boprdt.TabIndex = 1018;
            this.lbl74boprdt.Tag = "74boprdt";
            this.lbl74boprdt.Text = "b";
            // 
            // dcim74boprdt
            // 
            this.dcim74boprdt.Location = new System.Drawing.Point(377, 1351);
            this.dcim74boprdt.Name = "dcim74boprdt";
            this.dcim74boprdt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim74boprdt.OcxState")));
            this.dcim74boprdt.Size = new System.Drawing.Size(66, 18);
            this.dcim74boprdt.TabIndex = 1019;
            this.dcim74boprdt.TabStop = false;
            this.dcim74boprdt.Tag = "74boprdt";
            // 
            // dced74boprdt
            // 
            this.dced74boprdt.Location = new System.Drawing.Point(377, 1370);
            this.dced74boprdt.Name = "dced74boprdt";
            this.dced74boprdt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced74boprdt.OcxState")));
            this.dced74boprdt.Size = new System.Drawing.Size(66, 18);
            this.dced74boprdt.TabIndex = 184;
            this.dced74boprdt.Tag = "74boprdt";
            // 
            // lbl74coprcd
            // 
            this.lbl74coprcd.AutoSize = true;
            this.lbl74coprcd.BackColor = System.Drawing.Color.Lavender;
            this.lbl74coprcd.Location = new System.Drawing.Point(24, 1395);
            this.lbl74coprcd.Name = "lbl74coprcd";
            this.lbl74coprcd.Size = new System.Drawing.Size(13, 13);
            this.lbl74coprcd.TabIndex = 1021;
            this.lbl74coprcd.Tag = "74coprcd";
            this.lbl74coprcd.Text = "c";
            // 
            // dcim74coprcd
            // 
            this.dcim74coprcd.Location = new System.Drawing.Point(21, 1408);
            this.dcim74coprcd.Name = "dcim74coprcd";
            this.dcim74coprcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim74coprcd.OcxState")));
            this.dcim74coprcd.Size = new System.Drawing.Size(69, 18);
            this.dcim74coprcd.TabIndex = 1022;
            this.dcim74coprcd.TabStop = false;
            this.dcim74coprcd.Tag = "74coprcd";
            // 
            // dced74coprcd
            // 
            this.dced74coprcd.Location = new System.Drawing.Point(21, 1427);
            this.dced74coprcd.Name = "dced74coprcd";
            this.dced74coprcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced74coprcd.OcxState")));
            this.dced74coprcd.Size = new System.Drawing.Size(69, 18);
            this.dced74coprcd.TabIndex = 185;
            this.dced74coprcd.Tag = "74coprcd";
            // 
            // dcim74coprdt
            // 
            this.dcim74coprdt.Location = new System.Drawing.Point(91, 1408);
            this.dcim74coprdt.Name = "dcim74coprdt";
            this.dcim74coprdt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim74coprdt.OcxState")));
            this.dcim74coprdt.Size = new System.Drawing.Size(66, 18);
            this.dcim74coprdt.TabIndex = 1024;
            this.dcim74coprdt.TabStop = false;
            this.dcim74coprdt.Tag = "74coprdt";
            // 
            // dced74coprdt
            // 
            this.dced74coprdt.Location = new System.Drawing.Point(91, 1427);
            this.dced74coprdt.Name = "dced74coprdt";
            this.dced74coprdt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced74coprdt.OcxState")));
            this.dced74coprdt.Size = new System.Drawing.Size(66, 18);
            this.dced74coprdt.TabIndex = 186;
            this.dced74coprdt.Tag = "74coprdt";
            // 
            // lbl74doprcd
            // 
            this.lbl74doprcd.AutoSize = true;
            this.lbl74doprcd.BackColor = System.Drawing.Color.Lavender;
            this.lbl74doprcd.Location = new System.Drawing.Point(166, 1395);
            this.lbl74doprcd.Name = "lbl74doprcd";
            this.lbl74doprcd.Size = new System.Drawing.Size(13, 13);
            this.lbl74doprcd.TabIndex = 1026;
            this.lbl74doprcd.Tag = "74doprcd";
            this.lbl74doprcd.Text = "d";
            // 
            // dcim74doprcd
            // 
            this.dcim74doprcd.Location = new System.Drawing.Point(164, 1408);
            this.dcim74doprcd.Name = "dcim74doprcd";
            this.dcim74doprcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim74doprcd.OcxState")));
            this.dcim74doprcd.Size = new System.Drawing.Size(69, 18);
            this.dcim74doprcd.TabIndex = 1027;
            this.dcim74doprcd.TabStop = false;
            this.dcim74doprcd.Tag = "74doprcd";
            // 
            // dced74doprcd
            // 
            this.dced74doprcd.Location = new System.Drawing.Point(164, 1427);
            this.dced74doprcd.Name = "dced74doprcd";
            this.dced74doprcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced74doprcd.OcxState")));
            this.dced74doprcd.Size = new System.Drawing.Size(69, 18);
            this.dced74doprcd.TabIndex = 187;
            this.dced74doprcd.Tag = "74doprcd";
            // 
            // dcim74doprdt
            // 
            this.dcim74doprdt.Location = new System.Drawing.Point(234, 1408);
            this.dcim74doprdt.Name = "dcim74doprdt";
            this.dcim74doprdt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim74doprdt.OcxState")));
            this.dcim74doprdt.Size = new System.Drawing.Size(66, 18);
            this.dcim74doprdt.TabIndex = 1029;
            this.dcim74doprdt.TabStop = false;
            this.dcim74doprdt.Tag = "74doprdt";
            // 
            // dced74doprdt
            // 
            this.dced74doprdt.Location = new System.Drawing.Point(234, 1427);
            this.dced74doprdt.Name = "dced74doprdt";
            this.dced74doprdt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced74doprdt.OcxState")));
            this.dced74doprdt.Size = new System.Drawing.Size(66, 18);
            this.dced74doprdt.TabIndex = 188;
            this.dced74doprdt.Tag = "74doprdt";
            // 
            // lbl74eoprcd
            // 
            this.lbl74eoprcd.AutoSize = true;
            this.lbl74eoprcd.BackColor = System.Drawing.Color.Lavender;
            this.lbl74eoprcd.Location = new System.Drawing.Point(310, 1395);
            this.lbl74eoprcd.Name = "lbl74eoprcd";
            this.lbl74eoprcd.Size = new System.Drawing.Size(13, 13);
            this.lbl74eoprcd.TabIndex = 1031;
            this.lbl74eoprcd.Tag = "74eoprcd";
            this.lbl74eoprcd.Text = "e";
            // 
            // dcim74eoprcd
            // 
            this.dcim74eoprcd.Location = new System.Drawing.Point(307, 1408);
            this.dcim74eoprcd.Name = "dcim74eoprcd";
            this.dcim74eoprcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim74eoprcd.OcxState")));
            this.dcim74eoprcd.Size = new System.Drawing.Size(69, 18);
            this.dcim74eoprcd.TabIndex = 1032;
            this.dcim74eoprcd.TabStop = false;
            this.dcim74eoprcd.Tag = "74eoprcd";
            // 
            // dced74eoprcd
            // 
            this.dced74eoprcd.Location = new System.Drawing.Point(307, 1427);
            this.dced74eoprcd.Name = "dced74eoprcd";
            this.dced74eoprcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced74eoprcd.OcxState")));
            this.dced74eoprcd.Size = new System.Drawing.Size(69, 18);
            this.dced74eoprcd.TabIndex = 189;
            this.dced74eoprcd.Tag = "74eoprcd";
            // 
            // lbl74eoprdt
            // 
            this.lbl74eoprdt.AutoSize = true;
            this.lbl74eoprdt.BackColor = System.Drawing.Color.Lavender;
            this.lbl74eoprdt.Location = new System.Drawing.Point(19, 1322);
            this.lbl74eoprdt.Name = "lbl74eoprdt";
            this.lbl74eoprdt.Size = new System.Drawing.Size(156, 13);
            this.lbl74eoprdt.TabIndex = 1034;
            this.lbl74eoprdt.Tag = "74eoprdt";
            this.lbl74eoprdt.Text = "74 Procedure Codes and Dates";
            // 
            // dcim74eoprdt
            // 
            this.dcim74eoprdt.Location = new System.Drawing.Point(377, 1408);
            this.dcim74eoprdt.Name = "dcim74eoprdt";
            this.dcim74eoprdt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim74eoprdt.OcxState")));
            this.dcim74eoprdt.Size = new System.Drawing.Size(66, 18);
            this.dcim74eoprdt.TabIndex = 1035;
            this.dcim74eoprdt.TabStop = false;
            this.dcim74eoprdt.Tag = "74eoprdt";
            // 
            // dced74eoprdt
            // 
            this.dced74eoprdt.Location = new System.Drawing.Point(377, 1427);
            this.dced74eoprdt.Name = "dced74eoprdt";
            this.dced74eoprdt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced74eoprdt.OcxState")));
            this.dced74eoprdt.Size = new System.Drawing.Size(66, 18);
            this.dced74eoprdt.TabIndex = 190;
            this.dced74eoprdt.Tag = "74eoprdt";
            // 
            // lbl76apnpi
            // 
            this.lbl76apnpi.AutoSize = true;
            this.lbl76apnpi.BackColor = System.Drawing.Color.Lavender;
            this.lbl76apnpi.Location = new System.Drawing.Point(479, 1338);
            this.lbl76apnpi.Name = "lbl76apnpi";
            this.lbl76apnpi.Size = new System.Drawing.Size(25, 13);
            this.lbl76apnpi.TabIndex = 1037;
            this.lbl76apnpi.Tag = "76apnpi";
            this.lbl76apnpi.Text = "NPI";
            // 
            // dcim76apnpi
            // 
            this.dcim76apnpi.Location = new System.Drawing.Point(476, 1351);
            this.dcim76apnpi.Name = "dcim76apnpi";
            this.dcim76apnpi.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim76apnpi.OcxState")));
            this.dcim76apnpi.Size = new System.Drawing.Size(102, 18);
            this.dcim76apnpi.TabIndex = 1038;
            this.dcim76apnpi.TabStop = false;
            this.dcim76apnpi.Tag = "76apnpi";
            // 
            // dced76apnpi
            // 
            this.dced76apnpi.Location = new System.Drawing.Point(476, 1370);
            this.dced76apnpi.Name = "dced76apnpi";
            this.dced76apnpi.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced76apnpi.OcxState")));
            this.dced76apnpi.Size = new System.Drawing.Size(102, 18);
            this.dced76apnpi.TabIndex = 191;
            this.dced76apnpi.Tag = "76apnpi";
            // 
            // lbl76apqual
            // 
            this.lbl76apqual.AutoSize = true;
            this.lbl76apqual.BackColor = System.Drawing.Color.Lavender;
            this.lbl76apqual.Location = new System.Drawing.Point(583, 1338);
            this.lbl76apqual.Name = "lbl76apqual";
            this.lbl76apqual.Size = new System.Drawing.Size(32, 13);
            this.lbl76apqual.TabIndex = 1040;
            this.lbl76apqual.Tag = "76apqual";
            this.lbl76apqual.Text = "Qual.";
            // 
            // dcim76apqual
            // 
            this.dcim76apqual.Location = new System.Drawing.Point(585, 1351);
            this.dcim76apqual.Name = "dcim76apqual";
            this.dcim76apqual.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim76apqual.OcxState")));
            this.dcim76apqual.Size = new System.Drawing.Size(27, 18);
            this.dcim76apqual.TabIndex = 1041;
            this.dcim76apqual.TabStop = false;
            this.dcim76apqual.Tag = "76apqual";
            // 
            // dced76apqual
            // 
            this.dced76apqual.Location = new System.Drawing.Point(585, 1370);
            this.dced76apqual.Name = "dced76apqual";
            this.dced76apqual.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced76apqual.OcxState")));
            this.dced76apqual.Size = new System.Drawing.Size(27, 18);
            this.dced76apqual.TabIndex = 192;
            this.dced76apqual.Tag = "76apqual";
            // 
            // lbl76apid
            // 
            this.lbl76apid.AutoSize = true;
            this.lbl76apid.BackColor = System.Drawing.Color.Lavender;
            this.lbl76apid.Location = new System.Drawing.Point(617, 1338);
            this.lbl76apid.Name = "lbl76apid";
            this.lbl76apid.Size = new System.Drawing.Size(18, 13);
            this.lbl76apid.TabIndex = 1043;
            this.lbl76apid.Tag = "76apid";
            this.lbl76apid.Text = "ID";
            // 
            // dcim76apid
            // 
            this.dcim76apid.Location = new System.Drawing.Point(618, 1351);
            this.dcim76apid.Name = "dcim76apid";
            this.dcim76apid.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim76apid.OcxState")));
            this.dcim76apid.Size = new System.Drawing.Size(106, 18);
            this.dcim76apid.TabIndex = 1044;
            this.dcim76apid.TabStop = false;
            this.dcim76apid.Tag = "76apid";
            // 
            // dced76apid
            // 
            this.dced76apid.Location = new System.Drawing.Point(618, 1370);
            this.dced76apid.Name = "dced76apid";
            this.dced76apid.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced76apid.OcxState")));
            this.dced76apid.Size = new System.Drawing.Size(106, 18);
            this.dced76apid.TabIndex = 193;
            this.dced76apid.Tag = "76apid";
            // 
            // lbl76aplnm
            // 
            this.lbl76aplnm.AutoSize = true;
            this.lbl76aplnm.BackColor = System.Drawing.Color.Lavender;
            this.lbl76aplnm.Location = new System.Drawing.Point(472, 1398);
            this.lbl76aplnm.Name = "lbl76aplnm";
            this.lbl76aplnm.Size = new System.Drawing.Size(58, 13);
            this.lbl76aplnm.TabIndex = 1046;
            this.lbl76aplnm.Tag = "76aplnm";
            this.lbl76aplnm.Text = "Last Name";
            // 
            // dcim76aplnm
            // 
            this.dcim76aplnm.Location = new System.Drawing.Point(467, 1411);
            this.dcim76aplnm.Name = "dcim76aplnm";
            this.dcim76aplnm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim76aplnm.OcxState")));
            this.dcim76aplnm.Size = new System.Drawing.Size(134, 18);
            this.dcim76aplnm.TabIndex = 1047;
            this.dcim76aplnm.TabStop = false;
            this.dcim76aplnm.Tag = "76aplnm";
            // 
            // dced76aplnm
            // 
            this.dced76aplnm.Location = new System.Drawing.Point(467, 1430);
            this.dced76aplnm.Name = "dced76aplnm";
            this.dced76aplnm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced76aplnm.OcxState")));
            this.dced76aplnm.Size = new System.Drawing.Size(134, 18);
            this.dced76aplnm.TabIndex = 194;
            this.dced76aplnm.Tag = "76aplnm";
            // 
            // lbl76apfnm
            // 
            this.lbl76apfnm.AutoSize = true;
            this.lbl76apfnm.BackColor = System.Drawing.Color.Lavender;
            this.lbl76apfnm.Location = new System.Drawing.Point(603, 1398);
            this.lbl76apfnm.Name = "lbl76apfnm";
            this.lbl76apfnm.Size = new System.Drawing.Size(57, 13);
            this.lbl76apfnm.TabIndex = 1049;
            this.lbl76apfnm.Tag = "76apfnm";
            this.lbl76apfnm.Text = "First Name";
            // 
            // dcim76apfnm
            // 
            this.dcim76apfnm.Location = new System.Drawing.Point(606, 1411);
            this.dcim76apfnm.Name = "dcim76apfnm";
            this.dcim76apfnm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim76apfnm.OcxState")));
            this.dcim76apfnm.Size = new System.Drawing.Size(119, 18);
            this.dcim76apfnm.TabIndex = 1050;
            this.dcim76apfnm.TabStop = false;
            this.dcim76apfnm.Tag = "76apfnm";
            // 
            // dced76apfnm
            // 
            this.dced76apfnm.Location = new System.Drawing.Point(606, 1430);
            this.dced76apfnm.Name = "dced76apfnm";
            this.dced76apfnm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced76apfnm.OcxState")));
            this.dced76apfnm.Size = new System.Drawing.Size(119, 18);
            this.dced76apfnm.TabIndex = 195;
            this.dced76apfnm.Tag = "76apfnm";
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Lavender;
            this.pictureBox4.Location = new System.Drawing.Point(14, 1321);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(437, 131);
            this.pictureBox4.TabIndex = 1052;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.Lavender;
            this.pictureBox5.Location = new System.Drawing.Point(457, 1321);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(274, 131);
            this.pictureBox5.TabIndex = 1054;
            this.pictureBox5.TabStop = false;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Beige;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(535, 588);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 16);
            this.label1.TabIndex = 1056;
            this.label1.Tag = "Charges";
            this.label1.Text = "Charges";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.Beige;
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label6.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(183, 588);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(196, 16);
            this.label6.TabIndex = 1057;
            this.label6.Tag = "Charges";
            this.label6.Text = "Description";
            this.label6.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.Beige;
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label7.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(623, 588);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 16);
            this.label7.TabIndex = 1057;
            this.label7.Tag = "Charges";
            this.label7.Text = "Non Covered";
            this.label7.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.Beige;
            this.label8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label8.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(472, 588);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(63, 16);
            this.label8.TabIndex = 1058;
            this.label8.Tag = "Charges";
            this.label8.Text = "Units";
            this.label8.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.Color.Beige;
            this.label9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label9.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(379, 588);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(93, 16);
            this.label9.TabIndex = 1057;
            this.label9.Tag = "Charges";
            this.label9.Text = "Service Date";
            this.label9.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.Color.Beige;
            this.label11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label11.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(69, 588);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(114, 16);
            this.label11.TabIndex = 1057;
            this.label11.Tag = "Charges";
            this.label11.Text = "HCPCS / RATE";
            this.label11.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.Color.Beige;
            this.label12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label12.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(24, 588);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(45, 16);
            this.label12.TabIndex = 1057;
            this.label12.Tag = "Charges";
            this.label12.Text = "Rev Code";
            this.label12.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.Color.Beige;
            this.label14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label14.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(727, 588);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(104, 16);
            this.label14.TabIndex = 1059;
            this.label14.Tag = "Charges";
            this.label14.Text = "NDC";
            this.label14.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label15
            // 
            this.label15.BackColor = System.Drawing.Color.Beige;
            this.label15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label15.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(831, 588);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(68, 16);
            this.label15.TabIndex = 1057;
            this.label15.Tag = "Charges";
            this.label15.Text = "NDC Type";
            this.label15.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label16
            // 
            this.label16.BackColor = System.Drawing.Color.Beige;
            this.label16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label16.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(899, 588);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(101, 16);
            this.label16.TabIndex = 1057;
            this.label16.Tag = "Charges";
            this.label16.Text = "NDC Quantity";
            this.label16.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(316, 379);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(132, 13);
            this.label10.TabIndex = 806;
            this.label10.Tag = "32aocrcd";
            this.label10.Text = "33 Occurrence Code:Date";
            // 
            // dcim33aocrcd
            // 
            this.dcim33aocrcd.Location = new System.Drawing.Point(318, 394);
            this.dcim33aocrcd.Name = "dcim33aocrcd";
            this.dcim33aocrcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim33aocrcd.OcxState")));
            this.dcim33aocrcd.Size = new System.Drawing.Size(53, 18);
            this.dcim33aocrcd.TabIndex = 807;
            this.dcim33aocrcd.TabStop = false;
            this.dcim33aocrcd.Tag = "33aocrcd";
            // 
            // dced33aocrcd
            // 
            this.dced33aocrcd.Location = new System.Drawing.Point(318, 413);
            this.dced33aocrcd.Name = "dced33aocrcd";
            this.dced33aocrcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced33aocrcd.OcxState")));
            this.dced33aocrcd.Size = new System.Drawing.Size(53, 18);
            this.dced33aocrcd.TabIndex = 55;
            this.dced33aocrcd.Tag = "33aocrcd";
            // 
            // dcim33aocrdt
            // 
            this.dcim33aocrdt.Location = new System.Drawing.Point(374, 394);
            this.dcim33aocrdt.Name = "dcim33aocrdt";
            this.dcim33aocrdt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim33aocrdt.OcxState")));
            this.dcim33aocrdt.Size = new System.Drawing.Size(79, 18);
            this.dcim33aocrdt.TabIndex = 809;
            this.dcim33aocrdt.TabStop = false;
            this.dcim33aocrdt.Tag = "33aocrdt";
            // 
            // dced33aocrdt
            // 
            this.dced33aocrdt.Location = new System.Drawing.Point(374, 413);
            this.dced33aocrdt.Name = "dced33aocrdt";
            this.dced33aocrdt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced33aocrdt.OcxState")));
            this.dced33aocrdt.Size = new System.Drawing.Size(79, 18);
            this.dced33aocrdt.TabIndex = 56;
            this.dced33aocrdt.Tag = "33aocrdt";
            // 
            // dcim33bocrcd
            // 
            this.dcim33bocrcd.Location = new System.Drawing.Point(318, 436);
            this.dcim33bocrcd.Name = "dcim33bocrcd";
            this.dcim33bocrcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim33bocrcd.OcxState")));
            this.dcim33bocrcd.Size = new System.Drawing.Size(53, 18);
            this.dcim33bocrcd.TabIndex = 811;
            this.dcim33bocrcd.TabStop = false;
            this.dcim33bocrcd.Tag = "33bocrcd";
            // 
            // dced33bocrcd
            // 
            this.dced33bocrcd.Location = new System.Drawing.Point(318, 455);
            this.dced33bocrcd.Name = "dced33bocrcd";
            this.dced33bocrcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced33bocrcd.OcxState")));
            this.dced33bocrcd.Size = new System.Drawing.Size(53, 18);
            this.dced33bocrcd.TabIndex = 57;
            this.dced33bocrcd.Tag = "33bocrcd";
            // 
            // dcim33bocrdt
            // 
            this.dcim33bocrdt.Location = new System.Drawing.Point(374, 436);
            this.dcim33bocrdt.Name = "dcim33bocrdt";
            this.dcim33bocrdt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim33bocrdt.OcxState")));
            this.dcim33bocrdt.Size = new System.Drawing.Size(79, 18);
            this.dcim33bocrdt.TabIndex = 813;
            this.dcim33bocrdt.TabStop = false;
            this.dcim33bocrdt.Tag = "33bocrdt";
            // 
            // dced33bocrdt
            // 
            this.dced33bocrdt.Location = new System.Drawing.Point(374, 455);
            this.dced33bocrdt.Name = "dced33bocrdt";
            this.dced33bocrdt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced33bocrdt.OcxState")));
            this.dced33bocrdt.Size = new System.Drawing.Size(79, 18);
            this.dced33bocrdt.TabIndex = 58;
            this.dced33bocrdt.Tag = "33bocrdt";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(465, 379);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(132, 13);
            this.label17.TabIndex = 1060;
            this.label17.Tag = "32aocrcd";
            this.label17.Text = "34 Occurrence Code:Date";
            // 
            // dcim34aocrcd
            // 
            this.dcim34aocrcd.Location = new System.Drawing.Point(467, 394);
            this.dcim34aocrcd.Name = "dcim34aocrcd";
            this.dcim34aocrcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim34aocrcd.OcxState")));
            this.dcim34aocrcd.Size = new System.Drawing.Size(53, 18);
            this.dcim34aocrcd.TabIndex = 1061;
            this.dcim34aocrcd.TabStop = false;
            this.dcim34aocrcd.Tag = "34aocrcd";
            // 
            // dced34aocrcd
            // 
            this.dced34aocrcd.Location = new System.Drawing.Point(467, 413);
            this.dced34aocrcd.Name = "dced34aocrcd";
            this.dced34aocrcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced34aocrcd.OcxState")));
            this.dced34aocrcd.Size = new System.Drawing.Size(53, 18);
            this.dced34aocrcd.TabIndex = 59;
            this.dced34aocrcd.Tag = "34aocrcd";
            // 
            // dcim34aocrdt
            // 
            this.dcim34aocrdt.Location = new System.Drawing.Point(523, 394);
            this.dcim34aocrdt.Name = "dcim34aocrdt";
            this.dcim34aocrdt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim34aocrdt.OcxState")));
            this.dcim34aocrdt.Size = new System.Drawing.Size(79, 18);
            this.dcim34aocrdt.TabIndex = 1063;
            this.dcim34aocrdt.TabStop = false;
            this.dcim34aocrdt.Tag = "34aocrdt";
            // 
            // dced34aocrdt
            // 
            this.dced34aocrdt.Location = new System.Drawing.Point(523, 413);
            this.dced34aocrdt.Name = "dced34aocrdt";
            this.dced34aocrdt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced34aocrdt.OcxState")));
            this.dced34aocrdt.Size = new System.Drawing.Size(79, 18);
            this.dced34aocrdt.TabIndex = 60;
            this.dced34aocrdt.Tag = "34aocrdt";
            // 
            // dcim34bocrcd
            // 
            this.dcim34bocrcd.Location = new System.Drawing.Point(467, 436);
            this.dcim34bocrcd.Name = "dcim34bocrcd";
            this.dcim34bocrcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim34bocrcd.OcxState")));
            this.dcim34bocrcd.Size = new System.Drawing.Size(53, 18);
            this.dcim34bocrcd.TabIndex = 1065;
            this.dcim34bocrcd.TabStop = false;
            this.dcim34bocrcd.Tag = "34bocrcd";
            // 
            // dced34bocrcd
            // 
            this.dced34bocrcd.Location = new System.Drawing.Point(467, 455);
            this.dced34bocrcd.Name = "dced34bocrcd";
            this.dced34bocrcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced34bocrcd.OcxState")));
            this.dced34bocrcd.Size = new System.Drawing.Size(53, 18);
            this.dced34bocrcd.TabIndex = 61;
            this.dced34bocrcd.Tag = "34bocrcd";
            // 
            // dcim34bocrdt
            // 
            this.dcim34bocrdt.Location = new System.Drawing.Point(523, 436);
            this.dcim34bocrdt.Name = "dcim34bocrdt";
            this.dcim34bocrdt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim34bocrdt.OcxState")));
            this.dcim34bocrdt.Size = new System.Drawing.Size(79, 18);
            this.dcim34bocrdt.TabIndex = 1067;
            this.dcim34bocrdt.TabStop = false;
            this.dcim34bocrdt.Tag = "34bocrdt";
            // 
            // dced34bocrdt
            // 
            this.dced34bocrdt.Location = new System.Drawing.Point(523, 455);
            this.dced34bocrdt.Name = "dced34bocrdt";
            this.dced34bocrdt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced34bocrdt.OcxState")));
            this.dced34bocrdt.Size = new System.Drawing.Size(79, 18);
            this.dced34bocrdt.TabIndex = 62;
            this.dced34bocrdt.Tag = "34bocrdt";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.Lavender;
            this.label18.Location = new System.Drawing.Point(54, 479);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(208, 13);
            this.label18.TabIndex = 1069;
            this.label18.Tag = "36aospcd";
            this.label18.Text = "35 Occurrence Span. Code:From/Through";
            // 
            // dcim35aospcd
            // 
            this.dcim35aospcd.Location = new System.Drawing.Point(56, 492);
            this.dcim35aospcd.Name = "dcim35aospcd";
            this.dcim35aospcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim35aospcd.OcxState")));
            this.dcim35aospcd.Size = new System.Drawing.Size(92, 18);
            this.dcim35aospcd.TabIndex = 1070;
            this.dcim35aospcd.TabStop = false;
            this.dcim35aospcd.Tag = "35aospcd";
            // 
            // dced35aospcd
            // 
            this.dced35aospcd.Location = new System.Drawing.Point(56, 511);
            this.dced35aospcd.Name = "dced35aospcd";
            this.dced35aospcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced35aospcd.OcxState")));
            this.dced35aospcd.Size = new System.Drawing.Size(92, 18);
            this.dced35aospcd.TabIndex = 63;
            this.dced35aospcd.Tag = "35aospcd";
            // 
            // dcim35aospfr
            // 
            this.dcim35aospfr.Location = new System.Drawing.Point(152, 492);
            this.dcim35aospfr.Name = "dcim35aospfr";
            this.dcim35aospfr.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim35aospfr.OcxState")));
            this.dcim35aospfr.Size = new System.Drawing.Size(81, 18);
            this.dcim35aospfr.TabIndex = 1072;
            this.dcim35aospfr.TabStop = false;
            this.dcim35aospfr.Tag = "35aospfr";
            // 
            // dced35aospfr
            // 
            this.dced35aospfr.Location = new System.Drawing.Point(152, 511);
            this.dced35aospfr.Name = "dced35aospfr";
            this.dced35aospfr.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced35aospfr.OcxState")));
            this.dced35aospfr.Size = new System.Drawing.Size(81, 18);
            this.dced35aospfr.TabIndex = 64;
            this.dced35aospfr.Tag = "35aospfr";
            // 
            // dcim35aospth
            // 
            this.dcim35aospth.Location = new System.Drawing.Point(233, 492);
            this.dcim35aospth.Name = "dcim35aospth";
            this.dcim35aospth.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim35aospth.OcxState")));
            this.dcim35aospth.Size = new System.Drawing.Size(78, 18);
            this.dcim35aospth.TabIndex = 1074;
            this.dcim35aospth.TabStop = false;
            this.dcim35aospth.Tag = "35aospth";
            // 
            // dced35aospth
            // 
            this.dced35aospth.Location = new System.Drawing.Point(233, 511);
            this.dced35aospth.Name = "dced35aospth";
            this.dced35aospth.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced35aospth.OcxState")));
            this.dced35aospth.Size = new System.Drawing.Size(78, 18);
            this.dced35aospth.TabIndex = 65;
            this.dced35aospth.Tag = "35aospth";
            // 
            // dcim35bospcd
            // 
            this.dcim35bospcd.Location = new System.Drawing.Point(56, 535);
            this.dcim35bospcd.Name = "dcim35bospcd";
            this.dcim35bospcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim35bospcd.OcxState")));
            this.dcim35bospcd.Size = new System.Drawing.Size(92, 18);
            this.dcim35bospcd.TabIndex = 1076;
            this.dcim35bospcd.TabStop = false;
            this.dcim35bospcd.Tag = "35bospcd";
            // 
            // dced35bospcd
            // 
            this.dced35bospcd.Location = new System.Drawing.Point(56, 554);
            this.dced35bospcd.Name = "dced35bospcd";
            this.dced35bospcd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced35bospcd.OcxState")));
            this.dced35bospcd.Size = new System.Drawing.Size(92, 18);
            this.dced35bospcd.TabIndex = 66;
            this.dced35bospcd.Tag = "35bospcd";
            // 
            // dcim35bospfr
            // 
            this.dcim35bospfr.Location = new System.Drawing.Point(152, 535);
            this.dcim35bospfr.Name = "dcim35bospfr";
            this.dcim35bospfr.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim35bospfr.OcxState")));
            this.dcim35bospfr.Size = new System.Drawing.Size(81, 18);
            this.dcim35bospfr.TabIndex = 1078;
            this.dcim35bospfr.TabStop = false;
            this.dcim35bospfr.Tag = "35bospfr";
            // 
            // dced35bospfr
            // 
            this.dced35bospfr.Location = new System.Drawing.Point(152, 554);
            this.dced35bospfr.Name = "dced35bospfr";
            this.dced35bospfr.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced35bospfr.OcxState")));
            this.dced35bospfr.Size = new System.Drawing.Size(81, 18);
            this.dced35bospfr.TabIndex = 67;
            this.dced35bospfr.Tag = "35bospfr";
            // 
            // dcim35bospth
            // 
            this.dcim35bospth.Location = new System.Drawing.Point(233, 535);
            this.dcim35bospth.Name = "dcim35bospth";
            this.dcim35bospth.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim35bospth.OcxState")));
            this.dcim35bospth.Size = new System.Drawing.Size(78, 18);
            this.dcim35bospth.TabIndex = 1080;
            this.dcim35bospth.TabStop = false;
            this.dcim35bospth.Tag = "35bospth";
            // 
            // dced35bospth
            // 
            this.dced35bospth.Location = new System.Drawing.Point(233, 554);
            this.dced35bospth.Name = "dced35bospth";
            this.dced35bospth.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced35bospth.OcxState")));
            this.dced35bospth.Size = new System.Drawing.Size(78, 18);
            this.dced35bospth.TabIndex = 68;
            this.dced35bospth.Tag = "35bospth";
            // 
            // dcim2payto
            // 
            this.dcim2payto.Location = new System.Drawing.Point(328, 30);
            this.dcim2payto.Name = "dcim2payto";
            this.dcim2payto.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim2payto.OcxState")));
            this.dcim2payto.Size = new System.Drawing.Size(270, 95);
            this.dcim2payto.TabIndex = 7;
            this.dcim2payto.TabStop = false;
            this.dcim2payto.Tag = "2payto";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.Lavender;
            this.label19.Location = new System.Drawing.Point(327, 16);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(46, 13);
            this.label19.TabIndex = 1084;
            this.label19.Tag = "1provnam";
            this.label19.Text = "2 Pay to";
            // 
            // dced2paytnm
            // 
            this.dced2paytnm.Location = new System.Drawing.Point(328, 141);
            this.dced2paytnm.Name = "dced2paytnm";
            this.dced2paytnm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced2paytnm.OcxState")));
            this.dced2paytnm.Size = new System.Drawing.Size(270, 18);
            this.dced2paytnm.TabIndex = 8;
            this.dced2paytnm.Tag = "2paytnm";
            // 
            // dced2paytadd
            // 
            this.dced2paytadd.Location = new System.Drawing.Point(328, 177);
            this.dced2paytadd.Name = "dced2paytadd";
            this.dced2paytadd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced2paytadd.OcxState")));
            this.dced2paytadd.Size = new System.Drawing.Size(270, 18);
            this.dced2paytadd.TabIndex = 9;
            this.dced2paytadd.Tag = "2paytadd";
            // 
            // dced2paytcty
            // 
            this.dced2paytcty.Location = new System.Drawing.Point(328, 213);
            this.dced2paytcty.Name = "dced2paytcty";
            this.dced2paytcty.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced2paytcty.OcxState")));
            this.dced2paytcty.Size = new System.Drawing.Size(270, 18);
            this.dced2paytcty.TabIndex = 10;
            this.dced2paytcty.Tag = "2paytcty";
            // 
            // dced2paytst
            // 
            this.dced2paytst.Location = new System.Drawing.Point(328, 247);
            this.dced2paytst.Name = "dced2paytst";
            this.dced2paytst.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced2paytst.OcxState")));
            this.dced2paytst.Size = new System.Drawing.Size(178, 18);
            this.dced2paytst.TabIndex = 11;
            this.dced2paytst.Tag = "2paytst";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.Lavender;
            this.label20.Location = new System.Drawing.Point(328, 128);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(66, 13);
            this.label20.TabIndex = 1082;
            this.label20.Tag = "1fcynmad";
            this.label20.Text = "Pay to name";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.Lavender;
            this.label21.Location = new System.Drawing.Point(328, 164);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(45, 13);
            this.label21.TabIndex = 1086;
            this.label21.Tag = "1provadd";
            this.label21.Text = "Address";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.Lavender;
            this.label22.Location = new System.Drawing.Point(328, 200);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(24, 13);
            this.label22.TabIndex = 1088;
            this.label22.Tag = "1provcit";
            this.label22.Text = "City";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.Lavender;
            this.label23.Location = new System.Drawing.Point(328, 234);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(32, 13);
            this.label23.TabIndex = 1090;
            this.label23.Tag = "1provsta";
            this.label23.Text = "State";
            // 
            // dced2paytzip
            // 
            this.dced2paytzip.Location = new System.Drawing.Point(512, 246);
            this.dced2paytzip.Name = "dced2paytzip";
            this.dced2paytzip.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced2paytzip.OcxState")));
            this.dced2paytzip.Size = new System.Drawing.Size(86, 18);
            this.dced2paytzip.TabIndex = 12;
            this.dced2paytzip.Tag = "2paytzip";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.Lavender;
            this.label24.Location = new System.Drawing.Point(511, 233);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(22, 13);
            this.label24.TabIndex = 1092;
            this.label24.Tag = "1provzip";
            this.label24.Text = "Zip";
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.Color.Lavender;
            this.pictureBox6.Location = new System.Drawing.Point(322, 11);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(284, 296);
            this.pictureBox6.TabIndex = 1094;
            this.pictureBox6.TabStop = false;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.Color.Lavender;
            this.label25.Location = new System.Drawing.Point(474, 321);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(19, 13);
            this.label25.TabIndex = 1095;
            this.label25.Tag = "13admhr";
            this.label25.Text = "18";
            // 
            // dcim18concd
            // 
            this.dcim18concd.Location = new System.Drawing.Point(462, 334);
            this.dcim18concd.Name = "dcim18concd";
            this.dcim18concd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim18concd.OcxState")));
            this.dcim18concd.Size = new System.Drawing.Size(44, 18);
            this.dcim18concd.TabIndex = 1096;
            this.dcim18concd.TabStop = false;
            this.dcim18concd.Tag = "18concd";
            // 
            // dced18concd
            // 
            this.dced18concd.Location = new System.Drawing.Point(462, 353);
            this.dced18concd.Name = "dced18concd";
            this.dced18concd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced18concd.OcxState")));
            this.dced18concd.Size = new System.Drawing.Size(44, 18);
            this.dced18concd.TabIndex = 36;
            this.dced18concd.Tag = "18concd";
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackColor = System.Drawing.Color.Lavender;
            this.pictureBox7.Location = new System.Drawing.Point(374, 315);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(624, 63);
            this.pictureBox7.TabIndex = 873;
            this.pictureBox7.TabStop = false;
            // 
            // axDcimage1
            // 
            this.axDcimage1.Location = new System.Drawing.Point(510, 334);
            this.axDcimage1.Name = "axDcimage1";
            this.axDcimage1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axDcimage1.OcxState")));
            this.axDcimage1.Size = new System.Drawing.Size(44, 18);
            this.axDcimage1.TabIndex = 1099;
            this.axDcimage1.TabStop = false;
            this.axDcimage1.Tag = "18concd";
            // 
            // axDcedit1
            // 
            this.axDcedit1.Location = new System.Drawing.Point(510, 353);
            this.axDcedit1.Name = "axDcedit1";
            this.axDcedit1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axDcedit1.OcxState")));
            this.axDcedit1.Size = new System.Drawing.Size(44, 18);
            this.axDcedit1.TabIndex = 1100;
            this.axDcedit1.Tag = "18concd";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.BackColor = System.Drawing.Color.Lavender;
            this.label28.Location = new System.Drawing.Point(570, 321);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(19, 13);
            this.label28.TabIndex = 1102;
            this.label28.Tag = "13admhr";
            this.label28.Text = "20";
            // 
            // dcim20concd
            // 
            this.dcim20concd.Location = new System.Drawing.Point(558, 334);
            this.dcim20concd.Name = "dcim20concd";
            this.dcim20concd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim20concd.OcxState")));
            this.dcim20concd.Size = new System.Drawing.Size(44, 18);
            this.dcim20concd.TabIndex = 1103;
            this.dcim20concd.TabStop = false;
            this.dcim20concd.Tag = "20concd";
            // 
            // dced20concd
            // 
            this.dced20concd.Location = new System.Drawing.Point(558, 353);
            this.dced20concd.Name = "dced20concd";
            this.dced20concd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced20concd.OcxState")));
            this.dced20concd.Size = new System.Drawing.Size(44, 18);
            this.dced20concd.TabIndex = 38;
            this.dced20concd.Tag = "20concd";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.BackColor = System.Drawing.Color.Lavender;
            this.label26.Location = new System.Drawing.Point(522, 321);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(19, 13);
            this.label26.TabIndex = 1105;
            this.label26.Tag = "13admhr";
            this.label26.Text = "19";
            // 
            // dcim19concd
            // 
            this.dcim19concd.Location = new System.Drawing.Point(510, 334);
            this.dcim19concd.Name = "dcim19concd";
            this.dcim19concd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim19concd.OcxState")));
            this.dcim19concd.Size = new System.Drawing.Size(44, 18);
            this.dcim19concd.TabIndex = 1106;
            this.dcim19concd.TabStop = false;
            this.dcim19concd.Tag = "19concd";
            // 
            // dced19concd
            // 
            this.dced19concd.Location = new System.Drawing.Point(510, 353);
            this.dced19concd.Name = "dced19concd";
            this.dced19concd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced19concd.OcxState")));
            this.dced19concd.Size = new System.Drawing.Size(44, 18);
            this.dced19concd.TabIndex = 37;
            this.dced19concd.Tag = "19concd";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.BackColor = System.Drawing.Color.Lavender;
            this.label29.Location = new System.Drawing.Point(618, 321);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(19, 13);
            this.label29.TabIndex = 1108;
            this.label29.Tag = "13admhr";
            this.label29.Text = "21";
            // 
            // dcim21concd
            // 
            this.dcim21concd.Location = new System.Drawing.Point(606, 334);
            this.dcim21concd.Name = "dcim21concd";
            this.dcim21concd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim21concd.OcxState")));
            this.dcim21concd.Size = new System.Drawing.Size(44, 18);
            this.dcim21concd.TabIndex = 1109;
            this.dcim21concd.TabStop = false;
            this.dcim21concd.Tag = "21concd";
            // 
            // dced21concd
            // 
            this.dced21concd.Location = new System.Drawing.Point(606, 353);
            this.dced21concd.Name = "dced21concd";
            this.dced21concd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced21concd.OcxState")));
            this.dced21concd.Size = new System.Drawing.Size(44, 18);
            this.dced21concd.TabIndex = 39;
            this.dced21concd.Tag = "21concd";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.BackColor = System.Drawing.Color.Lavender;
            this.label30.Location = new System.Drawing.Point(714, 321);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(19, 13);
            this.label30.TabIndex = 1111;
            this.label30.Tag = "13admhr";
            this.label30.Text = "23";
            // 
            // dcim23concd
            // 
            this.dcim23concd.Location = new System.Drawing.Point(702, 334);
            this.dcim23concd.Name = "dcim23concd";
            this.dcim23concd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim23concd.OcxState")));
            this.dcim23concd.Size = new System.Drawing.Size(44, 18);
            this.dcim23concd.TabIndex = 1112;
            this.dcim23concd.TabStop = false;
            this.dcim23concd.Tag = "23concd";
            // 
            // dced23concd
            // 
            this.dced23concd.Location = new System.Drawing.Point(702, 353);
            this.dced23concd.Name = "dced23concd";
            this.dced23concd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced23concd.OcxState")));
            this.dced23concd.Size = new System.Drawing.Size(44, 18);
            this.dced23concd.TabIndex = 41;
            this.dced23concd.Tag = "23concd";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.BackColor = System.Drawing.Color.Lavender;
            this.label31.Location = new System.Drawing.Point(762, 321);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(19, 13);
            this.label31.TabIndex = 1114;
            this.label31.Tag = "13admhr";
            this.label31.Text = "24";
            // 
            // dcim24concd
            // 
            this.dcim24concd.Location = new System.Drawing.Point(750, 334);
            this.dcim24concd.Name = "dcim24concd";
            this.dcim24concd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim24concd.OcxState")));
            this.dcim24concd.Size = new System.Drawing.Size(44, 18);
            this.dcim24concd.TabIndex = 1115;
            this.dcim24concd.TabStop = false;
            this.dcim24concd.Tag = "24concd";
            // 
            // dced24concd
            // 
            this.dced24concd.Location = new System.Drawing.Point(750, 353);
            this.dced24concd.Name = "dced24concd";
            this.dced24concd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced24concd.OcxState")));
            this.dced24concd.Size = new System.Drawing.Size(44, 18);
            this.dced24concd.TabIndex = 42;
            this.dced24concd.Tag = "24concd";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.BackColor = System.Drawing.Color.Lavender;
            this.label32.Location = new System.Drawing.Point(810, 321);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(19, 13);
            this.label32.TabIndex = 1117;
            this.label32.Tag = "13admhr";
            this.label32.Text = "25";
            // 
            // dcim25concd
            // 
            this.dcim25concd.Location = new System.Drawing.Point(798, 334);
            this.dcim25concd.Name = "dcim25concd";
            this.dcim25concd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim25concd.OcxState")));
            this.dcim25concd.Size = new System.Drawing.Size(44, 18);
            this.dcim25concd.TabIndex = 1118;
            this.dcim25concd.TabStop = false;
            this.dcim25concd.Tag = "25concd";
            // 
            // dced25concd
            // 
            this.dced25concd.Location = new System.Drawing.Point(798, 353);
            this.dced25concd.Name = "dced25concd";
            this.dced25concd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced25concd.OcxState")));
            this.dced25concd.Size = new System.Drawing.Size(44, 18);
            this.dced25concd.TabIndex = 43;
            this.dced25concd.Tag = "25concd";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.BackColor = System.Drawing.Color.Lavender;
            this.label33.Location = new System.Drawing.Point(858, 321);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(19, 13);
            this.label33.TabIndex = 1120;
            this.label33.Tag = "13admhr";
            this.label33.Text = "26";
            // 
            // dcim26concd
            // 
            this.dcim26concd.Location = new System.Drawing.Point(846, 334);
            this.dcim26concd.Name = "dcim26concd";
            this.dcim26concd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim26concd.OcxState")));
            this.dcim26concd.Size = new System.Drawing.Size(44, 18);
            this.dcim26concd.TabIndex = 1121;
            this.dcim26concd.TabStop = false;
            this.dcim26concd.Tag = "26concd";
            // 
            // dced26concd
            // 
            this.dced26concd.Location = new System.Drawing.Point(846, 353);
            this.dced26concd.Name = "dced26concd";
            this.dced26concd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced26concd.OcxState")));
            this.dced26concd.Size = new System.Drawing.Size(44, 18);
            this.dced26concd.TabIndex = 44;
            this.dced26concd.Tag = "26concd";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.BackColor = System.Drawing.Color.Lavender;
            this.label34.Location = new System.Drawing.Point(666, 321);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(19, 13);
            this.label34.TabIndex = 1123;
            this.label34.Tag = "13admhr";
            this.label34.Text = "22";
            // 
            // dcim22concd
            // 
            this.dcim22concd.Location = new System.Drawing.Point(654, 334);
            this.dcim22concd.Name = "dcim22concd";
            this.dcim22concd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim22concd.OcxState")));
            this.dcim22concd.Size = new System.Drawing.Size(44, 18);
            this.dcim22concd.TabIndex = 1124;
            this.dcim22concd.TabStop = false;
            this.dcim22concd.Tag = "22concd";
            // 
            // dced22concd
            // 
            this.dced22concd.Location = new System.Drawing.Point(654, 353);
            this.dced22concd.Name = "dced22concd";
            this.dced22concd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced22concd.OcxState")));
            this.dced22concd.Size = new System.Drawing.Size(44, 18);
            this.dced22concd.TabIndex = 40;
            this.dced22concd.Tag = "22concd";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.BackColor = System.Drawing.Color.Lavender;
            this.label35.Location = new System.Drawing.Point(906, 321);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(19, 13);
            this.label35.TabIndex = 1126;
            this.label35.Tag = "13admhr";
            this.label35.Text = "27";
            // 
            // dcim27concd
            // 
            this.dcim27concd.Location = new System.Drawing.Point(894, 334);
            this.dcim27concd.Name = "dcim27concd";
            this.dcim27concd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim27concd.OcxState")));
            this.dcim27concd.Size = new System.Drawing.Size(44, 18);
            this.dcim27concd.TabIndex = 1127;
            this.dcim27concd.TabStop = false;
            this.dcim27concd.Tag = "27concd";
            // 
            // dced27concd
            // 
            this.dced27concd.Location = new System.Drawing.Point(894, 353);
            this.dced27concd.Name = "dced27concd";
            this.dced27concd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced27concd.OcxState")));
            this.dced27concd.Size = new System.Drawing.Size(44, 18);
            this.dced27concd.TabIndex = 45;
            this.dced27concd.Tag = "27concd";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.BackColor = System.Drawing.Color.Lavender;
            this.label27.Location = new System.Drawing.Point(954, 321);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(19, 13);
            this.label27.TabIndex = 1129;
            this.label27.Tag = "13admhr";
            this.label27.Text = "28";
            // 
            // dcim28concd
            // 
            this.dcim28concd.Location = new System.Drawing.Point(942, 334);
            this.dcim28concd.Name = "dcim28concd";
            this.dcim28concd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim28concd.OcxState")));
            this.dcim28concd.Size = new System.Drawing.Size(44, 18);
            this.dcim28concd.TabIndex = 1130;
            this.dcim28concd.TabStop = false;
            this.dcim28concd.Tag = "28concd";
            // 
            // dced28concd
            // 
            this.dced28concd.Location = new System.Drawing.Point(942, 353);
            this.dced28concd.Name = "dced28concd";
            this.dced28concd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced28concd.OcxState")));
            this.dced28concd.Size = new System.Drawing.Size(44, 18);
            this.dced28concd.TabIndex = 46;
            this.dced28concd.Tag = "28concd";
            // 
            // dced2paytid
            // 
            this.dced2paytid.Location = new System.Drawing.Point(329, 283);
            this.dced2paytid.Name = "dced2paytid";
            this.dced2paytid.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced2paytid.OcxState")));
            this.dced2paytid.Size = new System.Drawing.Size(269, 18);
            this.dced2paytid.TabIndex = 13;
            this.dced2paytid.Tag = "2paytid";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.BackColor = System.Drawing.Color.Lavender;
            this.label36.Location = new System.Drawing.Point(329, 270);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(18, 13);
            this.label36.TabIndex = 1132;
            this.label36.Tag = "1provsta";
            this.label36.Text = "ID";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.BackColor = System.Drawing.Color.Lavender;
            this.label37.Location = new System.Drawing.Point(378, 321);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(84, 13);
            this.label37.TabIndex = 1134;
            this.label37.Tag = "13admhr";
            this.label37.Text = "Condition Codes";
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackColor = System.Drawing.Color.Lavender;
            this.pictureBox8.Location = new System.Drawing.Point(27, 315);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(338, 63);
            this.pictureBox8.TabIndex = 874;
            this.pictureBox8.TabStop = false;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.BackColor = System.Drawing.Color.Lavender;
            this.label38.Location = new System.Drawing.Point(29, 321);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(54, 13);
            this.label38.TabIndex = 774;
            this.label38.Tag = "12admdte";
            this.label38.Text = "Admission";
            // 
            // pictureBox10
            // 
            this.pictureBox10.BackColor = System.Drawing.Color.Lavender;
            this.pictureBox10.Location = new System.Drawing.Point(29, 478);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(565, 99);
            this.pictureBox10.TabIndex = 1136;
            this.pictureBox10.TabStop = false;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(606, 404);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(15, 15);
            this.label13.TabIndex = 1137;
            this.label13.Text = "A";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(606, 446);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(16, 15);
            this.label39.TabIndex = 1138;
            this.label39.Text = "B";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(606, 487);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(16, 15);
            this.label40.TabIndex = 1139;
            this.label40.Text = "C";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(606, 530);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(17, 15);
            this.label41.TabIndex = 1140;
            this.label41.Text = "D";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.BackColor = System.Drawing.Color.Lavender;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(37, 501);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(15, 15);
            this.label42.TabIndex = 1141;
            this.label42.Text = "A";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.BackColor = System.Drawing.Color.Lavender;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(36, 545);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(16, 15);
            this.label43.TabIndex = 1142;
            this.label43.Text = "B";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(11, 404);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(15, 15);
            this.label44.TabIndex = 1143;
            this.label44.Text = "A";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(11, 446);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(16, 15);
            this.label45.TabIndex = 1144;
            this.label45.Text = "B";
            // 
            // dced67POA
            // 
            this.dced67POA.Location = new System.Drawing.Point(119, 1179);
            this.dced67POA.Name = "dced67POA";
            this.dced67POA.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced67POA.OcxState")));
            this.dced67POA.Size = new System.Drawing.Size(15, 18);
            this.dced67POA.TabIndex = 131;
            this.dced67POA.Tag = "67POA";
            // 
            // dcim67bPOA
            // 
            this.dcim67bPOA.Location = new System.Drawing.Point(301, 1160);
            this.dcim67bPOA.Name = "dcim67bPOA";
            this.dcim67bPOA.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim67bPOA.OcxState")));
            this.dcim67bPOA.Size = new System.Drawing.Size(15, 18);
            this.dcim67bPOA.TabIndex = 1147;
            this.dcim67bPOA.TabStop = false;
            this.dcim67bPOA.Tag = "67bPOA";
            // 
            // dced67bPOA
            // 
            this.dced67bPOA.Location = new System.Drawing.Point(301, 1179);
            this.dced67bPOA.Name = "dced67bPOA";
            this.dced67bPOA.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced67bPOA.OcxState")));
            this.dced67bPOA.Size = new System.Drawing.Size(15, 18);
            this.dced67bPOA.TabIndex = 135;
            this.dced67bPOA.Tag = "67bPOA";
            // 
            // dcim67dPOA
            // 
            this.dcim67dPOA.Location = new System.Drawing.Point(483, 1160);
            this.dcim67dPOA.Name = "dcim67dPOA";
            this.dcim67dPOA.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim67dPOA.OcxState")));
            this.dcim67dPOA.Size = new System.Drawing.Size(15, 18);
            this.dcim67dPOA.TabIndex = 1149;
            this.dcim67dPOA.TabStop = false;
            this.dcim67dPOA.Tag = "67dPOA";
            // 
            // dced67dPOA
            // 
            this.dced67dPOA.Location = new System.Drawing.Point(483, 1179);
            this.dced67dPOA.Name = "dced67dPOA";
            this.dced67dPOA.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced67dPOA.OcxState")));
            this.dced67dPOA.Size = new System.Drawing.Size(15, 18);
            this.dced67dPOA.TabIndex = 139;
            this.dced67dPOA.Tag = "67dPOA";
            // 
            // dcim67ePOA
            // 
            this.dcim67ePOA.Location = new System.Drawing.Point(575, 1160);
            this.dcim67ePOA.Name = "dcim67ePOA";
            this.dcim67ePOA.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim67ePOA.OcxState")));
            this.dcim67ePOA.Size = new System.Drawing.Size(15, 18);
            this.dcim67ePOA.TabIndex = 1151;
            this.dcim67ePOA.TabStop = false;
            this.dcim67ePOA.Tag = "67ePOA";
            // 
            // dced67ePOA
            // 
            this.dced67ePOA.Location = new System.Drawing.Point(575, 1179);
            this.dced67ePOA.Name = "dced67ePOA";
            this.dced67ePOA.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced67ePOA.OcxState")));
            this.dced67ePOA.Size = new System.Drawing.Size(15, 18);
            this.dced67ePOA.TabIndex = 141;
            this.dced67ePOA.Tag = "67ePOA";
            // 
            // dcim67fPOA
            // 
            this.dcim67fPOA.Location = new System.Drawing.Point(666, 1160);
            this.dcim67fPOA.Name = "dcim67fPOA";
            this.dcim67fPOA.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim67fPOA.OcxState")));
            this.dcim67fPOA.Size = new System.Drawing.Size(15, 18);
            this.dcim67fPOA.TabIndex = 1153;
            this.dcim67fPOA.TabStop = false;
            this.dcim67fPOA.Tag = "67fPOA";
            // 
            // dced67fPOA
            // 
            this.dced67fPOA.Location = new System.Drawing.Point(666, 1179);
            this.dced67fPOA.Name = "dced67fPOA";
            this.dced67fPOA.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced67fPOA.OcxState")));
            this.dced67fPOA.Size = new System.Drawing.Size(15, 18);
            this.dced67fPOA.TabIndex = 143;
            this.dced67fPOA.Tag = "67fPOA";
            // 
            // axDcimage6
            // 
            this.axDcimage6.Location = new System.Drawing.Point(210, 1214);
            this.axDcimage6.Name = "axDcimage6";
            this.axDcimage6.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axDcimage6.OcxState")));
            this.axDcimage6.Size = new System.Drawing.Size(15, 18);
            this.axDcimage6.TabIndex = 1161;
            this.axDcimage6.TabStop = false;
            this.axDcimage6.Tag = "67POA";
            // 
            // axDcedit8
            // 
            this.axDcedit8.Location = new System.Drawing.Point(210, 1233);
            this.axDcedit8.Name = "axDcedit8";
            this.axDcedit8.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axDcedit8.OcxState")));
            this.axDcedit8.Size = new System.Drawing.Size(15, 18);
            this.axDcedit8.TabIndex = 151;
            this.axDcedit8.Tag = "67POA";
            // 
            // dcim67hPOA
            // 
            this.dcim67hPOA.Location = new System.Drawing.Point(848, 1160);
            this.dcim67hPOA.Name = "dcim67hPOA";
            this.dcim67hPOA.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim67hPOA.OcxState")));
            this.dcim67hPOA.Size = new System.Drawing.Size(15, 18);
            this.dcim67hPOA.TabIndex = 1159;
            this.dcim67hPOA.TabStop = false;
            this.dcim67hPOA.Tag = "67hPOA";
            // 
            // dced67hPOA
            // 
            this.dced67hPOA.Location = new System.Drawing.Point(848, 1179);
            this.dced67hPOA.Name = "dced67hPOA";
            this.dced67hPOA.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced67hPOA.OcxState")));
            this.dced67hPOA.Size = new System.Drawing.Size(15, 18);
            this.dced67hPOA.TabIndex = 147;
            this.dced67hPOA.Tag = "67hPOA";
            // 
            // dcim67gPOA
            // 
            this.dcim67gPOA.Location = new System.Drawing.Point(757, 1160);
            this.dcim67gPOA.Name = "dcim67gPOA";
            this.dcim67gPOA.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim67gPOA.OcxState")));
            this.dcim67gPOA.Size = new System.Drawing.Size(15, 18);
            this.dcim67gPOA.TabIndex = 1157;
            this.dcim67gPOA.TabStop = false;
            this.dcim67gPOA.Tag = "67gPOA";
            // 
            // dced67gPOA
            // 
            this.dced67gPOA.Location = new System.Drawing.Point(757, 1179);
            this.dced67gPOA.Name = "dced67gPOA";
            this.dced67gPOA.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced67gPOA.OcxState")));
            this.dced67gPOA.Size = new System.Drawing.Size(15, 18);
            this.dced67gPOA.TabIndex = 145;
            this.dced67gPOA.Tag = "67gPOA";
            // 
            // dcim67cPOA
            // 
            this.dcim67cPOA.Location = new System.Drawing.Point(392, 1160);
            this.dcim67cPOA.Name = "dcim67cPOA";
            this.dcim67cPOA.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim67cPOA.OcxState")));
            this.dcim67cPOA.Size = new System.Drawing.Size(15, 18);
            this.dcim67cPOA.TabIndex = 1155;
            this.dcim67cPOA.TabStop = false;
            this.dcim67cPOA.Tag = "67cPOA";
            // 
            // dced67cPOA
            // 
            this.dced67cPOA.Location = new System.Drawing.Point(392, 1179);
            this.dced67cPOA.Name = "dced67cPOA";
            this.dced67cPOA.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced67cPOA.OcxState")));
            this.dced67cPOA.Size = new System.Drawing.Size(15, 18);
            this.dced67cPOA.TabIndex = 137;
            this.dced67cPOA.Tag = "67cPOA";
            // 
            // axDcimage10
            // 
            this.axDcimage10.Location = new System.Drawing.Point(392, 1214);
            this.axDcimage10.Name = "axDcimage10";
            this.axDcimage10.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axDcimage10.OcxState")));
            this.axDcimage10.Size = new System.Drawing.Size(15, 18);
            this.axDcimage10.TabIndex = 1169;
            this.axDcimage10.TabStop = false;
            this.axDcimage10.Tag = "67POA";
            // 
            // axDcedit12
            // 
            this.axDcedit12.Location = new System.Drawing.Point(392, 1233);
            this.axDcedit12.Name = "axDcedit12";
            this.axDcedit12.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axDcedit12.OcxState")));
            this.axDcedit12.Size = new System.Drawing.Size(15, 18);
            this.axDcedit12.TabIndex = 155;
            this.axDcedit12.Tag = "67POA";
            // 
            // axDcimage11
            // 
            this.axDcimage11.Location = new System.Drawing.Point(848, 1214);
            this.axDcimage11.Name = "axDcimage11";
            this.axDcimage11.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axDcimage11.OcxState")));
            this.axDcimage11.Size = new System.Drawing.Size(15, 18);
            this.axDcimage11.TabIndex = 1167;
            this.axDcimage11.TabStop = false;
            this.axDcimage11.Tag = "67POA";
            // 
            // axDcedit13
            // 
            this.axDcedit13.Location = new System.Drawing.Point(848, 1233);
            this.axDcedit13.Name = "axDcedit13";
            this.axDcedit13.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axDcedit13.OcxState")));
            this.axDcedit13.Size = new System.Drawing.Size(15, 18);
            this.axDcedit13.TabIndex = 164;
            this.axDcedit13.Tag = "67POA";
            // 
            // axDcimage12
            // 
            this.axDcimage12.Location = new System.Drawing.Point(301, 1214);
            this.axDcimage12.Name = "axDcimage12";
            this.axDcimage12.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axDcimage12.OcxState")));
            this.axDcimage12.Size = new System.Drawing.Size(15, 18);
            this.axDcimage12.TabIndex = 1165;
            this.axDcimage12.TabStop = false;
            this.axDcimage12.Tag = "67POA";
            // 
            // axDcedit14
            // 
            this.axDcedit14.Location = new System.Drawing.Point(301, 1233);
            this.axDcedit14.Name = "axDcedit14";
            this.axDcedit14.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axDcedit14.OcxState")));
            this.axDcedit14.Size = new System.Drawing.Size(15, 18);
            this.axDcedit14.TabIndex = 153;
            this.axDcedit14.Tag = "67POA";
            // 
            // axDcimage13
            // 
            this.axDcimage13.Location = new System.Drawing.Point(119, 1214);
            this.axDcimage13.Name = "axDcimage13";
            this.axDcimage13.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axDcimage13.OcxState")));
            this.axDcimage13.Size = new System.Drawing.Size(15, 18);
            this.axDcimage13.TabIndex = 1163;
            this.axDcimage13.TabStop = false;
            this.axDcimage13.Tag = "67POA";
            // 
            // axDcedit15
            // 
            this.axDcedit15.Location = new System.Drawing.Point(119, 1233);
            this.axDcedit15.Name = "axDcedit15";
            this.axDcedit15.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axDcedit15.OcxState")));
            this.axDcedit15.Size = new System.Drawing.Size(15, 18);
            this.axDcedit15.TabIndex = 149;
            this.axDcedit15.Tag = "67POA";
            // 
            // axDcimage14
            // 
            this.axDcimage14.Location = new System.Drawing.Point(757, 1214);
            this.axDcimage14.Name = "axDcimage14";
            this.axDcimage14.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axDcimage14.OcxState")));
            this.axDcimage14.Size = new System.Drawing.Size(15, 18);
            this.axDcimage14.TabIndex = 1177;
            this.axDcimage14.TabStop = false;
            this.axDcimage14.Tag = "67POA";
            // 
            // axDcedit16
            // 
            this.axDcedit16.Location = new System.Drawing.Point(757, 1233);
            this.axDcedit16.Name = "axDcedit16";
            this.axDcedit16.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axDcedit16.OcxState")));
            this.axDcedit16.Size = new System.Drawing.Size(15, 18);
            this.axDcedit16.TabIndex = 162;
            this.axDcedit16.Tag = "67POA";
            // 
            // axDcimage15
            // 
            this.axDcimage15.Location = new System.Drawing.Point(575, 1214);
            this.axDcimage15.Name = "axDcimage15";
            this.axDcimage15.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axDcimage15.OcxState")));
            this.axDcimage15.Size = new System.Drawing.Size(15, 18);
            this.axDcimage15.TabIndex = 1175;
            this.axDcimage15.TabStop = false;
            this.axDcimage15.Tag = "67POA";
            // 
            // axDcedit17
            // 
            this.axDcedit17.Location = new System.Drawing.Point(575, 1233);
            this.axDcedit17.Name = "axDcedit17";
            this.axDcedit17.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axDcedit17.OcxState")));
            this.axDcedit17.Size = new System.Drawing.Size(15, 18);
            this.axDcedit17.TabIndex = 159;
            this.axDcedit17.Tag = "67POA";
            // 
            // axDcimage16
            // 
            this.axDcimage16.Location = new System.Drawing.Point(484, 1214);
            this.axDcimage16.Name = "axDcimage16";
            this.axDcimage16.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axDcimage16.OcxState")));
            this.axDcimage16.Size = new System.Drawing.Size(15, 18);
            this.axDcimage16.TabIndex = 1173;
            this.axDcimage16.TabStop = false;
            this.axDcimage16.Tag = "67POA";
            // 
            // axDcedit18
            // 
            this.axDcedit18.Location = new System.Drawing.Point(484, 1233);
            this.axDcedit18.Name = "axDcedit18";
            this.axDcedit18.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axDcedit18.OcxState")));
            this.axDcedit18.Size = new System.Drawing.Size(15, 18);
            this.axDcedit18.TabIndex = 157;
            this.axDcedit18.Tag = "67POA";
            // 
            // dced67aPOA
            // 
            this.dced67aPOA.Location = new System.Drawing.Point(210, 1179);
            this.dced67aPOA.Name = "dced67aPOA";
            this.dced67aPOA.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced67aPOA.OcxState")));
            this.dced67aPOA.Size = new System.Drawing.Size(15, 18);
            this.dced67aPOA.TabIndex = 133;
            this.dced67aPOA.Tag = "67aPOA";
            // 
            // dcim67aPOA
            // 
            this.dcim67aPOA.Location = new System.Drawing.Point(210, 1160);
            this.dcim67aPOA.Name = "dcim67aPOA";
            this.dcim67aPOA.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim67aPOA.OcxState")));
            this.dcim67aPOA.Size = new System.Drawing.Size(15, 18);
            this.dcim67aPOA.TabIndex = 1179;
            this.dcim67aPOA.TabStop = false;
            this.dcim67aPOA.Tag = "67aPOA";
            // 
            // dcim67POA
            // 
            this.dcim67POA.Location = new System.Drawing.Point(119, 1160);
            this.dcim67POA.Name = "dcim67POA";
            this.dcim67POA.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim67POA.OcxState")));
            this.dcim67POA.Size = new System.Drawing.Size(15, 18);
            this.dcim67POA.TabIndex = 1180;
            this.dcim67POA.TabStop = false;
            this.dcim67POA.Tag = "67POA";
            // 
            // axDcimage2
            // 
            this.axDcimage2.Location = new System.Drawing.Point(666, 1214);
            this.axDcimage2.Name = "axDcimage2";
            this.axDcimage2.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axDcimage2.OcxState")));
            this.axDcimage2.Size = new System.Drawing.Size(15, 18);
            this.axDcimage2.TabIndex = 1181;
            this.axDcimage2.TabStop = false;
            this.axDcimage2.Tag = "67POA";
            // 
            // axDcedit2
            // 
            this.axDcedit2.Location = new System.Drawing.Point(666, 1233);
            this.axDcedit2.Name = "axDcedit2";
            this.axDcedit2.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axDcedit2.OcxState")));
            this.axDcedit2.Size = new System.Drawing.Size(15, 18);
            this.axDcedit2.TabIndex = 1182;
            this.axDcedit2.Tag = "67POA";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.BackColor = System.Drawing.Color.Lavender;
            this.label46.Location = new System.Drawing.Point(687, 1255);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(74, 13);
            this.label46.TabIndex = 1183;
            this.label46.Tag = "58clname";
            this.label46.Text = "72b EDI Code";
            // 
            // dcim72becicd
            // 
            this.dcim72becicd.Location = new System.Drawing.Point(687, 1268);
            this.dcim72becicd.Name = "dcim72becicd";
            this.dcim72becicd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim72becicd.OcxState")));
            this.dcim72becicd.Size = new System.Drawing.Size(69, 18);
            this.dcim72becicd.TabIndex = 1184;
            this.dcim72becicd.TabStop = false;
            this.dcim72becicd.Tag = "72becicd";
            // 
            // dced72becicd
            // 
            this.dced72becicd.Location = new System.Drawing.Point(687, 1287);
            this.dced72becicd.Name = "dced72becicd";
            this.dced72becicd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced72becicd.OcxState")));
            this.dced72becicd.Size = new System.Drawing.Size(69, 18);
            this.dced72becicd.TabIndex = 172;
            this.dced72becicd.Tag = "72becicd";
            // 
            // dcim72aPOA
            // 
            this.dcim72aPOA.Location = new System.Drawing.Point(666, 1268);
            this.dcim72aPOA.Name = "dcim72aPOA";
            this.dcim72aPOA.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim72aPOA.OcxState")));
            this.dcim72aPOA.Size = new System.Drawing.Size(15, 18);
            this.dcim72aPOA.TabIndex = 1186;
            this.dcim72aPOA.TabStop = false;
            this.dcim72aPOA.Tag = "72aPOA";
            // 
            // dced72aPOA
            // 
            this.dced72aPOA.Location = new System.Drawing.Point(666, 1287);
            this.dced72aPOA.Name = "dced72aPOA";
            this.dced72aPOA.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced72aPOA.OcxState")));
            this.dced72aPOA.Size = new System.Drawing.Size(15, 18);
            this.dced72aPOA.TabIndex = 171;
            this.dced72aPOA.Tag = "72aPOA";
            // 
            // dcim72bPOA
            // 
            this.dcim72bPOA.Location = new System.Drawing.Point(757, 1268);
            this.dcim72bPOA.Name = "dcim72bPOA";
            this.dcim72bPOA.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim72bPOA.OcxState")));
            this.dcim72bPOA.Size = new System.Drawing.Size(15, 18);
            this.dcim72bPOA.TabIndex = 1188;
            this.dcim72bPOA.TabStop = false;
            this.dcim72bPOA.Tag = "72bPOA";
            // 
            // dced72bPOA
            // 
            this.dced72bPOA.Location = new System.Drawing.Point(757, 1287);
            this.dced72bPOA.Name = "dced72bPOA";
            this.dced72bPOA.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced72bPOA.OcxState")));
            this.dced72bPOA.Size = new System.Drawing.Size(15, 18);
            this.dced72bPOA.TabIndex = 173;
            this.dced72bPOA.Tag = "72bPOA";
            // 
            // dcim72cPOA
            // 
            this.dcim72cPOA.Location = new System.Drawing.Point(848, 1268);
            this.dcim72cPOA.Name = "dcim72cPOA";
            this.dcim72cPOA.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim72cPOA.OcxState")));
            this.dcim72cPOA.Size = new System.Drawing.Size(15, 18);
            this.dcim72cPOA.TabIndex = 1193;
            this.dcim72cPOA.TabStop = false;
            this.dcim72cPOA.Tag = "72cPOA";
            // 
            // dced72cPOA
            // 
            this.dced72cPOA.Location = new System.Drawing.Point(848, 1287);
            this.dced72cPOA.Name = "dced72cPOA";
            this.dced72cPOA.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced72cPOA.OcxState")));
            this.dced72cPOA.Size = new System.Drawing.Size(15, 18);
            this.dced72cPOA.TabIndex = 175;
            this.dced72cPOA.Tag = "72cPOA";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.BackColor = System.Drawing.Color.Lavender;
            this.label47.Location = new System.Drawing.Point(778, 1255);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(74, 13);
            this.label47.TabIndex = 1190;
            this.label47.Tag = "58clname";
            this.label47.Text = "72c EDI Code";
            // 
            // dcim72cecicd
            // 
            this.dcim72cecicd.Location = new System.Drawing.Point(778, 1268);
            this.dcim72cecicd.Name = "dcim72cecicd";
            this.dcim72cecicd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim72cecicd.OcxState")));
            this.dcim72cecicd.Size = new System.Drawing.Size(69, 18);
            this.dcim72cecicd.TabIndex = 1191;
            this.dcim72cecicd.TabStop = false;
            this.dcim72cecicd.Tag = "72cecicd";
            // 
            // dced72cecicd
            // 
            this.dced72cecicd.Location = new System.Drawing.Point(778, 1287);
            this.dced72cecicd.Name = "dced72cecicd";
            this.dced72cecicd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced72cecicd.OcxState")));
            this.dced72cecicd.Size = new System.Drawing.Size(69, 18);
            this.dced72cecicd.TabIndex = 174;
            this.dced72cecicd.Tag = "72cecicd";
            // 
            // dcim55aetamt
            // 
            this.dcim55aetamt.Location = new System.Drawing.Point(492, 988);
            this.dcim55aetamt.Name = "dcim55aetamt";
            this.dcim55aetamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim55aetamt.OcxState")));
            this.dcim55aetamt.Size = new System.Drawing.Size(100, 18);
            this.dcim55aetamt.TabIndex = 1195;
            this.dcim55aetamt.TabStop = false;
            this.dcim55aetamt.Tag = "55aetamt";
            // 
            // dced55aetamt
            // 
            this.dced55aetamt.Location = new System.Drawing.Point(492, 1007);
            this.dced55aetamt.Name = "dced55aetamt";
            this.dced55aetamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced55aetamt.OcxState")));
            this.dced55aetamt.Size = new System.Drawing.Size(100, 18);
            this.dced55aetamt.TabIndex = 108;
            this.dced55aetamt.Tag = "55aetamt";
            // 
            // dcim55betamt
            // 
            this.dcim55betamt.Location = new System.Drawing.Point(492, 1032);
            this.dcim55betamt.Name = "dcim55betamt";
            this.dcim55betamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim55betamt.OcxState")));
            this.dcim55betamt.Size = new System.Drawing.Size(100, 18);
            this.dcim55betamt.TabIndex = 1197;
            this.dcim55betamt.TabStop = false;
            this.dcim55betamt.Tag = "55betamt";
            // 
            // dced55betamt
            // 
            this.dced55betamt.Location = new System.Drawing.Point(492, 1051);
            this.dced55betamt.Name = "dced55betamt";
            this.dced55betamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced55betamt.OcxState")));
            this.dced55betamt.Size = new System.Drawing.Size(100, 18);
            this.dced55betamt.TabIndex = 112;
            this.dced55betamt.Tag = "55betamt";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.BackColor = System.Drawing.Color.Lavender;
            this.label48.Location = new System.Drawing.Point(492, 975);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(81, 13);
            this.label48.TabIndex = 1201;
            this.label48.Tag = "60ccshi";
            this.label48.Text = "55 Est Amt Due";
            // 
            // dcim55cetamt
            // 
            this.dcim55cetamt.Location = new System.Drawing.Point(492, 1079);
            this.dcim55cetamt.Name = "dcim55cetamt";
            this.dcim55cetamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim55cetamt.OcxState")));
            this.dcim55cetamt.Size = new System.Drawing.Size(100, 18);
            this.dcim55cetamt.TabIndex = 1199;
            this.dcim55cetamt.TabStop = false;
            this.dcim55cetamt.Tag = "55cetamt";
            // 
            // dced55cetamt
            // 
            this.dced55cetamt.Location = new System.Drawing.Point(492, 1098);
            this.dced55cetamt.Name = "dced55cetamt";
            this.dced55cetamt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced55cetamt.OcxState")));
            this.dced55cetamt.Size = new System.Drawing.Size(100, 18);
            this.dced55cetamt.TabIndex = 116;
            this.dced55cetamt.Tag = "55cetamt";
            // 
            // dcim54aprpay
            // 
            this.dcim54aprpay.Location = new System.Drawing.Point(379, 988);
            this.dcim54aprpay.Name = "dcim54aprpay";
            this.dcim54aprpay.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim54aprpay.OcxState")));
            this.dcim54aprpay.Size = new System.Drawing.Size(100, 18);
            this.dcim54aprpay.TabIndex = 1202;
            this.dcim54aprpay.TabStop = false;
            this.dcim54aprpay.Tag = "54aprpay";
            // 
            // dced54aprpay
            // 
            this.dced54aprpay.Location = new System.Drawing.Point(379, 1007);
            this.dced54aprpay.Name = "dced54aprpay";
            this.dced54aprpay.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced54aprpay.OcxState")));
            this.dced54aprpay.Size = new System.Drawing.Size(100, 18);
            this.dced54aprpay.TabIndex = 107;
            this.dced54aprpay.Tag = "54aprpay";
            // 
            // dcim54bprpay
            // 
            this.dcim54bprpay.Location = new System.Drawing.Point(379, 1032);
            this.dcim54bprpay.Name = "dcim54bprpay";
            this.dcim54bprpay.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim54bprpay.OcxState")));
            this.dcim54bprpay.Size = new System.Drawing.Size(100, 18);
            this.dcim54bprpay.TabIndex = 1204;
            this.dcim54bprpay.TabStop = false;
            this.dcim54bprpay.Tag = "54bprpay";
            // 
            // dced54bprpay
            // 
            this.dced54bprpay.Location = new System.Drawing.Point(379, 1051);
            this.dced54bprpay.Name = "dced54bprpay";
            this.dced54bprpay.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced54bprpay.OcxState")));
            this.dced54bprpay.Size = new System.Drawing.Size(100, 18);
            this.dced54bprpay.TabIndex = 111;
            this.dced54bprpay.Tag = "54bprpay";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.BackColor = System.Drawing.Color.Lavender;
            this.label49.Location = new System.Drawing.Point(379, 975);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(67, 13);
            this.label49.TabIndex = 1208;
            this.label49.Tag = "60ccshi";
            this.label49.Text = "54 Prior Paid";
            // 
            // dcim54cprpay
            // 
            this.dcim54cprpay.Location = new System.Drawing.Point(379, 1079);
            this.dcim54cprpay.Name = "dcim54cprpay";
            this.dcim54cprpay.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim54cprpay.OcxState")));
            this.dcim54cprpay.Size = new System.Drawing.Size(100, 18);
            this.dcim54cprpay.TabIndex = 1206;
            this.dcim54cprpay.TabStop = false;
            this.dcim54cprpay.Tag = "54cprpay";
            // 
            // dced54cprpay
            // 
            this.dced54cprpay.Location = new System.Drawing.Point(379, 1098);
            this.dced54cprpay.Name = "dced54cprpay";
            this.dced54cprpay.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced54cprpay.OcxState")));
            this.dced54cprpay.Size = new System.Drawing.Size(100, 18);
            this.dced54cprpay.TabIndex = 115;
            this.dced54cprpay.Tag = "54cprpay";
            // 
            // pictureBox9
            // 
            this.pictureBox9.BackColor = System.Drawing.Color.Lavender;
            this.pictureBox9.Location = new System.Drawing.Point(606, 970);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(403, 154);
            this.pictureBox9.TabIndex = 1003;
            this.pictureBox9.TabStop = false;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.BackColor = System.Drawing.Color.Lavender;
            this.label50.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(611, 1085);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(16, 15);
            this.label50.TabIndex = 1211;
            this.label50.Text = "C";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.BackColor = System.Drawing.Color.Lavender;
            this.label51.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(610, 1040);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(16, 15);
            this.label51.TabIndex = 1210;
            this.label51.Text = "B";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.BackColor = System.Drawing.Color.Lavender;
            this.label52.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(611, 1000);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(15, 15);
            this.label52.TabIndex = 1209;
            this.label52.Text = "A";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.BackColor = System.Drawing.Color.Lavender;
            this.label53.Location = new System.Drawing.Point(746, 1325);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(116, 13);
            this.label53.TabIndex = 1227;
            this.label53.Text = "77 Operating Physician";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.BackColor = System.Drawing.Color.Lavender;
            this.label54.Location = new System.Drawing.Point(757, 1338);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(25, 13);
            this.label54.TabIndex = 1212;
            this.label54.Tag = "76apnpi";
            this.label54.Text = "NPI";
            // 
            // dcim77opnpi
            // 
            this.dcim77opnpi.Location = new System.Drawing.Point(754, 1351);
            this.dcim77opnpi.Name = "dcim77opnpi";
            this.dcim77opnpi.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim77opnpi.OcxState")));
            this.dcim77opnpi.Size = new System.Drawing.Size(101, 18);
            this.dcim77opnpi.TabIndex = 1213;
            this.dcim77opnpi.TabStop = false;
            this.dcim77opnpi.Tag = "77opnpi";
            // 
            // dced77opnpi
            // 
            this.dced77opnpi.Location = new System.Drawing.Point(754, 1370);
            this.dced77opnpi.Name = "dced77opnpi";
            this.dced77opnpi.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced77opnpi.OcxState")));
            this.dced77opnpi.Size = new System.Drawing.Size(101, 18);
            this.dced77opnpi.TabIndex = 196;
            this.dced77opnpi.Tag = "77opnpi";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.BackColor = System.Drawing.Color.Lavender;
            this.label55.Location = new System.Drawing.Point(859, 1338);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(32, 13);
            this.label55.TabIndex = 1215;
            this.label55.Tag = "76apqual";
            this.label55.Text = "Qual.";
            // 
            // dcim77opqual
            // 
            this.dcim77opqual.Location = new System.Drawing.Point(862, 1351);
            this.dcim77opqual.Name = "dcim77opqual";
            this.dcim77opqual.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim77opqual.OcxState")));
            this.dcim77opqual.Size = new System.Drawing.Size(27, 18);
            this.dcim77opqual.TabIndex = 1216;
            this.dcim77opqual.TabStop = false;
            this.dcim77opqual.Tag = "77opqual";
            // 
            // dced77opqual
            // 
            this.dced77opqual.Location = new System.Drawing.Point(862, 1370);
            this.dced77opqual.Name = "dced77opqual";
            this.dced77opqual.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced77opqual.OcxState")));
            this.dced77opqual.Size = new System.Drawing.Size(27, 18);
            this.dced77opqual.TabIndex = 197;
            this.dced77opqual.Tag = "77opqual";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.BackColor = System.Drawing.Color.Lavender;
            this.label56.Location = new System.Drawing.Point(895, 1338);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(18, 13);
            this.label56.TabIndex = 1218;
            this.label56.Tag = "76apid";
            this.label56.Text = "ID";
            // 
            // dcim77opid
            // 
            this.dcim77opid.Location = new System.Drawing.Point(896, 1351);
            this.dcim77opid.Name = "dcim77opid";
            this.dcim77opid.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim77opid.OcxState")));
            this.dcim77opid.Size = new System.Drawing.Size(106, 18);
            this.dcim77opid.TabIndex = 1219;
            this.dcim77opid.TabStop = false;
            this.dcim77opid.Tag = "77opid";
            // 
            // dced77opid
            // 
            this.dced77opid.Location = new System.Drawing.Point(896, 1370);
            this.dced77opid.Name = "dced77opid";
            this.dced77opid.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced77opid.OcxState")));
            this.dced77opid.Size = new System.Drawing.Size(106, 18);
            this.dced77opid.TabIndex = 198;
            this.dced77opid.Tag = "77opid";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.BackColor = System.Drawing.Color.Lavender;
            this.label57.Location = new System.Drawing.Point(745, 1398);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(58, 13);
            this.label57.TabIndex = 1221;
            this.label57.Tag = "76aplnm";
            this.label57.Text = "Last Name";
            // 
            // dcim77oplnm
            // 
            this.dcim77oplnm.Location = new System.Drawing.Point(745, 1411);
            this.dcim77oplnm.Name = "dcim77oplnm";
            this.dcim77oplnm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim77oplnm.OcxState")));
            this.dcim77oplnm.Size = new System.Drawing.Size(134, 18);
            this.dcim77oplnm.TabIndex = 1222;
            this.dcim77oplnm.TabStop = false;
            this.dcim77oplnm.Tag = "77oplnm";
            // 
            // dced77oplnm
            // 
            this.dced77oplnm.Location = new System.Drawing.Point(745, 1430);
            this.dced77oplnm.Name = "dced77oplnm";
            this.dced77oplnm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced77oplnm.OcxState")));
            this.dced77oplnm.Size = new System.Drawing.Size(134, 18);
            this.dced77oplnm.TabIndex = 199;
            this.dced77oplnm.Tag = "77oplnm";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.BackColor = System.Drawing.Color.Lavender;
            this.label58.Location = new System.Drawing.Point(881, 1398);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(57, 13);
            this.label58.TabIndex = 1224;
            this.label58.Tag = "76apfnm";
            this.label58.Text = "First Name";
            // 
            // dcim77opfnm
            // 
            this.dcim77opfnm.Location = new System.Drawing.Point(884, 1411);
            this.dcim77opfnm.Name = "dcim77opfnm";
            this.dcim77opfnm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim77opfnm.OcxState")));
            this.dcim77opfnm.Size = new System.Drawing.Size(119, 18);
            this.dcim77opfnm.TabIndex = 1225;
            this.dcim77opfnm.TabStop = false;
            this.dcim77opfnm.Tag = "77opfnm";
            // 
            // dced77opfnm
            // 
            this.dced77opfnm.Location = new System.Drawing.Point(884, 1430);
            this.dced77opfnm.Name = "dced77opfnm";
            this.dced77opfnm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced77opfnm.OcxState")));
            this.dced77opfnm.Size = new System.Drawing.Size(119, 18);
            this.dced77opfnm.TabIndex = 200;
            this.dced77opfnm.Tag = "77opfnm";
            // 
            // pictureBox11
            // 
            this.pictureBox11.BackColor = System.Drawing.Color.Lavender;
            this.pictureBox11.Location = new System.Drawing.Point(735, 1321);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(274, 131);
            this.pictureBox11.TabIndex = 1228;
            this.pictureBox11.TabStop = false;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.BackColor = System.Drawing.Color.Lavender;
            this.label59.Location = new System.Drawing.Point(420, 1462);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(51, 13);
            this.label59.TabIndex = 1244;
            this.label59.Text = "78 Other ";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.BackColor = System.Drawing.Color.Lavender;
            this.label60.Location = new System.Drawing.Point(465, 1475);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(25, 13);
            this.label60.TabIndex = 1229;
            this.label60.Tag = "76apnpi";
            this.label60.Text = "NPI";
            // 
            // dcimotnpi
            // 
            this.dcimotnpi.Location = new System.Drawing.Point(462, 1488);
            this.dcimotnpi.Name = "dcimotnpi";
            this.dcimotnpi.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimotnpi.OcxState")));
            this.dcimotnpi.Size = new System.Drawing.Size(101, 18);
            this.dcimotnpi.TabIndex = 1230;
            this.dcimotnpi.TabStop = false;
            this.dcimotnpi.Tag = "78otnpi";
            // 
            // dced78otnpi
            // 
            this.dced78otnpi.Location = new System.Drawing.Point(462, 1507);
            this.dced78otnpi.Name = "dced78otnpi";
            this.dced78otnpi.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced78otnpi.OcxState")));
            this.dced78otnpi.Size = new System.Drawing.Size(101, 18);
            this.dced78otnpi.TabIndex = 202;
            this.dced78otnpi.Tag = "78otnpi";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.BackColor = System.Drawing.Color.Lavender;
            this.label61.Location = new System.Drawing.Point(566, 1475);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(32, 13);
            this.label61.TabIndex = 1232;
            this.label61.Tag = "76apqual";
            this.label61.Text = "Qual.";
            // 
            // dcim78otql2
            // 
            this.dcim78otql2.Location = new System.Drawing.Point(569, 1488);
            this.dcim78otql2.Name = "dcim78otql2";
            this.dcim78otql2.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim78otql2.OcxState")));
            this.dcim78otql2.Size = new System.Drawing.Size(27, 18);
            this.dcim78otql2.TabIndex = 1233;
            this.dcim78otql2.TabStop = false;
            this.dcim78otql2.Tag = "78otql2";
            // 
            // dcedotql2
            // 
            this.dcedotql2.Location = new System.Drawing.Point(569, 1507);
            this.dcedotql2.Name = "dcedotql2";
            this.dcedotql2.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedotql2.OcxState")));
            this.dcedotql2.Size = new System.Drawing.Size(27, 18);
            this.dcedotql2.TabIndex = 203;
            this.dcedotql2.Tag = "78otql2";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.BackColor = System.Drawing.Color.Lavender;
            this.label62.Location = new System.Drawing.Point(601, 1475);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(18, 13);
            this.label62.TabIndex = 1235;
            this.label62.Tag = "76apid";
            this.label62.Text = "ID";
            // 
            // dcim78otid
            // 
            this.dcim78otid.Location = new System.Drawing.Point(597, 1488);
            this.dcim78otid.Name = "dcim78otid";
            this.dcim78otid.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim78otid.OcxState")));
            this.dcim78otid.Size = new System.Drawing.Size(106, 18);
            this.dcim78otid.TabIndex = 1236;
            this.dcim78otid.TabStop = false;
            this.dcim78otid.Tag = "78otid";
            // 
            // dced78otid
            // 
            this.dced78otid.Location = new System.Drawing.Point(597, 1507);
            this.dced78otid.Name = "dced78otid";
            this.dced78otid.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced78otid.OcxState")));
            this.dced78otid.Size = new System.Drawing.Size(106, 18);
            this.dced78otid.TabIndex = 204;
            this.dced78otid.Tag = "78otid";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.BackColor = System.Drawing.Color.Lavender;
            this.label63.Location = new System.Drawing.Point(451, 1535);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(58, 13);
            this.label63.TabIndex = 1238;
            this.label63.Tag = "76aplnm";
            this.label63.Text = "Last Name";
            // 
            // dcimotlnm
            // 
            this.dcimotlnm.Location = new System.Drawing.Point(446, 1548);
            this.dcimotlnm.Name = "dcimotlnm";
            this.dcimotlnm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimotlnm.OcxState")));
            this.dcimotlnm.Size = new System.Drawing.Size(134, 18);
            this.dcimotlnm.TabIndex = 1239;
            this.dcimotlnm.TabStop = false;
            this.dcimotlnm.Tag = "78otlnm";
            // 
            // dced78otlnm
            // 
            this.dced78otlnm.Location = new System.Drawing.Point(446, 1567);
            this.dced78otlnm.Name = "dced78otlnm";
            this.dced78otlnm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced78otlnm.OcxState")));
            this.dced78otlnm.Size = new System.Drawing.Size(134, 18);
            this.dced78otlnm.TabIndex = 205;
            this.dced78otlnm.Tag = "78otlnm";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.BackColor = System.Drawing.Color.Lavender;
            this.label64.Location = new System.Drawing.Point(582, 1535);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(57, 13);
            this.label64.TabIndex = 1241;
            this.label64.Tag = "76apfnm";
            this.label64.Text = "First Name";
            // 
            // dcim78otfnm
            // 
            this.dcim78otfnm.Location = new System.Drawing.Point(585, 1548);
            this.dcim78otfnm.Name = "dcim78otfnm";
            this.dcim78otfnm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim78otfnm.OcxState")));
            this.dcim78otfnm.Size = new System.Drawing.Size(119, 18);
            this.dcim78otfnm.TabIndex = 1242;
            this.dcim78otfnm.TabStop = false;
            this.dcim78otfnm.Tag = "78otfnm";
            // 
            // dced78otfnm
            // 
            this.dced78otfnm.Location = new System.Drawing.Point(585, 1567);
            this.dced78otfnm.Name = "dced78otfnm";
            this.dced78otfnm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced78otfnm.OcxState")));
            this.dced78otfnm.Size = new System.Drawing.Size(119, 18);
            this.dced78otfnm.TabIndex = 206;
            this.dced78otfnm.Tag = "78otfnm";
            // 
            // pictureBox12
            // 
            this.pictureBox12.BackColor = System.Drawing.Color.Lavender;
            this.pictureBox12.Location = new System.Drawing.Point(416, 1458);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(294, 131);
            this.pictureBox12.TabIndex = 1245;
            this.pictureBox12.TabStop = false;
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.BackColor = System.Drawing.Color.Lavender;
            this.label65.Location = new System.Drawing.Point(425, 1475);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(31, 13);
            this.label65.TabIndex = 1246;
            this.label65.Tag = "76apqual";
            this.label65.Text = "Type";
            // 
            // dcim78otql1
            // 
            this.dcim78otql1.Location = new System.Drawing.Point(428, 1488);
            this.dcim78otql1.Name = "dcim78otql1";
            this.dcim78otql1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim78otql1.OcxState")));
            this.dcim78otql1.Size = new System.Drawing.Size(27, 18);
            this.dcim78otql1.TabIndex = 1247;
            this.dcim78otql1.TabStop = false;
            this.dcim78otql1.Tag = "78otql1";
            // 
            // dced78otql1
            // 
            this.dced78otql1.Location = new System.Drawing.Point(428, 1507);
            this.dced78otql1.Name = "dced78otql1";
            this.dced78otql1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced78otql1.OcxState")));
            this.dced78otql1.Size = new System.Drawing.Size(27, 18);
            this.dced78otql1.TabIndex = 201;
            this.dced78otql1.Tag = "78otql1";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.BackColor = System.Drawing.Color.Lavender;
            this.label66.Location = new System.Drawing.Point(724, 1475);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(31, 13);
            this.label66.TabIndex = 1266;
            this.label66.Tag = "76apqual";
            this.label66.Text = "Type";
            // 
            // dcim79otql1
            // 
            this.dcim79otql1.Location = new System.Drawing.Point(727, 1488);
            this.dcim79otql1.Name = "dcim79otql1";
            this.dcim79otql1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim79otql1.OcxState")));
            this.dcim79otql1.Size = new System.Drawing.Size(27, 18);
            this.dcim79otql1.TabIndex = 1267;
            this.dcim79otql1.TabStop = false;
            this.dcim79otql1.Tag = "79otql1";
            // 
            // dced79otql1
            // 
            this.dced79otql1.Location = new System.Drawing.Point(727, 1507);
            this.dced79otql1.Name = "dced79otql1";
            this.dced79otql1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced79otql1.OcxState")));
            this.dced79otql1.Size = new System.Drawing.Size(27, 18);
            this.dced79otql1.TabIndex = 207;
            this.dced79otql1.Tag = "79otql1";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.BackColor = System.Drawing.Color.Lavender;
            this.label67.Location = new System.Drawing.Point(720, 1461);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(51, 13);
            this.label67.TabIndex = 1264;
            this.label67.Text = "79 Other ";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.BackColor = System.Drawing.Color.Lavender;
            this.label68.Location = new System.Drawing.Point(764, 1475);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(25, 13);
            this.label68.TabIndex = 1249;
            this.label68.Tag = "76apnpi";
            this.label68.Text = "NPI";
            // 
            // dcim79otnpi
            // 
            this.dcim79otnpi.Location = new System.Drawing.Point(761, 1488);
            this.dcim79otnpi.Name = "dcim79otnpi";
            this.dcim79otnpi.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim79otnpi.OcxState")));
            this.dcim79otnpi.Size = new System.Drawing.Size(101, 18);
            this.dcim79otnpi.TabIndex = 1250;
            this.dcim79otnpi.TabStop = false;
            this.dcim79otnpi.Tag = "79otnpi";
            // 
            // dced79otnpi
            // 
            this.dced79otnpi.Location = new System.Drawing.Point(761, 1507);
            this.dced79otnpi.Name = "dced79otnpi";
            this.dced79otnpi.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced79otnpi.OcxState")));
            this.dced79otnpi.Size = new System.Drawing.Size(101, 18);
            this.dced79otnpi.TabIndex = 208;
            this.dced79otnpi.Tag = "79otnpi";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.BackColor = System.Drawing.Color.Lavender;
            this.label69.Location = new System.Drawing.Point(865, 1475);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(32, 13);
            this.label69.TabIndex = 1252;
            this.label69.Tag = "76apqual";
            this.label69.Text = "Qual.";
            // 
            // dcim79otql2
            // 
            this.dcim79otql2.Location = new System.Drawing.Point(868, 1488);
            this.dcim79otql2.Name = "dcim79otql2";
            this.dcim79otql2.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim79otql2.OcxState")));
            this.dcim79otql2.Size = new System.Drawing.Size(27, 18);
            this.dcim79otql2.TabIndex = 1253;
            this.dcim79otql2.TabStop = false;
            this.dcim79otql2.Tag = "79otql2";
            // 
            // dced79otql2
            // 
            this.dced79otql2.Location = new System.Drawing.Point(868, 1507);
            this.dced79otql2.Name = "dced79otql2";
            this.dced79otql2.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced79otql2.OcxState")));
            this.dced79otql2.Size = new System.Drawing.Size(27, 18);
            this.dced79otql2.TabIndex = 209;
            this.dced79otql2.Tag = "79otql2";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.BackColor = System.Drawing.Color.Lavender;
            this.label70.Location = new System.Drawing.Point(895, 1475);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(18, 13);
            this.label70.TabIndex = 1255;
            this.label70.Tag = "76apid";
            this.label70.Text = "ID";
            // 
            // dcim79otid
            // 
            this.dcim79otid.Location = new System.Drawing.Point(896, 1488);
            this.dcim79otid.Name = "dcim79otid";
            this.dcim79otid.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim79otid.OcxState")));
            this.dcim79otid.Size = new System.Drawing.Size(106, 18);
            this.dcim79otid.TabIndex = 1256;
            this.dcim79otid.TabStop = false;
            this.dcim79otid.Tag = "79otid";
            // 
            // dced79otid
            // 
            this.dced79otid.Location = new System.Drawing.Point(896, 1507);
            this.dced79otid.Name = "dced79otid";
            this.dced79otid.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced79otid.OcxState")));
            this.dced79otid.Size = new System.Drawing.Size(106, 18);
            this.dced79otid.TabIndex = 210;
            this.dced79otid.Tag = "79otid";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.BackColor = System.Drawing.Color.Lavender;
            this.label71.Location = new System.Drawing.Point(750, 1535);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(58, 13);
            this.label71.TabIndex = 1258;
            this.label71.Tag = "76aplnm";
            this.label71.Text = "Last Name";
            // 
            // dcim79otlnm
            // 
            this.dcim79otlnm.Location = new System.Drawing.Point(745, 1548);
            this.dcim79otlnm.Name = "dcim79otlnm";
            this.dcim79otlnm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim79otlnm.OcxState")));
            this.dcim79otlnm.Size = new System.Drawing.Size(134, 18);
            this.dcim79otlnm.TabIndex = 1259;
            this.dcim79otlnm.TabStop = false;
            this.dcim79otlnm.Tag = "79otlnm";
            // 
            // dced79otlnm
            // 
            this.dced79otlnm.Location = new System.Drawing.Point(745, 1567);
            this.dced79otlnm.Name = "dced79otlnm";
            this.dced79otlnm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced79otlnm.OcxState")));
            this.dced79otlnm.Size = new System.Drawing.Size(134, 18);
            this.dced79otlnm.TabIndex = 211;
            this.dced79otlnm.Tag = "79otlnm";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.BackColor = System.Drawing.Color.Lavender;
            this.label72.Location = new System.Drawing.Point(881, 1535);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(57, 13);
            this.label72.TabIndex = 1261;
            this.label72.Tag = "76apfnm";
            this.label72.Text = "First Name";
            // 
            // dcim79otfnm
            // 
            this.dcim79otfnm.Location = new System.Drawing.Point(884, 1548);
            this.dcim79otfnm.Name = "dcim79otfnm";
            this.dcim79otfnm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim79otfnm.OcxState")));
            this.dcim79otfnm.Size = new System.Drawing.Size(119, 18);
            this.dcim79otfnm.TabIndex = 1262;
            this.dcim79otfnm.TabStop = false;
            this.dcim79otfnm.Tag = "79otfnm";
            // 
            // dced79otfnm
            // 
            this.dced79otfnm.Location = new System.Drawing.Point(884, 1567);
            this.dced79otfnm.Name = "dced79otfnm";
            this.dced79otfnm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced79otfnm.OcxState")));
            this.dced79otfnm.Size = new System.Drawing.Size(119, 18);
            this.dced79otfnm.TabIndex = 212;
            this.dced79otfnm.Tag = "79otfnm";
            // 
            // pictureBox13
            // 
            this.pictureBox13.BackColor = System.Drawing.Color.Lavender;
            this.pictureBox13.Location = new System.Drawing.Point(717, 1458);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(292, 131);
            this.pictureBox13.TabIndex = 1265;
            this.pictureBox13.TabStop = false;
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.BackColor = System.Drawing.Color.Lavender;
            this.label73.Location = new System.Drawing.Point(881, 1255);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(58, 13);
            this.label73.TabIndex = 1275;
            this.label73.Tag = "58clname";
            this.label73.Text = "57 PRV ID";
            // 
            // dcim57copidt
            // 
            this.dcim57copidt.Location = new System.Drawing.Point(881, 1268);
            this.dcim57copidt.Name = "dcim57copidt";
            this.dcim57copidt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim57copidt.OcxState")));
            this.dcim57copidt.Size = new System.Drawing.Size(119, 18);
            this.dcim57copidt.TabIndex = 1276;
            this.dcim57copidt.TabStop = false;
            this.dcim57copidt.Tag = "57copidt";
            // 
            // dced57copidt
            // 
            this.dced57copidt.Location = new System.Drawing.Point(881, 1287);
            this.dced57copidt.Name = "dced57copidt";
            this.dced57copidt.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced57copidt.OcxState")));
            this.dced57copidt.Size = new System.Drawing.Size(119, 18);
            this.dced57copidt.TabIndex = 178;
            this.dced57copidt.Tag = "57copidt";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.BackColor = System.Drawing.Color.Lavender;
            this.label74.Location = new System.Drawing.Point(883, 1147);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(19, 13);
            this.label74.TabIndex = 1269;
            this.label74.Tag = "67hothdg";
            this.label74.Text = "57";
            // 
            // dcim57aopidp
            // 
            this.dcim57aopidp.Location = new System.Drawing.Point(881, 1160);
            this.dcim57aopidp.Name = "dcim57aopidp";
            this.dcim57aopidp.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim57aopidp.OcxState")));
            this.dcim57aopidp.Size = new System.Drawing.Size(119, 18);
            this.dcim57aopidp.TabIndex = 1270;
            this.dcim57aopidp.TabStop = false;
            this.dcim57aopidp.Tag = "57aopidp";
            // 
            // dced57aopidp
            // 
            this.dced57aopidp.Location = new System.Drawing.Point(881, 1179);
            this.dced57aopidp.Name = "dced57aopidp";
            this.dced57aopidp.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced57aopidp.OcxState")));
            this.dced57aopidp.Size = new System.Drawing.Size(119, 18);
            this.dced57aopidp.TabIndex = 176;
            this.dced57aopidp.Tag = "57aopidp";
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.BackColor = System.Drawing.Color.Lavender;
            this.label75.Location = new System.Drawing.Point(883, 1201);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(48, 13);
            this.label75.TabIndex = 1272;
            this.label75.Tag = "67qothdg";
            this.label75.Text = "57 Other";
            // 
            // dcim57bopids
            // 
            this.dcim57bopids.Location = new System.Drawing.Point(881, 1214);
            this.dcim57bopids.Name = "dcim57bopids";
            this.dcim57bopids.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim57bopids.OcxState")));
            this.dcim57bopids.Size = new System.Drawing.Size(119, 18);
            this.dcim57bopids.TabIndex = 1273;
            this.dcim57bopids.TabStop = false;
            this.dcim57bopids.Tag = "57bopids";
            // 
            // dced57bopids
            // 
            this.dced57bopids.Location = new System.Drawing.Point(881, 1233);
            this.dced57bopids.Name = "dced57bopids";
            this.dced57bopids.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced57bopids.OcxState")));
            this.dced57bopids.Size = new System.Drawing.Size(119, 18);
            this.dced57bopids.TabIndex = 177;
            this.dced57bopids.Tag = "57bopids";
            // 
            // dcim80aremrk
            // 
            this.dcim80aremrk.Location = new System.Drawing.Point(67, 1463);
            this.dcim80aremrk.Name = "dcim80aremrk";
            this.dcim80aremrk.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim80aremrk.OcxState")));
            this.dcim80aremrk.Size = new System.Drawing.Size(338, 18);
            this.dcim80aremrk.TabIndex = 1278;
            this.dcim80aremrk.TabStop = false;
            this.dcim80aremrk.Tag = "80aremrk";
            // 
            // dced80aremrk
            // 
            this.dced80aremrk.Location = new System.Drawing.Point(67, 1482);
            this.dced80aremrk.Name = "dced80aremrk";
            this.dced80aremrk.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced80aremrk.OcxState")));
            this.dced80aremrk.Size = new System.Drawing.Size(338, 18);
            this.dced80aremrk.TabIndex = 213;
            this.dced80aremrk.Tag = "80aremrk";
            // 
            // dcim80bremrk
            // 
            this.dcim80bremrk.Location = new System.Drawing.Point(67, 1505);
            this.dcim80bremrk.Name = "dcim80bremrk";
            this.dcim80bremrk.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim80bremrk.OcxState")));
            this.dcim80bremrk.Size = new System.Drawing.Size(338, 18);
            this.dcim80bremrk.TabIndex = 1280;
            this.dcim80bremrk.TabStop = false;
            this.dcim80bremrk.Tag = "80bremrk";
            // 
            // dced80bremrk
            // 
            this.dced80bremrk.Location = new System.Drawing.Point(67, 1524);
            this.dced80bremrk.Name = "dced80bremrk";
            this.dced80bremrk.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced80bremrk.OcxState")));
            this.dced80bremrk.Size = new System.Drawing.Size(338, 18);
            this.dced80bremrk.TabIndex = 214;
            this.dced80bremrk.Tag = "80bremrk";
            // 
            // dcim80cremrk
            // 
            this.dcim80cremrk.Location = new System.Drawing.Point(67, 1547);
            this.dcim80cremrk.Name = "dcim80cremrk";
            this.dcim80cremrk.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim80cremrk.OcxState")));
            this.dcim80cremrk.Size = new System.Drawing.Size(338, 18);
            this.dcim80cremrk.TabIndex = 1282;
            this.dcim80cremrk.TabStop = false;
            this.dcim80cremrk.Tag = "80cremrk";
            // 
            // dced80cremrk
            // 
            this.dced80cremrk.Location = new System.Drawing.Point(67, 1566);
            this.dced80cremrk.Name = "dced80cremrk";
            this.dced80cremrk.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced80cremrk.OcxState")));
            this.dced80cremrk.Size = new System.Drawing.Size(338, 18);
            this.dced80cremrk.TabIndex = 215;
            this.dced80cremrk.Tag = "80cremrk";
            // 
            // dcim80dremrk
            // 
            this.dcim80dremrk.Location = new System.Drawing.Point(67, 1589);
            this.dcim80dremrk.Name = "dcim80dremrk";
            this.dcim80dremrk.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim80dremrk.OcxState")));
            this.dcim80dremrk.Size = new System.Drawing.Size(338, 18);
            this.dcim80dremrk.TabIndex = 1284;
            this.dcim80dremrk.TabStop = false;
            this.dcim80dremrk.Tag = "80dremrk";
            // 
            // dced80dremrk
            // 
            this.dced80dremrk.Location = new System.Drawing.Point(67, 1608);
            this.dced80dremrk.Name = "dced80dremrk";
            this.dced80dremrk.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced80dremrk.OcxState")));
            this.dced80dremrk.Size = new System.Drawing.Size(338, 18);
            this.dced80dremrk.TabIndex = 216;
            this.dced80dremrk.Tag = "80dremrk";
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(18, 1462);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(49, 13);
            this.label76.TabIndex = 1286;
            this.label76.Text = "Remarks";
            // 
            // IClaim_8
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(1008, 1662);
            this.ContentSize = new System.Drawing.Size(1024, 1700);
            this.Controls.Add(this.label76);
            this.Controls.Add(this.dcim80dremrk);
            this.Controls.Add(this.dced80dremrk);
            this.Controls.Add(this.dcim80aremrk);
            this.Controls.Add(this.dced80aremrk);
            this.Controls.Add(this.dcim80bremrk);
            this.Controls.Add(this.dced80bremrk);
            this.Controls.Add(this.dcim80cremrk);
            this.Controls.Add(this.dced80cremrk);
            this.Controls.Add(this.label73);
            this.Controls.Add(this.dcim57copidt);
            this.Controls.Add(this.dced57copidt);
            this.Controls.Add(this.label74);
            this.Controls.Add(this.dcim57aopidp);
            this.Controls.Add(this.dced57aopidp);
            this.Controls.Add(this.label75);
            this.Controls.Add(this.dcim57bopids);
            this.Controls.Add(this.dced57bopids);
            this.Controls.Add(this.label66);
            this.Controls.Add(this.dcim79otql1);
            this.Controls.Add(this.dced79otql1);
            this.Controls.Add(this.label67);
            this.Controls.Add(this.label68);
            this.Controls.Add(this.dcim79otnpi);
            this.Controls.Add(this.dced79otnpi);
            this.Controls.Add(this.label69);
            this.Controls.Add(this.dcim79otql2);
            this.Controls.Add(this.dced79otql2);
            this.Controls.Add(this.label70);
            this.Controls.Add(this.dcim79otid);
            this.Controls.Add(this.dced79otid);
            this.Controls.Add(this.label71);
            this.Controls.Add(this.dcim79otlnm);
            this.Controls.Add(this.dced79otlnm);
            this.Controls.Add(this.label72);
            this.Controls.Add(this.dcim79otfnm);
            this.Controls.Add(this.dced79otfnm);
            this.Controls.Add(this.pictureBox13);
            this.Controls.Add(this.label65);
            this.Controls.Add(this.dcim78otql1);
            this.Controls.Add(this.dced78otql1);
            this.Controls.Add(this.label59);
            this.Controls.Add(this.label60);
            this.Controls.Add(this.dcimotnpi);
            this.Controls.Add(this.dced78otnpi);
            this.Controls.Add(this.label61);
            this.Controls.Add(this.dcim78otql2);
            this.Controls.Add(this.dcedotql2);
            this.Controls.Add(this.label62);
            this.Controls.Add(this.dcim78otid);
            this.Controls.Add(this.dced78otid);
            this.Controls.Add(this.label63);
            this.Controls.Add(this.dcimotlnm);
            this.Controls.Add(this.dced78otlnm);
            this.Controls.Add(this.label64);
            this.Controls.Add(this.dcim78otfnm);
            this.Controls.Add(this.dced78otfnm);
            this.Controls.Add(this.pictureBox12);
            this.Controls.Add(this.label53);
            this.Controls.Add(this.label54);
            this.Controls.Add(this.dcim77opnpi);
            this.Controls.Add(this.dced77opnpi);
            this.Controls.Add(this.label55);
            this.Controls.Add(this.dcim77opqual);
            this.Controls.Add(this.dced77opqual);
            this.Controls.Add(this.label56);
            this.Controls.Add(this.dcim77opid);
            this.Controls.Add(this.dced77opid);
            this.Controls.Add(this.label57);
            this.Controls.Add(this.dcim77oplnm);
            this.Controls.Add(this.dced77oplnm);
            this.Controls.Add(this.label58);
            this.Controls.Add(this.dcim77opfnm);
            this.Controls.Add(this.dced77opfnm);
            this.Controls.Add(this.pictureBox11);
            this.Controls.Add(this.label50);
            this.Controls.Add(this.label51);
            this.Controls.Add(this.label52);
            this.Controls.Add(this.dcim54aprpay);
            this.Controls.Add(this.dced54aprpay);
            this.Controls.Add(this.dcim54bprpay);
            this.Controls.Add(this.dced54bprpay);
            this.Controls.Add(this.label49);
            this.Controls.Add(this.dcim54cprpay);
            this.Controls.Add(this.dced54cprpay);
            this.Controls.Add(this.dcim55aetamt);
            this.Controls.Add(this.dced55aetamt);
            this.Controls.Add(this.dcim55betamt);
            this.Controls.Add(this.dced55betamt);
            this.Controls.Add(this.label48);
            this.Controls.Add(this.dcim55cetamt);
            this.Controls.Add(this.dced55cetamt);
            this.Controls.Add(this.dcim72cPOA);
            this.Controls.Add(this.dced72cPOA);
            this.Controls.Add(this.label47);
            this.Controls.Add(this.dcim72cecicd);
            this.Controls.Add(this.dced72cecicd);
            this.Controls.Add(this.dcim72bPOA);
            this.Controls.Add(this.dced72bPOA);
            this.Controls.Add(this.dcim72aPOA);
            this.Controls.Add(this.dced72aPOA);
            this.Controls.Add(this.label46);
            this.Controls.Add(this.dcim72becicd);
            this.Controls.Add(this.dced72becicd);
            this.Controls.Add(this.axDcimage2);
            this.Controls.Add(this.axDcedit2);
            this.Controls.Add(this.dcim67POA);
            this.Controls.Add(this.dcim67aPOA);
            this.Controls.Add(this.axDcimage14);
            this.Controls.Add(this.axDcedit16);
            this.Controls.Add(this.axDcimage15);
            this.Controls.Add(this.axDcedit17);
            this.Controls.Add(this.axDcimage16);
            this.Controls.Add(this.axDcedit18);
            this.Controls.Add(this.dced67aPOA);
            this.Controls.Add(this.axDcimage10);
            this.Controls.Add(this.axDcedit12);
            this.Controls.Add(this.axDcimage11);
            this.Controls.Add(this.axDcedit13);
            this.Controls.Add(this.axDcimage12);
            this.Controls.Add(this.axDcedit14);
            this.Controls.Add(this.axDcimage13);
            this.Controls.Add(this.axDcedit15);
            this.Controls.Add(this.axDcimage6);
            this.Controls.Add(this.axDcedit8);
            this.Controls.Add(this.dcim67hPOA);
            this.Controls.Add(this.dced67hPOA);
            this.Controls.Add(this.dcim67gPOA);
            this.Controls.Add(this.dced67gPOA);
            this.Controls.Add(this.dcim67cPOA);
            this.Controls.Add(this.dced67cPOA);
            this.Controls.Add(this.dcim67fPOA);
            this.Controls.Add(this.dced67fPOA);
            this.Controls.Add(this.dcim67ePOA);
            this.Controls.Add(this.dced67ePOA);
            this.Controls.Add(this.dcim67dPOA);
            this.Controls.Add(this.dced67dPOA);
            this.Controls.Add(this.dcim67bPOA);
            this.Controls.Add(this.dced67bPOA);
            this.Controls.Add(this.dced67POA);
            this.Controls.Add(this.label45);
            this.Controls.Add(this.label44);
            this.Controls.Add(this.label43);
            this.Controls.Add(this.label42);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.lbl14admtyp);
            this.Controls.Add(this.dced2paytid);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.dcim28concd);
            this.Controls.Add(this.dced28concd);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.dcim27concd);
            this.Controls.Add(this.dced27concd);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.dcim22concd);
            this.Controls.Add(this.dced22concd);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.dcim26concd);
            this.Controls.Add(this.dced26concd);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.dcim25concd);
            this.Controls.Add(this.dced25concd);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.dcim24concd);
            this.Controls.Add(this.dced24concd);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.dcim23concd);
            this.Controls.Add(this.dced23concd);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.dcim21concd);
            this.Controls.Add(this.dced21concd);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.dcim19concd);
            this.Controls.Add(this.dced19concd);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.dcim20concd);
            this.Controls.Add(this.dced20concd);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.axDcimage1);
            this.Controls.Add(this.dcim18concd);
            this.Controls.Add(this.axDcedit1);
            this.Controls.Add(this.dced18concd);
            this.Controls.Add(this.dcim2payto);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.dced2paytnm);
            this.Controls.Add(this.dced2paytadd);
            this.Controls.Add(this.dced2paytcty);
            this.Controls.Add(this.dced2paytst);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.dced2paytzip);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.lbl8ptnm);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.dcim35aospcd);
            this.Controls.Add(this.dced35aospcd);
            this.Controls.Add(this.dcim35aospfr);
            this.Controls.Add(this.dced35aospfr);
            this.Controls.Add(this.dcim35aospth);
            this.Controls.Add(this.dced35aospth);
            this.Controls.Add(this.dcim35bospcd);
            this.Controls.Add(this.dced35bospcd);
            this.Controls.Add(this.dcim35bospfr);
            this.Controls.Add(this.dced35bospfr);
            this.Controls.Add(this.dcim35bospth);
            this.Controls.Add(this.dced35bospth);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.dcim34aocrcd);
            this.Controls.Add(this.dced34aocrcd);
            this.Controls.Add(this.dcim34aocrdt);
            this.Controls.Add(this.dced34aocrdt);
            this.Controls.Add(this.dcim34bocrcd);
            this.Controls.Add(this.dced34bocrcd);
            this.Controls.Add(this.dcim34bocrdt);
            this.Controls.Add(this.dced34bocrdt);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.dcim33aocrcd);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.dced33aocrcd);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.dcim33aocrdt);
            this.Controls.Add(this.dced33aocrdt);
            this.Controls.Add(this.dcim33bocrcd);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.dced33bocrcd);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.dcim33bocrdt);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.dced33bocrdt);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lbl74prprcd);
            this.Controls.Add(this.dcim74prprcd);
            this.Controls.Add(this.dced74prprcd);
            this.Controls.Add(this.dcim74prprdt);
            this.Controls.Add(this.dced74prprdt);
            this.Controls.Add(this.lbl74aoprcd);
            this.Controls.Add(this.dcim74aoprcd);
            this.Controls.Add(this.dced74aoprcd);
            this.Controls.Add(this.dcim74aoprdt);
            this.Controls.Add(this.dced74aoprdt);
            this.Controls.Add(this.dcim74boprcd);
            this.Controls.Add(this.dced74boprcd);
            this.Controls.Add(this.lbl74boprdt);
            this.Controls.Add(this.dcim74boprdt);
            this.Controls.Add(this.dced74boprdt);
            this.Controls.Add(this.lbl74coprcd);
            this.Controls.Add(this.dcim74coprcd);
            this.Controls.Add(this.dced74coprcd);
            this.Controls.Add(this.dcim74coprdt);
            this.Controls.Add(this.dced74coprdt);
            this.Controls.Add(this.lbl74doprcd);
            this.Controls.Add(this.dcim74doprcd);
            this.Controls.Add(this.dced74doprcd);
            this.Controls.Add(this.dcim74doprdt);
            this.Controls.Add(this.dced74doprdt);
            this.Controls.Add(this.lbl74eoprcd);
            this.Controls.Add(this.dcim74eoprcd);
            this.Controls.Add(this.dced74eoprcd);
            this.Controls.Add(this.lbl74eoprdt);
            this.Controls.Add(this.dcim74eoprdt);
            this.Controls.Add(this.dced74eoprdt);
            this.Controls.Add(this.lbl76apnpi);
            this.Controls.Add(this.dcim76apnpi);
            this.Controls.Add(this.dced76apnpi);
            this.Controls.Add(this.lbl76apqual);
            this.Controls.Add(this.dcim76apqual);
            this.Controls.Add(this.dced76apqual);
            this.Controls.Add(this.lbl76apid);
            this.Controls.Add(this.dcim76apid);
            this.Controls.Add(this.dced76apid);
            this.Controls.Add(this.lbl76aplnm);
            this.Controls.Add(this.dcim76aplnm);
            this.Controls.Add(this.dced76aplnm);
            this.Controls.Add(this.lbl76apfnm);
            this.Controls.Add(this.dcim76apfnm);
            this.Controls.Add(this.dced76apfnm);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnDelpbLINEITEM);
            this.Controls.Add(this.btnInsAfterpbLINEITEM);
            this.Controls.Add(this.btnInsBeforepbLINEITEM);
            this.Controls.Add(this.dcim50apayer);
            this.Controls.Add(this.dced50apayer);
            this.Controls.Add(this.dcim50bpayer);
            this.Controls.Add(this.dced50bpayer);
            this.Controls.Add(this.lbl50cpayer);
            this.Controls.Add(this.dcim50cpayer);
            this.Controls.Add(this.dced50cpayer);
            this.Controls.Add(this.dcim51aprvno);
            this.Controls.Add(this.dced51aprvno);
            this.Controls.Add(this.dcim51bprvno);
            this.Controls.Add(this.dced51bprvno);
            this.Controls.Add(this.lbl51cprvno);
            this.Controls.Add(this.dcim51cprvno);
            this.Controls.Add(this.dced51cprvno);
            this.Controls.Add(this.lbl56npi);
            this.Controls.Add(this.dcim56npi);
            this.Controls.Add(this.dced56npi);
            this.Controls.Add(this.dcim58ainsnm);
            this.Controls.Add(this.lbl58alname);
            this.Controls.Add(this.dced58alname);
            this.Controls.Add(this.lbl58afname);
            this.Controls.Add(this.dced58afname);
            this.Controls.Add(this.lbl58aminit);
            this.Controls.Add(this.dced58aminit);
            this.Controls.Add(this.lbl58binsnm);
            this.Controls.Add(this.dcim58binsnm);
            this.Controls.Add(this.lbl58blname);
            this.Controls.Add(this.dced58blname);
            this.Controls.Add(this.lbl58bfname);
            this.Controls.Add(this.dced58bfname);
            this.Controls.Add(this.lbl58bminit);
            this.Controls.Add(this.dced58bminit);
            this.Controls.Add(this.dcim58cinsnm);
            this.Controls.Add(this.lbl58clname);
            this.Controls.Add(this.dced58clname);
            this.Controls.Add(this.dced58cfname);
            this.Controls.Add(this.dced58cminit);
            this.Controls.Add(this.dcim60acshi);
            this.Controls.Add(this.dced60acshi);
            this.Controls.Add(this.dcim60bcshi);
            this.Controls.Add(this.dced60bcshi);
            this.Controls.Add(this.lbl60ccshi);
            this.Controls.Add(this.dcim60ccshi);
            this.Controls.Add(this.dced60ccshi);
            this.Controls.Add(this.dcim66dxverq);
            this.Controls.Add(this.dced66dxverq);
            this.Controls.Add(this.lbl67prdgcd);
            this.Controls.Add(this.dcim67prdgcd);
            this.Controls.Add(this.dced67prdgcd);
            this.Controls.Add(this.lbl67aothdg);
            this.Controls.Add(this.dcim67aothdg);
            this.Controls.Add(this.dced67aothdg);
            this.Controls.Add(this.lbl67bothdg);
            this.Controls.Add(this.dcim67bothdg);
            this.Controls.Add(this.dced67bothdg);
            this.Controls.Add(this.lbl67cothdg);
            this.Controls.Add(this.dcim67cothdg);
            this.Controls.Add(this.dced67cothdg);
            this.Controls.Add(this.lbl67dothdg);
            this.Controls.Add(this.dcim67dothdg);
            this.Controls.Add(this.dced67dothdg);
            this.Controls.Add(this.lbl67eothdg);
            this.Controls.Add(this.dcim67eothdg);
            this.Controls.Add(this.dced67eothdg);
            this.Controls.Add(this.lbl67fothdg);
            this.Controls.Add(this.dcim67fothdg);
            this.Controls.Add(this.dced67fothdg);
            this.Controls.Add(this.lbl67gothdg);
            this.Controls.Add(this.dcim67gothdg);
            this.Controls.Add(this.dced67gothdg);
            this.Controls.Add(this.lbl67hothdg);
            this.Controls.Add(this.dcim67hothdg);
            this.Controls.Add(this.dced67hothdg);
            this.Controls.Add(this.lbl67iothdg);
            this.Controls.Add(this.dcim67iothdg);
            this.Controls.Add(this.dced67iothdg);
            this.Controls.Add(this.lbl67jothdg);
            this.Controls.Add(this.dcim67jothdg);
            this.Controls.Add(this.dced67jothdg);
            this.Controls.Add(this.lbl67kothdg);
            this.Controls.Add(this.dcim67kothdg);
            this.Controls.Add(this.dced67kothdg);
            this.Controls.Add(this.lbl67lothdg);
            this.Controls.Add(this.dcim67lothdg);
            this.Controls.Add(this.dced67lothdg);
            this.Controls.Add(this.lbl67mothdg);
            this.Controls.Add(this.dcim67mothdg);
            this.Controls.Add(this.dced67mothdg);
            this.Controls.Add(this.lbl67nothdg);
            this.Controls.Add(this.dcim67nothdg);
            this.Controls.Add(this.dced67nothdg);
            this.Controls.Add(this.lbl67oothdg);
            this.Controls.Add(this.dcim67oothdg);
            this.Controls.Add(this.dced67oothdg);
            this.Controls.Add(this.lbl67pothdg);
            this.Controls.Add(this.dcim67pothdg);
            this.Controls.Add(this.dced67pothdg);
            this.Controls.Add(this.lbl67qothdg);
            this.Controls.Add(this.dcim67qothdg);
            this.Controls.Add(this.dced67qothdg);
            this.Controls.Add(this.dcim69amdgcd);
            this.Controls.Add(this.dced69amdgcd);
            this.Controls.Add(this.dcim70arfvcd);
            this.Controls.Add(this.dced70arfvcd);
            this.Controls.Add(this.dcim70brfvcd);
            this.Controls.Add(this.dced70brfvcd);
            this.Controls.Add(this.dcim70crfvcd);
            this.Controls.Add(this.dced70crfvcd);
            this.Controls.Add(this.dcim71ppscd);
            this.Controls.Add(this.dced71ppscd);
            this.Controls.Add(this.lbl72aecicd);
            this.Controls.Add(this.dcim72aecicd);
            this.Controls.Add(this.dced72aecicd);
            this.Controls.Add(this.dcim23TotChgs);
            this.Controls.Add(this.dced23TotChgs);
            this.Controls.Add(this.panLINEITEM);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.dcim1fcynmad);
            this.Controls.Add(this.lbl1provnam);
            this.Controls.Add(this.dced1provnam);
            this.Controls.Add(this.dced1provadd);
            this.Controls.Add(this.dced1provcit);
            this.Controls.Add(this.dced1provsta);
            this.Controls.Add(this.lbl3apctlnm);
            this.Controls.Add(this.dcim3apctlnm);
            this.Controls.Add(this.dced3apctlnm);
            this.Controls.Add(this.lbl3bmdrcnm);
            this.Controls.Add(this.dcim3bmdrcnm);
            this.Controls.Add(this.dced3bmdrcnm);
            this.Controls.Add(this.lbl4typbill);
            this.Controls.Add(this.dcim4typbill);
            this.Controls.Add(this.dced4typbill);
            this.Controls.Add(this.lbl5fedtxnm);
            this.Controls.Add(this.dcim5fedtxnm);
            this.Controls.Add(this.dced5fedtxnm);
            this.Controls.Add(this.lbl6scpfrom);
            this.Controls.Add(this.dcim6scpfrom);
            this.Controls.Add(this.dced6scpfrom);
            this.Controls.Add(this.dcim6scpthru);
            this.Controls.Add(this.dced6scpthru);
            this.Controls.Add(this.lbl8ptnmid);
            this.Controls.Add(this.dcim8ptnmid);
            this.Controls.Add(this.dced8ptnmid);
            this.Controls.Add(this.dcim8ptnm);
            this.Controls.Add(this.dced8plname);
            this.Controls.Add(this.dced8pfname);
            this.Controls.Add(this.dced8pminit);
            this.Controls.Add(this.dcim9paddstr);
            this.Controls.Add(this.dced9paddstr);
            this.Controls.Add(this.dcim9paddcty);
            this.Controls.Add(this.dced9paddcty);
            this.Controls.Add(this.dcim9paddsta);
            this.Controls.Add(this.dced9paddsta);
            this.Controls.Add(this.dcim9paddzip);
            this.Controls.Add(this.dced9paddzip);
            this.Controls.Add(this.dcim9paddccd);
            this.Controls.Add(this.dced9paddccd);
            this.Controls.Add(this.lbl10pbdate);
            this.Controls.Add(this.dcim10pbdate);
            this.Controls.Add(this.dced10pbdate);
            this.Controls.Add(this.lbl11psex);
            this.Controls.Add(this.dcim11psex);
            this.Controls.Add(this.dced11psex);
            this.Controls.Add(this.lbl12admdte);
            this.Controls.Add(this.dcim12admdte);
            this.Controls.Add(this.dced12admdte);
            this.Controls.Add(this.lbl13admhr);
            this.Controls.Add(this.dcim13admhr);
            this.Controls.Add(this.dced13admhr);
            this.Controls.Add(this.dcim14admtyp);
            this.Controls.Add(this.dced14admtyp);
            this.Controls.Add(this.lbl16dhr);
            this.Controls.Add(this.dcim16dhr);
            this.Controls.Add(this.dced16dhr);
            this.Controls.Add(this.lbl17stat);
            this.Controls.Add(this.dcim17stat);
            this.Controls.Add(this.dced17stat);
            this.Controls.Add(this.lbl31aocrcd);
            this.Controls.Add(this.dcim31aocrcd);
            this.Controls.Add(this.dced31aocrcd);
            this.Controls.Add(this.dcim31aocrdt);
            this.Controls.Add(this.dced31aocrdt);
            this.Controls.Add(this.dcim31bocrcd);
            this.Controls.Add(this.dced31bocrcd);
            this.Controls.Add(this.dcim31bocrdt);
            this.Controls.Add(this.dced31bocrdt);
            this.Controls.Add(this.lbl32aocrcd);
            this.Controls.Add(this.dcim32aocrcd);
            this.Controls.Add(this.dced32aocrcd);
            this.Controls.Add(this.dcim32aocrdt);
            this.Controls.Add(this.dced32aocrdt);
            this.Controls.Add(this.dcim32bocrcd);
            this.Controls.Add(this.dced32bocrcd);
            this.Controls.Add(this.dcim32bocrdt);
            this.Controls.Add(this.dced32bocrdt);
            this.Controls.Add(this.lbl36aospcd);
            this.Controls.Add(this.dcim36aospcd);
            this.Controls.Add(this.dced36aospcd);
            this.Controls.Add(this.dcim36aospfr);
            this.Controls.Add(this.dced36aospfr);
            this.Controls.Add(this.dcim36aospth);
            this.Controls.Add(this.dced36aospth);
            this.Controls.Add(this.dcim36bospcd);
            this.Controls.Add(this.dced36bospcd);
            this.Controls.Add(this.dcim36bospfr);
            this.Controls.Add(this.dced36bospfr);
            this.Controls.Add(this.dcim36bospth);
            this.Controls.Add(this.dced36bospth);
            this.Controls.Add(this.lbl39avlcd);
            this.Controls.Add(this.dcim39avlcd);
            this.Controls.Add(this.dced39avlcd);
            this.Controls.Add(this.dcim39avlamt);
            this.Controls.Add(this.dced39avlamt);
            this.Controls.Add(this.dcim39bvlcd);
            this.Controls.Add(this.dced39bvlcd);
            this.Controls.Add(this.dcim39bvlamt);
            this.Controls.Add(this.dced39bvlamt);
            this.Controls.Add(this.dcim39cvlcd);
            this.Controls.Add(this.dced39cvlcd);
            this.Controls.Add(this.dcim39cvlamt);
            this.Controls.Add(this.dced39cvlamt);
            this.Controls.Add(this.dcim39dvlcd);
            this.Controls.Add(this.dced39dvlcd);
            this.Controls.Add(this.dcim39dvlamt);
            this.Controls.Add(this.dced39dvlamt);
            this.Controls.Add(this.lbl40avlcd);
            this.Controls.Add(this.dcim40avlcd);
            this.Controls.Add(this.dced40avlcd);
            this.Controls.Add(this.dcim40avlamt);
            this.Controls.Add(this.dced40avlamt);
            this.Controls.Add(this.dcim40bvlcd);
            this.Controls.Add(this.dced40bvlcd);
            this.Controls.Add(this.dcim40bvlamt);
            this.Controls.Add(this.dced40bvlamt);
            this.Controls.Add(this.dcim40cvlcd);
            this.Controls.Add(this.dced40cvlcd);
            this.Controls.Add(this.dcim40cvlamt);
            this.Controls.Add(this.dced40cvlamt);
            this.Controls.Add(this.dcim40dvlcd);
            this.Controls.Add(this.dced40dvlcd);
            this.Controls.Add(this.dcim40dvlamt);
            this.Controls.Add(this.dced40dvlamt);
            this.Controls.Add(this.dcim41avlcd);
            this.Controls.Add(this.dced41avlcd);
            this.Controls.Add(this.dcim41avlamt);
            this.Controls.Add(this.dced41avlamt);
            this.Controls.Add(this.lbl41bvlcd);
            this.Controls.Add(this.dcim41bvlcd);
            this.Controls.Add(this.dced41bvlcd);
            this.Controls.Add(this.dcim41bvlamt);
            this.Controls.Add(this.dced41bvlamt);
            this.Controls.Add(this.dcim41cvlcd);
            this.Controls.Add(this.dced41cvlcd);
            this.Controls.Add(this.dcim41cvlamt);
            this.Controls.Add(this.dced41cvlamt);
            this.Controls.Add(this.dcim41dvlcd);
            this.Controls.Add(this.dced41dvlcd);
            this.Controls.Add(this.dcim41dvlamt);
            this.Controls.Add(this.dced41dvlamt);
            this.Controls.Add(this.lbl1fcynmad);
            this.Controls.Add(this.lbl1provadd);
            this.Controls.Add(this.lbl1provcit);
            this.Controls.Add(this.lbl1provsta);
            this.Controls.Add(this.dced1provzip);
            this.Controls.Add(this.lbl1provzip);
            this.Controls.Add(this.lbl8plname);
            this.Controls.Add(this.lbl8pfname);
            this.Controls.Add(this.lbl8pminit);
            this.Controls.Add(this.lbl9paddstr);
            this.Controls.Add(this.lbl9paddcty);
            this.Controls.Add(this.lbl9paddsta);
            this.Controls.Add(this.lbl9paddzip);
            this.Controls.Add(this.lbl9paddccd);
            this.Controls.Add(this.picbx1);
            this.Controls.Add(this.picbx8);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.pictureBox10);
            this.Controls.Add(this.lbl23TotChgs);
            this.Controls.Add(this.pictureBox9);
            this.MaximumSize = new System.Drawing.Size(1048, 1724);
            this.Name = "IClaim_8";
            ((System.ComponentModel.ISupportInitialize)(this.dcim1fcynmad)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced1provnam)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced1provadd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced1provcit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced1provsta)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim3apctlnm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced3apctlnm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim3bmdrcnm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced3bmdrcnm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim4typbill)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced4typbill)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim5fedtxnm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced5fedtxnm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim6scpfrom)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced6scpfrom)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim6scpthru)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced6scpthru)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim8ptnmid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced8ptnmid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim8ptnm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced8plname)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced8pfname)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced8pminit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim9paddstr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced9paddstr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim9paddcty)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced9paddcty)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim9paddsta)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced9paddsta)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim9paddzip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced9paddzip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim9paddccd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced9paddccd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim10pbdate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced10pbdate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim11psex)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced11psex)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim12admdte)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced12admdte)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim13admhr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced13admhr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim14admtyp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced14admtyp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim16dhr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced16dhr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim17stat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced17stat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim31aocrcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced31aocrcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim31aocrdt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced31aocrdt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim31bocrcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced31bocrcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim31bocrdt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced31bocrdt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim32aocrcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced32aocrcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim32aocrdt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced32aocrdt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim32bocrcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced32bocrcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim32bocrdt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced32bocrdt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim36aospcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced36aospcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim36aospfr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced36aospfr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim36aospth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced36aospth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim36bospcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced36bospcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim36bospfr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced36bospfr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim36bospth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced36bospth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim39avlcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced39avlcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim39avlamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced39avlamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim39bvlcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced39bvlcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim39bvlamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced39bvlamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim39cvlcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced39cvlcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim39cvlamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced39cvlamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim39dvlcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced39dvlcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim39dvlamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced39dvlamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim40avlcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced40avlcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim40avlamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced40avlamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim40bvlcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced40bvlcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim40bvlamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced40bvlamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim40cvlcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced40cvlcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim40cvlamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced40cvlamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim40dvlcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced40dvlcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim40dvlamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced40dvlamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim41avlcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced41avlcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim41avlamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced41avlamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim41bvlcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced41bvlcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim41bvlamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced41bvlamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim41cvlcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced41cvlcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim41cvlamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced41cvlamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim41dvlcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced41dvlcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim41dvlamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced41dvlamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced1provzip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim50apayer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced50apayer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim50bpayer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced50bpayer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim50cpayer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced50cpayer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim51aprvno)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced51aprvno)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim51bprvno)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced51bprvno)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim51cprvno)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced51cprvno)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim56npi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced56npi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim58ainsnm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced58alname)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced58afname)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced58aminit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim58binsnm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced58blname)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced58bfname)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced58bminit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim58cinsnm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced58clname)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced58cfname)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced58cminit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim60acshi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced60acshi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim60bcshi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced60bcshi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim60ccshi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced60ccshi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim66dxverq)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced66dxverq)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67prdgcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67prdgcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67aothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67aothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67bothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67bothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67cothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67cothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67dothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67dothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67eothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67eothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67fothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67fothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67gothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67gothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67hothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67hothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67iothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67iothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67jothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67jothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67kothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67kothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67lothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67lothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67mothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67mothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67nothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67nothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67oothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67oothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67pothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67pothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67qothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67qothdg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim69amdgcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced69amdgcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim70arfvcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced70arfvcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim70brfvcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced70brfvcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim70crfvcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced70crfvcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim71ppscd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced71ppscd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim72aecicd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced72aecicd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim23TotChgs)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced23TotChgs)).EndInit();
            this.panLINEITEM.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dcimNDCType)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedNDCType)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimNDCQty)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedNDCQty)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimRevCode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedRevCode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimDescription)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedDescription)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimHCPCS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedHCPCS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimServiceDate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedServiceDate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimUnits)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedUnits)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimCharges)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedCharges)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimNonCovered)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedNonCovered)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimNDC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedNDC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim74prprcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced74prprcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim74prprdt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced74prprdt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim74aoprcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced74aoprcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim74aoprdt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced74aoprdt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim74boprcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced74boprcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim74boprdt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced74boprdt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim74coprcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced74coprcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim74coprdt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced74coprdt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim74doprcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced74doprcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim74doprdt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced74doprdt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim74eoprcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced74eoprcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim74eoprdt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced74eoprdt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim76apnpi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced76apnpi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim76apqual)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced76apqual)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim76apid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced76apid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim76aplnm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced76aplnm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim76apfnm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced76apfnm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim33aocrcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced33aocrcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim33aocrdt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced33aocrdt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim33bocrcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced33bocrcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim33bocrdt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced33bocrdt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim34aocrcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced34aocrcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim34aocrdt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced34aocrdt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim34bocrcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced34bocrcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim34bocrdt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced34bocrdt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim35aospcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced35aospcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim35aospfr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced35aospfr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim35aospth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced35aospth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim35bospcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced35bospcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim35bospfr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced35bospfr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim35bospth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced35bospth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim2payto)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced2paytnm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced2paytadd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced2paytcty)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced2paytst)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced2paytzip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim18concd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced18concd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axDcimage1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axDcedit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim20concd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced20concd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim19concd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced19concd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim21concd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced21concd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim23concd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced23concd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim24concd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced24concd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim25concd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced25concd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim26concd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced26concd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim22concd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced22concd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim27concd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced27concd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim28concd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced28concd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced2paytid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67POA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67bPOA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67bPOA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67dPOA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67dPOA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67ePOA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67ePOA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67fPOA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67fPOA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axDcimage6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axDcedit8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67hPOA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67hPOA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67gPOA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67gPOA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67cPOA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67cPOA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axDcimage10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axDcedit12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axDcimage11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axDcedit13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axDcimage12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axDcedit14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axDcimage13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axDcedit15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axDcimage14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axDcedit16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axDcimage15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axDcedit17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axDcimage16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axDcedit18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced67aPOA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67aPOA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim67POA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axDcimage2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axDcedit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim72becicd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced72becicd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim72aPOA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced72aPOA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim72bPOA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced72bPOA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim72cPOA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced72cPOA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim72cecicd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced72cecicd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim55aetamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced55aetamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim55betamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced55betamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim55cetamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced55cetamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim54aprpay)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced54aprpay)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim54bprpay)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced54bprpay)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim54cprpay)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced54cprpay)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim77opnpi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced77opnpi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim77opqual)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced77opqual)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim77opid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced77opid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim77oplnm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced77oplnm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim77opfnm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced77opfnm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimotnpi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced78otnpi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim78otql2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedotql2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim78otid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced78otid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimotlnm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced78otlnm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim78otfnm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced78otfnm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim78otql1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced78otql1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim79otql1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced79otql1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim79otnpi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced79otnpi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim79otql2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced79otql2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim79otid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced79otid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim79otlnm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced79otlnm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim79otfnm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced79otfnm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim57copidt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced57copidt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim57aopidp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced57aopidp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim57bopids)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced57bopids)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim80aremrk)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced80aremrk)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim80bremrk)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced80bremrk)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim80cremrk)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced80cremrk)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim80dremrk)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced80dremrk)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private AxDCIMAGELib.AxDcimage dcim1fcynmad;
        private System.Windows.Forms.Label lbl1provnam;
        private AxDCEDITLib.AxDcedit dced1provnam;
        private AxDCEDITLib.AxDcedit dced1provadd;
        private AxDCEDITLib.AxDcedit dced1provcit;
        private AxDCEDITLib.AxDcedit dced1provsta;
        private System.Windows.Forms.Label lbl3apctlnm;
        private AxDCIMAGELib.AxDcimage dcim3apctlnm;
        private AxDCEDITLib.AxDcedit dced3apctlnm;
        private System.Windows.Forms.Label lbl3bmdrcnm;
        private AxDCIMAGELib.AxDcimage dcim3bmdrcnm;
        private AxDCEDITLib.AxDcedit dced3bmdrcnm;
        private System.Windows.Forms.Label lbl4typbill;
        private AxDCIMAGELib.AxDcimage dcim4typbill;
        private AxDCEDITLib.AxDcedit dced4typbill;
        private System.Windows.Forms.Label lbl5fedtxnm;
        private AxDCIMAGELib.AxDcimage dcim5fedtxnm;
        private AxDCEDITLib.AxDcedit dced5fedtxnm;
        private System.Windows.Forms.Label lbl6scpfrom;
        private AxDCIMAGELib.AxDcimage dcim6scpfrom;
        private AxDCEDITLib.AxDcedit dced6scpfrom;
        private AxDCIMAGELib.AxDcimage dcim6scpthru;
        private AxDCEDITLib.AxDcedit dced6scpthru;
        private System.Windows.Forms.Label lbl8ptnmid;
        private AxDCIMAGELib.AxDcimage dcim8ptnmid;
        private AxDCEDITLib.AxDcedit dced8ptnmid;
        private System.Windows.Forms.Label lbl8ptnm;
        private AxDCIMAGELib.AxDcimage dcim8ptnm;
        private AxDCEDITLib.AxDcedit dced8plname;
        private AxDCEDITLib.AxDcedit dced8pfname;
        private AxDCEDITLib.AxDcedit dced8pminit;
        private AxDCIMAGELib.AxDcimage dcim9paddstr;
        private AxDCEDITLib.AxDcedit dced9paddstr;
        private AxDCIMAGELib.AxDcimage dcim9paddcty;
        private AxDCEDITLib.AxDcedit dced9paddcty;
        private AxDCIMAGELib.AxDcimage dcim9paddsta;
        private AxDCEDITLib.AxDcedit dced9paddsta;
        private AxDCIMAGELib.AxDcimage dcim9paddzip;
        private AxDCEDITLib.AxDcedit dced9paddzip;
        private AxDCIMAGELib.AxDcimage dcim9paddccd;
        private AxDCEDITLib.AxDcedit dced9paddccd;
        private System.Windows.Forms.Label lbl10pbdate;
        private AxDCIMAGELib.AxDcimage dcim10pbdate;
        private AxDCEDITLib.AxDcedit dced10pbdate;
        private System.Windows.Forms.Label lbl11psex;
        private AxDCIMAGELib.AxDcimage dcim11psex;
        private AxDCEDITLib.AxDcedit dced11psex;
        private System.Windows.Forms.Label lbl12admdte;
        private AxDCIMAGELib.AxDcimage dcim12admdte;
        private AxDCEDITLib.AxDcedit dced12admdte;
        private System.Windows.Forms.Label lbl13admhr;
        private AxDCIMAGELib.AxDcimage dcim13admhr;
        private AxDCEDITLib.AxDcedit dced13admhr;
        private System.Windows.Forms.Label lbl14admtyp;
        private AxDCIMAGELib.AxDcimage dcim14admtyp;
        private AxDCEDITLib.AxDcedit dced14admtyp;
        private System.Windows.Forms.Label lbl16dhr;
        private AxDCIMAGELib.AxDcimage dcim16dhr;
        private AxDCEDITLib.AxDcedit dced16dhr;
        private System.Windows.Forms.Label lbl17stat;
        private AxDCIMAGELib.AxDcimage dcim17stat;
        private AxDCEDITLib.AxDcedit dced17stat;
        private System.Windows.Forms.Label lbl31aocrcd;
        private AxDCIMAGELib.AxDcimage dcim31aocrcd;
        private AxDCEDITLib.AxDcedit dced31aocrcd;
        private AxDCIMAGELib.AxDcimage dcim31aocrdt;
        private AxDCEDITLib.AxDcedit dced31aocrdt;
        private AxDCIMAGELib.AxDcimage dcim31bocrcd;
        private AxDCEDITLib.AxDcedit dced31bocrcd;
        private AxDCIMAGELib.AxDcimage dcim31bocrdt;
        private AxDCEDITLib.AxDcedit dced31bocrdt;
        private System.Windows.Forms.Label lbl32aocrcd;
        private AxDCIMAGELib.AxDcimage dcim32aocrcd;
        private AxDCEDITLib.AxDcedit dced32aocrcd;
        private AxDCIMAGELib.AxDcimage dcim32aocrdt;
        private AxDCEDITLib.AxDcedit dced32aocrdt;
        private AxDCIMAGELib.AxDcimage dcim32bocrcd;
        private AxDCEDITLib.AxDcedit dced32bocrcd;
        private AxDCIMAGELib.AxDcimage dcim32bocrdt;
        private AxDCEDITLib.AxDcedit dced32bocrdt;
        private System.Windows.Forms.Label lbl36aospcd;
        private AxDCIMAGELib.AxDcimage dcim36aospcd;
        private AxDCEDITLib.AxDcedit dced36aospcd;
        private AxDCIMAGELib.AxDcimage dcim36aospfr;
        private AxDCEDITLib.AxDcedit dced36aospfr;
        private AxDCIMAGELib.AxDcimage dcim36aospth;
        private AxDCEDITLib.AxDcedit dced36aospth;
        private AxDCIMAGELib.AxDcimage dcim36bospcd;
        private AxDCEDITLib.AxDcedit dced36bospcd;
        private AxDCIMAGELib.AxDcimage dcim36bospfr;
        private AxDCEDITLib.AxDcedit dced36bospfr;
        private AxDCIMAGELib.AxDcimage dcim36bospth;
        private AxDCEDITLib.AxDcedit dced36bospth;
        private System.Windows.Forms.Label lbl39avlcd;
        private AxDCIMAGELib.AxDcimage dcim39avlcd;
        private AxDCEDITLib.AxDcedit dced39avlcd;
        private AxDCIMAGELib.AxDcimage dcim39avlamt;
        private AxDCEDITLib.AxDcedit dced39avlamt;
        private AxDCIMAGELib.AxDcimage dcim39bvlcd;
        private AxDCEDITLib.AxDcedit dced39bvlcd;
        private AxDCIMAGELib.AxDcimage dcim39bvlamt;
        private AxDCEDITLib.AxDcedit dced39bvlamt;
        private AxDCIMAGELib.AxDcimage dcim39cvlcd;
        private AxDCEDITLib.AxDcedit dced39cvlcd;
        private AxDCIMAGELib.AxDcimage dcim39cvlamt;
        private AxDCEDITLib.AxDcedit dced39cvlamt;
        private AxDCIMAGELib.AxDcimage dcim39dvlcd;
        private AxDCEDITLib.AxDcedit dced39dvlcd;
        private AxDCIMAGELib.AxDcimage dcim39dvlamt;
        private AxDCEDITLib.AxDcedit dced39dvlamt;
        private System.Windows.Forms.Label lbl40avlcd;
        private AxDCIMAGELib.AxDcimage dcim40avlcd;
        private AxDCEDITLib.AxDcedit dced40avlcd;
        private AxDCIMAGELib.AxDcimage dcim40avlamt;
        private AxDCEDITLib.AxDcedit dced40avlamt;
        private AxDCIMAGELib.AxDcimage dcim40bvlcd;
        private AxDCEDITLib.AxDcedit dced40bvlcd;
        private AxDCIMAGELib.AxDcimage dcim40bvlamt;
        private AxDCEDITLib.AxDcedit dced40bvlamt;
        private AxDCIMAGELib.AxDcimage dcim40cvlcd;
        private AxDCEDITLib.AxDcedit dced40cvlcd;
        private AxDCIMAGELib.AxDcimage dcim40cvlamt;
        private AxDCEDITLib.AxDcedit dced40cvlamt;
        private AxDCIMAGELib.AxDcimage dcim40dvlcd;
        private AxDCEDITLib.AxDcedit dced40dvlcd;
        private AxDCIMAGELib.AxDcimage dcim40dvlamt;
        private AxDCEDITLib.AxDcedit dced40dvlamt;
        private AxDCIMAGELib.AxDcimage dcim41avlcd;
        private AxDCEDITLib.AxDcedit dced41avlcd;
        private AxDCIMAGELib.AxDcimage dcim41avlamt;
        private AxDCEDITLib.AxDcedit dced41avlamt;
        private System.Windows.Forms.Label lbl41bvlcd;
        private AxDCIMAGELib.AxDcimage dcim41bvlcd;
        private AxDCEDITLib.AxDcedit dced41bvlcd;
        private AxDCIMAGELib.AxDcimage dcim41bvlamt;
        private AxDCEDITLib.AxDcedit dced41bvlamt;
        private AxDCIMAGELib.AxDcimage dcim41cvlcd;
        private AxDCEDITLib.AxDcedit dced41cvlcd;
        private AxDCIMAGELib.AxDcimage dcim41cvlamt;
        private AxDCEDITLib.AxDcedit dced41cvlamt;
        private AxDCIMAGELib.AxDcimage dcim41dvlcd;
        private AxDCEDITLib.AxDcedit dced41dvlcd;
        private AxDCIMAGELib.AxDcimage dcim41dvlamt;
        private AxDCEDITLib.AxDcedit dced41dvlamt;
        private System.Windows.Forms.Label lbl1fcynmad;
        private System.Windows.Forms.Label lbl1provadd;
        private System.Windows.Forms.Label lbl1provcit;
        private System.Windows.Forms.Label lbl1provsta;
        private AxDCEDITLib.AxDcedit dced1provzip;
        private System.Windows.Forms.Label lbl1provzip;
        private System.Windows.Forms.Label lbl8plname;
        private System.Windows.Forms.Label lbl8pfname;
        private System.Windows.Forms.Label lbl8pminit;
        private System.Windows.Forms.Label lbl9paddstr;
        private System.Windows.Forms.Label lbl9paddcty;
        private System.Windows.Forms.Label lbl9paddsta;
        private System.Windows.Forms.Label lbl9paddzip;
        private System.Windows.Forms.Label lbl9paddccd;
        private System.Windows.Forms.PictureBox picbx1;
        private System.Windows.Forms.PictureBox picbx8;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnDelpbLINEITEM;
        private System.Windows.Forms.Button btnInsAfterpbLINEITEM;
        private System.Windows.Forms.Button btnInsBeforepbLINEITEM;
        private AxDCIMAGELib.AxDcimage dcim50apayer;
        private AxDCEDITLib.AxDcedit dced50apayer;
        private AxDCIMAGELib.AxDcimage dcim50bpayer;
        private AxDCEDITLib.AxDcedit dced50bpayer;
        private System.Windows.Forms.Label lbl50cpayer;
        private AxDCIMAGELib.AxDcimage dcim50cpayer;
        private AxDCEDITLib.AxDcedit dced50cpayer;
        private AxDCIMAGELib.AxDcimage dcim51aprvno;
        private AxDCEDITLib.AxDcedit dced51aprvno;
        private AxDCIMAGELib.AxDcimage dcim51bprvno;
        private AxDCEDITLib.AxDcedit dced51bprvno;
        private System.Windows.Forms.Label lbl51cprvno;
        private AxDCIMAGELib.AxDcimage dcim51cprvno;
        private AxDCEDITLib.AxDcedit dced51cprvno;
        private System.Windows.Forms.Label lbl56npi;
        private AxDCIMAGELib.AxDcimage dcim56npi;
        private AxDCEDITLib.AxDcedit dced56npi;
        private AxDCIMAGELib.AxDcimage dcim58ainsnm;
        private System.Windows.Forms.Label lbl58alname;
        private AxDCEDITLib.AxDcedit dced58alname;
        private System.Windows.Forms.Label lbl58afname;
        private AxDCEDITLib.AxDcedit dced58afname;
        private System.Windows.Forms.Label lbl58aminit;
        private AxDCEDITLib.AxDcedit dced58aminit;
        private System.Windows.Forms.Label lbl58binsnm;
        private AxDCIMAGELib.AxDcimage dcim58binsnm;
        private System.Windows.Forms.Label lbl58blname;
        private AxDCEDITLib.AxDcedit dced58blname;
        private System.Windows.Forms.Label lbl58bfname;
        private AxDCEDITLib.AxDcedit dced58bfname;
        private System.Windows.Forms.Label lbl58bminit;
        private AxDCEDITLib.AxDcedit dced58bminit;
        private AxDCIMAGELib.AxDcimage dcim58cinsnm;
        private System.Windows.Forms.Label lbl58clname;
        private AxDCEDITLib.AxDcedit dced58clname;
        private AxDCEDITLib.AxDcedit dced58cfname;
        private AxDCEDITLib.AxDcedit dced58cminit;
        private AxDCIMAGELib.AxDcimage dcim60acshi;
        private AxDCEDITLib.AxDcedit dced60acshi;
        private AxDCIMAGELib.AxDcimage dcim60bcshi;
        private AxDCEDITLib.AxDcedit dced60bcshi;
        private System.Windows.Forms.Label lbl60ccshi;
        private AxDCIMAGELib.AxDcimage dcim60ccshi;
        private AxDCEDITLib.AxDcedit dced60ccshi;
        private AxDCIMAGELib.AxDcimage dcim66dxverq;
        private AxDCEDITLib.AxDcedit dced66dxverq;
        private System.Windows.Forms.Label lbl67prdgcd;
        private AxDCIMAGELib.AxDcimage dcim67prdgcd;
        private AxDCEDITLib.AxDcedit dced67prdgcd;
        private System.Windows.Forms.Label lbl67aothdg;
        private AxDCIMAGELib.AxDcimage dcim67aothdg;
        private AxDCEDITLib.AxDcedit dced67aothdg;
        private System.Windows.Forms.Label lbl67bothdg;
        private AxDCIMAGELib.AxDcimage dcim67bothdg;
        private AxDCEDITLib.AxDcedit dced67bothdg;
        private System.Windows.Forms.Label lbl67cothdg;
        private AxDCIMAGELib.AxDcimage dcim67cothdg;
        private AxDCEDITLib.AxDcedit dced67cothdg;
        private System.Windows.Forms.Label lbl67dothdg;
        private AxDCIMAGELib.AxDcimage dcim67dothdg;
        private AxDCEDITLib.AxDcedit dced67dothdg;
        private System.Windows.Forms.Label lbl67eothdg;
        private AxDCIMAGELib.AxDcimage dcim67eothdg;
        private AxDCEDITLib.AxDcedit dced67eothdg;
        private System.Windows.Forms.Label lbl67fothdg;
        private AxDCIMAGELib.AxDcimage dcim67fothdg;
        private AxDCEDITLib.AxDcedit dced67fothdg;
        private System.Windows.Forms.Label lbl67gothdg;
        private AxDCIMAGELib.AxDcimage dcim67gothdg;
        private AxDCEDITLib.AxDcedit dced67gothdg;
        private System.Windows.Forms.Label lbl67hothdg;
        private AxDCIMAGELib.AxDcimage dcim67hothdg;
        private AxDCEDITLib.AxDcedit dced67hothdg;
        private System.Windows.Forms.Label lbl67iothdg;
        private AxDCIMAGELib.AxDcimage dcim67iothdg;
        private AxDCEDITLib.AxDcedit dced67iothdg;
        private System.Windows.Forms.Label lbl67jothdg;
        private AxDCIMAGELib.AxDcimage dcim67jothdg;
        private AxDCEDITLib.AxDcedit dced67jothdg;
        private System.Windows.Forms.Label lbl67kothdg;
        private AxDCIMAGELib.AxDcimage dcim67kothdg;
        private AxDCEDITLib.AxDcedit dced67kothdg;
        private System.Windows.Forms.Label lbl67lothdg;
        private AxDCIMAGELib.AxDcimage dcim67lothdg;
        private AxDCEDITLib.AxDcedit dced67lothdg;
        private System.Windows.Forms.Label lbl67mothdg;
        private AxDCIMAGELib.AxDcimage dcim67mothdg;
        private AxDCEDITLib.AxDcedit dced67mothdg;
        private System.Windows.Forms.Label lbl67nothdg;
        private AxDCIMAGELib.AxDcimage dcim67nothdg;
        private AxDCEDITLib.AxDcedit dced67nothdg;
        private System.Windows.Forms.Label lbl67oothdg;
        private AxDCIMAGELib.AxDcimage dcim67oothdg;
        private AxDCEDITLib.AxDcedit dced67oothdg;
        private System.Windows.Forms.Label lbl67pothdg;
        private AxDCIMAGELib.AxDcimage dcim67pothdg;
        private AxDCEDITLib.AxDcedit dced67pothdg;
        private System.Windows.Forms.Label lbl67qothdg;
        private AxDCIMAGELib.AxDcimage dcim67qothdg;
        private AxDCEDITLib.AxDcedit dced67qothdg;
        private AxDCIMAGELib.AxDcimage dcim69amdgcd;
        private AxDCEDITLib.AxDcedit dced69amdgcd;
        private AxDCIMAGELib.AxDcimage dcim70arfvcd;
        private AxDCEDITLib.AxDcedit dced70arfvcd;
        private AxDCIMAGELib.AxDcimage dcim70brfvcd;
        private AxDCEDITLib.AxDcedit dced70brfvcd;
        private AxDCIMAGELib.AxDcimage dcim70crfvcd;
        private AxDCEDITLib.AxDcedit dced70crfvcd;
        private AxDCIMAGELib.AxDcimage dcim71ppscd;
        private AxDCEDITLib.AxDcedit dced71ppscd;
        private System.Windows.Forms.Label lbl72aecicd;
        private AxDCIMAGELib.AxDcimage dcim72aecicd;
        private AxDCEDITLib.AxDcedit dced72aecicd;
        private System.Windows.Forms.Label lbl23TotChgs;
        private AxDCIMAGELib.AxDcimage dcim23TotChgs;
        private AxDCEDITLib.AxDcedit dced23TotChgs;
        private System.Windows.Forms.Panel panLINEITEM;
        private AxDCIMAGELib.AxDcimage dcimRevCode;
        private AxDCEDITLib.AxDcedit dcedRevCode;
        private AxDCIMAGELib.AxDcimage dcimDescription;
        private AxDCEDITLib.AxDcedit dcedDescription;
        private AxDCIMAGELib.AxDcimage dcimHCPCS;
        private AxDCEDITLib.AxDcedit dcedHCPCS;
        private AxDCIMAGELib.AxDcimage dcimServiceDate;
        private AxDCEDITLib.AxDcedit dcedServiceDate;
        private AxDCIMAGELib.AxDcimage dcimUnits;
        private AxDCEDITLib.AxDcedit dcedUnits;
        private AxDCIMAGELib.AxDcimage dcimCharges;
        private AxDCEDITLib.AxDcedit dcedCharges;
        private AxDCIMAGELib.AxDcimage dcimNonCovered;
        private AxDCEDITLib.AxDcedit dcedNonCovered;
        private AxDCIMAGELib.AxDcimage dcimNDC;
        private AxDCEDITLib.AxDcedit dcedNDC;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lbl74prprcd;
        private AxDCIMAGELib.AxDcimage dcim74prprcd;
        private AxDCEDITLib.AxDcedit dced74prprcd;
        private AxDCIMAGELib.AxDcimage dcim74prprdt;
        private AxDCEDITLib.AxDcedit dced74prprdt;
        private System.Windows.Forms.Label lbl74aoprcd;
        private AxDCIMAGELib.AxDcimage dcim74aoprcd;
        private AxDCEDITLib.AxDcedit dced74aoprcd;
        private AxDCIMAGELib.AxDcimage dcim74aoprdt;
        private AxDCEDITLib.AxDcedit dced74aoprdt;
        private AxDCIMAGELib.AxDcimage dcim74boprcd;
        private AxDCEDITLib.AxDcedit dced74boprcd;
        private System.Windows.Forms.Label lbl74boprdt;
        private AxDCIMAGELib.AxDcimage dcim74boprdt;
        private AxDCEDITLib.AxDcedit dced74boprdt;
        private System.Windows.Forms.Label lbl74coprcd;
        private AxDCIMAGELib.AxDcimage dcim74coprcd;
        private AxDCEDITLib.AxDcedit dced74coprcd;
        private AxDCIMAGELib.AxDcimage dcim74coprdt;
        private AxDCEDITLib.AxDcedit dced74coprdt;
        private System.Windows.Forms.Label lbl74doprcd;
        private AxDCIMAGELib.AxDcimage dcim74doprcd;
        private AxDCEDITLib.AxDcedit dced74doprcd;
        private AxDCIMAGELib.AxDcimage dcim74doprdt;
        private AxDCEDITLib.AxDcedit dced74doprdt;
        private System.Windows.Forms.Label lbl74eoprcd;
        private AxDCIMAGELib.AxDcimage dcim74eoprcd;
        private AxDCEDITLib.AxDcedit dced74eoprcd;
        private System.Windows.Forms.Label lbl74eoprdt;
        private AxDCIMAGELib.AxDcimage dcim74eoprdt;
        private AxDCEDITLib.AxDcedit dced74eoprdt;
        private System.Windows.Forms.Label lbl76apnpi;
        private AxDCIMAGELib.AxDcimage dcim76apnpi;
        private AxDCEDITLib.AxDcedit dced76apnpi;
        private System.Windows.Forms.Label lbl76apqual;
        private AxDCIMAGELib.AxDcimage dcim76apqual;
        private AxDCEDITLib.AxDcedit dced76apqual;
        private System.Windows.Forms.Label lbl76apid;
        private AxDCIMAGELib.AxDcimage dcim76apid;
        private AxDCEDITLib.AxDcedit dced76apid;
        private System.Windows.Forms.Label lbl76aplnm;
        private AxDCIMAGELib.AxDcimage dcim76aplnm;
        private AxDCEDITLib.AxDcedit dced76aplnm;
        private System.Windows.Forms.Label lbl76apfnm;
        private AxDCIMAGELib.AxDcimage dcim76apfnm;
        private AxDCEDITLib.AxDcedit dced76apfnm;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private AxDCIMAGELib.AxDcimage dcimNDCType;
        private AxDCEDITLib.AxDcedit dcedNDCType;
        private AxDCIMAGELib.AxDcimage dcimNDCQty;
        private AxDCEDITLib.AxDcedit dcedNDCQty;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label10;
        private AxDCIMAGELib.AxDcimage dcim33aocrcd;
        private AxDCEDITLib.AxDcedit dced33aocrcd;
        private AxDCIMAGELib.AxDcimage dcim33aocrdt;
        private AxDCEDITLib.AxDcedit dced33aocrdt;
        private AxDCIMAGELib.AxDcimage dcim33bocrcd;
        private AxDCEDITLib.AxDcedit dced33bocrcd;
        private AxDCIMAGELib.AxDcimage dcim33bocrdt;
        private AxDCEDITLib.AxDcedit dced33bocrdt;
        private System.Windows.Forms.Label label17;
        private AxDCIMAGELib.AxDcimage dcim34aocrcd;
        private AxDCEDITLib.AxDcedit dced34aocrcd;
        private AxDCIMAGELib.AxDcimage dcim34aocrdt;
        private AxDCEDITLib.AxDcedit dced34aocrdt;
        private AxDCIMAGELib.AxDcimage dcim34bocrcd;
        private AxDCEDITLib.AxDcedit dced34bocrcd;
        private AxDCIMAGELib.AxDcimage dcim34bocrdt;
        private AxDCEDITLib.AxDcedit dced34bocrdt;
        private System.Windows.Forms.Label label18;
        private AxDCIMAGELib.AxDcimage dcim35aospcd;
        private AxDCEDITLib.AxDcedit dced35aospcd;
        private AxDCIMAGELib.AxDcimage dcim35aospfr;
        private AxDCEDITLib.AxDcedit dced35aospfr;
        private AxDCIMAGELib.AxDcimage dcim35aospth;
        private AxDCEDITLib.AxDcedit dced35aospth;
        private AxDCIMAGELib.AxDcimage dcim35bospcd;
        private AxDCEDITLib.AxDcedit dced35bospcd;
        private AxDCIMAGELib.AxDcimage dcim35bospfr;
        private AxDCEDITLib.AxDcedit dced35bospfr;
        private AxDCIMAGELib.AxDcimage dcim35bospth;
        private AxDCEDITLib.AxDcedit dced35bospth;
        private AxDCIMAGELib.AxDcimage dcim2payto;
        private System.Windows.Forms.Label label19;
        private AxDCEDITLib.AxDcedit dced2paytnm;
        private AxDCEDITLib.AxDcedit dced2paytadd;
        private AxDCEDITLib.AxDcedit dced2paytcty;
        private AxDCEDITLib.AxDcedit dced2paytst;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private AxDCEDITLib.AxDcedit dced2paytzip;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Label label25;
        private AxDCIMAGELib.AxDcimage dcim18concd;
        private AxDCEDITLib.AxDcedit dced18concd;
        private System.Windows.Forms.PictureBox pictureBox7;
        private AxDCIMAGELib.AxDcimage axDcimage1;
        private AxDCEDITLib.AxDcedit axDcedit1;
        private System.Windows.Forms.Label label28;
        private AxDCIMAGELib.AxDcimage dcim20concd;
        private AxDCEDITLib.AxDcedit dced20concd;
        private System.Windows.Forms.Label label26;
        private AxDCIMAGELib.AxDcimage dcim19concd;
        private AxDCEDITLib.AxDcedit dced19concd;
        private System.Windows.Forms.Label label29;
        private AxDCIMAGELib.AxDcimage dcim21concd;
        private AxDCEDITLib.AxDcedit dced21concd;
        private System.Windows.Forms.Label label30;
        private AxDCIMAGELib.AxDcimage dcim23concd;
        private AxDCEDITLib.AxDcedit dced23concd;
        private System.Windows.Forms.Label label31;
        private AxDCIMAGELib.AxDcimage dcim24concd;
        private AxDCEDITLib.AxDcedit dced24concd;
        private System.Windows.Forms.Label label32;
        private AxDCIMAGELib.AxDcimage dcim25concd;
        private AxDCEDITLib.AxDcedit dced25concd;
        private System.Windows.Forms.Label label33;
        private AxDCIMAGELib.AxDcimage dcim26concd;
        private AxDCEDITLib.AxDcedit dced26concd;
        private System.Windows.Forms.Label label34;
        private AxDCIMAGELib.AxDcimage dcim22concd;
        private AxDCEDITLib.AxDcedit dced22concd;
        private System.Windows.Forms.Label label35;
        private AxDCIMAGELib.AxDcimage dcim27concd;
        private AxDCEDITLib.AxDcedit dced27concd;
        private System.Windows.Forms.Label label27;
        private AxDCIMAGELib.AxDcimage dcim28concd;
        private AxDCEDITLib.AxDcedit dced28concd;
        private AxDCEDITLib.AxDcedit dced2paytid;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private AxDCEDITLib.AxDcedit dced67POA;
        private AxDCIMAGELib.AxDcimage dcim67bPOA;
        private AxDCEDITLib.AxDcedit dced67bPOA;
        private AxDCIMAGELib.AxDcimage dcim67dPOA;
        private AxDCEDITLib.AxDcedit dced67dPOA;
        private AxDCIMAGELib.AxDcimage dcim67ePOA;
        private AxDCEDITLib.AxDcedit dced67ePOA;
        private AxDCIMAGELib.AxDcimage dcim67fPOA;
        private AxDCEDITLib.AxDcedit dced67fPOA;
        private AxDCIMAGELib.AxDcimage axDcimage6;
        private AxDCEDITLib.AxDcedit axDcedit8;
        private AxDCIMAGELib.AxDcimage dcim67hPOA;
        private AxDCEDITLib.AxDcedit dced67hPOA;
        private AxDCIMAGELib.AxDcimage dcim67gPOA;
        private AxDCEDITLib.AxDcedit dced67gPOA;
        private AxDCIMAGELib.AxDcimage dcim67cPOA;
        private AxDCEDITLib.AxDcedit dced67cPOA;
        private AxDCIMAGELib.AxDcimage axDcimage10;
        private AxDCEDITLib.AxDcedit axDcedit12;
        private AxDCIMAGELib.AxDcimage axDcimage11;
        private AxDCEDITLib.AxDcedit axDcedit13;
        private AxDCIMAGELib.AxDcimage axDcimage12;
        private AxDCEDITLib.AxDcedit axDcedit14;
        private AxDCIMAGELib.AxDcimage axDcimage13;
        private AxDCEDITLib.AxDcedit axDcedit15;
        private AxDCIMAGELib.AxDcimage axDcimage14;
        private AxDCEDITLib.AxDcedit axDcedit16;
        private AxDCIMAGELib.AxDcimage axDcimage15;
        private AxDCEDITLib.AxDcedit axDcedit17;
        private AxDCIMAGELib.AxDcimage axDcimage16;
        private AxDCEDITLib.AxDcedit axDcedit18;
        private AxDCEDITLib.AxDcedit dced67aPOA;
        private AxDCIMAGELib.AxDcimage dcim67aPOA;
        private AxDCIMAGELib.AxDcimage dcim67POA;
        private AxDCIMAGELib.AxDcimage axDcimage2;
        private AxDCEDITLib.AxDcedit axDcedit2;
        private System.Windows.Forms.Label label46;
        private AxDCIMAGELib.AxDcimage dcim72becicd;
        private AxDCEDITLib.AxDcedit dced72becicd;
        private AxDCIMAGELib.AxDcimage dcim72aPOA;
        private AxDCEDITLib.AxDcedit dced72aPOA;
        private AxDCIMAGELib.AxDcimage dcim72bPOA;
        private AxDCEDITLib.AxDcedit dced72bPOA;
        private AxDCIMAGELib.AxDcimage dcim72cPOA;
        private AxDCEDITLib.AxDcedit dced72cPOA;
        private System.Windows.Forms.Label label47;
        private AxDCIMAGELib.AxDcimage dcim72cecicd;
        private AxDCEDITLib.AxDcedit dced72cecicd;
        private AxDCIMAGELib.AxDcimage dcim55aetamt;
        private AxDCEDITLib.AxDcedit dced55aetamt;
        private AxDCIMAGELib.AxDcimage dcim55betamt;
        private AxDCEDITLib.AxDcedit dced55betamt;
        private System.Windows.Forms.Label label48;
        private AxDCIMAGELib.AxDcimage dcim55cetamt;
        private AxDCEDITLib.AxDcedit dced55cetamt;
        private AxDCIMAGELib.AxDcimage dcim54aprpay;
        private AxDCEDITLib.AxDcedit dced54aprpay;
        private AxDCIMAGELib.AxDcimage dcim54bprpay;
        private AxDCEDITLib.AxDcedit dced54bprpay;
        private System.Windows.Forms.Label label49;
        private AxDCIMAGELib.AxDcimage dcim54cprpay;
        private AxDCEDITLib.AxDcedit dced54cprpay;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private AxDCIMAGELib.AxDcimage dcim77opnpi;
        private AxDCEDITLib.AxDcedit dced77opnpi;
        private System.Windows.Forms.Label label55;
        private AxDCIMAGELib.AxDcimage dcim77opqual;
        private AxDCEDITLib.AxDcedit dced77opqual;
        private System.Windows.Forms.Label label56;
        private AxDCIMAGELib.AxDcimage dcim77opid;
        private AxDCEDITLib.AxDcedit dced77opid;
        private System.Windows.Forms.Label label57;
        private AxDCIMAGELib.AxDcimage dcim77oplnm;
        private AxDCEDITLib.AxDcedit dced77oplnm;
        private System.Windows.Forms.Label label58;
        private AxDCIMAGELib.AxDcimage dcim77opfnm;
        private AxDCEDITLib.AxDcedit dced77opfnm;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label60;
        private AxDCIMAGELib.AxDcimage dcimotnpi;
        private AxDCEDITLib.AxDcedit dced78otnpi;
        private System.Windows.Forms.Label label61;
        private AxDCIMAGELib.AxDcimage dcim78otql2;
        private AxDCEDITLib.AxDcedit dcedotql2;
        private System.Windows.Forms.Label label62;
        private AxDCIMAGELib.AxDcimage dcim78otid;
        private AxDCEDITLib.AxDcedit dced78otid;
        private System.Windows.Forms.Label label63;
        private AxDCIMAGELib.AxDcimage dcimotlnm;
        private AxDCEDITLib.AxDcedit dced78otlnm;
        private System.Windows.Forms.Label label64;
        private AxDCIMAGELib.AxDcimage dcim78otfnm;
        private AxDCEDITLib.AxDcedit dced78otfnm;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.Label label65;
        private AxDCIMAGELib.AxDcimage dcim78otql1;
        private AxDCEDITLib.AxDcedit dced78otql1;
        private System.Windows.Forms.Label label66;
        private AxDCIMAGELib.AxDcimage dcim79otql1;
        private AxDCEDITLib.AxDcedit dced79otql1;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label68;
        private AxDCIMAGELib.AxDcimage dcim79otnpi;
        private AxDCEDITLib.AxDcedit dced79otnpi;
        private System.Windows.Forms.Label label69;
        private AxDCIMAGELib.AxDcimage dcim79otql2;
        private AxDCEDITLib.AxDcedit dced79otql2;
        private System.Windows.Forms.Label label70;
        private AxDCIMAGELib.AxDcimage dcim79otid;
        private AxDCEDITLib.AxDcedit dced79otid;
        private System.Windows.Forms.Label label71;
        private AxDCIMAGELib.AxDcimage dcim79otlnm;
        private AxDCEDITLib.AxDcedit dced79otlnm;
        private System.Windows.Forms.Label label72;
        private AxDCIMAGELib.AxDcimage dcim79otfnm;
        private AxDCEDITLib.AxDcedit dced79otfnm;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.Label label73;
        private AxDCIMAGELib.AxDcimage dcim57copidt;
        private AxDCEDITLib.AxDcedit dced57copidt;
        private System.Windows.Forms.Label label74;
        private AxDCIMAGELib.AxDcimage dcim57aopidp;
        private AxDCEDITLib.AxDcedit dced57aopidp;
        private System.Windows.Forms.Label label75;
        private AxDCIMAGELib.AxDcimage dcim57bopids;
        private AxDCEDITLib.AxDcedit dced57bopids;
        private AxDCIMAGELib.AxDcimage dcim80aremrk;
        private AxDCEDITLib.AxDcedit dced80aremrk;
        private AxDCIMAGELib.AxDcimage dcim80bremrk;
        private AxDCEDITLib.AxDcedit dced80bremrk;
        private AxDCIMAGELib.AxDcimage dcim80cremrk;
        private AxDCEDITLib.AxDcedit dced80cremrk;
        private AxDCIMAGELib.AxDcimage dcim80dremrk;
        private AxDCEDITLib.AxDcedit dced80dremrk;
        private System.Windows.Forms.Label label76;



    }
}
                