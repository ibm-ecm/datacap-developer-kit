﻿namespace MedicalClaimsPanels
{
    partial class MCFixup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnFinish = new System.Windows.Forms.Button();
            this.btnRemove = new System.Windows.Forms.Button();
            this.btnMoveDn = new System.Windows.Forms.Button();
            this.btnMoveUp = new System.Windows.Forms.Button();
            this.isisToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.textFixupMsg = new System.Windows.Forms.TextBox();
            this.btnSplit = new System.Windows.Forms.Button();
            this.btnJoin = new System.Windows.Forms.Button();
            this.cbxMarkList = new System.Windows.Forms.ComboBox();
            this.listPageClass = new System.Windows.Forms.ComboBox();
            this.btnNextProb = new System.Windows.Forms.Button();
            this.listPageType = new System.Windows.Forms.ComboBox();
            this.listPageStatus = new System.Windows.Forms.ComboBox();
            this.lblClass = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblPageType = new System.Windows.Forms.Label();
            this.lblComment = new System.Windows.Forms.Label();
            this.btnMakeClaim = new System.Windows.Forms.Button();
            this.btnMakeAttachment = new System.Windows.Forms.Button();
            this.btnRotateLeft = new System.Windows.Forms.Button();
            this.btnRotateRight = new System.Windows.Forms.Button();
            this.btnFlip = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnCancel
            // 
            this.btnCancel.Font = new System.Drawing.Font("Tahoma", 10F);
            this.btnCancel.Location = new System.Drawing.Point(257, 358);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(119, 31);
            this.btnCancel.TabIndex = 31;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnFinish
            // 
            this.btnFinish.Font = new System.Drawing.Font("Tahoma", 10F);
            this.btnFinish.Location = new System.Drawing.Point(96, 358);
            this.btnFinish.Name = "btnFinish";
            this.btnFinish.Size = new System.Drawing.Size(119, 31);
            this.btnFinish.TabIndex = 32;
            this.btnFinish.Text = "OK";
            this.btnFinish.UseVisualStyleBackColor = true;
            this.btnFinish.Click += new System.EventHandler(this.btnFinish_Click);
            // 
            // btnRemove
            // 
            this.btnRemove.Font = new System.Drawing.Font("Tahoma", 10F);
            this.btnRemove.Location = new System.Drawing.Point(341, 140);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(135, 28);
            this.btnRemove.TabIndex = 34;
            this.btnRemove.Text = "Remove";
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // btnMoveDn
            // 
            this.btnMoveDn.Font = new System.Drawing.Font("Tahoma", 10F);
            this.btnMoveDn.Location = new System.Drawing.Point(341, 204);
            this.btnMoveDn.Name = "btnMoveDn";
            this.btnMoveDn.Size = new System.Drawing.Size(135, 28);
            this.btnMoveDn.TabIndex = 35;
            this.btnMoveDn.Text = "Move Down";
            this.btnMoveDn.UseVisualStyleBackColor = true;
            this.btnMoveDn.Click += new System.EventHandler(this.btnMoveDn_Click);
            // 
            // btnMoveUp
            // 
            this.btnMoveUp.Font = new System.Drawing.Font("Tahoma", 10F);
            this.btnMoveUp.Location = new System.Drawing.Point(341, 172);
            this.btnMoveUp.Name = "btnMoveUp";
            this.btnMoveUp.Size = new System.Drawing.Size(135, 28);
            this.btnMoveUp.TabIndex = 36;
            this.btnMoveUp.Text = "Move Up";
            this.btnMoveUp.UseVisualStyleBackColor = true;
            this.btnMoveUp.Click += new System.EventHandler(this.btnMoveUp_Click);
            // 
            // textFixupMsg
            // 
            this.textFixupMsg.Enabled = false;
            this.textFixupMsg.Font = new System.Drawing.Font("Tahoma", 10F);
            this.textFixupMsg.Location = new System.Drawing.Point(27, 178);
            this.textFixupMsg.Multiline = true;
            this.textFixupMsg.Name = "textFixupMsg";
            this.textFixupMsg.Size = new System.Drawing.Size(280, 79);
            this.textFixupMsg.TabIndex = 39;
            this.isisToolTip.SetToolTip(this.textFixupMsg, "Comment marker associated with this page or document");
            // 
            // btnSplit
            // 
            this.btnSplit.Font = new System.Drawing.Font("Tahoma", 10F);
            this.btnSplit.Location = new System.Drawing.Point(341, 268);
            this.btnSplit.Name = "btnSplit";
            this.btnSplit.Size = new System.Drawing.Size(135, 28);
            this.btnSplit.TabIndex = 9;
            this.btnSplit.Text = "Split";
            this.btnSplit.UseVisualStyleBackColor = true;
            this.btnSplit.Click += new System.EventHandler(this.btnSplit_Click);
            // 
            // btnJoin
            // 
            this.btnJoin.Font = new System.Drawing.Font("Tahoma", 10F);
            this.btnJoin.Location = new System.Drawing.Point(341, 236);
            this.btnJoin.Name = "btnJoin";
            this.btnJoin.Size = new System.Drawing.Size(135, 28);
            this.btnJoin.TabIndex = 10;
            this.btnJoin.Text = "Join";
            this.btnJoin.Click += new System.EventHandler(this.btnJoin_Click);
            // 
            // cbxMarkList
            // 
            this.cbxMarkList.AllowDrop = true;
            this.cbxMarkList.CausesValidation = false;
            this.cbxMarkList.Font = new System.Drawing.Font("Tahoma", 10F);
            this.cbxMarkList.FormattingEnabled = true;
            this.cbxMarkList.Location = new System.Drawing.Point(31, 178);
            this.cbxMarkList.Name = "cbxMarkList";
            this.cbxMarkList.Size = new System.Drawing.Size(274, 24);
            this.cbxMarkList.TabIndex = 0;
            this.cbxMarkList.Visible = false;
            this.cbxMarkList.SelectedIndexChanged += new System.EventHandler(this.cbxMarkList_SelectedIndexChanged);
            this.cbxMarkList.TextChanged += new System.EventHandler(this.cbxMarkList_TextChanged);
            this.cbxMarkList.LostFocus += new System.EventHandler(this.cbxMarkList_LostFocus);
            // 
            // listPageClass
            // 
            this.listPageClass.AllowDrop = true;
            this.listPageClass.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.listPageClass.Font = new System.Drawing.Font("Tahoma", 10F);
            this.listPageClass.FormattingEnabled = true;
            this.listPageClass.Location = new System.Drawing.Point(29, 127);
            this.listPageClass.Name = "listPageClass";
            this.listPageClass.Size = new System.Drawing.Size(278, 24);
            this.listPageClass.Sorted = true;
            this.listPageClass.TabIndex = 15;
            this.listPageClass.SelectedIndexChanged += new System.EventHandler(this.listPageClass_SelectedIndexChanged);
            // 
            // btnNextProb
            // 
            this.btnNextProb.Font = new System.Drawing.Font("Tahoma", 10F);
            this.btnNextProb.Location = new System.Drawing.Point(29, 266);
            this.btnNextProb.Name = "btnNextProb";
            this.btnNextProb.Size = new System.Drawing.Size(104, 28);
            this.btnNextProb.TabIndex = 16;
            this.btnNextProb.Text = "Next LC";
            this.btnNextProb.UseVisualStyleBackColor = true;
            this.btnNextProb.Click += new System.EventHandler(this.btnNextProb_Click);
            // 
            // listPageType
            // 
            this.listPageType.AllowDrop = true;
            this.listPageType.CausesValidation = false;
            this.listPageType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.listPageType.Font = new System.Drawing.Font("Tahoma", 10F);
            this.listPageType.FormattingEnabled = true;
            this.listPageType.Location = new System.Drawing.Point(29, 33);
            this.listPageType.Name = "listPageType";
            this.listPageType.Size = new System.Drawing.Size(278, 24);
            this.listPageType.Sorted = true;
            this.listPageType.TabIndex = 17;
            this.listPageType.SelectedIndexChanged += new System.EventHandler(this.listPageType_SelectedIndexChanged);
            // 
            // listPageStatus
            // 
            this.listPageStatus.AllowDrop = true;
            this.listPageStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.listPageStatus.Font = new System.Drawing.Font("Tahoma", 10F);
            this.listPageStatus.FormattingEnabled = true;
            this.listPageStatus.Location = new System.Drawing.Point(29, 80);
            this.listPageStatus.Name = "listPageStatus";
            this.listPageStatus.Size = new System.Drawing.Size(278, 24);
            this.listPageStatus.Sorted = true;
            this.listPageStatus.TabIndex = 18;
            this.listPageStatus.SelectedIndexChanged += new System.EventHandler(this.listPageStatus_SelectedIndexChanged);
            // 
            // lblClass
            // 
            this.lblClass.Font = new System.Drawing.Font("Tahoma", 10F);
            this.lblClass.Location = new System.Drawing.Point(28, 107);
            this.lblClass.Name = "lblClass";
            this.lblClass.Size = new System.Drawing.Size(100, 17);
            this.lblClass.TabIndex = 12;
            this.lblClass.Text = "Class";
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Tahoma", 10F);
            this.label2.Location = new System.Drawing.Point(29, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 17);
            this.label2.TabIndex = 13;
            this.label2.Text = "Status";
            // 
            // lblPageType
            // 
            this.lblPageType.Font = new System.Drawing.Font("Tahoma", 10F);
            this.lblPageType.Location = new System.Drawing.Point(29, 12);
            this.lblPageType.Name = "lblPageType";
            this.lblPageType.Size = new System.Drawing.Size(39, 18);
            this.lblPageType.TabIndex = 14;
            this.lblPageType.Text = "Type";
            // 
            // lblComment
            // 
            this.lblComment.Font = new System.Drawing.Font("Tahoma", 10F);
            this.lblComment.Location = new System.Drawing.Point(29, 158);
            this.lblComment.Name = "lblComment";
            this.lblComment.Size = new System.Drawing.Size(100, 17);
            this.lblComment.TabIndex = 40;
            this.lblComment.Text = "Comment";
            // 
            // btnMakeClaim
            // 
            this.btnMakeClaim.Font = new System.Drawing.Font("Tahoma", 10F);
            this.btnMakeClaim.Location = new System.Drawing.Point(341, 29);
            this.btnMakeClaim.Name = "btnMakeClaim";
            this.btnMakeClaim.Size = new System.Drawing.Size(135, 28);
            this.btnMakeClaim.TabIndex = 41;
            this.btnMakeClaim.Text = "Make Claim";
            this.btnMakeClaim.UseVisualStyleBackColor = true;
            this.btnMakeClaim.Click += new System.EventHandler(this.btnMakeClaim_Click);
            // 
            // btnMakeAttachment
            // 
            this.btnMakeAttachment.Font = new System.Drawing.Font("Tahoma", 10F);
            this.btnMakeAttachment.Location = new System.Drawing.Point(341, 63);
            this.btnMakeAttachment.Name = "btnMakeAttachment";
            this.btnMakeAttachment.Size = new System.Drawing.Size(135, 28);
            this.btnMakeAttachment.TabIndex = 42;
            this.btnMakeAttachment.Text = "Make Attachment";
            this.btnMakeAttachment.UseVisualStyleBackColor = true;
            this.btnMakeAttachment.Click += new System.EventHandler(this.btnMakeAttachment_Click);
            // 
            // btnRotateLeft
            // 
            this.btnRotateLeft.BackgroundImage = global::MedicalClaimsPanels.Properties.Resources.rotate_ccw;
            this.btnRotateLeft.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnRotateLeft.Location = new System.Drawing.Point(186, 268);
            this.btnRotateLeft.Name = "btnRotateLeft";
            this.btnRotateLeft.Size = new System.Drawing.Size(36, 35);
            this.btnRotateLeft.TabIndex = 45;
            this.btnRotateLeft.Click += new System.EventHandler(this.btnRotateLeft_Click);
            // 
            // btnRotateRight
            // 
            this.btnRotateRight.Image = global::MedicalClaimsPanels.Properties.Resources.rotate_cw;
            this.btnRotateRight.Location = new System.Drawing.Point(228, 268);
            this.btnRotateRight.Name = "btnRotateRight";
            this.btnRotateRight.Size = new System.Drawing.Size(36, 35);
            this.btnRotateRight.TabIndex = 44;
            this.btnRotateRight.Click += new System.EventHandler(this.btnRotateRight_Click);
            // 
            // btnFlip
            // 
            this.btnFlip.Image = global::MedicalClaimsPanels.Properties.Resources.rotate_180;
            this.btnFlip.Location = new System.Drawing.Point(270, 268);
            this.btnFlip.Name = "btnFlip";
            this.btnFlip.Size = new System.Drawing.Size(37, 35);
            this.btnFlip.TabIndex = 43;
            this.btnFlip.Click += new System.EventHandler(this.btnFlip_Click);
            // 
            // MCFixup
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(500, 389);
            this.Controls.Add(this.btnMakeAttachment);
            this.Controls.Add(this.btnMakeClaim);
            this.Controls.Add(this.lblComment);
            this.Controls.Add(this.cbxMarkList);
            this.Controls.Add(this.btnFlip);
            this.Controls.Add(this.btnRotateRight);
            this.Controls.Add(this.btnRotateLeft);
            this.Controls.Add(this.btnSplit);
            this.Controls.Add(this.btnJoin);
            this.Controls.Add(this.lblClass);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblPageType);
            this.Controls.Add(this.listPageClass);
            this.Controls.Add(this.btnNextProb);
            this.Controls.Add(this.listPageType);
            this.Controls.Add(this.listPageStatus);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnFinish);
            this.Controls.Add(this.btnRemove);
            this.Controls.Add(this.btnMoveDn);
            this.Controls.Add(this.btnMoveUp);
            this.Controls.Add(this.textFixupMsg);
            this.Name = "MCFixup";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnFinish;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.Button btnMoveDn;
        private System.Windows.Forms.Button btnMoveUp;
        private System.Windows.Forms.ToolTip isisToolTip;
        private System.Windows.Forms.Button btnSplit;
        private System.Windows.Forms.Button btnJoin;
        private System.Windows.Forms.Label lblClass;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblPageType;
        private System.Windows.Forms.ComboBox listPageClass;
        private System.Windows.Forms.Button btnNextProb;
        private System.Windows.Forms.ComboBox listPageType;
        private System.Windows.Forms.ComboBox listPageStatus;
        private System.Windows.Forms.ComboBox cbxMarkList;
        private System.Windows.Forms.TextBox textFixupMsg;
        private System.Windows.Forms.Label lblComment;
        private System.Windows.Forms.Button btnMakeClaim;
        private System.Windows.Forms.Button btnMakeAttachment;
        private System.Windows.Forms.Button btnRotateLeft;
        private System.Windows.Forms.Button btnRotateRight;
        private System.Windows.Forms.Button btnFlip;
#if NOTDEF
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBox1;
#endif
    }
}
