
namespace MedicalClaimsPanels
{
    partial class PClaim
    {
        /// 
        /// Required designer variable.
        /// 
        private System.ComponentModel.IContainer components = null;

        /// 
        /// Clean up any resources being used.
        /// 
        /// true if managed resources should be disposed; otherwise, false.
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// 
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PClaim));
            this.dced5PAddStr = new AxDCEDITLib.AxDcedit();
            this.dced5PAddCty = new AxDCEDITLib.AxDcedit();
            this.dcim5PAddSta = new AxDCIMAGELib.AxDcimage();
            this.dced5PAddSta = new AxDCEDITLib.AxDcedit();
            this.dcim5PAddZip = new AxDCIMAGELib.AxDcimage();
            this.dced5PAddZip = new AxDCEDITLib.AxDcedit();
            this.lbl3Pat_DOB = new System.Windows.Forms.Label();
            this.dcim3Pat_DOB = new AxDCIMAGELib.AxDcimage();
            this.dced3Pat_DOB = new AxDCEDITLib.AxDcedit();
            this.lbl3aPatSex = new System.Windows.Forms.Label();
            this.dcim3aPatSex = new AxDCIMAGELib.AxDcimage();
            this.cmb3aPatSex = new System.Windows.Forms.ComboBox();
            this.lbl1aInsrID = new System.Windows.Forms.Label();
            this.dcim1aInsrID = new AxDCIMAGELib.AxDcimage();
            this.dced1aInsrID = new AxDCEDITLib.AxDcedit();
            this.lbl7IAddStr = new System.Windows.Forms.Label();
            this.dced7IAddStr = new AxDCEDITLib.AxDcedit();
            this.lbl7IAddCty = new System.Windows.Forms.Label();
            this.dced7IAddCty = new AxDCEDITLib.AxDcedit();
            this.dced7IAddSta = new AxDCEDITLib.AxDcedit();
            this.dcim7IAddZip = new AxDCIMAGELib.AxDcimage();
            this.dced7IAddZip = new AxDCEDITLib.AxDcedit();
            this.lbl7IAddTel = new System.Windows.Forms.Label();
            this.dcim33DocAdd = new AxDCIMAGELib.AxDcimage();
            this.dced7IAddTel = new AxDCEDITLib.AxDcedit();
            this.lbl11IPolNo = new System.Windows.Forms.Label();
            this.dcim11IPolNo = new AxDCIMAGELib.AxDcimage();
            this.dced11IPolNo = new AxDCEDITLib.AxDcedit();
            this.lbl11aInSex = new System.Windows.Forms.Label();
            this.dcim11aInSex = new AxDCIMAGELib.AxDcimage();
            this.cmb11aInSex = new System.Windows.Forms.ComboBox();
            this.lbl11aInDOB = new System.Windows.Forms.Label();
            this.dcim11aInDOB = new AxDCIMAGELib.AxDcimage();
            this.dced11aInDOB = new AxDCEDITLib.AxDcedit();
            this.lbl11cIPlan = new System.Windows.Forms.Label();
            this.dcim11cIPlan = new AxDCIMAGELib.AxDcimage();
            this.dced11cIPlan = new AxDCEDITLib.AxDcedit();
            this.lbl11dPlOth = new System.Windows.Forms.Label();
            this.dcim11dPlOth = new AxDCIMAGELib.AxDcimage();
            this.cmb11dPlOth = new System.Windows.Forms.ComboBox();
            this.lbl17aRfDID = new System.Windows.Forms.Label();
            this.dcim17aRfDID = new AxDCIMAGELib.AxDcimage();
            this.dced17aRfDID = new AxDCEDITLib.AxDcedit();
            this.lbl17aRfCd = new System.Windows.Forms.Label();
            this.dced17aRfCd = new AxDCEDITLib.AxDcedit();
            this.dcim17bRfNPI = new AxDCIMAGELib.AxDcimage();
            this.dced17bRfNPI = new AxDCEDITLib.AxDcedit();
            this.lbl25aFedTx = new System.Windows.Forms.Label();
            this.dcim25aFedTx = new AxDCIMAGELib.AxDcimage();
            this.dced25aFedTx = new AxDCEDITLib.AxDcedit();
            this.lbl26PActNo = new System.Windows.Forms.Label();
            this.dcim26PActNo = new AxDCIMAGELib.AxDcimage();
            this.dced26PActNo = new AxDCEDITLib.AxDcedit();
            this.lbl27AccAss = new System.Windows.Forms.Label();
            this.dcim27AccAss = new AxDCIMAGELib.AxDcimage();
            this.cmb27AccAss = new System.Windows.Forms.ComboBox();
            this.lbl28TotChg = new System.Windows.Forms.Label();
            this.dcim28TotChg = new AxDCIMAGELib.AxDcimage();
            this.dced28TotChg = new AxDCEDITLib.AxDcedit();
            this.lbl29Amt_Pd = new System.Windows.Forms.Label();
            this.dcim29Amt_Pd = new AxDCIMAGELib.AxDcimage();
            this.dced29Amt_Pd = new AxDCEDITLib.AxDcedit();
            this.lbl30BalDue = new System.Windows.Forms.Label();
            this.dcim30BalDue = new AxDCIMAGELib.AxDcimage();
            this.dced30BalDue = new AxDCEDITLib.AxDcedit();
            this.dcim32FacAdd = new AxDCIMAGELib.AxDcimage();
            this.dced32FacNPI = new AxDCEDITLib.AxDcedit();
            this.dced32FacID = new AxDCEDITLib.AxDcedit();
            this.dced33PhyPIN = new AxDCEDITLib.AxDcedit();
            this.dced33PhyGRP = new AxDCEDITLib.AxDcedit();
            this.lbl24aDtFr1 = new System.Windows.Forms.Label();
            this.dced2PaLName = new AxDCEDITLib.AxDcedit();
            this.dced2PaFName = new AxDCEDITLib.AxDcedit();
            this.dced2PaMInit = new AxDCEDITLib.AxDcedit();
            this.dced4InsLNam = new AxDCEDITLib.AxDcedit();
            this.dced4InsFNam = new AxDCEDITLib.AxDcedit();
            this.dced4InsMIni = new AxDCEDITLib.AxDcedit();
            this.dcim17ReCred = new AxDCIMAGELib.AxDcimage();
            this.dced17ReCred = new AxDCEDITLib.AxDcedit();
            this.dcim17ReSufx = new AxDCIMAGELib.AxDcimage();
            this.dced17ReSufx = new AxDCEDITLib.AxDcedit();
            this.dced31aPhLNm = new AxDCEDITLib.AxDcedit();
            this.dced31aPhFNm = new AxDCEDITLib.AxDcedit();
            this.dced31aPhIni = new AxDCEDITLib.AxDcedit();
            this.dced32FacNam = new AxDCEDITLib.AxDcedit();
            this.dced32F1Addr = new AxDCEDITLib.AxDcedit();
            this.dced32F2Addr = new AxDCEDITLib.AxDcedit();
            this.dced32FacCit = new AxDCEDITLib.AxDcedit();
            this.dced32FacSta = new AxDCEDITLib.AxDcedit();
            this.dced32FacZip = new AxDCEDITLib.AxDcedit();
            this.dced33PhBNam = new AxDCEDITLib.AxDcedit();
            this.dced33Ph1Add = new AxDCEDITLib.AxDcedit();
            this.dced33Ph2Add = new AxDCEDITLib.AxDcedit();
            this.dced33PhCity = new AxDCEDITLib.AxDcedit();
            this.dced33PhStat = new AxDCEDITLib.AxDcedit();
            this.dced33PhyZip = new AxDCEDITLib.AxDcedit();
            this.dced33PhyNPI = new AxDCEDITLib.AxDcedit();
            this.dced33PhyID = new AxDCEDITLib.AxDcedit();
            this.lbEPSD = new System.Windows.Forms.Label();
            this.lbReferenceId = new System.Windows.Forms.Label();
            this.lbCOB = new System.Windows.Forms.Label();
            this.dcimEPSD = new AxDCIMAGELib.AxDcimage();
            this.dcedEPSD = new AxDCEDITLib.AxDcedit();
            this.dcimCOB = new AxDCIMAGELib.AxDcimage();
            this.dcedCOB = new AxDCEDITLib.AxDcedit();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.lbDateFrom = new System.Windows.Forms.Label();
            this.lbPlaceofService = new System.Windows.Forms.Label();
            this.lbTypeofService = new System.Windows.Forms.Label();
            this.lbCPT_Code = new System.Windows.Forms.Label();
            this.lbDiagPointer = new System.Windows.Forms.Label();
            this.lbCharges = new System.Windows.Forms.Label();
            this.lbDays_Units = new System.Windows.Forms.Label();
            this.lbInfo = new System.Windows.Forms.Label();
            this.lbNPI = new System.Windows.Forms.Label();
            this.panLINEITEM = new System.Windows.Forms.Panel();
            this.dcimEMG_C = new AxDCIMAGELib.AxDcimage();
            this.dcedEMG_C = new AxDCEDITLib.AxDcedit();
            this.dcimReferenceId = new AxDCIMAGELib.AxDcimage();
            this.dcedReferenceId = new AxDCEDITLib.AxDcedit();
            this.dcimDateFrom = new AxDCIMAGELib.AxDcimage();
            this.dcedDateFrom = new AxDCEDITLib.AxDcedit();
            this.dcimDateThru = new AxDCIMAGELib.AxDcimage();
            this.dcedDateThru = new AxDCEDITLib.AxDcedit();
            this.dcimPlaceofService = new AxDCIMAGELib.AxDcimage();
            this.dcedPlaceofService = new AxDCEDITLib.AxDcedit();
            this.dcimCPT_Code = new AxDCIMAGELib.AxDcimage();
            this.dcedCPT_Code = new AxDCEDITLib.AxDcedit();
            this.dcimModifiers = new AxDCIMAGELib.AxDcimage();
            this.dcedModifiers = new AxDCEDITLib.AxDcedit();
            this.dcimDiagPointer = new AxDCIMAGELib.AxDcimage();
            this.dcedDiagPointer = new AxDCEDITLib.AxDcedit();
            this.dcimCharges = new AxDCIMAGELib.AxDcimage();
            this.dcedCharges = new AxDCEDITLib.AxDcedit();
            this.dcimDays_Units = new AxDCIMAGELib.AxDcimage();
            this.dcedDays_Units = new AxDCEDITLib.AxDcedit();
            this.dcimQualifier = new AxDCIMAGELib.AxDcimage();
            this.dcedQualifier = new AxDCEDITLib.AxDcedit();
            this.dcimNPI = new AxDCIMAGELib.AxDcimage();
            this.dcedNPI = new AxDCEDITLib.AxDcedit();
            this.dcedInfo = new AxDCEDITLib.AxDcedit();
            this.dcimInfo = new AxDCIMAGELib.AxDcimage();
            this.btnDelpbLINEITEM = new System.Windows.Forms.Button();
            this.btnInsAfterpbLINEITEM = new System.Windows.Forms.Button();
            this.btnInsBeforepbLINEITEM = new System.Windows.Forms.Button();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.dcim7IAddStr = new AxDCIMAGELib.AxDcimage();
            this.lbl7IAddSta = new System.Windows.Forms.Label();
            this.dced21_Diag1 = new AxDCEDITLib.AxDcedit();
            this.dced21_Diag2 = new AxDCEDITLib.AxDcedit();
            this.dced21_Diag3 = new AxDCEDITLib.AxDcedit();
            this.dced21_Diag4 = new AxDCEDITLib.AxDcedit();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btnSwapNm31 = new System.Windows.Forms.Button();
            this.lblcopynm = new System.Windows.Forms.Label();
            this.lblCopyAddress = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.dced5PAddTel = new AxDCEDITLib.AxDcedit();
            this.lblCopyAll = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.btnCopyAdd2to4 = new System.Windows.Forms.Button();
            this.btnCopyAdd4to2 = new System.Windows.Forms.Button();
            this.btnCopyNm4to2 = new System.Windows.Forms.Button();
            this.btnCopyNm2to4 = new System.Windows.Forms.Button();
            this.btnSwapNames4 = new System.Windows.Forms.Button();
            this.btnSwapNamesFld2 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dced5PAddStr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced5PAddCty)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim5PAddSta)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced5PAddSta)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim5PAddZip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced5PAddZip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim3Pat_DOB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced3Pat_DOB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim3aPatSex)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim1aInsrID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced1aInsrID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced7IAddStr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced7IAddCty)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced7IAddSta)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim7IAddZip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced7IAddZip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim33DocAdd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced7IAddTel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim11IPolNo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced11IPolNo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim11aInSex)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim11aInDOB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced11aInDOB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim11cIPlan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced11cIPlan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim11dPlOth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim17aRfDID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced17aRfDID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced17aRfCd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim17bRfNPI)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced17bRfNPI)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim25aFedTx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced25aFedTx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim26PActNo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced26PActNo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim27AccAss)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim28TotChg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced28TotChg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim29Amt_Pd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced29Amt_Pd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim30BalDue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced30BalDue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim32FacAdd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced32FacNPI)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced32FacID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced33PhyPIN)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced33PhyGRP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced2PaLName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced2PaFName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced2PaMInit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced4InsLNam)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced4InsFNam)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced4InsMIni)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim17ReCred)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced17ReCred)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim17ReSufx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced17ReSufx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced31aPhLNm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced31aPhFNm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced31aPhIni)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced32FacNam)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced32F1Addr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced32F2Addr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced32FacCit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced32FacSta)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced32FacZip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced33PhBNam)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced33Ph1Add)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced33Ph2Add)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced33PhCity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced33PhStat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced33PhyZip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced33PhyNPI)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced33PhyID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimEPSD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedEPSD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimCOB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedCOB)).BeginInit();
            this.panLINEITEM.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dcimEMG_C)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedEMG_C)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimReferenceId)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedReferenceId)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimDateFrom)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedDateFrom)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimDateThru)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedDateThru)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimPlaceofService)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedPlaceofService)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimCPT_Code)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedCPT_Code)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimModifiers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedModifiers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimDiagPointer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedDiagPointer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimCharges)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedCharges)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimDays_Units)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedDays_Units)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimQualifier)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedQualifier)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimNPI)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedNPI)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedInfo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimInfo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim7IAddStr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced21_Diag1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced21_Diag2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced21_Diag3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced21_Diag4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced5PAddTel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // dced5PAddStr
            // 
            this.dced5PAddStr.Location = new System.Drawing.Point(197, 265);
            this.dced5PAddStr.Name = "dced5PAddStr";
            this.dced5PAddStr.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced5PAddStr.OcxState")));
            this.dced5PAddStr.Size = new System.Drawing.Size(312, 23);
            this.dced5PAddStr.TabIndex = 20;
            this.dced5PAddStr.Tag = "5PAddStr";
            // 
            // dced5PAddCty
            // 
            this.dced5PAddCty.Location = new System.Drawing.Point(197, 304);
            this.dced5PAddCty.Name = "dced5PAddCty";
            this.dced5PAddCty.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced5PAddCty.OcxState")));
            this.dced5PAddCty.Size = new System.Drawing.Size(242, 23);
            this.dced5PAddCty.TabIndex = 22;
            this.dced5PAddCty.Tag = "5PAddCty";
            // 
            // dcim5PAddSta
            // 
            this.dcim5PAddSta.Location = new System.Drawing.Point(197, 47);
            this.dcim5PAddSta.Name = "dcim5PAddSta";
            this.dcim5PAddSta.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim5PAddSta.OcxState")));
            this.dcim5PAddSta.Size = new System.Drawing.Size(312, 126);
            this.dcim5PAddSta.TabIndex = 12;
            this.dcim5PAddSta.TabStop = false;
            this.dcim5PAddSta.Tag = "2PatSFLD";
            // 
            // dced5PAddSta
            // 
            this.dced5PAddSta.Location = new System.Drawing.Point(447, 304);
            this.dced5PAddSta.Name = "dced5PAddSta";
            this.dced5PAddSta.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced5PAddSta.OcxState")));
            this.dced5PAddSta.Size = new System.Drawing.Size(62, 23);
            this.dced5PAddSta.TabIndex = 24;
            this.dced5PAddSta.Tag = "5PAddSta";
            // 
            // dcim5PAddZip
            // 
            this.dcim5PAddZip.Location = new System.Drawing.Point(571, 47);
            this.dcim5PAddZip.Name = "dcim5PAddZip";
            this.dcim5PAddZip.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim5PAddZip.OcxState")));
            this.dcim5PAddZip.Size = new System.Drawing.Size(312, 126);
            this.dcim5PAddZip.TabIndex = 28;
            this.dcim5PAddZip.TabStop = false;
            this.dcim5PAddZip.Tag = "4InsSFLD";
            // 
            // dced5PAddZip
            // 
            this.dced5PAddZip.Location = new System.Drawing.Point(197, 343);
            this.dced5PAddZip.Name = "dced5PAddZip";
            this.dced5PAddZip.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced5PAddZip.OcxState")));
            this.dced5PAddZip.Size = new System.Drawing.Size(112, 23);
            this.dced5PAddZip.TabIndex = 26;
            this.dced5PAddZip.Tag = "5PAddZip";
            // 
            // lbl3Pat_DOB
            // 
            this.lbl3Pat_DOB.AutoSize = true;
            this.lbl3Pat_DOB.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl3Pat_DOB.Location = new System.Drawing.Point(13, 108);
            this.lbl3Pat_DOB.Name = "lbl3Pat_DOB";
            this.lbl3Pat_DOB.Size = new System.Drawing.Size(99, 14);
            this.lbl3Pat_DOB.TabIndex = 3;
            this.lbl3Pat_DOB.Tag = "3Pat_DOB";
            this.lbl3Pat_DOB.Text = "3. Patient DOB";
            // 
            // dcim3Pat_DOB
            // 
            this.dcim3Pat_DOB.Location = new System.Drawing.Point(16, 125);
            this.dcim3Pat_DOB.Name = "dcim3Pat_DOB";
            this.dcim3Pat_DOB.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim3Pat_DOB.OcxState")));
            this.dcim3Pat_DOB.Size = new System.Drawing.Size(133, 23);
            this.dcim3Pat_DOB.TabIndex = 4;
            this.dcim3Pat_DOB.TabStop = false;
            this.dcim3Pat_DOB.Tag = "3Pat_DOB";
            // 
            // dced3Pat_DOB
            // 
            this.dced3Pat_DOB.Location = new System.Drawing.Point(16, 151);
            this.dced3Pat_DOB.Name = "dced3Pat_DOB";
            this.dced3Pat_DOB.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced3Pat_DOB.OcxState")));
            this.dced3Pat_DOB.Size = new System.Drawing.Size(133, 23);
            this.dced3Pat_DOB.TabIndex = 5;
            this.dced3Pat_DOB.Tag = "3Pat_DOB";
            // 
            // lbl3aPatSex
            // 
            this.lbl3aPatSex.AutoSize = true;
            this.lbl3aPatSex.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl3aPatSex.Location = new System.Drawing.Point(13, 187);
            this.lbl3aPatSex.Name = "lbl3aPatSex";
            this.lbl3aPatSex.Size = new System.Drawing.Size(103, 14);
            this.lbl3aPatSex.TabIndex = 6;
            this.lbl3aPatSex.Tag = "3aPatSex";
            this.lbl3aPatSex.Text = "3a. Patient Sex";
            // 
            // dcim3aPatSex
            // 
            this.dcim3aPatSex.Location = new System.Drawing.Point(16, 204);
            this.dcim3aPatSex.Name = "dcim3aPatSex";
            this.dcim3aPatSex.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim3aPatSex.OcxState")));
            this.dcim3aPatSex.Size = new System.Drawing.Size(130, 45);
            this.dcim3aPatSex.TabIndex = 7;
            this.dcim3aPatSex.TabStop = false;
            this.dcim3aPatSex.Tag = "3aPatSex";
            // 
            // cmb3aPatSex
            // 
            this.cmb3aPatSex.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb3aPatSex.FormattingEnabled = true;
            this.cmb3aPatSex.Location = new System.Drawing.Point(16, 252);
            this.cmb3aPatSex.Name = "cmb3aPatSex";
            this.cmb3aPatSex.Size = new System.Drawing.Size(133, 26);
            this.cmb3aPatSex.TabIndex = 8;
            this.cmb3aPatSex.Tag = "3aPatSex";
            // 
            // lbl1aInsrID
            // 
            this.lbl1aInsrID.AutoSize = true;
            this.lbl1aInsrID.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1aInsrID.Location = new System.Drawing.Point(13, 30);
            this.lbl1aInsrID.Name = "lbl1aInsrID";
            this.lbl1aInsrID.Size = new System.Drawing.Size(108, 14);
            this.lbl1aInsrID.TabIndex = 0;
            this.lbl1aInsrID.Tag = "1aInsrID";
            this.lbl1aInsrID.Text = "1a. Insured\'s ID";
            // 
            // dcim1aInsrID
            // 
            this.dcim1aInsrID.Location = new System.Drawing.Point(16, 47);
            this.dcim1aInsrID.Name = "dcim1aInsrID";
            this.dcim1aInsrID.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim1aInsrID.OcxState")));
            this.dcim1aInsrID.Size = new System.Drawing.Size(133, 23);
            this.dcim1aInsrID.TabIndex = 1;
            this.dcim1aInsrID.TabStop = false;
            this.dcim1aInsrID.Tag = "1aInsrID";
            // 
            // dced1aInsrID
            // 
            this.dced1aInsrID.Location = new System.Drawing.Point(16, 73);
            this.dced1aInsrID.Name = "dced1aInsrID";
            this.dced1aInsrID.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced1aInsrID.OcxState")));
            this.dced1aInsrID.Size = new System.Drawing.Size(133, 26);
            this.dced1aInsrID.TabIndex = 2;
            this.dced1aInsrID.Tag = "1aInsrID";
            // 
            // lbl7IAddStr
            // 
            this.lbl7IAddStr.AutoSize = true;
            this.lbl7IAddStr.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl7IAddStr.Location = new System.Drawing.Point(194, 30);
            this.lbl7IAddStr.Name = "lbl7IAddStr";
            this.lbl7IAddStr.Size = new System.Drawing.Size(225, 14);
            this.lbl7IAddStr.TabIndex = 11;
            this.lbl7IAddStr.Tag = "";
            this.lbl7IAddStr.Text = "2. Patient Name/Address/Zip Code";
            // 
            // dced7IAddStr
            // 
            this.dced7IAddStr.Location = new System.Drawing.Point(571, 265);
            this.dced7IAddStr.Name = "dced7IAddStr";
            this.dced7IAddStr.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced7IAddStr.OcxState")));
            this.dced7IAddStr.Size = new System.Drawing.Size(312, 23);
            this.dced7IAddStr.TabIndex = 36;
            this.dced7IAddStr.Tag = "7IAddStr";
            // 
            // lbl7IAddCty
            // 
            this.lbl7IAddCty.AutoSize = true;
            this.lbl7IAddCty.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl7IAddCty.Location = new System.Drawing.Point(568, 30);
            this.lbl7IAddCty.Name = "lbl7IAddCty";
            this.lbl7IAddCty.Size = new System.Drawing.Size(229, 14);
            this.lbl7IAddCty.TabIndex = 27;
            this.lbl7IAddCty.Tag = "";
            this.lbl7IAddCty.Text = "4. Insured Name/Address/Zip Code";
            // 
            // dced7IAddCty
            // 
            this.dced7IAddCty.Location = new System.Drawing.Point(571, 304);
            this.dced7IAddCty.Name = "dced7IAddCty";
            this.dced7IAddCty.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced7IAddCty.OcxState")));
            this.dced7IAddCty.Size = new System.Drawing.Size(242, 23);
            this.dced7IAddCty.TabIndex = 38;
            this.dced7IAddCty.Tag = "7IAddCty";
            // 
            // dced7IAddSta
            // 
            this.dced7IAddSta.Location = new System.Drawing.Point(821, 304);
            this.dced7IAddSta.Name = "dced7IAddSta";
            this.dced7IAddSta.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced7IAddSta.OcxState")));
            this.dced7IAddSta.Size = new System.Drawing.Size(62, 23);
            this.dced7IAddSta.TabIndex = 40;
            this.dced7IAddSta.Tag = "7IAddSta";
            // 
            // dcim7IAddZip
            // 
            this.dcim7IAddZip.Location = new System.Drawing.Point(16, 1101);
            this.dcim7IAddZip.Name = "dcim7IAddZip";
            this.dcim7IAddZip.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim7IAddZip.OcxState")));
            this.dcim7IAddZip.Size = new System.Drawing.Size(250, 81);
            this.dcim7IAddZip.TabIndex = 88;
            this.dcim7IAddZip.TabStop = false;
            this.dcim7IAddZip.Tag = "31aPhSig";
            // 
            // dced7IAddZip
            // 
            this.dced7IAddZip.Location = new System.Drawing.Point(571, 343);
            this.dced7IAddZip.Name = "dced7IAddZip";
            this.dced7IAddZip.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced7IAddZip.OcxState")));
            this.dced7IAddZip.Size = new System.Drawing.Size(112, 23);
            this.dced7IAddZip.TabIndex = 42;
            this.dced7IAddZip.Tag = "7IAddZip";
            // 
            // lbl7IAddTel
            // 
            this.lbl7IAddTel.AutoSize = true;
            this.lbl7IAddTel.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl7IAddTel.Location = new System.Drawing.Point(13, 1084);
            this.lbl7IAddTel.Name = "lbl7IAddTel";
            this.lbl7IAddTel.Size = new System.Drawing.Size(154, 14);
            this.lbl7IAddTel.TabIndex = 87;
            this.lbl7IAddTel.Tag = "";
            this.lbl7IAddTel.Text = "31. Physician Signature";
            // 
            // dcim33DocAdd
            // 
            this.dcim33DocAdd.Location = new System.Drawing.Point(669, 1101);
            this.dcim33DocAdd.Name = "dcim33DocAdd";
            this.dcim33DocAdd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim33DocAdd.OcxState")));
            this.dcim33DocAdd.Size = new System.Drawing.Size(247, 94);
            this.dcim33DocAdd.TabIndex = 123;
            this.dcim33DocAdd.TabStop = false;
            this.dcim33DocAdd.Tag = "33DocAdd";
            // 
            // dced7IAddTel
            // 
            this.dced7IAddTel.Location = new System.Drawing.Point(691, 343);
            this.dced7IAddTel.Name = "dced7IAddTel";
            this.dced7IAddTel.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced7IAddTel.OcxState")));
            this.dced7IAddTel.Size = new System.Drawing.Size(192, 23);
            this.dced7IAddTel.TabIndex = 44;
            this.dced7IAddTel.Tag = "7IAddTel";
            // 
            // lbl11IPolNo
            // 
            this.lbl11IPolNo.AutoSize = true;
            this.lbl11IPolNo.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl11IPolNo.Location = new System.Drawing.Point(13, 390);
            this.lbl11IPolNo.Name = "lbl11IPolNo";
            this.lbl11IPolNo.Size = new System.Drawing.Size(119, 14);
            this.lbl11IPolNo.TabIndex = 45;
            this.lbl11IPolNo.Tag = "11IPolNo";
            this.lbl11IPolNo.Text = "11. Policy Number";
            // 
            // dcim11IPolNo
            // 
            this.dcim11IPolNo.Location = new System.Drawing.Point(16, 407);
            this.dcim11IPolNo.Name = "dcim11IPolNo";
            this.dcim11IPolNo.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim11IPolNo.OcxState")));
            this.dcim11IPolNo.Size = new System.Drawing.Size(133, 23);
            this.dcim11IPolNo.TabIndex = 46;
            this.dcim11IPolNo.TabStop = false;
            this.dcim11IPolNo.Tag = "11IPolNo";
            // 
            // dced11IPolNo
            // 
            this.dced11IPolNo.Location = new System.Drawing.Point(16, 433);
            this.dced11IPolNo.Name = "dced11IPolNo";
            this.dced11IPolNo.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced11IPolNo.OcxState")));
            this.dced11IPolNo.Size = new System.Drawing.Size(133, 23);
            this.dced11IPolNo.TabIndex = 47;
            this.dced11IPolNo.Tag = "11IPolNo";
            // 
            // lbl11aInSex
            // 
            this.lbl11aInSex.AutoSize = true;
            this.lbl11aInSex.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl11aInSex.Location = new System.Drawing.Point(322, 390);
            this.lbl11aInSex.Name = "lbl11aInSex";
            this.lbl11aInSex.Size = new System.Drawing.Size(115, 14);
            this.lbl11aInSex.TabIndex = 51;
            this.lbl11aInSex.Tag = "11aInSex";
            this.lbl11aInSex.Text = "11a. Insured Sex";
            // 
            // dcim11aInSex
            // 
            this.dcim11aInSex.Location = new System.Drawing.Point(325, 407);
            this.dcim11aInSex.Name = "dcim11aInSex";
            this.dcim11aInSex.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim11aInSex.OcxState")));
            this.dcim11aInSex.Size = new System.Drawing.Size(114, 39);
            this.dcim11aInSex.TabIndex = 52;
            this.dcim11aInSex.TabStop = false;
            this.dcim11aInSex.Tag = "11aInSex";
            // 
            // cmb11aInSex
            // 
            this.cmb11aInSex.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb11aInSex.FormattingEnabled = true;
            this.cmb11aInSex.Location = new System.Drawing.Point(325, 448);
            this.cmb11aInSex.Name = "cmb11aInSex";
            this.cmb11aInSex.Size = new System.Drawing.Size(112, 26);
            this.cmb11aInSex.TabIndex = 53;
            this.cmb11aInSex.Tag = "11aInSex";
            // 
            // lbl11aInDOB
            // 
            this.lbl11aInDOB.AutoSize = true;
            this.lbl11aInDOB.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl11aInDOB.Location = new System.Drawing.Point(179, 390);
            this.lbl11aInDOB.Name = "lbl11aInDOB";
            this.lbl11aInDOB.Size = new System.Drawing.Size(119, 14);
            this.lbl11aInDOB.TabIndex = 48;
            this.lbl11aInDOB.Tag = "11aInDOB";
            this.lbl11aInDOB.Text = "11a. Insured DOB";
            // 
            // dcim11aInDOB
            // 
            this.dcim11aInDOB.Location = new System.Drawing.Point(182, 407);
            this.dcim11aInDOB.Name = "dcim11aInDOB";
            this.dcim11aInDOB.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim11aInDOB.OcxState")));
            this.dcim11aInDOB.Size = new System.Drawing.Size(125, 23);
            this.dcim11aInDOB.TabIndex = 49;
            this.dcim11aInDOB.TabStop = false;
            this.dcim11aInDOB.Tag = "11aInDOB";
            // 
            // dced11aInDOB
            // 
            this.dced11aInDOB.Location = new System.Drawing.Point(182, 433);
            this.dced11aInDOB.Name = "dced11aInDOB";
            this.dced11aInDOB.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced11aInDOB.OcxState")));
            this.dced11aInDOB.Size = new System.Drawing.Size(125, 23);
            this.dced11aInDOB.TabIndex = 50;
            this.dced11aInDOB.Tag = "11aInDOB";
            // 
            // lbl11cIPlan
            // 
            this.lbl11cIPlan.AutoSize = true;
            this.lbl11cIPlan.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl11cIPlan.Location = new System.Drawing.Point(464, 390);
            this.lbl11cIPlan.Name = "lbl11cIPlan";
            this.lbl11cIPlan.Size = new System.Drawing.Size(171, 14);
            this.lbl11cIPlan.TabIndex = 54;
            this.lbl11cIPlan.Tag = "11cIPlan";
            this.lbl11cIPlan.Text = "11c. Insurance Plan Name";
            // 
            // dcim11cIPlan
            // 
            this.dcim11cIPlan.Location = new System.Drawing.Point(467, 407);
            this.dcim11cIPlan.Name = "dcim11cIPlan";
            this.dcim11cIPlan.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim11cIPlan.OcxState")));
            this.dcim11cIPlan.Size = new System.Drawing.Size(242, 23);
            this.dcim11cIPlan.TabIndex = 55;
            this.dcim11cIPlan.TabStop = false;
            this.dcim11cIPlan.Tag = "11cIPlan";
            // 
            // dced11cIPlan
            // 
            this.dced11cIPlan.Location = new System.Drawing.Point(467, 433);
            this.dced11cIPlan.Name = "dced11cIPlan";
            this.dced11cIPlan.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced11cIPlan.OcxState")));
            this.dced11cIPlan.Size = new System.Drawing.Size(242, 23);
            this.dced11cIPlan.TabIndex = 56;
            this.dced11cIPlan.Tag = "11cIPlan";
            // 
            // lbl11dPlOth
            // 
            this.lbl11dPlOth.AutoSize = true;
            this.lbl11dPlOth.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl11dPlOth.Location = new System.Drawing.Point(740, 390);
            this.lbl11dPlOth.Name = "lbl11dPlOth";
            this.lbl11dPlOth.Size = new System.Drawing.Size(120, 14);
            this.lbl11dPlOth.TabIndex = 57;
            this.lbl11dPlOth.Tag = "11dPlOth";
            this.lbl11dPlOth.Text = "11d. Another Plan";
            // 
            // dcim11dPlOth
            // 
            this.dcim11dPlOth.Location = new System.Drawing.Point(741, 407);
            this.dcim11dPlOth.Name = "dcim11dPlOth";
            this.dcim11dPlOth.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim11dPlOth.OcxState")));
            this.dcim11dPlOth.Size = new System.Drawing.Size(114, 39);
            this.dcim11dPlOth.TabIndex = 58;
            this.dcim11dPlOth.TabStop = false;
            this.dcim11dPlOth.Tag = "11dPlOth";
            // 
            // cmb11dPlOth
            // 
            this.cmb11dPlOth.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb11dPlOth.FormattingEnabled = true;
            this.cmb11dPlOth.Location = new System.Drawing.Point(743, 448);
            this.cmb11dPlOth.Name = "cmb11dPlOth";
            this.cmb11dPlOth.Size = new System.Drawing.Size(112, 26);
            this.cmb11dPlOth.TabIndex = 59;
            this.cmb11dPlOth.Tag = "11dPlOth";
            // 
            // lbl17aRfDID
            // 
            this.lbl17aRfDID.AutoSize = true;
            this.lbl17aRfDID.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl17aRfDID.Location = new System.Drawing.Point(10, 478);
            this.lbl17aRfDID.Name = "lbl17aRfDID";
            this.lbl17aRfDID.Size = new System.Drawing.Size(165, 14);
            this.lbl17aRfDID.TabIndex = 60;
            this.lbl17aRfDID.Tag = "";
            this.lbl17aRfDID.Text = "17a. Qualifier and Ref. ID";
            // 
            // dcim17aRfDID
            // 
            this.dcim17aRfDID.Location = new System.Drawing.Point(13, 494);
            this.dcim17aRfDID.Name = "dcim17aRfDID";
            this.dcim17aRfDID.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim17aRfDID.OcxState")));
            this.dcim17aRfDID.Size = new System.Drawing.Size(179, 23);
            this.dcim17aRfDID.TabIndex = 61;
            this.dcim17aRfDID.TabStop = false;
            this.dcim17aRfDID.Tag = "17aRfDID";
            // 
            // dced17aRfDID
            // 
            this.dced17aRfDID.Location = new System.Drawing.Point(56, 518);
            this.dced17aRfDID.Name = "dced17aRfDID";
            this.dced17aRfDID.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced17aRfDID.OcxState")));
            this.dced17aRfDID.Size = new System.Drawing.Size(136, 23);
            this.dced17aRfDID.TabIndex = 64;
            this.dced17aRfDID.Tag = "17aRfDID";
            // 
            // lbl17aRfCd
            // 
            this.lbl17aRfCd.AutoSize = true;
            this.lbl17aRfCd.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl17aRfCd.Location = new System.Drawing.Point(336, 1084);
            this.lbl17aRfCd.Name = "lbl17aRfCd";
            this.lbl17aRfCd.Size = new System.Drawing.Size(187, 14);
            this.lbl17aRfCd.TabIndex = 104;
            this.lbl17aRfCd.Tag = "";
            this.lbl17aRfCd.Text = "32. Facility\'s Name / Address";
            // 
            // dced17aRfCd
            // 
            this.dced17aRfCd.Location = new System.Drawing.Point(13, 518);
            this.dced17aRfCd.Name = "dced17aRfCd";
            this.dced17aRfCd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced17aRfCd.OcxState")));
            this.dced17aRfCd.Size = new System.Drawing.Size(41, 23);
            this.dced17aRfCd.TabIndex = 63;
            this.dced17aRfCd.Tag = "17aRfCd";
            // 
            // dcim17bRfNPI
            // 
            this.dcim17bRfNPI.Location = new System.Drawing.Point(13, 560);
            this.dcim17bRfNPI.Name = "dcim17bRfNPI";
            this.dcim17bRfNPI.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim17bRfNPI.OcxState")));
            this.dcim17bRfNPI.Size = new System.Drawing.Size(179, 23);
            this.dcim17bRfNPI.TabIndex = 65;
            this.dcim17bRfNPI.TabStop = false;
            this.dcim17bRfNPI.Tag = "17bRfNPI";
            // 
            // dced17bRfNPI
            // 
            this.dced17bRfNPI.Location = new System.Drawing.Point(13, 584);
            this.dced17bRfNPI.Name = "dced17bRfNPI";
            this.dced17bRfNPI.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced17bRfNPI.OcxState")));
            this.dced17bRfNPI.Size = new System.Drawing.Size(179, 26);
            this.dced17bRfNPI.TabIndex = 67;
            this.dced17bRfNPI.Tag = "17bRfNPI";
            // 
            // lbl25aFedTx
            // 
            this.lbl25aFedTx.AutoSize = true;
            this.lbl25aFedTx.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl25aFedTx.Location = new System.Drawing.Point(13, 988);
            this.lbl25aFedTx.Name = "lbl25aFedTx";
            this.lbl25aFedTx.Size = new System.Drawing.Size(140, 14);
            this.lbl25aFedTx.TabIndex = 78;
            this.lbl25aFedTx.Tag = "25aFedTx";
            this.lbl25aFedTx.Text = "25a. Federal Tax ID#";
            // 
            // dcim25aFedTx
            // 
            this.dcim25aFedTx.Location = new System.Drawing.Point(16, 1005);
            this.dcim25aFedTx.Name = "dcim25aFedTx";
            this.dcim25aFedTx.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim25aFedTx.OcxState")));
            this.dcim25aFedTx.Size = new System.Drawing.Size(130, 21);
            this.dcim25aFedTx.TabIndex = 79;
            this.dcim25aFedTx.TabStop = false;
            this.dcim25aFedTx.Tag = "25aFedTx";
            // 
            // dced25aFedTx
            // 
            this.dced25aFedTx.Location = new System.Drawing.Point(16, 1029);
            this.dced25aFedTx.Name = "dced25aFedTx";
            this.dced25aFedTx.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced25aFedTx.OcxState")));
            this.dced25aFedTx.Size = new System.Drawing.Size(130, 23);
            this.dced25aFedTx.TabIndex = 80;
            this.dced25aFedTx.Tag = "25aFedTx";
            // 
            // lbl26PActNo
            // 
            this.lbl26PActNo.AutoSize = true;
            this.lbl26PActNo.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl26PActNo.Location = new System.Drawing.Point(185, 988);
            this.lbl26PActNo.Name = "lbl26PActNo";
            this.lbl26PActNo.Size = new System.Drawing.Size(143, 14);
            this.lbl26PActNo.TabIndex = 81;
            this.lbl26PActNo.Tag = "26PActNo";
            this.lbl26PActNo.Text = "26. Patient Account #";
            // 
            // dcim26PActNo
            // 
            this.dcim26PActNo.Location = new System.Drawing.Point(188, 1005);
            this.dcim26PActNo.Name = "dcim26PActNo";
            this.dcim26PActNo.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim26PActNo.OcxState")));
            this.dcim26PActNo.Size = new System.Drawing.Size(156, 21);
            this.dcim26PActNo.TabIndex = 82;
            this.dcim26PActNo.TabStop = false;
            this.dcim26PActNo.Tag = "26PActNo";
            // 
            // dced26PActNo
            // 
            this.dced26PActNo.Location = new System.Drawing.Point(188, 1029);
            this.dced26PActNo.Name = "dced26PActNo";
            this.dced26PActNo.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced26PActNo.OcxState")));
            this.dced26PActNo.Size = new System.Drawing.Size(156, 23);
            this.dced26PActNo.TabIndex = 83;
            this.dced26PActNo.Tag = "26PActNo";
            // 
            // lbl27AccAss
            // 
            this.lbl27AccAss.AutoSize = true;
            this.lbl27AccAss.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl27AccAss.Location = new System.Drawing.Point(373, 988);
            this.lbl27AccAss.Name = "lbl27AccAss";
            this.lbl27AccAss.Size = new System.Drawing.Size(104, 14);
            this.lbl27AccAss.TabIndex = 84;
            this.lbl27AccAss.Tag = "27AccAss";
            this.lbl27AccAss.Text = "27. Assignment";
            // 
            // dcim27AccAss
            // 
            this.dcim27AccAss.Location = new System.Drawing.Point(376, 1005);
            this.dcim27AccAss.Name = "dcim27AccAss";
            this.dcim27AccAss.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim27AccAss.OcxState")));
            this.dcim27AccAss.Size = new System.Drawing.Size(88, 39);
            this.dcim27AccAss.TabIndex = 85;
            this.dcim27AccAss.TabStop = false;
            this.dcim27AccAss.Tag = "27AccAss";
            // 
            // cmb27AccAss
            // 
            this.cmb27AccAss.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb27AccAss.FormattingEnabled = true;
            this.cmb27AccAss.Location = new System.Drawing.Point(467, 1005);
            this.cmb27AccAss.Name = "cmb27AccAss";
            this.cmb27AccAss.Size = new System.Drawing.Size(119, 26);
            this.cmb27AccAss.TabIndex = 86;
            this.cmb27AccAss.Tag = "27AccAss";
            // 
            // lbl28TotChg
            // 
            this.lbl28TotChg.AutoSize = true;
            this.lbl28TotChg.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl28TotChg.Location = new System.Drawing.Point(632, 992);
            this.lbl28TotChg.Name = "lbl28TotChg";
            this.lbl28TotChg.Size = new System.Drawing.Size(66, 14);
            this.lbl28TotChg.TabIndex = 95;
            this.lbl28TotChg.Tag = "28TotChg";
            this.lbl28TotChg.Text = "28. Total ";
            // 
            // dcim28TotChg
            // 
            this.dcim28TotChg.Location = new System.Drawing.Point(635, 1010);
            this.dcim28TotChg.Name = "dcim28TotChg";
            this.dcim28TotChg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim28TotChg.OcxState")));
            this.dcim28TotChg.Size = new System.Drawing.Size(84, 21);
            this.dcim28TotChg.TabIndex = 96;
            this.dcim28TotChg.TabStop = false;
            this.dcim28TotChg.Tag = "28TotChg";
            // 
            // dced28TotChg
            // 
            this.dced28TotChg.Location = new System.Drawing.Point(635, 1034);
            this.dced28TotChg.Name = "dced28TotChg";
            this.dced28TotChg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced28TotChg.OcxState")));
            this.dced28TotChg.Size = new System.Drawing.Size(84, 23);
            this.dced28TotChg.TabIndex = 97;
            this.dced28TotChg.Tag = "28TotChg";
            // 
            // lbl29Amt_Pd
            // 
            this.lbl29Amt_Pd.AutoSize = true;
            this.lbl29Amt_Pd.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl29Amt_Pd.Location = new System.Drawing.Point(731, 992);
            this.lbl29Amt_Pd.Name = "lbl29Amt_Pd";
            this.lbl29Amt_Pd.Size = new System.Drawing.Size(58, 14);
            this.lbl29Amt_Pd.TabIndex = 98;
            this.lbl29Amt_Pd.Tag = "29Amt_Pd";
            this.lbl29Amt_Pd.Text = "29. Paid";
            // 
            // dcim29Amt_Pd
            // 
            this.dcim29Amt_Pd.Location = new System.Drawing.Point(734, 1010);
            this.dcim29Amt_Pd.Name = "dcim29Amt_Pd";
            this.dcim29Amt_Pd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim29Amt_Pd.OcxState")));
            this.dcim29Amt_Pd.Size = new System.Drawing.Size(84, 21);
            this.dcim29Amt_Pd.TabIndex = 99;
            this.dcim29Amt_Pd.TabStop = false;
            this.dcim29Amt_Pd.Tag = "29Amt_Pd";
            // 
            // dced29Amt_Pd
            // 
            this.dced29Amt_Pd.Location = new System.Drawing.Point(734, 1034);
            this.dced29Amt_Pd.Name = "dced29Amt_Pd";
            this.dced29Amt_Pd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced29Amt_Pd.OcxState")));
            this.dced29Amt_Pd.Size = new System.Drawing.Size(84, 23);
            this.dced29Amt_Pd.TabIndex = 100;
            this.dced29Amt_Pd.Tag = "29Amt_Pd";
            // 
            // lbl30BalDue
            // 
            this.lbl30BalDue.AutoSize = true;
            this.lbl30BalDue.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl30BalDue.Location = new System.Drawing.Point(830, 992);
            this.lbl30BalDue.Name = "lbl30BalDue";
            this.lbl30BalDue.Size = new System.Drawing.Size(56, 14);
            this.lbl30BalDue.TabIndex = 101;
            this.lbl30BalDue.Tag = "30BalDue";
            this.lbl30BalDue.Text = "30. Due";
            // 
            // dcim30BalDue
            // 
            this.dcim30BalDue.Location = new System.Drawing.Point(833, 1010);
            this.dcim30BalDue.Name = "dcim30BalDue";
            this.dcim30BalDue.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim30BalDue.OcxState")));
            this.dcim30BalDue.Size = new System.Drawing.Size(84, 21);
            this.dcim30BalDue.TabIndex = 102;
            this.dcim30BalDue.TabStop = false;
            this.dcim30BalDue.Tag = "30BalDue";
            // 
            // dced30BalDue
            // 
            this.dced30BalDue.Location = new System.Drawing.Point(833, 1034);
            this.dced30BalDue.Name = "dced30BalDue";
            this.dced30BalDue.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced30BalDue.OcxState")));
            this.dced30BalDue.Size = new System.Drawing.Size(84, 23);
            this.dced30BalDue.TabIndex = 103;
            this.dced30BalDue.Tag = "30BalDue";
            // 
            // dcim32FacAdd
            // 
            this.dcim32FacAdd.Location = new System.Drawing.Point(339, 1101);
            this.dcim32FacAdd.Name = "dcim32FacAdd";
            this.dcim32FacAdd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim32FacAdd.OcxState")));
            this.dcim32FacAdd.Size = new System.Drawing.Size(250, 94);
            this.dcim32FacAdd.TabIndex = 105;
            this.dcim32FacAdd.TabStop = false;
            this.dcim32FacAdd.Tag = "32FacAdd";
            // 
            // dced32FacNPI
            // 
            this.dced32FacNPI.Location = new System.Drawing.Point(339, 1406);
            this.dced32FacNPI.Name = "dced32FacNPI";
            this.dced32FacNPI.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced32FacNPI.OcxState")));
            this.dced32FacNPI.Size = new System.Drawing.Size(125, 23);
            this.dced32FacNPI.TabIndex = 119;
            this.dced32FacNPI.Tag = "32FacNPI";
            // 
            // dced32FacID
            // 
            this.dced32FacID.Location = new System.Drawing.Point(471, 1405);
            this.dced32FacID.Name = "dced32FacID";
            this.dced32FacID.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced32FacID.OcxState")));
            this.dced32FacID.Size = new System.Drawing.Size(117, 23);
            this.dced32FacID.TabIndex = 121;
            this.dced32FacID.Tag = "32FacID";
            // 
            // dced33PhyPIN
            // 
            this.dced33PhyPIN.Location = new System.Drawing.Point(668, 1405);
            this.dced33PhyPIN.Name = "dced33PhyPIN";
            this.dced33PhyPIN.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced33PhyPIN.OcxState")));
            this.dced33PhyPIN.Size = new System.Drawing.Size(125, 23);
            this.dced33PhyPIN.TabIndex = 137;
            this.dced33PhyPIN.Tag = "33PhyPIN";
            // 
            // dced33PhyGRP
            // 
            this.dced33PhyGRP.Location = new System.Drawing.Point(800, 1405);
            this.dced33PhyGRP.Name = "dced33PhyGRP";
            this.dced33PhyGRP.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced33PhyGRP.OcxState")));
            this.dced33PhyGRP.Size = new System.Drawing.Size(117, 23);
            this.dced33PhyGRP.TabIndex = 139;
            this.dced33PhyGRP.Tag = "33PhyGRP";
            // 
            // lbl24aDtFr1
            // 
            this.lbl24aDtFr1.AutoSize = true;
            this.lbl24aDtFr1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl24aDtFr1.Location = new System.Drawing.Point(666, 1084);
            this.lbl24aDtFr1.Name = "lbl24aDtFr1";
            this.lbl24aDtFr1.Size = new System.Drawing.Size(195, 14);
            this.lbl24aDtFr1.TabIndex = 122;
            this.lbl24aDtFr1.Tag = "";
            this.lbl24aDtFr1.Text = "33. Physician\'s Name/Address";
            // 
            // dced2PaLName
            // 
            this.dced2PaLName.Location = new System.Drawing.Point(197, 187);
            this.dced2PaLName.Name = "dced2PaLName";
            this.dced2PaLName.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced2PaLName.OcxState")));
            this.dced2PaLName.Size = new System.Drawing.Size(312, 23);
            this.dced2PaLName.TabIndex = 14;
            this.dced2PaLName.Tag = "2PaLName";
            // 
            // dced2PaFName
            // 
            this.dced2PaFName.Location = new System.Drawing.Point(197, 226);
            this.dced2PaFName.Name = "dced2PaFName";
            this.dced2PaFName.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced2PaFName.OcxState")));
            this.dced2PaFName.Size = new System.Drawing.Size(242, 23);
            this.dced2PaFName.TabIndex = 16;
            this.dced2PaFName.Tag = "2PaFName";
            // 
            // dced2PaMInit
            // 
            this.dced2PaMInit.Location = new System.Drawing.Point(447, 226);
            this.dced2PaMInit.Name = "dced2PaMInit";
            this.dced2PaMInit.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced2PaMInit.OcxState")));
            this.dced2PaMInit.Size = new System.Drawing.Size(62, 23);
            this.dced2PaMInit.TabIndex = 18;
            this.dced2PaMInit.Tag = "2PaMInit";
            // 
            // dced4InsLNam
            // 
            this.dced4InsLNam.Location = new System.Drawing.Point(571, 187);
            this.dced4InsLNam.Name = "dced4InsLNam";
            this.dced4InsLNam.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced4InsLNam.OcxState")));
            this.dced4InsLNam.Size = new System.Drawing.Size(312, 23);
            this.dced4InsLNam.TabIndex = 30;
            this.dced4InsLNam.Tag = "4InsLNam";
            // 
            // dced4InsFNam
            // 
            this.dced4InsFNam.Location = new System.Drawing.Point(571, 226);
            this.dced4InsFNam.Name = "dced4InsFNam";
            this.dced4InsFNam.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced4InsFNam.OcxState")));
            this.dced4InsFNam.Size = new System.Drawing.Size(242, 23);
            this.dced4InsFNam.TabIndex = 32;
            this.dced4InsFNam.Tag = "4InsFNam";
            // 
            // dced4InsMIni
            // 
            this.dced4InsMIni.Location = new System.Drawing.Point(821, 226);
            this.dced4InsMIni.Name = "dced4InsMIni";
            this.dced4InsMIni.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced4InsMIni.OcxState")));
            this.dced4InsMIni.Size = new System.Drawing.Size(62, 23);
            this.dced4InsMIni.TabIndex = 34;
            this.dced4InsMIni.Tag = "4InsMIni";
            // 
            // dcim17ReCred
            // 
            this.dcim17ReCred.Location = new System.Drawing.Point(894, 3311);
            this.dcim17ReCred.Name = "dcim17ReCred";
            this.dcim17ReCred.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim17ReCred.OcxState")));
            this.dcim17ReCred.Size = new System.Drawing.Size(130, 23);
            this.dcim17ReCred.TabIndex = 568;
            this.dcim17ReCred.TabStop = false;
            this.dcim17ReCred.Tag = "17ReCred";
            // 
            // dced17ReCred
            // 
            this.dced17ReCred.Location = new System.Drawing.Point(896, 3335);
            this.dced17ReCred.Name = "dced17ReCred";
            this.dced17ReCred.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced17ReCred.OcxState")));
            this.dced17ReCred.Size = new System.Drawing.Size(125, 23);
            this.dced17ReCred.TabIndex = 569;
            this.dced17ReCred.Tag = "17ReCred";
            // 
            // dcim17ReSufx
            // 
            this.dcim17ReSufx.Location = new System.Drawing.Point(1053, 3311);
            this.dcim17ReSufx.Name = "dcim17ReSufx";
            this.dcim17ReSufx.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim17ReSufx.OcxState")));
            this.dcim17ReSufx.Size = new System.Drawing.Size(130, 23);
            this.dcim17ReSufx.TabIndex = 571;
            this.dcim17ReSufx.TabStop = false;
            this.dcim17ReSufx.Tag = "17ReSufx";
            // 
            // dced17ReSufx
            // 
            this.dced17ReSufx.Location = new System.Drawing.Point(1054, 3335);
            this.dced17ReSufx.Name = "dced17ReSufx";
            this.dced17ReSufx.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced17ReSufx.OcxState")));
            this.dced17ReSufx.Size = new System.Drawing.Size(125, 23);
            this.dced17ReSufx.TabIndex = 572;
            this.dced17ReSufx.Tag = "17ReSufx";
            // 
            // dced31aPhLNm
            // 
            this.dced31aPhLNm.Location = new System.Drawing.Point(16, 1201);
            this.dced31aPhLNm.Name = "dced31aPhLNm";
            this.dced31aPhLNm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced31aPhLNm.OcxState")));
            this.dced31aPhLNm.Size = new System.Drawing.Size(250, 23);
            this.dced31aPhLNm.TabIndex = 90;
            this.dced31aPhLNm.Tag = "31aPhLNm";
            // 
            // dced31aPhFNm
            // 
            this.dced31aPhFNm.Location = new System.Drawing.Point(16, 1238);
            this.dced31aPhFNm.Name = "dced31aPhFNm";
            this.dced31aPhFNm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced31aPhFNm.OcxState")));
            this.dced31aPhFNm.Size = new System.Drawing.Size(203, 23);
            this.dced31aPhFNm.TabIndex = 92;
            this.dced31aPhFNm.Tag = "31aPhFNm";
            // 
            // dced31aPhIni
            // 
            this.dced31aPhIni.Location = new System.Drawing.Point(227, 1238);
            this.dced31aPhIni.Name = "dced31aPhIni";
            this.dced31aPhIni.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced31aPhIni.OcxState")));
            this.dced31aPhIni.Size = new System.Drawing.Size(39, 23);
            this.dced31aPhIni.TabIndex = 94;
            this.dced31aPhIni.Tag = "31aPhIni";
            // 
            // dced32FacNam
            // 
            this.dced32FacNam.Location = new System.Drawing.Point(339, 1210);
            this.dced32FacNam.Name = "dced32FacNam";
            this.dced32FacNam.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced32FacNam.OcxState")));
            this.dced32FacNam.Size = new System.Drawing.Size(250, 23);
            this.dced32FacNam.TabIndex = 107;
            this.dced32FacNam.Tag = "32FacNam";
            // 
            // dced32F1Addr
            // 
            this.dced32F1Addr.Location = new System.Drawing.Point(339, 1249);
            this.dced32F1Addr.Name = "dced32F1Addr";
            this.dced32F1Addr.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced32F1Addr.OcxState")));
            this.dced32F1Addr.Size = new System.Drawing.Size(250, 23);
            this.dced32F1Addr.TabIndex = 109;
            this.dced32F1Addr.Tag = "32F1Addr";
            // 
            // dced32F2Addr
            // 
            this.dced32F2Addr.Location = new System.Drawing.Point(339, 1288);
            this.dced32F2Addr.Name = "dced32F2Addr";
            this.dced32F2Addr.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced32F2Addr.OcxState")));
            this.dced32F2Addr.Size = new System.Drawing.Size(250, 23);
            this.dced32F2Addr.TabIndex = 111;
            this.dced32F2Addr.Tag = "32F2Addr";
            // 
            // dced32FacCit
            // 
            this.dced32FacCit.Location = new System.Drawing.Point(339, 1327);
            this.dced32FacCit.Name = "dced32FacCit";
            this.dced32FacCit.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced32FacCit.OcxState")));
            this.dced32FacCit.Size = new System.Drawing.Size(179, 23);
            this.dced32FacCit.TabIndex = 113;
            this.dced32FacCit.Tag = "32FacCit";
            // 
            // dced32FacSta
            // 
            this.dced32FacSta.Location = new System.Drawing.Point(526, 1327);
            this.dced32FacSta.Name = "dced32FacSta";
            this.dced32FacSta.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced32FacSta.OcxState")));
            this.dced32FacSta.Size = new System.Drawing.Size(62, 23);
            this.dced32FacSta.TabIndex = 115;
            this.dced32FacSta.Tag = "32FacSta";
            // 
            // dced32FacZip
            // 
            this.dced32FacZip.Location = new System.Drawing.Point(339, 1366);
            this.dced32FacZip.Name = "dced32FacZip";
            this.dced32FacZip.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced32FacZip.OcxState")));
            this.dced32FacZip.Size = new System.Drawing.Size(250, 23);
            this.dced32FacZip.TabIndex = 117;
            this.dced32FacZip.Tag = "32FacZip";
            // 
            // dced33PhBNam
            // 
            this.dced33PhBNam.Location = new System.Drawing.Point(668, 1210);
            this.dced33PhBNam.Name = "dced33PhBNam";
            this.dced33PhBNam.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced33PhBNam.OcxState")));
            this.dced33PhBNam.Size = new System.Drawing.Size(250, 23);
            this.dced33PhBNam.TabIndex = 125;
            this.dced33PhBNam.Tag = "33PhBNam";
            // 
            // dced33Ph1Add
            // 
            this.dced33Ph1Add.Location = new System.Drawing.Point(668, 1249);
            this.dced33Ph1Add.Name = "dced33Ph1Add";
            this.dced33Ph1Add.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced33Ph1Add.OcxState")));
            this.dced33Ph1Add.Size = new System.Drawing.Size(250, 23);
            this.dced33Ph1Add.TabIndex = 127;
            this.dced33Ph1Add.Tag = "33Ph1Add";
            // 
            // dced33Ph2Add
            // 
            this.dced33Ph2Add.Location = new System.Drawing.Point(668, 1288);
            this.dced33Ph2Add.Name = "dced33Ph2Add";
            this.dced33Ph2Add.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced33Ph2Add.OcxState")));
            this.dced33Ph2Add.Size = new System.Drawing.Size(250, 23);
            this.dced33Ph2Add.TabIndex = 129;
            this.dced33Ph2Add.Tag = "33Ph2Add";
            // 
            // dced33PhCity
            // 
            this.dced33PhCity.Location = new System.Drawing.Point(668, 1327);
            this.dced33PhCity.Name = "dced33PhCity";
            this.dced33PhCity.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced33PhCity.OcxState")));
            this.dced33PhCity.Size = new System.Drawing.Size(179, 23);
            this.dced33PhCity.TabIndex = 131;
            this.dced33PhCity.Tag = "33PhCity";
            // 
            // dced33PhStat
            // 
            this.dced33PhStat.Location = new System.Drawing.Point(854, 1327);
            this.dced33PhStat.Name = "dced33PhStat";
            this.dced33PhStat.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced33PhStat.OcxState")));
            this.dced33PhStat.Size = new System.Drawing.Size(62, 23);
            this.dced33PhStat.TabIndex = 133;
            this.dced33PhStat.Tag = "33PhStat";
            // 
            // dced33PhyZip
            // 
            this.dced33PhyZip.Location = new System.Drawing.Point(668, 1366);
            this.dced33PhyZip.Name = "dced33PhyZip";
            this.dced33PhyZip.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced33PhyZip.OcxState")));
            this.dced33PhyZip.Size = new System.Drawing.Size(250, 23);
            this.dced33PhyZip.TabIndex = 135;
            this.dced33PhyZip.Tag = "33PhyZip";
            // 
            // dced33PhyNPI
            // 
            this.dced33PhyNPI.Location = new System.Drawing.Point(668, 1405);
            this.dced33PhyNPI.Name = "dced33PhyNPI";
            this.dced33PhyNPI.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced33PhyNPI.OcxState")));
            this.dced33PhyNPI.Size = new System.Drawing.Size(125, 23);
            this.dced33PhyNPI.TabIndex = 623;
            this.dced33PhyNPI.Tag = "33PhyNPI";
            // 
            // dced33PhyID
            // 
            this.dced33PhyID.Location = new System.Drawing.Point(800, 1405);
            this.dced33PhyID.Name = "dced33PhyID";
            this.dced33PhyID.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced33PhyID.OcxState")));
            this.dced33PhyID.Size = new System.Drawing.Size(117, 23);
            this.dced33PhyID.TabIndex = 626;
            this.dced33PhyID.Tag = "33PhyID";
            // 
            // lbEPSD
            // 
            this.lbEPSD.AutoSize = true;
            this.lbEPSD.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbEPSD.Location = new System.Drawing.Point(278, 1487);
            this.lbEPSD.Name = "lbEPSD";
            this.lbEPSD.Size = new System.Drawing.Size(40, 14);
            this.lbEPSD.TabIndex = 168;
            this.lbEPSD.Tag = "EPSD";
            this.lbEPSD.Text = "EPSD";
            this.lbEPSD.Visible = false;
            // 
            // lbReferenceId
            // 
            this.lbReferenceId.BackColor = System.Drawing.Color.Beige;
            this.lbReferenceId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbReferenceId.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbReferenceId.Location = new System.Drawing.Point(734, 623);
            this.lbReferenceId.Name = "lbReferenceId";
            this.lbReferenceId.Size = new System.Drawing.Size(180, 16);
            this.lbReferenceId.TabIndex = 165;
            this.lbReferenceId.Tag = "ReferenceId";
            this.lbReferenceId.Text = "Reference ID";
            this.lbReferenceId.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lbCOB
            // 
            this.lbCOB.AutoSize = true;
            this.lbCOB.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCOB.Location = new System.Drawing.Point(131, 1487);
            this.lbCOB.Name = "lbCOB";
            this.lbCOB.Size = new System.Drawing.Size(34, 14);
            this.lbCOB.TabIndex = 162;
            this.lbCOB.Tag = "COB";
            this.lbCOB.Text = "COB";
            this.lbCOB.Visible = false;
            // 
            // dcimEPSD
            // 
            this.dcimEPSD.Location = new System.Drawing.Point(281, 1504);
            this.dcimEPSD.Name = "dcimEPSD";
            this.dcimEPSD.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimEPSD.OcxState")));
            this.dcimEPSD.Size = new System.Drawing.Size(40, 23);
            this.dcimEPSD.TabIndex = 169;
            this.dcimEPSD.TabStop = false;
            this.dcimEPSD.Tag = "EPSD";
            this.dcimEPSD.Visible = false;
            // 
            // dcedEPSD
            // 
            this.dcedEPSD.Location = new System.Drawing.Point(281, 1526);
            this.dcedEPSD.Name = "dcedEPSD";
            this.dcedEPSD.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedEPSD.OcxState")));
            this.dcedEPSD.Size = new System.Drawing.Size(40, 23);
            this.dcedEPSD.TabIndex = 170;
            this.dcedEPSD.Tag = "EPSD";
            this.dcedEPSD.Visible = false;
            // 
            // dcimCOB
            // 
            this.dcimCOB.Location = new System.Drawing.Point(120, 1504);
            this.dcimCOB.Name = "dcimCOB";
            this.dcimCOB.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimCOB.OcxState")));
            this.dcimCOB.Size = new System.Drawing.Size(65, 23);
            this.dcimCOB.TabIndex = 163;
            this.dcimCOB.TabStop = false;
            this.dcimCOB.Tag = "COB";
            this.dcimCOB.Visible = false;
            // 
            // dcedCOB
            // 
            this.dcedCOB.Location = new System.Drawing.Point(120, 1526);
            this.dcedCOB.Name = "dcedCOB";
            this.dcedCOB.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedCOB.OcxState")));
            this.dcedCOB.Size = new System.Drawing.Size(65, 23);
            this.dcedCOB.TabIndex = 164;
            this.dcedCOB.Tag = "COB";
            this.dcedCOB.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(194, 174);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 13);
            this.label3.TabIndex = 13;
            this.label3.Text = "Last Name";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(194, 213);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 13);
            this.label5.TabIndex = 15;
            this.label5.Text = "First Name";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(444, 213);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(19, 13);
            this.label6.TabIndex = 17;
            this.label6.Text = "MI";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(194, 252);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(88, 13);
            this.label7.TabIndex = 19;
            this.label7.Text = "Patient\'s Address";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(194, 291);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(24, 13);
            this.label8.TabIndex = 21;
            this.label8.Text = "City";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(444, 291);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(32, 13);
            this.label9.TabIndex = 23;
            this.label9.Text = "State";
            this.label9.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(194, 330);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(50, 13);
            this.label10.TabIndex = 25;
            this.label10.Text = "Zip Code";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(568, 174);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(58, 13);
            this.label18.TabIndex = 29;
            this.label18.Text = "Last Name";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(568, 213);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(57, 13);
            this.label19.TabIndex = 31;
            this.label19.Text = "First Name";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(568, 252);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(88, 13);
            this.label20.TabIndex = 35;
            this.label20.Text = "Patient\'s Address";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(818, 213);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(19, 13);
            this.label21.TabIndex = 33;
            this.label21.Text = "MI";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(568, 291);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(24, 13);
            this.label22.TabIndex = 37;
            this.label22.Text = "City";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(818, 291);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(32, 13);
            this.label23.TabIndex = 39;
            this.label23.Text = "State";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(568, 330);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(50, 13);
            this.label24.TabIndex = 41;
            this.label24.Text = "Zip Code";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(688, 330);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(58, 13);
            this.label25.TabIndex = 43;
            this.label25.Text = "Telephone";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(13, 1187);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(58, 13);
            this.label32.TabIndex = 89;
            this.label32.Text = "Last Name";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(13, 1224);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(57, 13);
            this.label33.TabIndex = 91;
            this.label33.Text = "First Name";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(224, 1224);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(19, 13);
            this.label34.TabIndex = 93;
            this.label34.Text = "MI";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(336, 1196);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(70, 13);
            this.label35.TabIndex = 106;
            this.label35.Text = "Facility Name";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(336, 1235);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(54, 13);
            this.label36.TabIndex = 108;
            this.label36.Text = "Address 1";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(336, 1274);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(54, 13);
            this.label37.TabIndex = 110;
            this.label37.Text = "Address 2";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(336, 1313);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(24, 13);
            this.label38.TabIndex = 112;
            this.label38.Text = "City";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(523, 1313);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(32, 13);
            this.label39.TabIndex = 114;
            this.label39.Text = "State";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(336, 1352);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(50, 13);
            this.label40.TabIndex = 116;
            this.label40.Text = "Zip Code";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(336, 1392);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(25, 13);
            this.label41.TabIndex = 118;
            this.label41.Text = "NPI";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(468, 1392);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(18, 13);
            this.label42.TabIndex = 120;
            this.label42.Text = "ID";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(666, 1196);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(83, 13);
            this.label43.TabIndex = 124;
            this.label43.Text = "Physician Name";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(666, 1235);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(54, 13);
            this.label44.TabIndex = 126;
            this.label44.Text = "Address 1";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(666, 1274);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(54, 13);
            this.label45.TabIndex = 128;
            this.label45.Text = "Address 2";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(666, 1313);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(24, 13);
            this.label46.TabIndex = 130;
            this.label46.Text = "City";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(851, 1313);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(32, 13);
            this.label47.TabIndex = 132;
            this.label47.Text = "State";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(666, 1352);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(50, 13);
            this.label48.TabIndex = 134;
            this.label48.Text = "Zip Code";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(666, 1391);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(25, 13);
            this.label49.TabIndex = 136;
            this.label49.Text = "NPI";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(797, 1391);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(30, 13);
            this.label50.TabIndex = 138;
            this.label50.Text = "GRP";
            // 
            // lbDateFrom
            // 
            this.lbDateFrom.BackColor = System.Drawing.Color.Beige;
            this.lbDateFrom.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDateFrom.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDateFrom.Location = new System.Drawing.Point(21, 641);
            this.lbDateFrom.Name = "lbDateFrom";
            this.lbDateFrom.Size = new System.Drawing.Size(190, 16);
            this.lbDateFrom.TabIndex = 627;
            this.lbDateFrom.Tag = "DateFrom";
            this.lbDateFrom.Text = "Dates of Service (from-to)";
            // 
            // lbPlaceofService
            // 
            this.lbPlaceofService.BackColor = System.Drawing.Color.Beige;
            this.lbPlaceofService.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbPlaceofService.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPlaceofService.Location = new System.Drawing.Point(212, 641);
            this.lbPlaceofService.Name = "lbPlaceofService";
            this.lbPlaceofService.Size = new System.Drawing.Size(50, 16);
            this.lbPlaceofService.TabIndex = 629;
            this.lbPlaceofService.Tag = "PlaceofService";
            this.lbPlaceofService.Text = "POS";
            this.lbPlaceofService.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lbTypeofService
            // 
            this.lbTypeofService.BackColor = System.Drawing.Color.Beige;
            this.lbTypeofService.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbTypeofService.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTypeofService.Location = new System.Drawing.Point(264, 641);
            this.lbTypeofService.Name = "lbTypeofService";
            this.lbTypeofService.Size = new System.Drawing.Size(40, 16);
            this.lbTypeofService.TabIndex = 631;
            this.lbTypeofService.Tag = "TypeofService";
            this.lbTypeofService.Text = "EMG";
            this.lbTypeofService.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lbCPT_Code
            // 
            this.lbCPT_Code.BackColor = System.Drawing.Color.Beige;
            this.lbCPT_Code.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbCPT_Code.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCPT_Code.Location = new System.Drawing.Point(307, 641);
            this.lbCPT_Code.Name = "lbCPT_Code";
            this.lbCPT_Code.Size = new System.Drawing.Size(175, 16);
            this.lbCPT_Code.TabIndex = 632;
            this.lbCPT_Code.Tag = "CPT_Code";
            this.lbCPT_Code.Text = "Procedures/Modifiers";
            this.lbCPT_Code.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lbDiagPointer
            // 
            this.lbDiagPointer.BackColor = System.Drawing.Color.Beige;
            this.lbDiagPointer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDiagPointer.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDiagPointer.Location = new System.Drawing.Point(484, 641);
            this.lbDiagPointer.Name = "lbDiagPointer";
            this.lbDiagPointer.Size = new System.Drawing.Size(55, 16);
            this.lbDiagPointer.TabIndex = 634;
            this.lbDiagPointer.Tag = "DiagPointer";
            this.lbDiagPointer.Text = "Diag";
            this.lbDiagPointer.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lbCharges
            // 
            this.lbCharges.BackColor = System.Drawing.Color.Beige;
            this.lbCharges.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbCharges.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCharges.Location = new System.Drawing.Point(541, 641);
            this.lbCharges.Name = "lbCharges";
            this.lbCharges.Size = new System.Drawing.Size(98, 16);
            this.lbCharges.TabIndex = 635;
            this.lbCharges.Tag = "Charges";
            this.lbCharges.Text = "Charges";
            this.lbCharges.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lbDays_Units
            // 
            this.lbDays_Units.BackColor = System.Drawing.Color.Beige;
            this.lbDays_Units.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDays_Units.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDays_Units.Location = new System.Drawing.Point(640, 641);
            this.lbDays_Units.Name = "lbDays_Units";
            this.lbDays_Units.Size = new System.Drawing.Size(45, 16);
            this.lbDays_Units.TabIndex = 636;
            this.lbDays_Units.Tag = "Days_Units";
            this.lbDays_Units.Text = "Days";
            this.lbDays_Units.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lbInfo
            // 
            this.lbInfo.AutoSize = true;
            this.lbInfo.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbInfo.Location = new System.Drawing.Point(-3, 623);
            this.lbInfo.Name = "lbInfo";
            this.lbInfo.Size = new System.Drawing.Size(27, 14);
            this.lbInfo.TabIndex = 640;
            this.lbInfo.Tag = "Info";
            this.lbInfo.Text = "24.";
            // 
            // lbNPI
            // 
            this.lbNPI.BackColor = System.Drawing.Color.Beige;
            this.lbNPI.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbNPI.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNPI.Location = new System.Drawing.Point(734, 641);
            this.lbNPI.Name = "lbNPI";
            this.lbNPI.Size = new System.Drawing.Size(180, 16);
            this.lbNPI.TabIndex = 639;
            this.lbNPI.Tag = "NPI";
            this.lbNPI.Text = "NPI";
            this.lbNPI.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // panLINEITEM
            // 
            this.panLINEITEM.AutoScroll = true;
            this.panLINEITEM.BackColor = System.Drawing.Color.Beige;
            this.panLINEITEM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panLINEITEM.Controls.Add(this.dcimEMG_C);
            this.panLINEITEM.Controls.Add(this.dcedEMG_C);
            this.panLINEITEM.Controls.Add(this.dcimReferenceId);
            this.panLINEITEM.Controls.Add(this.dcedReferenceId);
            this.panLINEITEM.Controls.Add(this.dcimDateFrom);
            this.panLINEITEM.Controls.Add(this.dcedDateFrom);
            this.panLINEITEM.Controls.Add(this.dcimDateThru);
            this.panLINEITEM.Controls.Add(this.dcedDateThru);
            this.panLINEITEM.Controls.Add(this.dcimPlaceofService);
            this.panLINEITEM.Controls.Add(this.dcedPlaceofService);
            this.panLINEITEM.Controls.Add(this.dcimCPT_Code);
            this.panLINEITEM.Controls.Add(this.dcedCPT_Code);
            this.panLINEITEM.Controls.Add(this.dcimModifiers);
            this.panLINEITEM.Controls.Add(this.dcedModifiers);
            this.panLINEITEM.Controls.Add(this.dcimDiagPointer);
            this.panLINEITEM.Controls.Add(this.dcedDiagPointer);
            this.panLINEITEM.Controls.Add(this.dcimCharges);
            this.panLINEITEM.Controls.Add(this.dcedCharges);
            this.panLINEITEM.Controls.Add(this.dcimDays_Units);
            this.panLINEITEM.Controls.Add(this.dcedDays_Units);
            this.panLINEITEM.Controls.Add(this.dcimQualifier);
            this.panLINEITEM.Controls.Add(this.dcedQualifier);
            this.panLINEITEM.Controls.Add(this.dcimNPI);
            this.panLINEITEM.Controls.Add(this.dcedNPI);
            this.panLINEITEM.Controls.Add(this.dcedInfo);
            this.panLINEITEM.Controls.Add(this.dcimInfo);
            this.panLINEITEM.Location = new System.Drawing.Point(18, 658);
            this.panLINEITEM.Name = "panLINEITEM";
            this.panLINEITEM.Size = new System.Drawing.Size(906, 293);
            this.panLINEITEM.TabIndex = 630;
            this.panLINEITEM.Tag = "LINEITEM";
            // 
            // dcimEMG_C
            // 
            this.dcimEMG_C.Location = new System.Drawing.Point(245, 47);
            this.dcimEMG_C.Name = "dcimEMG_C";
            this.dcimEMG_C.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimEMG_C.OcxState")));
            this.dcimEMG_C.Size = new System.Drawing.Size(43, 23);
            this.dcimEMG_C.TabIndex = 170;
            this.dcimEMG_C.TabStop = false;
            this.dcimEMG_C.Tag = "EMG_C";
            this.dcimEMG_C.Visible = false;
            // 
            // dcedEMG_C
            // 
            this.dcedEMG_C.Location = new System.Drawing.Point(245, 69);
            this.dcedEMG_C.Name = "dcedEMG_C";
            this.dcedEMG_C.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedEMG_C.OcxState")));
            this.dcedEMG_C.Size = new System.Drawing.Size(43, 23);
            this.dcedEMG_C.TabIndex = 171;
            this.dcedEMG_C.Tag = "EMG_C";
            this.dcedEMG_C.Visible = false;
            // 
            // dcimReferenceId
            // 
            this.dcimReferenceId.Location = new System.Drawing.Point(713, 2);
            this.dcimReferenceId.Name = "dcimReferenceId";
            this.dcimReferenceId.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimReferenceId.OcxState")));
            this.dcimReferenceId.Size = new System.Drawing.Size(177, 23);
            this.dcimReferenceId.TabIndex = 168;
            this.dcimReferenceId.TabStop = false;
            this.dcimReferenceId.Tag = "ReferenceId";
            this.dcimReferenceId.Visible = false;
            // 
            // dcedReferenceId
            // 
            this.dcedReferenceId.Location = new System.Drawing.Point(713, 24);
            this.dcedReferenceId.Name = "dcedReferenceId";
            this.dcedReferenceId.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedReferenceId.OcxState")));
            this.dcedReferenceId.Size = new System.Drawing.Size(177, 23);
            this.dcedReferenceId.TabIndex = 169;
            this.dcedReferenceId.Tag = "ReferenceId";
            this.dcedReferenceId.Visible = false;
            // 
            // dcimDateFrom
            // 
            this.dcimDateFrom.Location = new System.Drawing.Point(0, 47);
            this.dcimDateFrom.Name = "dcimDateFrom";
            this.dcimDateFrom.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimDateFrom.OcxState")));
            this.dcimDateFrom.Size = new System.Drawing.Size(96, 23);
            this.dcimDateFrom.TabIndex = 0;
            this.dcimDateFrom.TabStop = false;
            this.dcimDateFrom.Tag = "DateFrom";
            // 
            // dcedDateFrom
            // 
            this.dcedDateFrom.Location = new System.Drawing.Point(0, 69);
            this.dcedDateFrom.Name = "dcedDateFrom";
            this.dcedDateFrom.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedDateFrom.OcxState")));
            this.dcedDateFrom.Size = new System.Drawing.Size(96, 23);
            this.dcedDateFrom.TabIndex = 1;
            this.dcedDateFrom.Tag = "DateFrom";
            // 
            // dcimDateThru
            // 
            this.dcimDateThru.Location = new System.Drawing.Point(96, 47);
            this.dcimDateThru.Name = "dcimDateThru";
            this.dcimDateThru.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimDateThru.OcxState")));
            this.dcimDateThru.Size = new System.Drawing.Size(96, 23);
            this.dcimDateThru.TabIndex = 2;
            this.dcimDateThru.TabStop = false;
            this.dcimDateThru.Tag = "DateThru";
            // 
            // dcedDateThru
            // 
            this.dcedDateThru.Location = new System.Drawing.Point(96, 69);
            this.dcedDateThru.Name = "dcedDateThru";
            this.dcedDateThru.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedDateThru.OcxState")));
            this.dcedDateThru.Size = new System.Drawing.Size(96, 23);
            this.dcedDateThru.TabIndex = 3;
            this.dcedDateThru.Tag = "DateThru";
            // 
            // dcimPlaceofService
            // 
            this.dcimPlaceofService.Location = new System.Drawing.Point(192, 47);
            this.dcimPlaceofService.Name = "dcimPlaceofService";
            this.dcimPlaceofService.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimPlaceofService.OcxState")));
            this.dcimPlaceofService.Size = new System.Drawing.Size(53, 23);
            this.dcimPlaceofService.TabIndex = 4;
            this.dcimPlaceofService.TabStop = false;
            this.dcimPlaceofService.Tag = "PlaceofService";
            // 
            // dcedPlaceofService
            // 
            this.dcedPlaceofService.Location = new System.Drawing.Point(192, 69);
            this.dcedPlaceofService.Name = "dcedPlaceofService";
            this.dcedPlaceofService.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedPlaceofService.OcxState")));
            this.dcedPlaceofService.Size = new System.Drawing.Size(53, 23);
            this.dcedPlaceofService.TabIndex = 5;
            this.dcedPlaceofService.Tag = "PlaceofService";
            // 
            // dcimCPT_Code
            // 
            this.dcimCPT_Code.Location = new System.Drawing.Point(288, 47);
            this.dcimCPT_Code.Name = "dcimCPT_Code";
            this.dcimCPT_Code.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimCPT_Code.OcxState")));
            this.dcimCPT_Code.Size = new System.Drawing.Size(88, 23);
            this.dcimCPT_Code.TabIndex = 8;
            this.dcimCPT_Code.TabStop = false;
            this.dcimCPT_Code.Tag = "CPT_Code";
            // 
            // dcedCPT_Code
            // 
            this.dcedCPT_Code.Location = new System.Drawing.Point(288, 69);
            this.dcedCPT_Code.Name = "dcedCPT_Code";
            this.dcedCPT_Code.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedCPT_Code.OcxState")));
            this.dcedCPT_Code.Size = new System.Drawing.Size(88, 23);
            this.dcedCPT_Code.TabIndex = 9;
            this.dcedCPT_Code.Tag = "CPT_Code";
            // 
            // dcimModifiers
            // 
            this.dcimModifiers.Location = new System.Drawing.Point(375, 47);
            this.dcimModifiers.Name = "dcimModifiers";
            this.dcimModifiers.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimModifiers.OcxState")));
            this.dcimModifiers.Size = new System.Drawing.Size(88, 23);
            this.dcimModifiers.TabIndex = 10;
            this.dcimModifiers.TabStop = false;
            this.dcimModifiers.Tag = "Modifiers";
            // 
            // dcedModifiers
            // 
            this.dcedModifiers.Location = new System.Drawing.Point(375, 69);
            this.dcedModifiers.Name = "dcedModifiers";
            this.dcedModifiers.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedModifiers.OcxState")));
            this.dcedModifiers.Size = new System.Drawing.Size(88, 23);
            this.dcedModifiers.TabIndex = 11;
            this.dcedModifiers.Tag = "Modifiers";
            // 
            // dcimDiagPointer
            // 
            this.dcimDiagPointer.Location = new System.Drawing.Point(463, 47);
            this.dcimDiagPointer.Name = "dcimDiagPointer";
            this.dcimDiagPointer.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimDiagPointer.OcxState")));
            this.dcimDiagPointer.Size = new System.Drawing.Size(57, 23);
            this.dcimDiagPointer.TabIndex = 12;
            this.dcimDiagPointer.TabStop = false;
            this.dcimDiagPointer.Tag = "DiagPointer";
            // 
            // dcedDiagPointer
            // 
            this.dcedDiagPointer.Location = new System.Drawing.Point(463, 69);
            this.dcedDiagPointer.Name = "dcedDiagPointer";
            this.dcedDiagPointer.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedDiagPointer.OcxState")));
            this.dcedDiagPointer.Size = new System.Drawing.Size(57, 23);
            this.dcedDiagPointer.TabIndex = 13;
            this.dcedDiagPointer.Tag = "DiagPointer";
            // 
            // dcimCharges
            // 
            this.dcimCharges.Location = new System.Drawing.Point(520, 47);
            this.dcimCharges.Name = "dcimCharges";
            this.dcimCharges.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimCharges.OcxState")));
            this.dcimCharges.Size = new System.Drawing.Size(101, 23);
            this.dcimCharges.TabIndex = 14;
            this.dcimCharges.TabStop = false;
            this.dcimCharges.Tag = "Charges";
            // 
            // dcedCharges
            // 
            this.dcedCharges.Location = new System.Drawing.Point(520, 69);
            this.dcedCharges.Name = "dcedCharges";
            this.dcedCharges.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedCharges.OcxState")));
            this.dcedCharges.Size = new System.Drawing.Size(101, 23);
            this.dcedCharges.TabIndex = 15;
            this.dcedCharges.Tag = "Charges";
            // 
            // dcimDays_Units
            // 
            this.dcimDays_Units.Location = new System.Drawing.Point(621, 47);
            this.dcimDays_Units.Name = "dcimDays_Units";
            this.dcimDays_Units.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimDays_Units.OcxState")));
            this.dcimDays_Units.Size = new System.Drawing.Size(45, 23);
            this.dcimDays_Units.TabIndex = 16;
            this.dcimDays_Units.TabStop = false;
            this.dcimDays_Units.Tag = "Days_Units";
            // 
            // dcedDays_Units
            // 
            this.dcedDays_Units.Location = new System.Drawing.Point(621, 69);
            this.dcedDays_Units.Name = "dcedDays_Units";
            this.dcedDays_Units.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedDays_Units.OcxState")));
            this.dcedDays_Units.Size = new System.Drawing.Size(45, 23);
            this.dcedDays_Units.TabIndex = 17;
            this.dcedDays_Units.Tag = "Days_Units";
            // 
            // dcimQualifier
            // 
            this.dcimQualifier.Location = new System.Drawing.Point(666, 2);
            this.dcimQualifier.Name = "dcimQualifier";
            this.dcimQualifier.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimQualifier.OcxState")));
            this.dcimQualifier.Size = new System.Drawing.Size(47, 23);
            this.dcimQualifier.TabIndex = 18;
            this.dcimQualifier.TabStop = false;
            this.dcimQualifier.Tag = "Qualifier";
            // 
            // dcedQualifier
            // 
            this.dcedQualifier.Location = new System.Drawing.Point(666, 24);
            this.dcedQualifier.Name = "dcedQualifier";
            this.dcedQualifier.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedQualifier.OcxState")));
            this.dcedQualifier.Size = new System.Drawing.Size(47, 23);
            this.dcedQualifier.TabIndex = 19;
            this.dcedQualifier.Tag = "Qualifier";
            // 
            // dcimNPI
            // 
            this.dcimNPI.Location = new System.Drawing.Point(713, 47);
            this.dcimNPI.Name = "dcimNPI";
            this.dcimNPI.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimNPI.OcxState")));
            this.dcimNPI.Size = new System.Drawing.Size(177, 23);
            this.dcimNPI.TabIndex = 22;
            this.dcimNPI.TabStop = false;
            this.dcimNPI.Tag = "NPI";
            // 
            // dcedNPI
            // 
            this.dcedNPI.Location = new System.Drawing.Point(713, 69);
            this.dcedNPI.Name = "dcedNPI";
            this.dcedNPI.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedNPI.OcxState")));
            this.dcedNPI.Size = new System.Drawing.Size(177, 23);
            this.dcedNPI.TabIndex = 23;
            this.dcedNPI.Tag = "NPI";
            // 
            // dcedInfo
            // 
            this.dcedInfo.Location = new System.Drawing.Point(0, 24);
            this.dcedInfo.Name = "dcedInfo";
            this.dcedInfo.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedInfo.OcxState")));
            this.dcedInfo.Size = new System.Drawing.Size(666, 23);
            this.dcedInfo.TabIndex = 25;
            this.dcedInfo.Tag = "Info";
            // 
            // dcimInfo
            // 
            this.dcimInfo.Location = new System.Drawing.Point(0, 2);
            this.dcimInfo.Name = "dcimInfo";
            this.dcimInfo.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimInfo.OcxState")));
            this.dcimInfo.Size = new System.Drawing.Size(666, 23);
            this.dcimInfo.TabIndex = 24;
            this.dcimInfo.TabStop = false;
            this.dcimInfo.Tag = "Info";
            // 
            // btnDelpbLINEITEM
            // 
            this.btnDelpbLINEITEM.Location = new System.Drawing.Point(137, 955);
            this.btnDelpbLINEITEM.Name = "btnDelpbLINEITEM";
            this.btnDelpbLINEITEM.Size = new System.Drawing.Size(55, 23);
            this.btnDelpbLINEITEM.TabIndex = 643;
            this.btnDelpbLINEITEM.Tag = "LINEITEM";
            this.btnDelpbLINEITEM.Text = "Delete";
            this.btnDelpbLINEITEM.UseVisualStyleBackColor = true;
            // 
            // btnInsAfterpbLINEITEM
            // 
            this.btnInsAfterpbLINEITEM.Location = new System.Drawing.Point(76, 955);
            this.btnInsAfterpbLINEITEM.Name = "btnInsAfterpbLINEITEM";
            this.btnInsAfterpbLINEITEM.Size = new System.Drawing.Size(55, 23);
            this.btnInsAfterpbLINEITEM.TabIndex = 642;
            this.btnInsAfterpbLINEITEM.Tag = "LINEITEM";
            this.btnInsAfterpbLINEITEM.Text = "Append";
            this.btnInsAfterpbLINEITEM.UseVisualStyleBackColor = true;
            // 
            // btnInsBeforepbLINEITEM
            // 
            this.btnInsBeforepbLINEITEM.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnInsBeforepbLINEITEM.Location = new System.Drawing.Point(15, 955);
            this.btnInsBeforepbLINEITEM.Name = "btnInsBeforepbLINEITEM";
            this.btnInsBeforepbLINEITEM.Size = new System.Drawing.Size(55, 23);
            this.btnInsBeforepbLINEITEM.TabIndex = 641;
            this.btnInsBeforepbLINEITEM.Tag = "LINEITEM";
            this.btnInsBeforepbLINEITEM.Text = "Insert";
            this.btnInsBeforepbLINEITEM.UseVisualStyleBackColor = true;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.BackColor = System.Drawing.Color.Lavender;
            this.label31.Location = new System.Drawing.Point(822, 573);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(16, 13);
            this.label31.TabIndex = 653;
            this.label31.Text = "4.";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.BackColor = System.Drawing.Color.Lavender;
            this.label30.Location = new System.Drawing.Point(822, 536);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(16, 13);
            this.label30.TabIndex = 651;
            this.label30.Text = "3.";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.BackColor = System.Drawing.Color.Lavender;
            this.label29.Location = new System.Drawing.Point(734, 573);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(16, 13);
            this.label29.TabIndex = 649;
            this.label29.Text = "2.";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.BackColor = System.Drawing.Color.Lavender;
            this.label28.Location = new System.Drawing.Point(734, 536);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(16, 13);
            this.label28.TabIndex = 647;
            this.label28.Text = "1.";
            // 
            // dcim7IAddStr
            // 
            this.dcim7IAddStr.Location = new System.Drawing.Point(257, 518);
            this.dcim7IAddStr.Name = "dcim7IAddStr";
            this.dcim7IAddStr.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim7IAddStr.OcxState")));
            this.dcim7IAddStr.Size = new System.Drawing.Size(473, 73);
            this.dcim7IAddStr.TabIndex = 646;
            this.dcim7IAddStr.TabStop = false;
            this.dcim7IAddStr.Tag = "21DiSFLD";
            // 
            // lbl7IAddSta
            // 
            this.lbl7IAddSta.AutoSize = true;
            this.lbl7IAddSta.BackColor = System.Drawing.Color.Lavender;
            this.lbl7IAddSta.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl7IAddSta.Location = new System.Drawing.Point(254, 502);
            this.lbl7IAddSta.Name = "lbl7IAddSta";
            this.lbl7IAddSta.Size = new System.Drawing.Size(129, 14);
            this.lbl7IAddSta.TabIndex = 645;
            this.lbl7IAddSta.Tag = "";
            this.lbl7IAddSta.Text = "21. Diagnosis Code";
            // 
            // dced21_Diag1
            // 
            this.dced21_Diag1.Location = new System.Drawing.Point(751, 526);
            this.dced21_Diag1.Name = "dced21_Diag1";
            this.dced21_Diag1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced21_Diag1.OcxState")));
            this.dced21_Diag1.Size = new System.Drawing.Size(70, 23);
            this.dced21_Diag1.TabIndex = 648;
            this.dced21_Diag1.Tag = "21_Diag1";
            // 
            // dced21_Diag2
            // 
            this.dced21_Diag2.Location = new System.Drawing.Point(751, 563);
            this.dced21_Diag2.Name = "dced21_Diag2";
            this.dced21_Diag2.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced21_Diag2.OcxState")));
            this.dced21_Diag2.Size = new System.Drawing.Size(70, 23);
            this.dced21_Diag2.TabIndex = 650;
            this.dced21_Diag2.Tag = "21_Diag2";
            // 
            // dced21_Diag3
            // 
            this.dced21_Diag3.Location = new System.Drawing.Point(839, 526);
            this.dced21_Diag3.Name = "dced21_Diag3";
            this.dced21_Diag3.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced21_Diag3.OcxState")));
            this.dced21_Diag3.Size = new System.Drawing.Size(70, 23);
            this.dced21_Diag3.TabIndex = 652;
            this.dced21_Diag3.Tag = "21_Diag3";
            // 
            // dced21_Diag4
            // 
            this.dced21_Diag4.Location = new System.Drawing.Point(839, 563);
            this.dced21_Diag4.Name = "dced21_Diag4";
            this.dced21_Diag4.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced21_Diag4.OcxState")));
            this.dced21_Diag4.Size = new System.Drawing.Size(70, 23);
            this.dced21_Diag4.TabIndex = 654;
            this.dced21_Diag4.Tag = "21_Diag4";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(10, 544);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 14);
            this.label1.TabIndex = 655;
            this.label1.Tag = "";
            this.label1.Text = "17b. NPI ID";
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Beige;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(687, 623);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 16);
            this.label2.TabIndex = 657;
            this.label2.Tag = "ReferenceId";
            this.label2.Text = "Qual ID";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.Beige;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label4.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(21, 623);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(663, 16);
            this.label4.TabIndex = 658;
            this.label4.Tag = "Info";
            this.label4.Text = "Service Information";
            this.label4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label4.UseMnemonic = false;
            // 
            // btnSwapNm31
            // 
            this.btnSwapNm31.Image = global::MedicalClaimsPanels.Properties.Resources.sw90neg;
            this.btnSwapNm31.Location = new System.Drawing.Point(269, 1208);
            this.btnSwapNm31.Name = "btnSwapNm31";
            this.btnSwapNm31.Size = new System.Drawing.Size(35, 45);
            this.btnSwapNm31.TabIndex = 663;
            this.btnSwapNm31.UseVisualStyleBackColor = true;
            this.btnSwapNm31.Click += new System.EventHandler(this.btnSwapNm31_Click);
            // 
            // lblcopynm
            // 
            this.lblcopynm.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcopynm.Location = new System.Drawing.Point(518, 161);
            this.lblcopynm.Name = "lblcopynm";
            this.lblcopynm.Size = new System.Drawing.Size(47, 49);
            this.lblcopynm.TabIndex = 665;
            this.lblcopynm.Text = "Copy Name";
            this.lblcopynm.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCopyAddress
            // 
            this.lblCopyAddress.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCopyAddress.Location = new System.Drawing.Point(514, 265);
            this.lblCopyAddress.Name = "lblCopyAddress";
            this.lblCopyAddress.Size = new System.Drawing.Size(59, 49);
            this.lblCopyAddress.TabIndex = 666;
            this.lblCopyAddress.Text = "Copy Address";
            this.lblCopyAddress.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(314, 330);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(58, 13);
            this.label11.TabIndex = 667;
            this.label11.Text = "Telephone";
            // 
            // dced5PAddTel
            // 
            this.dced5PAddTel.Location = new System.Drawing.Point(317, 343);
            this.dced5PAddTel.Name = "dced5PAddTel";
            this.dced5PAddTel.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced5PAddTel.OcxState")));
            this.dced5PAddTel.Size = new System.Drawing.Size(192, 23);
            this.dced5PAddTel.TabIndex = 668;
            this.dced5PAddTel.Tag = "5PAddTel";
            // 
            // lblCopyAll
            // 
            this.lblCopyAll.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCopyAll.Location = new System.Drawing.Point(604, 1201);
            this.lblCopyAll.Name = "lblCopyAll";
            this.lblCopyAll.Size = new System.Drawing.Size(47, 49);
            this.lblCopyAll.TabIndex = 666;
            this.lblCopyAll.Text = "Copy All";
            this.lblCopyAll.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button7
            // 
            this.button7.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.Image = global::MedicalClaimsPanels.Properties.Resources.golt;
            this.button7.Location = new System.Drawing.Point(609, 1273);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(35, 32);
            this.button7.TabIndex = 660;
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button6
            // 
            this.button6.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Image = global::MedicalClaimsPanels.Properties.Resources.gort;
            this.button6.Location = new System.Drawing.Point(609, 1242);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(35, 32);
            this.button6.TabIndex = 664;
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // btnCopyAdd2to4
            // 
            this.btnCopyAdd2to4.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCopyAdd2to4.Image = global::MedicalClaimsPanels.Properties.Resources.gort;
            this.btnCopyAdd2to4.Location = new System.Drawing.Point(524, 303);
            this.btnCopyAdd2to4.Name = "btnCopyAdd2to4";
            this.btnCopyAdd2to4.Size = new System.Drawing.Size(35, 32);
            this.btnCopyAdd2to4.TabIndex = 660;
            this.btnCopyAdd2to4.UseVisualStyleBackColor = true;
            this.btnCopyAdd2to4.Click += new System.EventHandler(this.btnCopyAdd2to4_Click);
            // 
            // btnCopyAdd4to2
            // 
            this.btnCopyAdd4to2.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCopyAdd4to2.Image = global::MedicalClaimsPanels.Properties.Resources.golt;
            this.btnCopyAdd4to2.Location = new System.Drawing.Point(524, 334);
            this.btnCopyAdd4to2.Name = "btnCopyAdd4to2";
            this.btnCopyAdd4to2.Size = new System.Drawing.Size(35, 32);
            this.btnCopyAdd4to2.TabIndex = 660;
            this.btnCopyAdd4to2.UseVisualStyleBackColor = true;
            this.btnCopyAdd4to2.Click += new System.EventHandler(this.btnCopyAdd4to2_Click);
            // 
            // btnCopyNm4to2
            // 
            this.btnCopyNm4to2.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCopyNm4to2.Image = global::MedicalClaimsPanels.Properties.Resources.golt;
            this.btnCopyNm4to2.Location = new System.Drawing.Point(524, 234);
            this.btnCopyNm4to2.Name = "btnCopyNm4to2";
            this.btnCopyNm4to2.Size = new System.Drawing.Size(35, 32);
            this.btnCopyNm4to2.TabIndex = 662;
            this.btnCopyNm4to2.UseVisualStyleBackColor = true;
            this.btnCopyNm4to2.Click += new System.EventHandler(this.btnCopyNm4to2_Click);
            // 
            // btnCopyNm2to4
            // 
            this.btnCopyNm2to4.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCopyNm2to4.Image = global::MedicalClaimsPanels.Properties.Resources.gort;
            this.btnCopyNm2to4.Location = new System.Drawing.Point(524, 203);
            this.btnCopyNm2to4.Name = "btnCopyNm2to4";
            this.btnCopyNm2to4.Size = new System.Drawing.Size(35, 32);
            this.btnCopyNm2to4.TabIndex = 661;
            this.btnCopyNm2to4.UseVisualStyleBackColor = true;
            this.btnCopyNm2to4.Click += new System.EventHandler(this.btnCopyNm2to4_Click);
            // 
            // btnSwapNames4
            // 
            this.btnSwapNames4.Image = global::MedicalClaimsPanels.Properties.Resources.sw90neg;
            this.btnSwapNames4.Location = new System.Drawing.Point(889, 198);
            this.btnSwapNames4.Name = "btnSwapNames4";
            this.btnSwapNames4.Size = new System.Drawing.Size(35, 45);
            this.btnSwapNames4.TabIndex = 660;
            this.btnSwapNames4.UseVisualStyleBackColor = true;
            this.btnSwapNames4.Click += new System.EventHandler(this.btnSwapNames4_Click);
            // 
            // btnSwapNamesFld2
            // 
            this.btnSwapNamesFld2.Image = global::MedicalClaimsPanels.Properties.Resources.sw90pos;
            this.btnSwapNamesFld2.Location = new System.Drawing.Point(157, 197);
            this.btnSwapNamesFld2.Name = "btnSwapNamesFld2";
            this.btnSwapNamesFld2.Size = new System.Drawing.Size(35, 46);
            this.btnSwapNamesFld2.TabIndex = 659;
            this.btnSwapNamesFld2.UseVisualStyleBackColor = true;
            this.btnSwapNamesFld2.Click += new System.EventHandler(this.btnSwapNamesFld2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Lavender;
            this.pictureBox1.Location = new System.Drawing.Point(244, 496);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(673, 109);
            this.pictureBox1.TabIndex = 656;
            this.pictureBox1.TabStop = false;
            // 
            // PClaim
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.BackColor = System.Drawing.Color.MintCream;
            this.ClientSize = new System.Drawing.Size(934, 1462);
            this.ContentSize = new System.Drawing.Size(950, 1500);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.dced5PAddTel);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.btnSwapNm31);
            this.Controls.Add(this.btnCopyAdd2to4);
            this.Controls.Add(this.btnCopyAdd4to2);
            this.Controls.Add(this.btnCopyNm4to2);
            this.Controls.Add(this.btnCopyNm2to4);
            this.Controls.Add(this.btnSwapNames4);
            this.Controls.Add(this.btnSwapNamesFld2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lbl7IAddSta);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.dcim7IAddStr);
            this.Controls.Add(this.dced21_Diag1);
            this.Controls.Add(this.dced21_Diag2);
            this.Controls.Add(this.dced21_Diag3);
            this.Controls.Add(this.dced21_Diag4);
            this.Controls.Add(this.lbDateFrom);
            this.Controls.Add(this.lbPlaceofService);
            this.Controls.Add(this.lbTypeofService);
            this.Controls.Add(this.lbCPT_Code);
            this.Controls.Add(this.lbDiagPointer);
            this.Controls.Add(this.lbCharges);
            this.Controls.Add(this.lbDays_Units);
            this.Controls.Add(this.lbInfo);
            this.Controls.Add(this.lbNPI);
            this.Controls.Add(this.panLINEITEM);
            this.Controls.Add(this.btnDelpbLINEITEM);
            this.Controls.Add(this.btnInsAfterpbLINEITEM);
            this.Controls.Add(this.btnInsBeforepbLINEITEM);
            this.Controls.Add(this.label50);
            this.Controls.Add(this.label49);
            this.Controls.Add(this.label48);
            this.Controls.Add(this.label47);
            this.Controls.Add(this.label46);
            this.Controls.Add(this.label45);
            this.Controls.Add(this.label44);
            this.Controls.Add(this.label43);
            this.Controls.Add(this.label42);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.dcimEPSD);
            this.Controls.Add(this.dcedEPSD);
            this.Controls.Add(this.dcimCOB);
            this.Controls.Add(this.dcedCOB);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dced5PAddStr);
            this.Controls.Add(this.dced5PAddCty);
            this.Controls.Add(this.dcim5PAddSta);
            this.Controls.Add(this.dced5PAddSta);
            this.Controls.Add(this.dcim5PAddZip);
            this.Controls.Add(this.dced5PAddZip);
            this.Controls.Add(this.lbl3Pat_DOB);
            this.Controls.Add(this.dcim3Pat_DOB);
            this.Controls.Add(this.dced3Pat_DOB);
            this.Controls.Add(this.lbl3aPatSex);
            this.Controls.Add(this.dcim3aPatSex);
            this.Controls.Add(this.cmb3aPatSex);
            this.Controls.Add(this.lbl1aInsrID);
            this.Controls.Add(this.dcim1aInsrID);
            this.Controls.Add(this.dced1aInsrID);
            this.Controls.Add(this.lbl7IAddStr);
            this.Controls.Add(this.dced7IAddStr);
            this.Controls.Add(this.lbl7IAddCty);
            this.Controls.Add(this.dced7IAddCty);
            this.Controls.Add(this.dced7IAddSta);
            this.Controls.Add(this.dcim7IAddZip);
            this.Controls.Add(this.dced7IAddZip);
            this.Controls.Add(this.lbl7IAddTel);
            this.Controls.Add(this.dcim33DocAdd);
            this.Controls.Add(this.dced7IAddTel);
            this.Controls.Add(this.lbl11IPolNo);
            this.Controls.Add(this.dcim11IPolNo);
            this.Controls.Add(this.dced11IPolNo);
            this.Controls.Add(this.lbl11aInSex);
            this.Controls.Add(this.dcim11aInSex);
            this.Controls.Add(this.cmb11aInSex);
            this.Controls.Add(this.lbl11aInDOB);
            this.Controls.Add(this.dcim11aInDOB);
            this.Controls.Add(this.dced11aInDOB);
            this.Controls.Add(this.lbl11cIPlan);
            this.Controls.Add(this.dcim11cIPlan);
            this.Controls.Add(this.dced11cIPlan);
            this.Controls.Add(this.lbl11dPlOth);
            this.Controls.Add(this.dcim11dPlOth);
            this.Controls.Add(this.cmb11dPlOth);
            this.Controls.Add(this.lbl17aRfDID);
            this.Controls.Add(this.dcim17aRfDID);
            this.Controls.Add(this.dced17aRfDID);
            this.Controls.Add(this.lbl17aRfCd);
            this.Controls.Add(this.dced17aRfCd);
            this.Controls.Add(this.dcim17bRfNPI);
            this.Controls.Add(this.dced17bRfNPI);
            this.Controls.Add(this.lbl25aFedTx);
            this.Controls.Add(this.dcim25aFedTx);
            this.Controls.Add(this.dced25aFedTx);
            this.Controls.Add(this.lbl26PActNo);
            this.Controls.Add(this.dcim26PActNo);
            this.Controls.Add(this.dced26PActNo);
            this.Controls.Add(this.lbl27AccAss);
            this.Controls.Add(this.dcim27AccAss);
            this.Controls.Add(this.cmb27AccAss);
            this.Controls.Add(this.lbl28TotChg);
            this.Controls.Add(this.dcim28TotChg);
            this.Controls.Add(this.dced28TotChg);
            this.Controls.Add(this.lbl29Amt_Pd);
            this.Controls.Add(this.dcim29Amt_Pd);
            this.Controls.Add(this.dced29Amt_Pd);
            this.Controls.Add(this.lbl30BalDue);
            this.Controls.Add(this.dcim30BalDue);
            this.Controls.Add(this.dced30BalDue);
            this.Controls.Add(this.dcim32FacAdd);
            this.Controls.Add(this.dced32FacNPI);
            this.Controls.Add(this.dced32FacID);
            this.Controls.Add(this.dced33PhyPIN);
            this.Controls.Add(this.dced33PhyGRP);
            this.Controls.Add(this.lbl24aDtFr1);
            this.Controls.Add(this.dced2PaLName);
            this.Controls.Add(this.dced2PaFName);
            this.Controls.Add(this.dced2PaMInit);
            this.Controls.Add(this.dced4InsLNam);
            this.Controls.Add(this.dced4InsFNam);
            this.Controls.Add(this.dced4InsMIni);
            this.Controls.Add(this.dcim17ReCred);
            this.Controls.Add(this.dced17ReCred);
            this.Controls.Add(this.dcim17ReSufx);
            this.Controls.Add(this.dced17ReSufx);
            this.Controls.Add(this.dced31aPhLNm);
            this.Controls.Add(this.dced31aPhFNm);
            this.Controls.Add(this.dced31aPhIni);
            this.Controls.Add(this.dced32FacNam);
            this.Controls.Add(this.dced32F1Addr);
            this.Controls.Add(this.dced32F2Addr);
            this.Controls.Add(this.dced32FacCit);
            this.Controls.Add(this.dced32FacSta);
            this.Controls.Add(this.dced32FacZip);
            this.Controls.Add(this.dced33PhBNam);
            this.Controls.Add(this.dced33Ph1Add);
            this.Controls.Add(this.dced33Ph2Add);
            this.Controls.Add(this.dced33PhCity);
            this.Controls.Add(this.dced33PhStat);
            this.Controls.Add(this.dced33PhyZip);
            this.Controls.Add(this.dced33PhyNPI);
            this.Controls.Add(this.dced33PhyID);
            this.Controls.Add(this.lbEPSD);
            this.Controls.Add(this.lbReferenceId);
            this.Controls.Add(this.lbCOB);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lblcopynm);
            this.Controls.Add(this.lblCopyAddress);
            this.Controls.Add(this.lblCopyAll);
            this.MaximumSize = new System.Drawing.Size(974, 1524);
            this.Name = "PClaim";
            ((System.ComponentModel.ISupportInitialize)(this.dced5PAddStr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced5PAddCty)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim5PAddSta)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced5PAddSta)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim5PAddZip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced5PAddZip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim3Pat_DOB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced3Pat_DOB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim3aPatSex)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim1aInsrID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced1aInsrID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced7IAddStr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced7IAddCty)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced7IAddSta)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim7IAddZip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced7IAddZip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim33DocAdd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced7IAddTel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim11IPolNo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced11IPolNo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim11aInSex)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim11aInDOB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced11aInDOB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim11cIPlan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced11cIPlan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim11dPlOth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim17aRfDID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced17aRfDID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced17aRfCd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim17bRfNPI)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced17bRfNPI)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim25aFedTx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced25aFedTx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim26PActNo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced26PActNo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim27AccAss)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim28TotChg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced28TotChg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim29Amt_Pd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced29Amt_Pd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim30BalDue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced30BalDue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim32FacAdd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced32FacNPI)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced32FacID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced33PhyPIN)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced33PhyGRP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced2PaLName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced2PaFName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced2PaMInit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced4InsLNam)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced4InsFNam)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced4InsMIni)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim17ReCred)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced17ReCred)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim17ReSufx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced17ReSufx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced31aPhLNm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced31aPhFNm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced31aPhIni)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced32FacNam)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced32F1Addr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced32F2Addr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced32FacCit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced32FacSta)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced32FacZip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced33PhBNam)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced33Ph1Add)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced33Ph2Add)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced33PhCity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced33PhStat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced33PhyZip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced33PhyNPI)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced33PhyID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimEPSD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedEPSD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimCOB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedCOB)).EndInit();
            this.panLINEITEM.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dcimEMG_C)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedEMG_C)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimReferenceId)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedReferenceId)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimDateFrom)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedDateFrom)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimDateThru)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedDateThru)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimPlaceofService)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedPlaceofService)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimCPT_Code)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedCPT_Code)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimModifiers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedModifiers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimDiagPointer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedDiagPointer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimCharges)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedCharges)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimDays_Units)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedDays_Units)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimQualifier)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedQualifier)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimNPI)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedNPI)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedInfo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimInfo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim7IAddStr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced21_Diag1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced21_Diag2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced21_Diag3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced21_Diag4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced5PAddTel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private AxDCEDITLib.AxDcedit dced5PAddStr;
        private AxDCEDITLib.AxDcedit dced5PAddCty;
        private AxDCIMAGELib.AxDcimage dcim5PAddSta;
        private AxDCEDITLib.AxDcedit dced5PAddSta;
        private AxDCIMAGELib.AxDcimage dcim5PAddZip;
        private AxDCEDITLib.AxDcedit dced5PAddZip;
        private System.Windows.Forms.Label lbl3Pat_DOB;
        private AxDCIMAGELib.AxDcimage dcim3Pat_DOB;
        private AxDCEDITLib.AxDcedit dced3Pat_DOB;
        private System.Windows.Forms.Label lbl3aPatSex;
        private AxDCIMAGELib.AxDcimage dcim3aPatSex;
        private System.Windows.Forms.ComboBox cmb3aPatSex;
        private System.Windows.Forms.Label lbl1aInsrID;
        private AxDCIMAGELib.AxDcimage dcim1aInsrID;
        private AxDCEDITLib.AxDcedit dced1aInsrID;
        private System.Windows.Forms.Label lbl7IAddStr;
        private AxDCEDITLib.AxDcedit dced7IAddStr;
        private System.Windows.Forms.Label lbl7IAddCty;
        private AxDCEDITLib.AxDcedit dced7IAddCty;
        private AxDCEDITLib.AxDcedit dced7IAddSta;
        private AxDCIMAGELib.AxDcimage dcim7IAddZip;
        private AxDCEDITLib.AxDcedit dced7IAddZip;
        private System.Windows.Forms.Label lbl7IAddTel;
        private AxDCIMAGELib.AxDcimage dcim33DocAdd;
        private AxDCEDITLib.AxDcedit dced7IAddTel;
        private System.Windows.Forms.Label lbl11IPolNo;
        private AxDCIMAGELib.AxDcimage dcim11IPolNo;
        private AxDCEDITLib.AxDcedit dced11IPolNo;
        private System.Windows.Forms.Label lbl11aInSex;
        private AxDCIMAGELib.AxDcimage dcim11aInSex;
        private System.Windows.Forms.ComboBox cmb11aInSex;
        private System.Windows.Forms.Label lbl11aInDOB;
        private AxDCIMAGELib.AxDcimage dcim11aInDOB;
        private AxDCEDITLib.AxDcedit dced11aInDOB;
        private System.Windows.Forms.Label lbl11cIPlan;
        private AxDCIMAGELib.AxDcimage dcim11cIPlan;
        private AxDCEDITLib.AxDcedit dced11cIPlan;
        private System.Windows.Forms.Label lbl11dPlOth;
        private AxDCIMAGELib.AxDcimage dcim11dPlOth;
        private System.Windows.Forms.ComboBox cmb11dPlOth;
        private System.Windows.Forms.Label lbl17aRfDID;
        private AxDCIMAGELib.AxDcimage dcim17aRfDID;
        private AxDCEDITLib.AxDcedit dced17aRfDID;
        private System.Windows.Forms.Label lbl17aRfCd;
        private AxDCEDITLib.AxDcedit dced17aRfCd;
        private AxDCIMAGELib.AxDcimage dcim17bRfNPI;
        private AxDCEDITLib.AxDcedit dced17bRfNPI;
        private System.Windows.Forms.Label lbl25aFedTx;
        private AxDCIMAGELib.AxDcimage dcim25aFedTx;
        private AxDCEDITLib.AxDcedit dced25aFedTx;
        private System.Windows.Forms.Label lbl26PActNo;
        private AxDCIMAGELib.AxDcimage dcim26PActNo;
        private AxDCEDITLib.AxDcedit dced26PActNo;
        private System.Windows.Forms.Label lbl27AccAss;
        private AxDCIMAGELib.AxDcimage dcim27AccAss;
        private System.Windows.Forms.ComboBox cmb27AccAss;
        private System.Windows.Forms.Label lbl28TotChg;
        private AxDCIMAGELib.AxDcimage dcim28TotChg;
        private AxDCEDITLib.AxDcedit dced28TotChg;
        private System.Windows.Forms.Label lbl29Amt_Pd;
        private AxDCIMAGELib.AxDcimage dcim29Amt_Pd;
        private AxDCEDITLib.AxDcedit dced29Amt_Pd;
        private System.Windows.Forms.Label lbl30BalDue;
        private AxDCIMAGELib.AxDcimage dcim30BalDue;
        private AxDCEDITLib.AxDcedit dced30BalDue;
        private AxDCIMAGELib.AxDcimage dcim32FacAdd;
        private AxDCEDITLib.AxDcedit dced32FacNPI;
        private AxDCEDITLib.AxDcedit dced32FacID;
        private AxDCEDITLib.AxDcedit dced33PhyPIN;
        private AxDCEDITLib.AxDcedit dced33PhyGRP;
        private System.Windows.Forms.Label lbl24aDtFr1;
        private AxDCEDITLib.AxDcedit dced2PaLName;
        private AxDCEDITLib.AxDcedit dced2PaFName;
        private AxDCEDITLib.AxDcedit dced2PaMInit;
        private AxDCEDITLib.AxDcedit dced4InsLNam;
        private AxDCEDITLib.AxDcedit dced4InsFNam;
        private AxDCEDITLib.AxDcedit dced4InsMIni;
        private AxDCIMAGELib.AxDcimage dcim17ReCred;
        private AxDCEDITLib.AxDcedit dced17ReCred;
        private AxDCIMAGELib.AxDcimage dcim17ReSufx;
        private AxDCEDITLib.AxDcedit dced17ReSufx;
        private AxDCEDITLib.AxDcedit dced31aPhLNm;
        private AxDCEDITLib.AxDcedit dced31aPhFNm;
        private AxDCEDITLib.AxDcedit dced31aPhIni;
        private AxDCEDITLib.AxDcedit dced32FacNam;
        private AxDCEDITLib.AxDcedit dced32F1Addr;
        private AxDCEDITLib.AxDcedit dced32F2Addr;
        private AxDCEDITLib.AxDcedit dced32FacCit;
        private AxDCEDITLib.AxDcedit dced32FacSta;
        private AxDCEDITLib.AxDcedit dced32FacZip;
        private AxDCEDITLib.AxDcedit dced33PhBNam;
        private AxDCEDITLib.AxDcedit dced33Ph1Add;
        private AxDCEDITLib.AxDcedit dced33Ph2Add;
        private AxDCEDITLib.AxDcedit dced33PhCity;
        private AxDCEDITLib.AxDcedit dced33PhStat;
        private AxDCEDITLib.AxDcedit dced33PhyZip;
        private AxDCEDITLib.AxDcedit dced33PhyNPI;
        private AxDCEDITLib.AxDcedit dced33PhyID;
        private System.Windows.Forms.Label lbEPSD;
        private System.Windows.Forms.Label lbReferenceId;
        private System.Windows.Forms.Label lbCOB;
        private AxDCIMAGELib.AxDcimage dcimEPSD;
        private AxDCEDITLib.AxDcedit dcedEPSD;
        private AxDCIMAGELib.AxDcimage dcimCOB;
        private AxDCEDITLib.AxDcedit dcedCOB;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label lbDateFrom;
        private System.Windows.Forms.Label lbPlaceofService;
        private System.Windows.Forms.Label lbTypeofService;
        private System.Windows.Forms.Label lbCPT_Code;
        private System.Windows.Forms.Label lbDiagPointer;
        private System.Windows.Forms.Label lbCharges;
        private System.Windows.Forms.Label lbDays_Units;
        private System.Windows.Forms.Label lbInfo;
        private System.Windows.Forms.Label lbNPI;
        private System.Windows.Forms.Panel panLINEITEM;
        private AxDCIMAGELib.AxDcimage dcimDateFrom;
        private AxDCEDITLib.AxDcedit dcedDateFrom;
        private AxDCIMAGELib.AxDcimage dcimDateThru;
        private AxDCEDITLib.AxDcedit dcedDateThru;
        private AxDCIMAGELib.AxDcimage dcimPlaceofService;
        private AxDCEDITLib.AxDcedit dcedPlaceofService;
        private AxDCIMAGELib.AxDcimage dcimCPT_Code;
        private AxDCEDITLib.AxDcedit dcedCPT_Code;
        private AxDCIMAGELib.AxDcimage dcimModifiers;
        private AxDCEDITLib.AxDcedit dcedModifiers;
        private AxDCIMAGELib.AxDcimage dcimDiagPointer;
        private AxDCEDITLib.AxDcedit dcedDiagPointer;
        private AxDCIMAGELib.AxDcimage dcimCharges;
        private AxDCEDITLib.AxDcedit dcedCharges;
        private AxDCIMAGELib.AxDcimage dcimDays_Units;
        private AxDCEDITLib.AxDcedit dcedDays_Units;
        private AxDCIMAGELib.AxDcimage dcimQualifier;
        private AxDCEDITLib.AxDcedit dcedQualifier;
        private AxDCIMAGELib.AxDcimage dcimNPI;
        private AxDCEDITLib.AxDcedit dcedNPI;
        private AxDCEDITLib.AxDcedit dcedInfo;
        private AxDCIMAGELib.AxDcimage dcimInfo;
        private System.Windows.Forms.Button btnDelpbLINEITEM;
        private System.Windows.Forms.Button btnInsAfterpbLINEITEM;
        private System.Windows.Forms.Button btnInsBeforepbLINEITEM;
        private AxDCIMAGELib.AxDcimage dcimReferenceId;
        private AxDCEDITLib.AxDcedit dcedReferenceId;
        private AxDCIMAGELib.AxDcimage dcimEMG_C;
        private AxDCEDITLib.AxDcedit dcedEMG_C;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private AxDCIMAGELib.AxDcimage dcim7IAddStr;
        private System.Windows.Forms.Label lbl7IAddSta;
        private AxDCEDITLib.AxDcedit dced21_Diag1;
        private AxDCEDITLib.AxDcedit dced21_Diag2;
        private AxDCEDITLib.AxDcedit dced21_Diag3;
        private AxDCEDITLib.AxDcedit dced21_Diag4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnSwapNamesFld2;
        private System.Windows.Forms.Button btnSwapNames4;
        private System.Windows.Forms.Button btnCopyNm2to4;
        private System.Windows.Forms.Button btnCopyNm4to2;
        private System.Windows.Forms.Button btnCopyAdd4to2;
        private System.Windows.Forms.Button btnCopyAdd2to4;
        private System.Windows.Forms.Button btnSwapNm31;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Label lblcopynm;
        private System.Windows.Forms.Label lblCopyAddress;
        private System.Windows.Forms.Label label11;
        private AxDCEDITLib.AxDcedit dced5PAddTel;
        private System.Windows.Forms.Label lblCopyAll;
                        
    }
}
                